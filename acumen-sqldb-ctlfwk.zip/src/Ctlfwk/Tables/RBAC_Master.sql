﻿CREATE TABLE [ctlfwk].[RBAC_Master](
	[RBAC_Master_id] [int] IDENTITY(1,1) NOT NULL,
	[RBAC_Master_code] [varchar](255) NULL,
	[RBAC_Master_desc] [varchar](255) NULL,
	[start_date_time] [datetime] NOT NULL,
	[end_date_time] [datetime] NOT NULL,
	[last_modified_datetime] [datetime2](7) NOT NULL,
	[last_modified_by] [nvarchar](128) NOT NULL,
 CONSTRAINT [RBAC_Master_id_PK] PRIMARY KEY CLUSTERED 
(
	[RBAC_Master_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ctlfwk].[RBAC_Master] ADD  CONSTRAINT [DF_RBAC_Master_start_date_time]  DEFAULT (getdate()) FOR [start_date_time]
GO

ALTER TABLE [ctlfwk].[RBAC_Master] ADD  CONSTRAINT [DF_RBAC_Master_end_date_time]  DEFAULT ('9999-12-31 11:59:59') FOR [end_date_time]
GO

ALTER TABLE [ctlfwk].[RBAC_Master] ADD  CONSTRAINT [DF_RBAC_Master_last_modified_datetime]  DEFAULT (sysdatetime()) FOR [last_modified_datetime]
GO

ALTER TABLE [ctlfwk].[RBAC_Master] ADD  CONSTRAINT [DF_RBAC_Master_last_modified_by]  DEFAULT (original_login()) FOR [last_modified_by]
GO


