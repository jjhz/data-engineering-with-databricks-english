﻿CREATE TABLE ctlfwk.PoolConfigurationDetails
(PoolConfigurationDetailsID INT IDENTITY(1,1) 
,PoolName VARCHAR(MAX)
,PoolId NVARCHAR(MAX)
,[last_modified_datetime] [datetime2](7) NOT NULL CONSTRAINT [DF_PoolConfigurationDetails_Last_Modified_Datetime]  DEFAULT (sysdatetime())
,[last_modified_by] [sysname] NOT NULL CONSTRAINT [DF_PoolConfigurationDetails_Last_Modified_By]  DEFAULT (original_login())
,[cluster_type] [varchar](100)
,CONSTRAINT [PoolConfigurationDetails_PK] PRIMARY KEY CLUSTERED ([PoolConfigurationDetailsID] ASC)

)