﻿CREATE TABLE [ctlfwk].[SourceSystemDatabaseName](
	[SourceSystemDatabaseName_ID] [int] IDENTITY(1,1) NOT NULL,
	[SourceSystemDatabaseName] [varchar](100) NOT NULL,
	[last_modified_datetime] [datetime2](7) NOT NULL CONSTRAINT [DF_SourceSystemDatabaseName_Last_Modified_Datetime]  DEFAULT (sysdatetime()),
	[last_modified_by] [sysname] NOT NULL  CONSTRAINT [DF_SourceSystemDatabaseName_Last_Modified_By]  DEFAULT (original_login()),
 CONSTRAINT [SourceSystemDatabaseName_ID_PK] PRIMARY KEY CLUSTERED ([SourceSystemDatabaseName_ID] ASC ),
 CONSTRAINT [SourceSystemDatabaseName_UQ] UNIQUE NONCLUSTERED ([SourceSystemDatabaseName_ID] ASC)
 )
