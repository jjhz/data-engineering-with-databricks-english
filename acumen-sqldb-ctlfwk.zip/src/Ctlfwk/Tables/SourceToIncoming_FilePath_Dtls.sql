﻿CREATE TABLE [ctlfwk].[SourceToIncoming_FilePath_Dtls](
	[SourceToIncoming_FilePath_Dtls_ID] [int] IDENTITY(1,1) NOT NULL,
	[source_app_id] [int] NOT NULL,
	[source_object_id] [int] NOT NULL,
	[load_type_id] [int] NULL,
	[source_file_path] [varchar](200) NOT NULL,
	[start_date_time] [datetime] NULL,
	[end_date_time] [datetime] NULL,
	[last_modified_datetime_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([last_modified_datetime])),
	[last_modified_datetime] [datetime2](7) NOT NULL,
	[last_modified_by] [sysname] NOT NULL,
 CONSTRAINT [SourceToIncoming_FilePath_Dtls_ID_PK] PRIMARY KEY CLUSTERED 
(
	[SourceToIncoming_FilePath_Dtls_ID] ASC
)
) ON [PRIMARY]
GO

ALTER TABLE [ctlfwk].[SourceToIncoming_FilePath_Dtls] ADD  CONSTRAINT [DF_SourceToIncomingFilePathDtls_Last_Modified_Datetime]  DEFAULT (sysdatetime()) FOR [last_modified_datetime]
GO

ALTER TABLE [ctlfwk].[SourceToIncoming_FilePath_Dtls] ADD  CONSTRAINT [DF_SourceToIncomingFilePathDtls_Last_Modified_By]  DEFAULT (original_login()) FOR [last_modified_by]
GO
