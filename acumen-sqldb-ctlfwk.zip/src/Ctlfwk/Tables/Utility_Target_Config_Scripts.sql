﻿CREATE TABLE [Ctlfwk].[Utility_Target_Config_Scripts](
	[utility_target_row_num] [int] NULL,
	[script_seq] [int] NULL,
	[utility_target_exec_script] [varchar](max) NULL,
	[input_filename] [varchar](200) NULL,
	[last_modified_datetime] [datetime2](7) NOT NULL CONSTRAINT [DF_UtilityTargetConfigScripts_Last_Modified_Datetime]  DEFAULT (sysdatetime()),
	[last_modified_datetime_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([last_modified_datetime])),
	[last_modified_by] [sysname] NOT NULL CONSTRAINT [DF_UtilityTargetConfigScripts_Last_Modified_By]  DEFAULT (original_login())
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]