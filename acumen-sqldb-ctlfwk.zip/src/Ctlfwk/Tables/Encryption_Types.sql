﻿CREATE TABLE [ctlfwk].[Encryption_Types](
	[Encryption_TypeID] [int] IDENTITY(1,1) NOT NULL,
	[Encryption_Type] [varchar](10) NOT NULL,
	[Encryption_Name] [varchar](100) NOT NULL,
	[last_modified_datetime] [datetime2](7) NOT NULL CONSTRAINT [DF_EncryptionTypes_Last_Modified_Datetime]  DEFAULT (sysdatetime()),
	[last_modified_by] [sysname] NOT NULL CONSTRAINT [DF_EncryptionTypes_Last_Modified_By]  DEFAULT (original_login()),
   CONSTRAINT [Encryption_TypeID_PK] PRIMARY KEY CLUSTERED ([Encryption_TypeID] ASC),
   CONSTRAINT [Encryption_Type_Encryption_Type_UQ] UNIQUE NONCLUSTERED ([Encryption_TypeID] ASC),
   )