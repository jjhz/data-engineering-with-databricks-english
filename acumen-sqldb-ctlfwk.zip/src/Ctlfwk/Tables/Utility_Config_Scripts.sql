﻿CREATE TABLE [ctlfwk].[Utility_Config_Scripts](
	[utility_row_num] [int] NULL,
	[script_seq] [int] NULL,
	[utility_exec_script] [varchar](max) NULL,
	[input_filename] VARCHAR (200) NULL,
	[last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_UtilityConfigScripts_Last_Modified_Datetime DEFAULT SYSDATETIME(),
	[last_modified_datetime_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([last_modified_datetime])),
	[last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_UtilityConfigScripts_Last_Modified_By DEFAULT ORIGINAL_LOGIN()
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

