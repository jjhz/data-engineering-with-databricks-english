﻿CREATE TABLE [ctlfwk].[business_unit] (
    [business_unit_id]        INT           IDENTITY (1, 1) NOT NULL,
    [business_unit_name]      VARCHAR (100) NULL,
    [business_unit_name_code] VARCHAR (7)   NULL,
    [start_date_time]         DATETIME      CONSTRAINT [Business_Unit_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]           DATETIME      CONSTRAINT [Business_Unit_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
    [storage_account]         VARCHAR (100) NULL,
    [storage_secret_name]     VARCHAR(100)  NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_BusinessUnit_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_BusinessUnit_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    CONSTRAINT [business_unit_business_unit_PK] PRIMARY KEY CLUSTERED ([business_unit_id] ASC),
    CONSTRAINT [business_unit_business_unit_Name_Code_UQ] UNIQUE NONCLUSTERED ([business_unit_name_code] ASC)
);

