CREATE TABLE ctlfwk.process_errors
( process_error_id  INT IDENTITY (1,1) NOT NULL 
,error_flag				VARCHAR(100) NULL
,error_description		VARCHAR(4000) NULL
,additional_data		NVARCHAR(400) NULL
,processing_module		VARCHAR(500) NULL    
,last_modified_datetime  DATETIME2(7) NOT NULL CONSTRAINT DF_ProcessErrors_Last_Modified_Datetime DEFAULT SYSDATETIME()
,last_modified_datetime_aet  AS ([CtlFwk].[fn_ConverttoAETTime]([last_modified_datetime]))
,last_modified_by SYSNAME NOT NULL CONSTRAINT DF_ProcessErrors_Last_Modified_By DEFAULT ORIGINAL_LOGIN()
)