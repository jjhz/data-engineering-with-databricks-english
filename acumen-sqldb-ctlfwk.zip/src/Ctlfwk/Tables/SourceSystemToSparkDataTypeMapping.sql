
CREATE TABLE [Ctlfwk].[SourceSystemToSparkDataTypeMapping](
	[SourceSystemToSparkDataTypeMappingID] [int] IDENTITY(1,1) NOT NULL,
	[DataSource] [varchar](100) NOT NULL,
	[DataType] [varchar](100) NOT NULL,
	[SparkSQLDatatype] [varchar](100) NULL,
	[IsDateWithTimezone] [varchar](1) NOT NULL,
	[last_modified_datetime] [datetime2](7) NOT NULL CONSTRAINT [DF_SourceSystemToSparkDataTypeMapping_last_modified_datetime]  DEFAULT (sysdatetime())  ,
	[last_modified_by] [sysname] NOT NULL CONSTRAINT [DF_SourceSystemToSparkDataTypeMapping_last_modified_by]  DEFAULT (original_login())  ,
	CONSTRAINT [SourceSystemToSparkDataTypeMappingID_PK] PRIMARY KEY CLUSTERED ([SourceSystemToSparkDataTypeMappingID] ASC),
	CONSTRAINT [DatabaseType_DataType_UQ] UNIQUE NONCLUSTERED (
																[DataSource] ASC,
																[DataType] ASC
															  )
)
