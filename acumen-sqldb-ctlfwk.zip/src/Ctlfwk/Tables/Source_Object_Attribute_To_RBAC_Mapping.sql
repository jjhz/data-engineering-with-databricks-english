﻿CREATE TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping](
	[Source_Object_Attribute_To_RBAC_Mapping_id] [int] IDENTITY(1,1) NOT NULL,
	[Source_Object_ID] [int] NULL,
	[Source_Object_Attribute_Name] [varchar](100) NULL,
	[RBAC_ID] [int] NULL,
	[start_date_time] [datetime] NOT NULL,
	[end_date_time] [datetime] NOT NULL,
	[last_modified_datetime] [datetime2](7) NOT NULL,
	[last_modified_by] [nvarchar](128) NOT NULL,
 CONSTRAINT [Source_Object_Attribute_To_RBAC_Mapping_id_PK] PRIMARY KEY CLUSTERED 
(
	[Source_Object_Attribute_To_RBAC_Mapping_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] ADD  CONSTRAINT [DF_Source_Object_Attribute_To_RBAC_Mapping_start_date_time]  DEFAULT (getdate()) FOR [start_date_time]
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] ADD  CONSTRAINT [DF_Source_Object_Attribute_To_RBAC_Mapping_end_date_time]  DEFAULT ('9999-12-31 11:59:59') FOR [end_date_time]
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] ADD  CONSTRAINT [DF_Source_Object_Attribute_To_RBAC_Mapping_last_modified_datetime]  DEFAULT (sysdatetime()) FOR [last_modified_datetime]
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] ADD  CONSTRAINT [DF_Source_Object_Attribute_To_RBAC_Mapping_last_modified_by]  DEFAULT (original_login()) FOR [last_modified_by]
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping]  WITH CHECK ADD  CONSTRAINT [FK_RBAC_ID] FOREIGN KEY([RBAC_ID])
REFERENCES [ctlfwk].[RBAC_Master] ([RBAC_Master_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] CHECK CONSTRAINT [FK_RBAC_ID]
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping]  WITH CHECK ADD  CONSTRAINT [FK_Source_Objects_Attribute_ID] FOREIGN KEY([Source_Object_ID], [Source_Object_Attribute_Name])
REFERENCES [ctlfwk].[source_objects_attributes] ([source_object_id], [source_object_attribute_name])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] CHECK CONSTRAINT [FK_Source_Objects_Attribute_ID]
GO


