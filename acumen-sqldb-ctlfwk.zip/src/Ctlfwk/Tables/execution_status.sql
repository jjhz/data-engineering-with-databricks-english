﻿CREATE TABLE [ctlfwk].[execution_status] (
    [execution_status_id]   INT          IDENTITY (1, 1) NOT NULL,
    [execution_status_name] VARCHAR (10) NULL,
    [start_date_time]       DATETIME     CONSTRAINT [Execution_Status_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]         DATETIME     CONSTRAINT [Execution_Status_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_ExecutionStatus_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_ExecutionStatus_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    CONSTRAINT [execution_status_execution_status_id_PK] PRIMARY KEY CLUSTERED ([execution_status_id] ASC),
     CONSTRAINT [UQ_ctlfwk_ExecutionStatus_ExecutionStatusName] UNIQUE NONCLUSTERED ([execution_status_name])
);

