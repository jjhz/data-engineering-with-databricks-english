﻿CREATE TABLE [ctlfwk].[source_objects_attributes] (
    [source_object_id]                                    INT           NOT NULL,
    [source_object_attribute_name]                        VARCHAR (100) NULL,
    [source_object_attribute_seq]                         INT           NULL,
    [source_object_attribute_data_type]                   VARCHAR (50)  NULL,
    [source_object_attribute_precision]                   VARCHAR (10)  NULL,
	[source_object_attribute_scale]                       VARCHAR (10) NULL,
    [source_object_attribute_is_null]                     VARCHAR (1)   NULL,
    [source_object_attribute_is_pk]                       VARCHAR (1)   NULL,
    [source_object_attribute_is_BusinessKey]              VARCHAR (1)   NULL,
    [source_object_attribute_is_PII]                      VARCHAR (1)   NULL,
    [source_object_attribute_is_historystitch]            VARCHAR (1)   NULL,
    [source_object_attribute_is_iud_column]               VARCHAR (1)   NULL,
    [source_object_attribute_is_historystitch_sortkey]    VARCHAR (1)   NULL,
    [input_formatstring]                                  VARCHAR (100)  NULL,
    [dynamic_masking_function]                            VARCHAR (500) NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_SourceObjectsAttributes_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_SourceObjectsAttributes_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    [source_time_zone] [varchar](50) NULL,
	[Encryption_TypeID]                                       INT       NULL,
    [default_value_if_not_nullable]                       VARCHAR (500) NULL,
    [DataFormat]                                          vARCHAR(50) NULL,
    [extraction_custom_logic_id] int NULL,
   -- CONSTRAINT [source_objects_attributes_source_object_id_FK] FOREIGN KEY ([source_object_id]) REFERENCES [ctlfwk].[source_objects] ([source_object_id]),
   -- CONSTRAINT [source_objects_attributes_Encryption_TypeID_FK] FOREIGN KEY([Encryption_TypeID]) REFERENCES [ctlfwk].[Encryption_Types] ([Encryption_TypeID]),
    CONSTRAINT [SourceObjectId_SourceAttributeName_UQ] UNIQUE NONCLUSTERED ([source_object_id]  ,	[source_object_attribute_name]  )
);



