﻿CREATE TABLE [ctlfwk].[target_objects] (
    [target_object_id]          INT            IDENTITY (1, 1) NOT NULL,
    [target_object_name]        VARCHAR (100)  NULL,
    [target_object_description] VARCHAR (1000)  NULL,
    [Schema_Name]               VARCHAR (50)  NULL,
    [load_type_id]              INT            NULL,
    [source_app_id]             INT            NULL,
    [start_date_time]           DATETIME       CONSTRAINT [Target_Objects_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]             DATETIME       CONSTRAINT [Target_Objects_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
    [notebook_name]             VARCHAR(255)   NULL,
	[notebook_path]             NVARCHAR(255)  NULL,
	[synapse_distribution_type] VARCHAR(max)   NULL,
    [synapse_override]          VARCHAR(max)   NULL,
	[Input_Source_Type]         VARCHAR(30)    NULL,
    [replication_type]          VARCHAR(20)    NULL,
    [last_modified_datetime]    DATETIME2(7)   CONSTRAINT [DF_TargetObjects_Last_Modified_Datetime]  DEFAULT (sysdatetime()) NULL,
	[last_modified_by]          NVARCHAR(128) CONSTRAINT [DF_TargetObjects_Last_Modified_By]  DEFAULT (original_login()) NULL,
    CONSTRAINT [target_object_target_object_id_PK] PRIMARY KEY CLUSTERED ([target_object_id] ASC),
    CONSTRAINT [TargetObjectName_NotebookPath_NotebookName_UQ] UNIQUE NONCLUSTERED ([target_object_name] ASC, [schema_name] ASC, [notebook_path] ASC, [notebook_name] ASC),
    CONSTRAINT [target_objects_source_app_id_FK] FOREIGN KEY([source_app_id]) REFERENCES [Ctlfwk].[source_app] ([source_app_id]),
    CONSTRAINT [target_objects_load_type_id_FK] FOREIGN KEY ([load_type_id]) REFERENCES [ctlfwk].[load_types] ([load_type_id])
);

