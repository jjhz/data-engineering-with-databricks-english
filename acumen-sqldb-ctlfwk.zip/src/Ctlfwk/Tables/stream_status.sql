﻿CREATE TABLE [ctlfwk].[stream_status] (
    [stream_status_id]    INT      IDENTITY (1, 1) NOT NULL,
    [stream_id]           INT      NULL,
    [execution_status_id] INT      NULL,
    [start_date_time]     DATETIME NULL,
    [end_date_time]       DATETIME NULL,
	[start_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([start_date_time])),
	[end_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([end_date_time])),
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_StreamStatus_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_StreamStatus_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    CONSTRAINT [stream_status_stream_status_id_PK] PRIMARY KEY CLUSTERED ([stream_status_id] ASC),
    CONSTRAINT [stream_status_stream_id_FK] FOREIGN KEY ([stream_id]) REFERENCES [ctlfwk].[stream] ([stream_id])
);

