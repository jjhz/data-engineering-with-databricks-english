﻿CREATE TABLE [ctlfwk].[Source_To_Target_Mapping] (
    [Source_To_Target_Mapping_ID] INT            NOT NULL,
    [Target_Object_ID]            INT            NOT NULL,
    [Target_Schema]               VARCHAR (100)  NOT NULL,
    [Target_Object]               VARCHAR (100)  NOT NULL,
    [Target_Object_Type]          VARCHAR (100)  NOT NULL,
    [Source_Object_ID]            INT            NOT NULL,
    [Source_Schema]               VARCHAR (100)  NOT NULL,
    [Source_Object]               VARCHAR (100)  NOT NULL,
    [Source_BK_Column_Sequence]   INT            NOT NULL,
    [Source_BK_Column]            VARCHAR (500)  NOT NULL,
    [Query_Filter]                VARCHAR (4000) NULL,
    [Truncate_Flag]               CHAR (1)       NULL,
    [Hash_key_Name]               VARCHAR (100)  NULL,
    [Key_Source_Name]             VARCHAR (40)   NULL,
    [Load_Type]                   VARCHAR (10)   NULL,
    [Change_Detection_Column]     VARCHAR (100)  NOT NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_SourceToTargetMapping_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_SourceToTargetMapping_Last_Modified_By DEFAULT ORIGINAL_LOGIN()
);


GO


