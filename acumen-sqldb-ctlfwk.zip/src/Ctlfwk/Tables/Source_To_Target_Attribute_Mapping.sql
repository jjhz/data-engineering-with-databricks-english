﻿

CREATE TABLE [Ctlfwk].[Source_To_Target_Attribute_Mapping]
(
	[Source_To_Target_Mapping_ID] [int] NOT NULL,
	[Target_Object_ID] [int] NOT NULL,
	[Target_Schema] [varchar](100) NOT NULL,
	[Target_Object] [varchar](100) NOT NULL,
	[Target_Attribute_Name] [varchar](100) NOT NULL,
	[Target_Object_Type] [varchar](100) NOT NULL,
	[Source_Object_ID] [int] NOT NULL,
	[Source_Schema] [varchar](100) NOT NULL,
	[Source_Object] [varchar](100) NOT NULL,
	[Source_Attribute_Name] [varchar](100) NOT NULL,
	[Column_Sequence] [int] NOT NULL,
	[Attribute_IS_BK] [char](1) NULL,
	[last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_SourceToTargetAttributeMapping_Last_Modified_Datetime DEFAULT SYSDATETIME(),
	[last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_SourceToTargetAttributeMapping_Last_Modified_By DEFAULT ORIGINAL_LOGIN()
)

GO


