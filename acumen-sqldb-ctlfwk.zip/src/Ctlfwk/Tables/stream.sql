﻿CREATE TABLE [ctlfwk].[stream] (
    [stream_id]          INT           IDENTITY (1, 1) NOT NULL,
    [stream_name]        VARCHAR (255)  NULL,
    [stream_description] VARCHAR (255) NULL,
    [source_app_id]      INT           NULL,
    [start_date_time]    DATETIME      CONSTRAINT [Stream_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]      DATETIME      CONSTRAINT [Stream_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
	[start_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([start_date_time])),
	[end_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([end_date_time])),
    [restart_from_beginning] [bit] NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_Stream_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_Stream_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    CONSTRAINT [stream_stream_id_PK] PRIMARY KEY CLUSTERED ([stream_id] ASC),
    CONSTRAINT [StreamName_UQ] UNIQUE NONCLUSTERED (stream_name ),
    CONSTRAINT [stream_source_app_id_FK] FOREIGN KEY ([source_app_id]) REFERENCES [ctlfwk].[source_app] ([source_app_id])
);

