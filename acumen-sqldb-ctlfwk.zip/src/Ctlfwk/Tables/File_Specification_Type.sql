
CREATE TABLE [Ctlfwk].[File_Specification_Type](
	[File_Specification_Type_Id] [int] IDENTITY(1,1) NOT NULL,
	[File_Pattern_Name] [varchar](100) NOT NULL,
	[Has_Header] [varchar](1) NULL,
	[File_Extension_Type] [varchar](50) NOT NULL,
	[Field_Delimiter] [varchar](5) NULL,
	[TimeStamp_Filename_Pattern] [varchar](50) NOT NULL,
	[TimeStamp_Filename_RegexPattern] [varchar](100) NOT NULL,
	[Last_Modified_Date_time] [datetime2](7) NOT NULL CONSTRAINT [DF_FileSpecificationType_Last_Modified_Datetime]  DEFAULT (sysdatetime())  ,
	[last_modified_by] [sysname] NOT NULL CONSTRAINT [DF_FileSpecificationType_Last_Modified_By]  DEFAULT (original_login())  ,
	[File_Encoding] [varchar](100) NULL,
	[Escape_Character] [char](1) NULL,
	[Contains_Multiline_Data] [varchar](1) NULL,
 CONSTRAINT [File_Specification_Type_Id_PK] PRIMARY KEY CLUSTERED 
(
	[File_Specification_Type_Id] ASC
)
)