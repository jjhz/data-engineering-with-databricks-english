﻿CREATE TABLE [ctlfwk].[process_parameters] (
    [process_parameters_id] INT            IDENTITY (1, 1) NOT NULL,
    [process_id]            INT            NOT NULL,
    [parameter_name]        VARCHAR (100)  NULL,
    [parameter_value]       VARCHAR (1000) NULL,
    CONSTRAINT [Process_Parameters_Process_Parameters_ID_PK] PRIMARY KEY CLUSTERED ([process_parameters_id] ASC)
);

