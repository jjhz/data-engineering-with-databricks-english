﻿CREATE TABLE  [ctlfwk].[extraction_custom_logic]
(
	[extraction_custom_logic_id] [int] IDENTITY(1,1) NOT NULL,
	[extraction_custom_logic_code] [varchar](20) NULL,
	[extraction_custom_logic_desc] [varchar](255) NULL,
	[start_date_time] [datetime] NULL,
	[end_date_time] [datetime] NULL,
	[last_modified_datetime] [datetime2](7) NOT NULL CONSTRAINT DF_extraction_custom_logic_last_modified_datetime DEFAULT (original_login()),
	[last_modified_by] [nvarchar](128) NOT NULL CONSTRAINT DF_extraction_custom_logic_last_modified_by DEFAULT (original_login()),
	CONSTRAINT extraction_custom_logic_id_PK PRIMARY KEY CLUSTERED ([extraction_custom_logic_id] ASC)
)
