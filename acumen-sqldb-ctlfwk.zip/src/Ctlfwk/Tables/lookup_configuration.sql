﻿CREATE TABLE [ctlfwk].[lookup_configuration] (
    [lookup_configuration_id] INT           IDENTITY (1, 1) NOT NULL,
    [TargetDBName]            VARCHAR (100) NULL,
    [TargetTableName]         VARCHAR (100) NULL,
    [LookupDBName]            VARCHAR (100) NULL,
    [LookupTableName]         VARCHAR (100) NULL,
    [SourceDBName]            VARCHAR (100) NULL,
    [SourceTableName]         VARCHAR (250) NULL,
    [KeymapDBName]            VARCHAR (100) NULL,
    [KeymapTableName]         VARCHAR (100) NULL,
    [lookUpKey]               VARCHAR (250) NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_LookupConfigurations_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_LookupConfigurations_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    CONSTRAINT [lookup_configuration_id_PK] PRIMARY KEY CLUSTERED ([lookup_configuration_id] ASC)
);

