﻿CREATE TABLE [ctlfwk].[load_types] (
    [load_type_id]          INT          IDENTITY (1, 1) NOT NULL,
    [load_type_code]        VARCHAR (5)  NULL,
    [load_type_description] VARCHAR (30) NULL,
    [start_date_time]       DATETIME     CONSTRAINT [Load_Types_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]         DATETIME     CONSTRAINT [Load_Types_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_LoadTypes_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_LoadTypes_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    CONSTRAINT [load_types_load_type_id_PK] PRIMARY KEY CLUSTERED ([load_type_id] ASC),
    CONSTRAINT [load_types_load_type_code_UQ] UNIQUE NONCLUSTERED ([load_type_code] ASC)
);

