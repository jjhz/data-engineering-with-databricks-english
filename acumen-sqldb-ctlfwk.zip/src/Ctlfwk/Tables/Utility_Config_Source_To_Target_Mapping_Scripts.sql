﻿CREATE TABLE [ctlfwk].[Utility_Config_Source_To_Target_Mapping_Scripts] (
    [utility_exec_script] VARCHAR (MAX) NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_UtilityConfigSourceToTargetMappingScripts_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_UtilityConfigSourceToTargetMappingScripts_Last_Modified_By DEFAULT ORIGINAL_LOGIN()
);

