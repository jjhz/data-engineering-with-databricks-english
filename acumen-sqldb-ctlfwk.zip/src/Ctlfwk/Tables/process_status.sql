﻿CREATE TABLE [ctlfwk].[process_status] (
    [process_status_id]   INT      IDENTITY (1, 1) NOT NULL,
    [process_id]          INT      NULL,
    [execution_status_id] INT      NULL,
    [start_date_time]     DATETIME NULL,
    [end_date_time]       DATETIME NULL,
	[start_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([start_date_time])),
	[end_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([end_date_time])),
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_ProcessStatus_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_ProcessStatus_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    [data_doc_link] [nvarchar](max) NULL,
    [src_file_count] VARCHAR(200) NULL,
    Is_restart_from_monitor VARCHAR(50) NULL,
    CONSTRAINT [process_status_process_status_id_PK] PRIMARY KEY CLUSTERED ([process_status_id] ASC),
    CONSTRAINT [process_status_process_id_FK] FOREIGN KEY ([process_id]) REFERENCES [ctlfwk].[process] ([process_id])
);

