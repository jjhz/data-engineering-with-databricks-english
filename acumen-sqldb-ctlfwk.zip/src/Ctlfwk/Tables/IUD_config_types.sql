﻿CREATE TABLE [ctlfwk].[IUD_config_types](
	[config_type_id] [int] IDENTITY (1,1) NOT NULL,
	[config_type] [varchar](50) NOT NULL,
	[config_type_description] [varchar](100) NULL,
	[last_modified_datetime] datetime2(7) NOT NULL,
	[last_modified_by] [varchar](100) NOT NULL,

 CONSTRAINT [config_id_PK] PRIMARY KEY CLUSTERED 
(
	[config_type_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
