﻿CREATE TABLE [ctlfwk].[source_app] (
    [source_app_id]    INT           IDENTITY (1, 1) NOT NULL,
    [source_app_name]  VARCHAR (100) NULL,
    [source_app_code]  VARCHAR (25)   NULL,
    [business_unit_id] INT           NULL,
    [start_date_time]  DATETIME      CONSTRAINT [source_app_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]    DATETIME      CONSTRAINT [source_app_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
    [retention_days]   INT           NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_SourceApp_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_SourceApp_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    [SourceSystemDatabaseName_ID] [int] NULL,
    [IUD_config_id] [varchar](10) NULL,
    CONSTRAINT [source_app_source_app_id_PK] PRIMARY KEY CLUSTERED ([source_app_id] ASC),
    CONSTRAINT [source_app_buniess_unit_id_FK] FOREIGN KEY ([business_unit_id]) REFERENCES [ctlfwk].[business_unit] ([business_unit_id]) ,
    CONSTRAINT [SourceAppCode_UQ] UNIQUE NONCLUSTERED ([source_app_code]   ),
    CONSTRAINT [SourceSystemDatabaseName_ID_FK] FOREIGN KEY([SourceSystemDatabaseName_ID]) REFERENCES [Ctlfwk].[SourceSystemDatabaseName] ([SourceSystemDatabaseName_ID])
);

