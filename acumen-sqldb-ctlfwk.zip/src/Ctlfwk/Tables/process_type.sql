﻿CREATE TABLE [ctlfwk].[process_type] (
    [process_type_id] INT          IDENTITY (1, 1) NOT NULL,
    [process_type]    VARCHAR (20) NULL,
    [start_date_time] DATETIME     CONSTRAINT [Process_Type_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]   DATETIME     CONSTRAINT [Process_Type_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_ProcessType_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_ProcessType_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    CONSTRAINT [process_type_process_type_id_PK] PRIMARY KEY CLUSTERED ([process_type_id] ASC),
    CONSTRAINT [UQ_ctlfwk_ProcessType_ProcessType] UNIQUE NONCLUSTERED ([process_type] ASC)
);

