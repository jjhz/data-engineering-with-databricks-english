﻿CREATE TABLE [ctlfwk].[source_objects] (
    [source_object_id]          INT           IDENTITY (1, 1) NOT NULL,
    [source_object_name]        VARCHAR (100) NULL,
    [source_object_description] VARCHAR (1000) NULL,
    [Schema_Name] VARCHAR(50) NULL , 
    [load_type_id]              INT           NULL,
    [start_date_time]           DATETIME      CONSTRAINT [Source_Objects_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]             DATETIME      CONSTRAINT [Source_Objects_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
    [source_app_id]             INT           NULL,
    [is_file_mandatory]         bit           NULL,
	[last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_SourceObjects_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_SourceObjects_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    [File_Specification_Type_Id] INT NULL,
    [detect_hard_deletes] [bit] NULL,
    CONSTRAINT [source_object_source_object_id_PK] PRIMARY KEY CLUSTERED ([source_object_id] ASC),
    CONSTRAINT [source_objects_load_type_id_FK] FOREIGN KEY ([load_type_id]) REFERENCES [ctlfwk].[load_types] ([load_type_id]),
    CONSTRAINT [source_objects_source_app_id_FK] FOREIGN KEY ([source_app_id]) REFERENCES [ctlfwk].[source_app] ([source_app_id]),
    CONSTRAINT [File_Specification_Type_Id_FK] FOREIGN KEY([File_Specification_Type_Id]) REFERENCES [ctlfwk].[File_Specification_Type] ([File_Specification_Type_Id]),
    CONSTRAINT [SourceObjects_SourceObjectName_SourceAppID_UQ] UNIQUE NONCLUSTERED ([source_object_name] ,	[source_app_id] )
);

