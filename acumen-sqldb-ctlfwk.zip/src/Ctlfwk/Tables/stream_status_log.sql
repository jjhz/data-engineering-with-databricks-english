﻿CREATE TABLE [ctlfwk].[stream_status_log] (
    [stream_status_id]    INT      NULL,
    [stream_id]           INT      NULL,
    [execution_status_id] INT      NULL,
    [start_date_time]     DATETIME NULL,
    [end_date_time]       DATETIME NULL,
    [start_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([start_date_time])),
	[end_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([end_date_time])),
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_StreamStatusLog_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_StreamStatusLog_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
);

