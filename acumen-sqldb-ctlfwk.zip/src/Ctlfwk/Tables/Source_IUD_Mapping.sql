﻿CREATE TABLE [ctlfwk].[Source_IUD_Mapping](
	[config_IUD_type_id] [int] IDENTITY(1,1) NOT NULL,
	[config_id] [int] NOT NULL,
	[record_type_id] [int] NOT NULL,
	[record_type_name] [varchar](10) NULL,
	[record_type_description] [varchar](50) NULL,
	[source_CDC_record_type_value] [varchar](50) NULL,
 CONSTRAINT [config_IUD_type_id_PK] PRIMARY KEY CLUSTERED 
(
	[config_IUD_type_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO