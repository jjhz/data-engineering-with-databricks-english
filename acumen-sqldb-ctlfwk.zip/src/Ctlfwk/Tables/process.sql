﻿CREATE TABLE [ctlfwk].[process] (
    [process_id]               INT           IDENTITY (1, 1) NOT NULL,
    [process_name]             VARCHAR (200) NULL,
    [process_name_description] VARCHAR (100) NULL,
    [is_enabled]               VARCHAR (1)   DEFAULT ('Y') NULL,
    [stream_id]                INT           NULL,
    [process_type_id]          INT           NULL,
    [source_object_id]         INT           NULL,
    [target_object_id]         INT           NULL,
    [start_date_time]          DATETIME      CONSTRAINT [Process_Start_Date_Time_Default] DEFAULT (getdate()) NULL,
    [end_date_time]            DATETIME      CONSTRAINT [Process_Unit_End_Date_Time_Default] DEFAULT ('9999-12-31 00:00:00.000') NULL,
	[start_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([start_date_time])),
	[end_date_time_aet]  AS ([CtlFwk].[fn_ConverttoAETTime]([end_date_time])),
    [last_modified_datetime] DATETIME2(7) NOT NULL CONSTRAINT DF_Process_Last_Modified_Datetime DEFAULT SYSDATETIME(),
    [last_modified_by] SYSNAME NOT NULL CONSTRAINT DF_Process_Last_Modified_By DEFAULT ORIGINAL_LOGIN(),
    PoolConfigurationDetailsID INT NULL ,
    NoOfWorkers INT NULL
    CONSTRAINT [process_process_id_PK] PRIMARY KEY CLUSTERED ([process_id] ASC),
    CONSTRAINT [Process_Name_UQ] UNIQUE NONCLUSTERED ([process_name]),
    CONSTRAINT [process_process_type_id_FK] FOREIGN KEY ([process_type_id]) REFERENCES [ctlfwk].[process_type] ([process_type_id]),
    CONSTRAINT [process_source_object_id_FK] FOREIGN KEY ([source_object_id]) REFERENCES [ctlfwk].[source_objects] ([source_object_id]),
    CONSTRAINT [process_stream_id_FK] FOREIGN KEY ([stream_id]) REFERENCES [ctlfwk].[stream] ([stream_id]),
    CONSTRAINT [process_target_object_id_FK] FOREIGN KEY ([target_object_id]) REFERENCES [ctlfwk].[target_objects] ([target_object_id])
);

