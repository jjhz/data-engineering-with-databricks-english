﻿
/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte 				 1.0				InitialVersion
	17-12-2021						Sheela R				 1.1				Added Data Doc Link,src_file_count,Is_restart_from_monitor
 ================================================================================================= */ 


CREATE VIEW [Ctlfwk].[vw_process_status_log]
AS
SELECT
	pslg.process_status_id,
	p.process_id,
	p.process_name,
	pslg.execution_status_id,
	es.execution_status_name,
	pslg.start_date_time,
	pslg.end_date_time,
	pslg.data_doc_link,
	pslg.src_file_count,
	pslg.Is_restart_from_monitor 
	 

FROM
	ctlfwk.process_status_log pslg
INNER JOIN
	ctlfwk.process p
ON
	pslg.process_id = p.process_id
INNER JOIN
	ctlfwk.execution_status es
ON
	pslg.execution_status_id = es.execution_status_id

 