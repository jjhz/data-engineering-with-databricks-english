﻿
CREATE VIEW [ctlfwk].[vw_Source_to_BU_Storage_Account] 
/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	19-01-2022						Tammy H					 1.0				Initial Version
	07-04-2022						Vikas p 				 1.1				Added Replication_type
    07-04-2022						Vikas p 				 1.2				Added SourceAppname
 ================================================================================================= */

AS
Select 
DISTINCT
sa.source_app_name as source_app_name,
so.source_object_name AS source_object_name, 
bu.business_unit_name_code AS business_unit_name_code, 
bu.storage_account  AS storage_account,
bu.storage_secret_name AS storage_secret_name
from [ctlfwk].[source_objects] so
INNER JOIN [ctlfwk].[source_app] sa
ON so.source_app_id = sa.source_app_id
INNER JOIN [ctlfwk].[business_unit] bu
ON sa.business_unit_id = bu.business_unit_id
where so.end_date_time = '9999-12-31 00:00:00.000'
And sa.end_date_time = '9999-12-31 00:00:00.000'
And bu.end_date_time = '9999-12-31 00:00:00.000'


GO


