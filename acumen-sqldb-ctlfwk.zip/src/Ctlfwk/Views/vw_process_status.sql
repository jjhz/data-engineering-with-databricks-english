﻿/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte 				 1.0				InitialVersion
	22-11-2021						Vikas P					 1.1				Added data_doc_link and  src_file_count
	05-04-2022                      Sheela R                 1.2                Adding aet date
 ================================================================================================= */
CREATE VIEW [Ctlfwk].[vw_process_status]
AS
SELECT
	ps.process_status_id,
	ps.process_id,
	p.process_name,
	ps.execution_status_id,
	es.execution_status_name,
	ps.start_date_time,
	ps.end_date_time,
	ps.data_doc_link,
	ps.src_file_count,
	ps.Is_restart_from_monitor,
	ps.start_date_time_aet,
	ps.end_date_time_aet
FROM
	Ctlfwk.process_status ps
INNER JOIN
	Ctlfwk.process P
ON
	ps.process_id = p.process_id
INNER JOIN
	Ctlfwk.execution_status es
ON
	ps.execution_status_id = es.execution_status_id
