﻿CREATE VIEW [ctlfwk].[vw_Source_To_Target_Mapping]
AS
SELECT 
	Source_To_Target_Mapping_ID
	,Target_Object_ID
	,Target_Schema
	,Target_Object
	,Target_Object_Type
	,Source_Object_ID
	,Source_Schema
	,Source_Object
	,Source_BK_Column_Sequence
	,Source_BK_Column
	,Query_Filter
	,Truncate_Flag
	,Hash_key_Name
	,Key_Source_Name
	,Load_type
	,Change_Detection_Column
FROM
	[Ctlfwk].[Source_To_Target_Mapping]
GO


