﻿CREATE VIEW [ctlfwk].[vw_business_unit] 
AS
SELECT 
	business_unit_id,
	business_unit_name,
	business_unit_name_code as business_unit_code,
	start_date_time,
	end_date_time,
	storage_secret_name
FROM
	ctlfwk.business_unit
WHERE
	end_date_time = '9999-12-31 00:0:00.000'

