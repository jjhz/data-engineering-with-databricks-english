﻿
CREATE VIEW [Ctlfwk].[vw_source_app]
AS
SELECT 
	sa.source_app_id,
	sa.source_app_name,
	sa.source_app_code,
	-- Added business_unit_id by HK
	bu.business_unit_id,
	bu.business_unit_name_code,
	bu.business_unit_name,
	ssdn.SourceSystemDatabaseName_ID,
	ssdn.SourceSystemDatabaseName,
	sa.start_date_time,
	sa.end_date_time
FROM
	ctlfwk.source_app sa
INNER JOIN
	ctlfwk.business_unit bu
ON
	sa.business_unit_id = bu.business_unit_id
LEFT JOIN
	Ctlfwk.SourceSystemDatabaseName ssdn
ON sa.SourceSystemDatabaseName_ID = ssdn.SourceSystemDatabaseName_ID

WHERE
	sa.end_Date_time = '9999-12-31 00:0:00.000'
AND
	bu.end_date_time = '9999-12-31 00:0:00.000'
