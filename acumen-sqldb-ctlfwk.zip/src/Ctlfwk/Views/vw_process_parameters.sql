﻿


/****** Object:  View [ctlfwk].[vw_process_parameters]    Script Date: 8/07/2020 2:27:39 PM ******/

CREATE VIEW [ctlfwk].[vw_process_parameters]
AS
SELECT 
	P.process_name,
	p.stream_name,
	p.process_type,
	p.source_object_name,
	p.target_object_name,
	pp.parameter_name,
	pp.parameter_value
FROM
	[ctlfwk].[vw_process] AS P
INNER JOIN
	[ctlfwk].[process_parameters] AS PP
ON
	P.process_id = PP.process_id
WHERE
	P.end_date_time='9999-12-31 00:00:00.000'






