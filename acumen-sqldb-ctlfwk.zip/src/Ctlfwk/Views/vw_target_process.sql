﻿CREATE VIEW [ctlfwk].[vw_target_process]
 
/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-02-2022						Vikas P 				 1.0				InitialVersion
	04-03-2022						Tammy H					 1.1				Update validations and rules to meet new req: Unique set of keys for target object -schema_name, notebook_path, notebook_name, target_object
	20-04-2022						Tammy H					 1.2				Accomodate new process: Ref_Replication -does not have notebook name or path 
																				Bugfix and removal of source objects (process is for source objects, target_process is for target objects)	
	17-05-2022						Sakshi S				1.3					Added cluster_type column to view 
 
 ================================================================================================= */ 

AS
SELECT 
	p.process_id,
	p.process_name,
	p.is_enabled,
	s.stream_name,
	pt.process_type,
	so.target_object_name,
	so.[Schema_Name], --V1.1
	CASE WHEN pt.process_type = 'Ref_Replication' THEN NULL ELSE so.notebook_path END AS notebook_path,--V1.1 --V1.2 Ref_Replication process type, notebook_path should be NULL
	CASE WHEN pt.process_Type = 'Ref_Replication' THEN NULL ELSE so.notebook_name END AS notebook_name, --V1.2 Ref_Replication process type, notebook_name should be NULL
	sa.source_app_name,
	p.start_date_time,
	p.end_date_time,
	lt.load_type_code  
	,p.NoOfWorkers
	,pc.PoolId
	,pc.[cluster_type] --V1.3
FROM
	ctlfwk.process p
INNER JOIN
	ctlfwk.stream s
ON
	p.stream_id = s.stream_id 
INNER JOIN
	ctlfwk.process_type pt
ON
	p.process_type_id = pt.process_type_id
INNER JOIN
	ctlfwk.target_objects so
ON
	p.target_object_id = so.target_object_id

INNER JOIN ctlfwk.load_types as lt 

ON lt.load_type_id=so.load_type_id 

INNER JOIN ctlfwk.source_app sa

ON so.source_app_id = sa.source_app_id

INNER JOIN 
	[Ctlfwk].[PoolConfigurationDetails] as pc 

ON pc.[PoolConfigurationDetailsID]=p.[PoolConfigurationDetailsID] 

GO
