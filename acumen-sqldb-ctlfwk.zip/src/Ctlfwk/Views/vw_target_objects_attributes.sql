﻿
CREATE VIEW [ctlfwk].[vw_target_objects_attributes]
AS

/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	19-01-2022						Tammy H					 1.0				Initial Version
	04-03-2022						Tammy H					 1.1				Added new columns: target_attribute_default_value
 ================================================================================================= */

SELECT
	tao.target_object_id,
	tao.target_object_name,
	lt.load_type_code,
	lt.load_type_description,
	toa.target_attribute_name,
	toa.target_attribute_seq,
	toa.target_attribute_data_type,
	toa.target_attribute_scale,
	toa.target_attribute_precision,
	toa.target_attribute_is_null AS Column_IS_Null,
	toa.target_attribute_is_pk AS Column_IS_PrimaryKey,
	toa.target_attribute_is_BusinessKey AS Column_IS_BusinessKey,
	toa.Encryption_TypeID,
	toa.target_attribute_PII_Function,
	toa.target_attribute_is_historystitch,
	toa.target_attribute_is_historystitch_sortkey,
	toa.target_attribute_Distributed_On,
	toa.target_attribute_Integration_KeyName,
	toa.target_attribute_default_value

FROM
	ctlfwk.target_objects tao
INNER JOIN
	ctlfwk.target_objects_attributes toa
ON
	tao.target_object_id = toa.target_object_id
INNER JOIN
	ctlfwk.load_types lt
ON
	tao.load_type_id = lt.load_type_id
WHERE
	tao.end_date_time = '9999-12-31 00:00:00.000'


GO


