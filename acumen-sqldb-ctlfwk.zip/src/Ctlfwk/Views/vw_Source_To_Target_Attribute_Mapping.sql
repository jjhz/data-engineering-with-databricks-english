﻿

CREATE VIEW [Ctlfwk].[vw_Source_To_Target_Attribute_Mapping]
AS
SELECT 
	Source_To_Target_Mapping_ID
	,Target_Object_ID
	,Target_Schema
	,Target_Object
	,Target_Attribute_Name
	,Target_Object_Type
	,Source_Object_ID
	,Source_Schema
	,Source_Object
	,Source_Attribute_Name
	,Column_Sequence
	,Attribute_IS_BK
FROM
	[Ctlfwk].[Source_To_Target_Attribute_Mapping]
GO


