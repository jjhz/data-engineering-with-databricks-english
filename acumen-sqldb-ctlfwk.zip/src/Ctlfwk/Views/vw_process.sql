﻿CREATE VIEW [ctlfwk].[vw_process]

/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte 				 1.0				InitialVersion
	30-08-2021						Vikas P					 1.1				Added LoadType 
	21-12-2021						Vikas P					 1.2				Added NoOfWorkers and  [PoolId]
	17-05-2022						Sakshi S				 1.3				Added Cluster_type

 ================================================================================================= */ 

AS
SELECT 
	p.process_id,
	p.process_name,
	p.is_enabled,
	s.stream_name,
	pt.process_type,
	so.source_object_name,
	tob.target_object_name,
	p.start_date_time,
	p.end_date_time,
	lt.load_type_code  --V1.1
	,p.NoOfWorkers
	,pc.PoolId --V1.2
	,pc.Cluster_type --V1.3
FROM
	ctlfwk.process p
INNER JOIN
	ctlfwk.stream s
ON
	p.stream_id = s.stream_id
INNER JOIN
	ctlfwk.process_type pt
ON
	p.process_type_id = pt.process_type_id
LEFT JOIN
	ctlfwk.source_objects so
ON
	p.source_object_id = so.source_object_id
LEFT JOIN
	ctlfwk.target_objects tob
ON
	p.target_object_id = tob.target_object_id
LEFT join ctlfwk.load_types as lt 

ON lt.load_type_id=so.load_type_id --V1.1

LEFT JOIN 
	[Ctlfwk].[PoolConfigurationDetails] as pc 

ON pc.[PoolConfigurationDetailsID]=p.[PoolConfigurationDetailsID]  --V1.2