﻿CREATE VIEW [Ctlfwk].[vw_source_objects_attributes]
AS
SELECT 
	so.source_object_id,
	so.source_object_name,
	lt.load_type_code,
	lt.load_type_description,
	soa.source_object_attribute_name,
	soa.source_object_attribute_seq,
	source_object_attribute_data_type,
	soa.source_object_attribute_scale,
	soa.source_object_attribute_precision,
	soa.source_object_attribute_is_Null AS Column_IS_Null,
	soa.source_object_attribute_is_pk AS Column_IS_PrimaryKey,
	soa.source_object_attribute_is_PII AS Column_IS_PII,
	soa.source_object_attribute_is_iud_column,
	soa.source_object_attribute_is_historystitch,
	soa.source_object_attribute_is_historystitch_sortkey,
	soa.input_formatstring ,
	soa.dynamic_masking_function,
	soa.default_value_if_not_nullable,
	soa.source_time_zone,
	soa.source_object_attribute_is_BusinessKey,
	soa.Encryption_TypeID,
	et.[Encryption_Type]
FROM
	ctlfwk.source_objects so
INNER JOIN 	ctlfwk.source_objects_attributes soa ON so.source_object_id = soa.source_object_id
INNER JOIN 	ctlfwk.load_types lt ON so.load_type_id = lt.load_type_id
LEFT OUTER JOIN ctlfwk.Encryption_Types et ON soa.Encryption_TypeID = et.Encryption_TypeID
WHERE
	so.end_date_time = '9999-12-31 00:00:00.000'


