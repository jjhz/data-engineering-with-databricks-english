﻿CREATE VIEW [ctlfwk].[vw_SourceToIncoming_FilePath_Dtls]
 
/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	04-05-2022						Deloitte 				 1.0				InitialVersion
 ================================================================================================= */ 

AS
SELECT DISTINCT
       sa.source_app_name
      ,so.source_object_name
      ,bu.business_unit_name_code
      ,bu.storage_account
      ,bu.storage_secret_name
	  ,lt.load_type_code
	  ,fst.File_Pattern_Name
	  ,fst.TimeStamp_Filename_Pattern
	  ,fst.File_Extension_Type	  
	  ,sfd.source_file_path	  
	  ,sfd.last_modified_datetime_aet
  FROM [ctlfwk].[source_objects] so
 INNER JOIN [ctlfwk].[source_app] sa
    ON so.source_app_id = sa.source_app_id
 INNER JOIN [ctlfwk].[business_unit] bu
    ON sa.business_unit_id = bu.business_unit_id
 INNER JOIN [ctlfwk].[File_Specification_Type] fst
    ON  fst.File_Specification_Type_Id = so.File_Specification_Type_Id	
  LEFT JOIN [ctlfwk].[SourceToIncoming_FilePath_Dtls] sfd
    ON sfd.source_app_id = sa.source_app_id
       AND sfd.source_object_id = so.source_object_id
	   AND sfd.end_date_time = '9999-12-31 00:00:00.000'
 LEFT JOIN [ctlfwk].[load_types] lt 
    ON lt.load_type_id = COALESCE(sfd.load_type_id, so.load_type_id)
 WHERE so.end_date_time = '9999-12-31 00:00:00.000'
   AND sa.end_date_time = '9999-12-31 00:00:00.000'
   AND bu.end_date_time = '9999-12-31 00:00:00.000'   
   