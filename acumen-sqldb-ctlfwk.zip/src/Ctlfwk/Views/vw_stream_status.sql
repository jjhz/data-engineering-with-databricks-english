﻿

/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte 				 1.0				InitialVersion
	05-04-2022                      Sheela R                 1.2                Adding aet date
 ================================================================================================= */

CREATE VIEW [ctlfwk].[vw_stream_status]
AS
SELECT
	ss.stream_status_id,
	ss.stream_id,
	s.stream_name,
	ss.execution_status_id,
	es.execution_status_name,
	ss.start_date_time,
	ss.end_date_time,
	ss.start_date_time_aet, 
	ss.end_date_time_aet 
FROM
	ctlfwk.stream_status ss
INNER JOIN
	ctlfwk.stream s
ON
	ss.stream_id = s.stream_id
INNER JOIN
	ctlfwk.execution_status es
ON
	ss.execution_status_id = es.execution_status_id




