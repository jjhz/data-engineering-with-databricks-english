﻿


CREATE VIEW [ctlfwk].[vw_source_objects]
AS
SELECT 
	so.source_object_id,
	so.source_object_name,
	so.start_date_time,
	so.end_date_time,
	so.Schema_Name,
	so.is_file_mandatory,
	lt.load_type_code,
	lt.load_type_description,
	vsa.source_app_id,
	vsa.source_app_name,
	vsa.business_unit_id,
	vsa.business_unit_name_code,
	NULL AS Is_Enabled,
	fs.File_Specification_Type_Id,
	fs.File_Extension_Type
FROM
	ctlfwk.source_objects so
INNER JOIN ctlfwk.load_types lt ON so.load_type_id = lt.load_type_id
INNER JOIN ctlfwk.vw_source_app vsa ON so.source_app_id = vsa.source_app_id
LEFT OUTER  JOIN ctlfwk.File_Specification_Type fs ON fs.File_Specification_Type_Id = so.File_Specification_Type_Id
WHERE
	so.end_date_time='9999-12-31 00:00:00.000'
AND
	lt.end_date_time='9999-12-31 00:00:00.000'
AND
	vsa.end_date_time='9999-12-31 00:00:00.000'

GO


