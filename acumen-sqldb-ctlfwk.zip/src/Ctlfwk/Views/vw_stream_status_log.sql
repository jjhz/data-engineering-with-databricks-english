﻿CREATE VIEW ctlfwk.vw_stream_status_log
AS
SELECT
	sslg.stream_status_id,
	s.stream_id,
	s.stream_name,
	sslg.execution_status_id,
	es.execution_status_name,
	sslg.start_date_time,
	sslg.end_date_time
FROM
	ctlfwk.stream_status_log sslg
INNER JOIN
	ctlfwk.stream s
ON
	sslg.stream_id = s.stream_id
INNER JOIN
	ctlfwk.execution_status es
ON
	sslg.execution_status_id = es.execution_status_id
	
