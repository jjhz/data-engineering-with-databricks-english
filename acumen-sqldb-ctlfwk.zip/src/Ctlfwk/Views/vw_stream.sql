﻿

CREATE VIEW [ctlfwk].[vw_stream]
AS
SELECT 
	st.stream_id,
	st.stream_name,
	st.stream_description,
	sa.source_app_name,
	sa.source_app_code,
	sa.business_unit_name_code,	
	st.start_date_time,
	st.end_date_time
FROM
	ctlfwk.stream st
INNER JOIN
	ctlfwk.vw_source_app sa
ON
	st.source_app_id = sa.source_app_id
WHERE
	st.end_date_time='9999-12-31 00:0:00.000'
AND
	sa.end_date_time ='9999-12-31 00:0:00.000'
