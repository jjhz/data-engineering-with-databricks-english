﻿CREATE VIEW [ctlfwk].[vw_load_types]
AS
SELECT 
	lt.load_type_id,
	lt.load_type_code,
	lt.load_type_description,
	lt.start_date_time,
	lt.end_date_time
FROM
	ctlfwk.load_types lt
WHERE
	lt.end_date_time='9999-12-31 00:00:00.000'

