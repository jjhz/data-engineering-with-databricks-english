﻿CREATE VIEW [ctlfwk].[vw_Target_to_BU_Storage_Account]
AS

/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	19-01-2022						Tammy H					 1.0				Initial Version
	24-02-2022						Tammy H					 1.1				Code_Set_name changed as reference_Type_name
	04-02-2022						Tammy H					 1.2				Added schema_name, notebook_name, notebook_path
	04-02-2022						Sakshi S				 1.3				Removed reference_type_name
 ================================================================================================= */

SELECT DISTINCT
	so.target_object_name AS target_object_name, 
	bu.business_unit_name_code AS business_unit_name_code,
	bu.storage_account  AS storage_account,
	bu.storage_secret_name AS storage_secret_name,
	CONCAT(so.notebook_path, '/', so.notebook_name) AS merge_template_path,
	so.notebook_path AS notebook_path, --V1.2
	so.notebook_name AS notebook_name, --V1.2
	--so.reference_type_name as reference_type_name, --V1.1 --V1.3
	so.[Schema_Name] as [schema_name],
	sa.source_app_name --V1.2,

FROM 
	[ctlfwk].[target_objects] so
INNER JOIN 
	[ctlfwk].[source_app] sa
ON 
	so.source_app_id = sa.source_app_id
INNER JOIN 
	[ctlfwk].[business_unit] bu
ON 
	sa.business_unit_id = bu.business_unit_id


WHERE 
	so.end_date_time = '9999-12-31 00:00:00.000'
AND sa.end_date_time = '9999-12-31 00:00:00.000'
AND bu.end_date_time = '9999-12-31 00:00:00.000'
GO


