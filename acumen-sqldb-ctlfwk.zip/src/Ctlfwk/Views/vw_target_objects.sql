﻿
CREATE VIEW [ctlfwk].[vw_target_objects]
AS

/*=================================================================================================
-- Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	19-01-2022						Tammy H					 1.0				Initial Version
	08-03-2022						Tammy H					 1.1				Added synapse_override
 ================================================================================================= */ 

SELECT 
	so.target_object_id,
	so.target_object_name,
	so.[Schema_Name],
	lt.load_type_code,
	lt.load_type_description,
	so.source_app_id,
	sa.source_app_name,
	so.notebook_name,
	so.notebook_path,
	so.synapse_distribution_type,
	so.synapse_override, --V1.1
	so.start_date_time,
	so.end_date_time
FROM
	ctlfwk.target_objects so
INNER JOIN
	ctlfwk.source_app sa
ON
	so.source_app_id = sa.source_app_id
INNER JOIN
	ctlfwk.load_types lt
ON
	so.load_type_id = lt.load_type_id
WHERE
	so.end_date_time='9999-12-31 00:0:00.000'
AND
	lt.end_date_time='9999-12-31 00:0:00.000'

GO


