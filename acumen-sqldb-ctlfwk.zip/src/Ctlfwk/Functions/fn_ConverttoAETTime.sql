﻿CREATE FUNCTION [Ctlfwk].[fn_ConverttoAETTime] (@Processtime DATETIME)
	RETURNS DATETIME
/*============================================================================================
04-02-2022			Sakshi S			1.0			 Initial Version
-- ==========================================================================================*/
		AS
		BEGIN
		DECLARE @timeinAET DATETIME2

		select @timeinAET = NULL

			SELECT @timeinAET=CAST(coalesce(dateadd(minute,datepart(tzoffset,cast(@Processtime as Datetime2) AT TIME ZONE 'AUS Eastern Standard Time'),@Processtime),'1900-01-01 00:00:00.000') as datetime2)
		return @timeinAET
		END
GO