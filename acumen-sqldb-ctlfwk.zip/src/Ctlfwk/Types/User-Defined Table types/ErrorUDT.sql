CREATE TYPE [ctlfwk].[ErrorUDT] AS TABLE(
	[error_flag] [varchar](100) NULL,
	[error_message] [varchar](4000) NULL,
	[additional_message] [nvarchar](4000) NULL
	 
)
GO