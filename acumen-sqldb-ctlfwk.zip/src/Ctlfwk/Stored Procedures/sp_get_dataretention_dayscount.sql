﻿
CREATE PROCEDURE [Ctlfwk].[sp_get_dataretention_dayscount]
( 
   @source_app_name	VARCHAR(100) NULL
)
AS

BEGIN

	SET NOCOUNT ON

	DECLARE @ret_status VARCHAR(100)

	IF @source_app_name IS NOT NULL
	BEGIN
		SELECT 
			retention_days
		FROM
			ctlfwk.source_app
		WHERE
			source_app_name = @source_app_name
	END
END
GO


