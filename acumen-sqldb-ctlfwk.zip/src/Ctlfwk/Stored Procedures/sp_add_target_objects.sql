﻿
CREATE PROCEDURE [ctlfwk].[sp_add_target_objects]
(
	@business_unit_name_code varchar(7)
,	@source_app_code VARCHAR(25) --V2.1
,	@target_object_name VARCHAR(100) = NULL
,	@target_object_description VARCHAR(1000) --V2.4
,	@Schema_Name	VARCHAR(50) --V2.3
,	@load_type_code VARCHAR(5) 
,	@notebook_name VARCHAR(255)
,	@notebook_path NVARCHAR(255)
,	@synapse_distribution_type VARCHAR(max)
,	@synapse_override VARCHAR(max) --V1.9
,	@Input_Source_Type VARCHAR(30) --V1.5
,	@replication_type VARCHAR(20) = NULL --V2.2
)
AS
/*=============================================
   Description: Adds and updates records in ctlfwk.target_objects table

   Parameters:
	 @business_unit_name_code - unique code from ctlfwk.business_unit
     @source_app_code - source app code from ctlfwk.source_app -business_unit_name_code & source_app_code together is unique
	 @target_object_name - name of target object
	 @target_object_description - description of target object
	 @Schema_Name - Schema that target object belongs to
	 @load_type_code - unique load type code from ctlfwk.load_types
	 @notebook_name - name of ADB notebook
	 @notebook_path - path of ADB notebook
	 @synapse_distribution_type - type of synapse distribution
	 @replication_type - 
	 

  Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	21-01-2022						Tammy H					 1.0				InitialVersion
	02-02-2022						Tammy H					 1.1				Add Raise Error
	07-02-2022						Tammy H					 1.2				Adding business_unit_name_code & source_app_code parameter, Include it in relevant table filtering and validations
	15-02-2022						Tammy H					 1.3				Adding Code_Set_Name parameter and relevant validations
	16-02-2022						Tammy H					 1.4				Changing insert/update to merge actions instead and dependent on target/reference object
																				Validation change -load_type_code can only be D/T/R
	17-02-2022						Tammy H					 1.5				Adding Input_Source_Type column and default value to 'ADB' when NULL
	23-02-2022						Tammy H					 1.6				Code_Set_Name renamed to reference_type_name
	04-03-2022						Tammy H					 1.7				Update validations and rules to meet new req: Unique set of keys for target object -schema_name, notebook_path, notebook_name, target_object.
	04-03-2022                      Sheela R                 1.8                Removed Reference_Type_Name 
	04-03-2022                      Sakshi S                 1.9                Added synapse_override 
	08-03-2022						Tammy H					 2.0				Added synapse_overide validation: Blank, set to NULL.
	10-03-2022						Tammy H					 2.1				New req: Change source_app_code varchar(6) to varchar(25)
	25-03-2022						Niharika S				 2.2				Adding new column replication_type
	29-03-2022						Tammy H					 2.3				Updating last_modified_by and last_modified_datetime
	08-04-2022						Niharika S				 2.4				Setting default value for replication_type given load_type_code	
	02-05-2022						Tammy H					 2.3				Schema_Name(100) to Schema_Name(50) to match PK constraint in target_objects
	09-05-2022						Tammy H					 2.4				New req: Increasing target_object_description varchar(100) to varchar(1000)
	06-02-2023                      Arunava Das              2.5                Adding new load type- IO and changing from checking load_type table to just not in D/T/R to D/T/R/IO 
-- =============================================*/

BEGIN

set nocount on;
	
	declare @ErrorUDT [ctlfwk].[ErrorUDT]
	declare @target_object_id INT ;
	declare @source_app_id INT ;
	declare @load_type_id INT ;
	declare @Returnvalue INT = 0;

	--Table to capture Input Parameters
	declare @FinalValues AS TABLE
	(
			target_object_name VARCHAR(100)
		,	target_object_description VARCHAR(1000) --V2.4
		,	[Schema_Name]	VARCHAR(50) --V2.3
		,	load_Type_id	INT
		,	source_app_id	INT
		,	start_date_time	datetime
		,	end_date_time	datetime
		,	notebook_name	VARCHAR(max)
		,	notebook_path	VARCHAR(max)
		,	synapse_distribution_type	varchar(max)
		--,	reference_type_name	VARCHAR(100)
		,	synapse_override varchar(max)  --V1.9
		,	Input_Source_Type VARCHAR(30)
		,	replication_type VARCHAR(20) --V2.2
	)
--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
		--V1.3
		--V1.5
		IF (@Input_Source_Type IS NULL OR LEN(@Input_Source_Type) = 0)
			SET @Input_Source_Type = 'ADB'

		--V2.0
		IF (LEN(@synapse_override) = 0)
			SET @synapse_override = NULL
		--V2.2
		IF (LEN(@replication_type) = 0)
			SET @replication_type = NULL
		--V2.4
		IF @load_type_code = 'R' 
			SET @replication_type = 'UI' --update insert
		IF @load_type_code = 'D' AND @replication_type IS NULL
			SET @replication_type = 'DI'	--delete insert
		IF @load_type_code = 'T' AND @replication_type IS NULL
			SET @replication_type = 'T'		--truncate
     	IF @load_type_code = 'IO' AND @replication_type IS NULL
			SET @replication_type = 'DI'	--delete insert
		--V1.2
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.business_unit WHERE business_unit_name_code = @business_unit_name_code ) 
			BEGIN 
			
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Business_Unit_Name_Code does not exist', (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
																			+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																		 	+'}' )
						);

				SET @Returnvalue =2 ;

			END 		
		
		--V1.2 adding business_unit_name_code as source_app_code itself is not unique
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app sa 
						INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
						WHERE source_app_code = @source_app_code AND business_unit_name_code = @business_unit_name_code)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Business_Unit_Name_Code and Source_App_Name does not exist together' , (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
																										+','+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" '
																										+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																										+'}' )
						) ;
				SET @Returnvalue =2 ;
			END

		--V1.4 changing from checking load_type table to just not in D/T/R
		--V2.5 adding IO
		IF @load_type_code NOT IN ('D', 'T', 'R', 'IO') 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Load_Type_Code does not exist' ,  (N'{' +',' +CONCAT('"Load_Type_Code": "',COALESCE(@load_type_code, ''))	+'" '
																	 +','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																    + '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END 


		IF (@target_object_name IS NULL OR LEN(@target_object_name) = 0) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Target_Object_Name cannot be NULL or Blank', (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" ' 
																						+'}' )
						);

				SET @Returnvalue =2 ;
			END 

		IF (@target_object_description IS NULL OR LEN(@target_object_description) = 0) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Target_Object_Desciption cannot be NULL or Blank', (N'{'+CONCAT('"Target_Object_Desciption": "',COALESCE( @target_object_description ,''))  +'" '
																						+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" ' 
																						+'}' )
						);

				SET @Returnvalue =2 ;
			END 

	

		
		--V1.7 Schema_Name is part of unique keys so cannot be NULL
		IF (@Schema_Name IS NULL OR LEN(@Schema_Name) = 0) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Schema_Name cannot be NULL or Blank' ,  (N'{'+CONCAT('"Schema_Name": "',COALESCE(@notebook_name, ''))	+'" '
																			+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																			
																			+ '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END

		IF (@notebook_name IS NULL OR LEN(@notebook_name) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Notebook_Name cannot be NULL or Blank' ,  (N'{'+CONCAT('"Notebook_Name": "',COALESCE(@notebook_name, ''))	+'" '
																			+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																			
																			+ '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END

		IF (@notebook_path IS NULL OR LEN(@notebook_path) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Notebook_Path cannot be NULL or Blank' ,  (N'{' +',' +CONCAT('"Notebook_Path": "',COALESCE(@notebook_path, ''))	+'" '
																				+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																				
																				+ '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END

		IF (@synapse_distribution_type IS NULL OR LEN(@synapse_distribution_type) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Synapse_Distribution_Type cannot be NULL or Blank' ,  (N'{' +',' +CONCAT('"Synapse_Distribution_Type": "',COALESCE(@synapse_distribution_type, ''))	+'" '
																							+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																							
																							+ '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END
		--V2.2 start
		IF @load_type_code = 'D' AND @replication_type NOT IN ('DI', 'CTAS') 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Replication_Type does not exist with Delta Merge load type' ,  (N'{' +',' +CONCAT('"Replication_Type": "',COALESCE(@replication_type, ''))	+'" '
																	 +','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																    + '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END 

			
		IF @load_type_code = 'T' AND @replication_type NOT IN ('T') 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Replication_Type does not exist with Truncate load type' ,  (N'{' +',' +CONCAT('"Replication_Type": "',COALESCE(@replication_type, ''))	+'" '
																	 +','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																    + '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END 
		--v2.5
		IF @load_type_code = 'IO' AND @replication_type NOT IN ('DI') 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Replication_Type does not exist with Insert Overwrite type' ,  (N'{' +',' +CONCAT('"Replication_Type": "',COALESCE(@replication_type, ''))	+'" '
																	 +','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																    + '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END
		

--===========================-- Input Paramter Validation and  Setting Return Value ENDS ====================================================

 	-- V1.1
	IF @Returnvalue = 2 
		RAISERROR('sp_add_target_objects: ERROR - Refer to Process_Error Table .', 16, -1)

	IF @Returnvalue = 0
		BEGIN --Returnvalue0
			BEGIN TRY
				BEGIN TRANSACTION 
					--V1.2 adding business_unit_name_code
					SELECT @source_app_id = source_app_id FROM [ctlfwk].[source_app] sa 
											INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
											WHERE source_app_code = @source_app_code AND business_unit_name_code = @business_unit_name_code;
			
					SELECT @load_type_id= load_type_id FROM [ctlfwk].[load_types] WHERE load_type_code = @load_type_code;

					--V1.4 Changes START
					INSERT INTO @FinalValues
					(
							target_object_name 
						,	target_object_description 
						,	[Schema_Name]	
						,	load_Type_id	
						,	source_app_id
						,	start_date_time	
						,	end_date_time	
						,	notebook_name	
						,	notebook_path	
						,	synapse_distribution_type	
					--	,	reference_type_name	
						,	synapse_override  --V1.9
						,	Input_Source_Type
						,	replication_type --V2.2
					)
					VALUES
					(
							@target_object_name
						,	@target_object_description
						,	@Schema_Name	
						,	@load_type_id	
						,	@source_app_id
						,	GETDATE()
						,	'9999-12-31'
						,	@notebook_name	
						,	@notebook_path	
						,	@synapse_distribution_type	
						--,	@reference_type_name  --SR
						,	@synapse_override  --V1.9
						,	@Input_Source_Type
						,	@replication_type --V2.2
					)
					
					
					--Capturing the Merge Action into #MergeActions Table 			 
					DROP TABLE IF EXISTS #MergeActions ;
					CREATE TABLE #MergeActions ([Action] VARCHAR(10), target_object_id INT  ) 
					

					--Check if Target Object/Reference Object already exists and fetch the Target_Object_Id to identify Insert/Update
		
						
							--V1.7
					SELECT @target_object_id = target_object_id
					FROM @FinalValues fv
					LEFT JOIN Ctlfwk.target_objects so ON fv.target_object_name = so.target_object_name AND fv.[Schema_Name] = so.[Schema_Name] AND fv.notebook_path = so.notebook_path AND fv.notebook_name = so.notebook_name					--fv.source_app_id = so.source_app_id AND 	

					INSERT INTO #MergeActions ([Action],target_object_id)
					SELECT [Action], target_object_id
					FROM (
						MERGE ctlfwk.target_objects as tgt
						USING @FinalValues as source ON (tgt.target_object_id = ISNULL(@target_object_id,0))

						WHEN MATCHED THEN
							UPDATE
							SET	  tgt.target_object_description = source.target_object_description
								, tgt.load_type_id = source.load_type_id
								, tgt.source_app_id = source.source_app_id
								, tgt.start_date_time = source.start_date_time
								, tgt.end_date_time = source.end_date_time
								, tgt.synapse_distribution_type = source.synapse_distribution_type
								--, tgt.reference_type_name = NULL
								, tgt.synapse_override = source.synapse_override  --V1.9
								, tgt.Input_Source_Type = source.Input_Source_Type
								, tgt.replication_type = source.replication_type --V2.2
								, tgt.Last_Modified_Datetime =SYSDATETIME() --V2.3
								, tgt.Last_Modified_By = ORIGINAL_LOGIN() --V2.3
					
						WHEN NOT MATCHED THEN
							INSERT ( target_object_name, target_object_description, [Schema_Name], load_type_id, source_app_id, 
									start_date_time, end_date_time, notebook_name, notebook_path, synapse_distribution_type
									--, reference_type_name
									, synapse_override  --V1.9
									, Input_Source_Type
									, replication_type) --V2.2
							VALUES (
									   source.target_object_name
									 , source.target_object_description
									 , source.[Schema_Name]
									 , source.load_type_id
									 , source.source_app_id
									 , source.start_date_time
									 , source.end_date_time
									 , source.notebook_name
									 , source.notebook_path
									 , source.synapse_distribution_type
								--	 , source.reference_type_name
									 , source.synapse_override  --V1.9
									 , source.Input_Source_Type
									 , source.replication_type --V2.2
									)
						OUTPUT	$action AS [Action], inserted.target_object_id
						) MergeOutput

						

					--V1.4 Changes END
 
				COMMIT TRANSACTION;
			END TRY
	
			BEGIN CATCH
		
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION

			END CATCH
		END --Returnvalue0

	IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_target_objects' 
					FROM @ErrorUDT; 
				
					SELECT * FROM @ErrorUDT 
				END

		ELSE 
				SELECT CONCAT('target_object_id ', + CONVERT(VARCHAR, target_object_id)  + ' is ' + Action + 'D' )  FROM #MergeActions

END