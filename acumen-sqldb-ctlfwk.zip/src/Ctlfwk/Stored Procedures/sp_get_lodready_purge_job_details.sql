﻿
CREATE PROCEDURE [Ctlfwk].[sp_get_lodready_purge_job_details]
( 
  @stream_name	VARCHAR(255) ,
  @source_app_name	VARCHAR(100) ,
  @object_name	VARCHAR(100) NULL
)
AS

BEGIN

	SET NOCOUNT ON

	DECLARE @ret_status VARCHAR(100)
	DECLARE @retention_days_count INT

	SET @retention_days_count = (SELECT retention_days FROM ctlfwk.source_app WHERE source_app_name = @source_app_name )

		SELECT 
			 @retention_days_count as retention_days_count
			,process_name
			,stream_name
			,process_type
			,source_object_name
			,is_enabled

		FROM
			ctlfwk.vw_process
		WHERE
			stream_name = @stream_name
        AND
		    source_object_name = @object_name

END





GO


