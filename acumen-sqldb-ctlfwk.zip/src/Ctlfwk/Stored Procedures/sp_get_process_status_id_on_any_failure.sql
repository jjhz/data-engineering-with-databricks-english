﻿CREATE PROCEDURE [Ctlfwk].[sp_get_process_status_id_on_any_failure]
( 
  @stream_name	VARCHAR(255) , --V1.4
  @process_type	VARCHAR(20) NULL,
  @object_name	VARCHAR(100) NULL,
  @sourceapp_name	VARCHAR(100) NULL
)
AS
/*=================================================================================================
-- Usage Comments if Any :Used to Fetch get_process_status_id_on_any_failure and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	19-10-2021						Vikas P					 1.1				newly Added  
	19-01-2022						Vikas P					 1.2				Added target object details  
	22-02-2022						Vikas P					 1.3				Added  more filters as one object can be in multiple process type
	18-03-2022						Tammy H					 1.4			    New req: Stream_name raised to be varchar(255)
 ================================================================================================= */ 

--v1.2
BEGIN

	Declare @Source_object_Name_Check Int,
			@Target_object_Name_Check int
    -- Check for Bronze and Silver Layer 
	SELECT @Source_object_Name_Check=Count(1) 
	FROM Ctlfwk.source_objects as so 
	JOIN Ctlfwk.source_app as sa ON so.source_app_id=sa.source_app_id 
	JOIN Ctlfwk.process p ON p.source_object_id =so.source_object_id
	JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
    JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
    WHERE  pt.process_type =@process_type--v1.3
    AND    so.source_object_name=@object_name
    AND    sa.source_app_name=@sourceapp_name
    AND    st.stream_name=@stream_name
	-- Check for Gold Layer 
	SELECT @Target_object_Name_Check=Count(1) 
	FROM Ctlfwk.target_objects as so 
	JOIN Ctlfwk.source_app as sa ON so.source_app_id=sa.source_app_id
	JOIN Ctlfwk.process p ON p.target_object_id  =so.target_object_id
	JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
    JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
    WHERE  pt.process_type =@process_type--v1.3
    AND    so.target_object_name=@object_name
    AND    sa.source_app_name=@sourceapp_name
    AND    st.stream_name=@stream_name

IF @Source_object_Name_Check=0 and @Target_object_Name_Check=0
	BEGIN 
		RAISERROR('Process not found ERROR - source_objects or target_objects is not linked with source_app' ,17,1)
	END

	
--v1.2

IF @Source_object_Name_Check>=1
	BEGIN
		SELECT Max(process_status_id) AS process_status_id
			FROM  (
				  SELECT --Add case stmt according to load type
                     CASE
                            WHEN pt.process_type=@process_type THEN ps.process_status_id
                            WHEN pt.process_type is null  THEN NULL 
                     END AS process_status_id
              FROM   ctlfwk.process p
              JOIN   ctlfwk.process_status AS ps  ON     ps.process_id=p.process_id
              JOIN   ctlfwk.source_objects AS s   ON     s.source_object_id=p.source_object_id
              JOIN   ctlfwk.source_app AS sa      ON     sa.source_app_id=s.source_app_id
              JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
              JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
              WHERE  pt.process_type =@process_type
              AND    s.source_object_name=@object_name
              AND    sa.source_app_name=@sourceapp_name
              AND    st.stream_name=@stream_name
		) as s

	END

--v1.2
IF @Target_object_Name_Check>=1
	BEGIN
	SELECT Max(process_status_id) AS process_status_id
			FROM  (
				  SELECT --Add case stmt according to load type
                     CASE
                            WHEN pt.process_type=@process_type THEN ps.process_status_id
                            WHEN pt.process_type is null  THEN NULL 
                     END AS process_status_id
              FROM   ctlfwk.process p
              JOIN   ctlfwk.process_status AS ps  ON     ps.process_id=p.process_id
              JOIN   ctlfwk.target_objects AS s   ON     s.target_object_id=p.target_object_id
              JOIN   ctlfwk.source_app AS sa      ON     sa.source_app_id=s.source_app_id
              JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
              JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
              WHERE  pt.process_type =@process_type
              AND    s.target_object_name=@object_name
              AND    sa.source_app_name=@sourceapp_name
              AND    st.stream_name=@stream_name
		) as s
	END
	
END
--v1.2

