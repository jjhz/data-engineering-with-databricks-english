CREATE PROCEDURE [Ctlfwk].[sp_force_start_process]
( 
  @process_name VARCHAR(200)
)
AS

SET NOCOUNT ON
SET XACT_ABORT ON

BEGIN TRY

	DECLARE 
		@Last_Execution_Status VARCHAR(10),
		@Execution_Status_ID	INT,
		@Process_ID				INT
		
	DECLARE 
		@error_flag						 VARCHAR(100),
		@error_message					 VARCHAR(100),
		@process_status_id				 VARCHAR(50),
		@process_start_ts				 VARCHAR(100),
		@prev_process_start_ts			 VARCHAR(100),
		@last_succ_process_start_ts		 VARCHAR(100)
				

	/* Fetch Execution_Status_ID From Execution_Status Table */
	SELECT @Execution_Status_ID = Execution_Status_ID FROM ctlfwk.execution_status WHERE execution_status_name = 'Running'

	/* Fetch Process_ID From process Table */
	SELECT @Process_ID = process_id FROM ctlfwk.vw_process WHERE process_name = @process_name
	
	IF @Process_ID IS NULL
	BEGIN
		SET @error_flag = 'Error'
		SET @error_message = 'ERROR - Job Cannot Start. Process does not exist.' 
		SET @process_status_id = 'None'
		SET @process_start_ts = 'None'
			
		SELECT NULL AS Process_Status_ID, NULL AS Process_Start_TimeStamp,
		       NULL AS Prev_Process_Start_TimeStamp, 
			   @error_flag AS Erro_Flag, @error_message AS ErrorMessage
		RAISERROR('ERROR - Process does not exist.', 16, -1) 
    END

/****************************************** FETCHING METADATA FOR LAST PROCESS FROM 'PROCESS_STATUS' ******************************************************************/

	/* GET Last Execution Status Information of process For Given Stream Name */
	SELECT 
		@Last_Execution_Status = execution_status_name, -- any status
		@prev_process_start_ts = FORMAT(start_date_time,'yyyyMMddHHmmss')
	FROM 
		ctlfwk.vw_process_status
	WHERE
		process_name = @process_name

/****************************ADD A NEW PROCESS ID IN PROCESS_STATUS IF THE PROCESS IS RUNNING FOR FIRST TIME**************************************/

	IF  @Last_Execution_Status IS NULL
	BEGIN

		/* INSERT NEW EXECUTION in Process_Status Table */
		INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time)
		VALUES
		(@Process_ID,1,format(getdate(),'yyyy-MM-dd HH:mm:ss'))
	
		SET	@process_status_id = (SELECT MAX(A.process_status_id) 
									FROM (	SELECT process_status_id
											FROM [ctlfwk].[vw_process_status] 
											WHERE process_name = @process_name)A)
		SET @process_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmss')
									FROM (	SELECT MAX(start_date_time) as start_date_time
											FROM [ctlfwk].[vw_process_status]
											WHERE process_name = @process_name)B)
		SET @error_flag ='Success'
		SET @error_message ='Success'


        SET @prev_process_start_ts = '19000101000000'

		SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
		       @prev_process_start_ts AS Prev_Process_Start_TimeStamp, 
			   @error_flag AS Erro_Flag, @error_message AS ErrorMessage
	END
		


/*******************************************************************************************************************************************************************	
*****************************************         INSERT PROCESS METDATA AS PER SCENARIOS          *****************************************************************
*******************************************************************************************************************************************************************/	
	IF  @Last_Execution_Status IN ('Success' ,'Cancelled','Failed')  
	BEGIN

		/* COPY PREVIOUS SUCCESSFUL/COMPLETED RUN VALUES FROM PROCESS_STATUS Table to PROCESS_STATUS_LOG */

		INSERT INTO ctlfwk.process_status_log 
			(process_status_id, process_id, execution_status_id, start_date_time, end_date_time)
		SELECT 
			process_status_id, process_id, execution_status_id, start_date_time, end_date_time
		FROM
			ctlfwk.vw_process_status
		WHERE
			process_name = @process_name	
			
		/* GET PREVIOUS SUCCESSFUL PROCESS START TIME */
		SET @last_succ_process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmss')
                              FROM (select p.process_id, max(ps.Start_Date_Time) as start_date_time from    
                              ctlfwk.process p
                              INNER JOIN [Ctlfwk].[vw_process_status_log] ps
                              ON p.process_id = ps.Process_id
                              AND ps.execution_status_name = 'Success'
                              AND p.process_name = @process_name
                              Group by p.process_id) X )
	
		/* DELETE RECORD FROM PROCESS_STATUS Table*/

		DELETE FROM ctlfwk.process_status WHERE process_id = @Process_ID 

		/* INSERT NEW EXECUTION in Process_Status Table */

		INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time)
		VALUES
		(@Process_ID,@Execution_Status_ID,format(getdate(),'yyyy-MM-dd HH:mm:ss'))
	
		SET	@process_status_id = (SELECT MAX(A.process_status_id) 
									FROM (	SELECT process_status_id
											FROM [ctlfwk].[vw_process_status] 
											WHERE process_name = @process_name) A)
		SET @process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmss')
									FROM (	SELECT MAX(start_date_time) as start_date_time
											FROM [ctlfwk].[vw_process_status]
											WHERE process_name = @process_name) B)
		SET @error_flag = 'Success'
		SET @error_message = 'Success'

		SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
		       @last_succ_process_start_ts AS Prev_Process_Start_TimeStamp, -- last successful process will be picked
			   @error_flag AS Erro_Flag, @error_message AS ErrorMessage
	END

END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()
	
	RAISERROR	(@error_message,
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;







GO

