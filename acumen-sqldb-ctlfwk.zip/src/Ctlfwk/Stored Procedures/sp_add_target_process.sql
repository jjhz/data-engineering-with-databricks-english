﻿CREATE PROCEDURE [ctlfwk].[sp_add_target_process]
    @process_name varchar(200)   
,   @process_name_description VARCHAR(100)
,	@is_enabled varchar(1)
,	@stream_name varchar(255) --V1.5
,	@process_type varchar(20)
,	@business_unit_name_code varchar(7)
,	@source_app_code varchar(24) --V1.4
,   @target_object_name varchar(100) 
--,	@reference_type_name varchar(100) = NULL --V1.3
,	@Schema_Name varchar(50)
,	@notebook_path varchar(255)
,	@notebook_name varchar(255)
,   @PoolName VARCHAR(MAX)  
,   @NoOfWorkers INT     

AS 

/*=============================================
   Description: Adds and updates records in ctlfwk.process table

   Parameters:

   Usage Comments if Any : 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	18-02-2022						Tammy H					 1.0				InitialVersion
	23-02-2022						Tammy H					 1.1				Code_Set_Name renamed to reference_type_name
	04-03-2022						Tammy H					 1.2				Adding Schema_Name, notebook_path, notebook_name parameters (unique set of keys for target_object)
	04-03-2022						Sakshi S				 1.3				Removed Reference_type_name 
	10-03-2022						Tammy H					 1.4				New req: Change source_app_code varchar(6) to varchar(25)
	18-03-2022						Tammy H					 1.5			    New req: Stream_name raised to be varchar(255)
	21-04-2022						Tammy H					 1.6				New process_type Ref_Replication and it's rules
	14-05-2022						Sakshi S				 1.7			    NoofWorkers can be 0, if passed as Null will be treated as 0

-- =============================================*/
BEGIN

set nocount on;
    
	-- Error Validations Start 
	declare @stream_id INT;
	declare @process_type_id INT;
	declare @target_object_id INT;
	declare @processId INT=NULL ; 
	declare @source_app_id INT

	declare @Actiontype varchar(100) ; 

	-- Table Variable to Capture Input Paramters 
	declare @InsertedParameterValues AS TABLE 
	(
	    process_name varchar(200)  
	,	process_name_description VARCHAR(100)
	,	is_enabled varchar(1)
	,	stream_name varchar(255)
	,	process_type varchar(20)
	--,	business_unit_name_code varchar(7) --V1.2 
	--,	source_app_code varchar(6) --V1.2
	,   target_object_name varchar(100) NULL
	--,	reference_type_name varchar(100) NULL -- V1.3
	,   PoolName VARCHAR(MAX) NULL
	,   NoOfWorkers INT NULL 

	)
	-- Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 

	-- Table Variable to fetch ID's by doing Looukups to Input into Process  Table 
	declare @FinalValues AS TABLE 
				( 
				process_name VARCHAR(200) 
				, process_name_description  VARCHAR(100) 
				, is_enabled VARCHAR(1) 
				, stream_id INT 
				, process_type_id INT 
				, source_object_id INT NULL
				, target_object_id INT NULL
				, start_date_time datetime
				, end_date_time   datetime
				, PoolConfigurationDetailsID VARCHAR(MAX) 
				,  NoOfWorkers INT NULL 
				) 
	declare @PoolConfigurationId INT 

--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
	IF LEN(@target_object_name) = 0
		SET @target_object_name = NULL
	/*IF LEN(@reference_type_name) = 0
		SET @reference_type_name = NULL*/ --V1.3

	IF (@process_name IS NULL OR LEN(@process_name) = 0) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Process Name cannot be NULL or Blank', (N'{' +CONCAT('"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
																		+',' +CONCAT('"Stream_Name": "' ,COALESCE( @stream_name ,'')) +'" '
																		+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																	--	+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" '  --V1.3
																		+ '}')
			);

			SET @Returnvalue =2 ;
		END 

	IF (@process_name_description IS NULL OR LEN(@process_name_description) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Process name description cannot be NULL or Blank', (N'{' +CONCAT('"Process_Name_Description": "',COALESCE( @process_name_description ,''))  +'" ' 
																				+',' +CONCAT('"Process_Name": "' ,COALESCE( @process_name ,'')) +'" '
																				+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																			--	+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" ' --V1.3
																				+ '}')
				);

			SET @Returnvalue =2 ;
		END 
		
	IF (@is_enabled NOT IN ( 'Y','N') OR  @is_enabled IS NULL) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Is_enabled can only be Y/N' , (N'{' +CONCAT('"IsEnabled": "',COALESCE( @is_enabled ,''))  +'" '
																					+',' +CONCAT('"Process_Name": "' ,COALESCE( @process_name ,'')) +'" '
																					+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																			--		+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" '  --V1.3
																					+ '}')
					) ;
			SET @Returnvalue =2 ;
		END

	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.stream WHERE stream_name =@stream_name ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Stream_Name does not exist' , (N'{' +CONCAT('"Stream_Name": "',COALESCE( @stream_name ,''))  +'" ' 
																+',' +CONCAT('"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
																+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
															--	+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" ' --V1.3
																+ '}')
					) ;
			SET @Returnvalue =2 ;
		END  

	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.process_type  WHERE process_type =@process_type ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Process_Type does not exist' , (N'{' +CONCAT('"Process_Type": "',COALESCE( @process_type ,''))  +'" ' 
																	+',' +CONCAT('"Process_Name": "' ,COALESCE( @process_name ,'')) +'" '
																	+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																--	+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" '  --V1.3
																	+ '}')
					) ;
			SET @Returnvalue =2 ;
		END 
		
	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.business_unit WHERE business_unit_name_code = @business_unit_name_code ) 
		BEGIN 
			
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Business_Unit_Name_Code does not exist', (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
																		+',' +CONCAT('"Process_Name": "' ,COALESCE( @process_name ,'')) +'" '
																		+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																	--	+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" ' --V1.3
																		+ '}')
					);
			SET @Returnvalue =2 ;
		END 

	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app sa 
					INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
					WHERE source_app_code = @source_app_code AND business_unit_name_code = @business_unit_name_code)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error','Business_Unit_Name_Code and Source_App_Name does not exist together' , (N'{' +CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																									+',' +CONCAT('"Process_Name": "' ,COALESCE( @process_name ,'')) +'" '
																									+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																							--		+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" '  --V1.3
																									+ '}')
					) ;
			SET @Returnvalue =2 ;
		END 
	ELSE -- Get the unique id -source_app_id
		BEGIN
			SELECT @source_app_id = source_app_id 
			FROM ctlfwk.source_app sa 
			INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
			WHERE source_app_code = @source_app_code AND business_unit_name_code = @business_unit_name_code
		END

	--V1.6 introducing ref_replication process_type
	IF @process_type != 'Ref_Replication'
		BEGIN
			IF (@notebook_name IS NULL OR @notebook_path IS NULL)
				BEGIN 
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Notebook_Path and Notebook_Name cannot be NULL if process_type NOT Ref_Replication' , 
							(N'{' +CONCAT('"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
								+',' +CONCAT('"Process_Type": "' ,COALESCE( @process_type ,'')) +'" '
								+',' +CONCAT('"Schema_Name": "' ,COALESCE( @schema_name ,'')) +'" '
								+',' +CONCAT('"Notebook_Path": "' ,COALESCE( @notebook_path ,'')) +'" '
								+',' +CONCAT('"Notebook_Name": "' ,COALESCE( @notebook_name ,'')) +'" '
								+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
								+ '}')
							) ;
					SET @Returnvalue =2 ;
				END 				
			---- V1.2 refernce_type_name takes priority. replace source_app_id with schema_name, notebook_path & notebook_name in identifying target_object from table
			--IF @target_object_name IS NOT NULL --AND @reference_type_name IS NULL  V1.3
			--	BEGIN
				IF NOT EXISTS ( SELECT 1 FROM ctlfwk.target_objects    WHERE target_object_name = @target_object_name AND [Schema_Name] = @Schema_Name AND notebook_path = @notebook_path AND notebook_name = @notebook_name) 
					BEGIN 
						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						VALUES ('Error', 'Target_Object_Name must exist in ctlfwk.target_objects with Schema_Name, Notebook_Path, Notebook_Name if process_type NOT Ref_Replication' , 
								(N'{' +CONCAT('"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
									+',' +CONCAT('"Schema_Name": "' ,COALESCE( @schema_name ,'')) +'" '
									+',' +CONCAT('"Notebook_Path": "' ,COALESCE( @notebook_path ,'')) +'" '
									+',' +CONCAT('"Notebook_Name": "' ,COALESCE( @notebook_name ,'')) +'" '
									+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
									+ '}')
								) ;
						SET @Returnvalue =2 ;
					END 
				--END
		END
	ELSE --process_Type = 'Ref_Replication'
		BEGIN
			IF NOT EXISTS ( SELECT 1 FROM ctlfwk.target_objects so JOIN ctlfwk.load_types lt ON so.load_type_id =lt.load_type_id
							WHERE load_type_code ='R' AND target_object_name = @target_object_name AND [Schema_Name] = @Schema_Name AND source_app_id = @source_app_id) 
				BEGIN 
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Ref_Replication: Target_Object_Name must exist in ctlfwk.target_objects with Schema_Name, Source_App_Id (Business_unit_name_code + Source_App_Code) and LoadType Reference' , 
							(N'{' +CONCAT('"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
								+',' +CONCAT('"Schema_Name": "' ,COALESCE( @schema_name ,'')) +'" '
								+',' +CONCAT('"Source_App_Id": "' ,COALESCE( @source_app_id ,'')) +'" '
								+',' +CONCAT('"Business_Unit_Name_Code": "' ,COALESCE( @business_unit_name_code ,'')) +'" '
								+',' +CONCAT('"Source_App_Code": "' ,COALESCE( @source_app_code ,'')) +'" '
								+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
								+ '}')
							) ;
					SET @Returnvalue =2 ;
				END 			
		END

	IF (@PoolName  IS NULL OR LEN(@PoolName) = 0)  
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'PoolName cannot be Null or Blank' , (N'{' +CONCAT('"PoolName": "' ,COALESCE( @PoolName ,'')) +'" '
																		+',' +CONCAT('"Process_Name": "' ,COALESCE( @process_name ,'')) +'" '
																		+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																	--	+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" '  V1.3
																		+ '}')
				    ) ;
			SET @Returnvalue =2 ;
				  
		END
	
	IF (@PoolName  IS NOT  NULL OR LEN(@PoolName) > 0)
		BEGIN 
			IF NOT EXISTS ( SELECT 1 FROM Ctlfwk.PoolConfigurationDetails 
				                WHERE PoolName =@PoolName 
							)
				BEGIN 
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Pool Name does not exist in PoolConfigurationDetails Table',(N'{' +CONCAT('"Pool Name": "' ,COALESCE( @PoolName ,'')) +'" '
																									+',' +CONCAT('"Process_Name": "' ,COALESCE( @process_name ,'')) +'" '
																									+',' +CONCAT('"Target_Object_Name": "' ,COALESCE( @target_object_name ,'')) +'" '
																								--	+',' +CONCAT('"reference_type_name": "' ,COALESCE( @reference_type_name ,'')) +'" ' --V1.3
																										+ '}')
							)

					SET @Returnvalue =2 ;
				END 
				  
		END
	--V1.7 NoofWorkers can be 0, if passed as Null will be treated as 0
	IF(@NoOfWorkers  IS NULL)
			SET @NoOfWorkers =0
			
--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

	IF @Returnvalue = 2 
		RAISERROR('sp_add_process: ERROR - Refer to Process_Error Table .', 16, -1) 

--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				BEGIN TRY 
					BEGIN TRANSACTION
			          
						--Fetch PoolconfigurationId 
						SELECT @PoolConfigurationId= PoolConfigurationDetailsID  FROM ctlfwk.PoolConfigurationDetails
						WHERE PoolName =@PoolName ;
					
						--V1.6
						IF @process_type != 'Ref_Replication'
							BEGIN
								SELECT @target_object_id = target_object_id
								FROM Ctlfwk.target_objects 
								WHERE target_object_name = @target_object_name AND [schema_name] = @schema_name AND notebook_path = @notebook_path AND notebook_name = @notebook_name	--V1.2 replace source_app_id with schema_name, notebook_path & notebook_name in identifying target_object from table						

							END
						ELSE --process_Type = 'Ref_Replication'
							BEGIN
								SELECT @target_object_id = MIN(target_object_id) 
								FROM ctlfwk.target_objects so
								JOIN ctlfwk.load_types lt ON so.load_type_id =lt.load_type_id
								WHERE load_type_code ='R' AND target_object_name = @target_object_name
								AND [Schema_Name] = @Schema_Name AND source_app_id = @source_app_id
							END
	         
						INSERT INTO @InsertedParameterValues
						(  
							process_name
						  , process_name_description 
						  , is_enabled 
						  , stream_name 
						  , process_type 
						  --, source_app_code  
						  , target_object_name
						  --, reference_type_name
						  , PoolName  
						  , NoOfWorkers 
						)
						VALUES 
						(
							 @process_name 
						   , @process_name_description
						   , @is_enabled 
						   , @stream_name 
						   , @process_type 
						   --, @source_app_code 
						   , @target_object_name
						   --, @reference_type_name
						   , @PoolName   
						   , @NoOfWorkers

						)

						INSERT INTO @FinalValues
						(
							  process_name
							, process_name_description 
							, is_enabled 
							, stream_id 
							, process_type_id 
							, source_object_id
							, target_object_id
							, start_date_time 
							, end_date_time 
							, PoolConfigurationDetailsID  
							, NoOfWorkers 
						)
						SELECT 
							  ipv.process_name 
							, ipv.process_name_description 
							, ipv.is_enabled 
							, st.stream_id 
							, pt.process_type_id 
							, NULL
							, @target_object_id
							, GETDATE()
							, '9999-12-31'
							, @PoolConfigurationId    
							, ipv.NoOfWorkers 
						FROM @InsertedParameterValues ipv
						JOIN ctlfwk.stream st ON ipv.stream_name =st.stream_name 
						JOIN ctlfwk.process_type pt ON pt.process_type =ipv.process_type 
						WHERE st.source_app_id = @source_app_id

						--SELECT * from @FinalValues 
		   --=======================================================================================================================
						--Check if ProcessName Already Exists and fetch the Process ID to identify the Insert/Update Action 
						SELECT @processId =Process_id 
						FROM  @FinalValues fv 
						LEFT JOIN ctlfwk.process p ON fv.process_name = p.process_name 
					--SELECT @processId 
			--================================Update  Process Table ==============================================			 
						--Capturing the Merge Action into #MergeActions Table 
						 
						DROP TABLE IF EXISTS #MergeActions ;
						CREATE TABLE #MergeActions ([Action] VARCHAR(10),ProcessId INT)
						
						INSERT INTO #MergeActions ([Action],ProcessId)
						SELECT [Action]  ,process_id
						FROM ( 
						MERGE ctlfwk.process as tgt 
						USING @FinalValues as source ON ( tgt.process_id =ISNULL(@processID,0)						  
							)
						WHEN MATCHED THEN 
							UPDATE 
							SET   tgt.process_name_description =source.process_name_description
								, tgt.is_enabled =source.is_enabled
								, tgt.stream_id =source.stream_id
								, tgt.process_type_id = source.process_type_id
								, tgt.source_object_id =source.source_object_id
								, tgt.target_object_id = source.target_object_id
								, tgt.start_date_time = source.start_date_time 
								, tgt.end_date_time =  source.end_date_time 
								, tgt.Last_Modified_Datetime =SYSDATETIME()
								, tgt.Last_Modified_By = ORIGINAL_LOGIN()

						WHEN NOT MATCHED THEN 
							INSERT ( process_name,process_name_description,is_enabled,stream_id,process_type_id,source_object_id, target_object_id
									, start_date_time,end_date_time,PoolConfigurationDetailsID,NoOfWorkers)
							VALUES ( 
									source.process_name
								, source.process_name_description
								, source.is_enabled
								, source.stream_id
								, source.process_type_id
								, source.source_object_id
								, source.target_object_id
								, source.start_date_time
								, source.end_date_time
								, source.PoolConfigurationDetailsID
								, source.NoOfWorkers
           						)
						   
						OUTPUT
								$action as Action ,
							inserted.process_id
							) MergeOutput 
					--	SELECT * FROM #MergeActions ;    
				COMMIT TRANSACTION	 
			END TRY
        
	  
       
		BEGIN CATCH 
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10),(ERROR_LINE())) + '"}')); 
				ROLLBACK TRANSACTION 
		END CATCH 
	   END  --ReturnValue 0

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_target_process' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
		  END 
	   ELSE 
		  
	      SELECT CONCAT('Process ID ',+CONVERT(VARCHAR,processId)  + ' Is '+Action +'D')  FROM #MergeActions
	 
END


