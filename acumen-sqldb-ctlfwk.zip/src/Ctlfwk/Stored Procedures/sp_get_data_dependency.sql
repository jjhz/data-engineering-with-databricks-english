﻿CREATE PROCEDURE [ctlfwk].[sp_get_data_dependency]
( 
	@PoolConfigurationDetailsID INT = NULL,	
	@EncryptionType VARCHAR(100) = NULL,
	@SourceSystemDatabaseName VARCHAR(100) = NULL,
	@SourceSystemToSparkDataTypeMapping VARCHAR(100) = NULL,
	@SourceObjectName VARCHAR(100) = NULL,
	@ExecutionStatus VARCHAR(100) = NULL,
	@BusinessUnit VARCHAR(100) = NULL,
	@FileSpecificationType INT = NULL,
	@ProcessType VARCHAR(100) = NULL,
	@LoadTypeCode CHAR = NULL,
	@ProcessName VARCHAR(200) = NULL,
	@StreamName VARCHAR(255) = NULL,
	@ShowCount CHAR = 'Y'
)
AS

/*===============================================================================================================================================================================
-- Usage Comments if Any: Returns the dependencies for Master Tables.
	DATE						ChangesMadeBy			VERSION				COMMENTS  
	05-04-2022					Sheela R  				 1.0				InitialVersion.
	21/04/2022					TN & SL					 1.1				Added queries for each master table.
	28/04/2022					SL						 1.2				Added query for SourceSystemDatabaseName.
	28/04/2022					TN						 1.3				Added query for SourceSystemToSparkDataTypeMapping.
	02/05/2022					SL						 1.4				Added ReturnCount flag to display all or row counts.
	17/05/2022					SL						 1.5				Optimised Execution Status query. + static columns to show queried dependency for each Master table.
	17/05/2022					SL						 1.6				Formatted columnames to camelCase. Renamed ReturnCount -> ShowCount. 
		...						...						 ...				Changed parameters to use names instead of IDs. 
		...						...						 ...				Added static column to show queried dependency.
	27/05/2022					TN & SL					 1.7				Added query for process, stream and source object attributes.
	07/06/2022					TN						 1.8				Added SourceToIncoming_FilePath_Dtls dependencies
  ================================================================================================================================================================================ */  

BEGIN
	SET NOCOUNT ON
	DECLARE @ret_status VARCHAR(100)
	
	IF @SourceObjectName IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
		SELECT DISTINCT
			@SourceObjectName AS dependency,
			soa.source_object_attribute_name AS sourceObjectAttributeName,
			p.process_name AS processName,
			ps.process_id AS processId,
			sfpd.source_object_id AS sourceobjectfilepath
		FROM [ctlfwk].[source_objects] so
			INNER JOIN [ctlfwk].[source_objects_attributes] soa ON so.source_object_id = soa.source_object_id
			INNER JOIN [ctlfwk].[process] p ON soa.source_object_id = p.source_object_id
			INNER JOIN [ctlfwk].[process_status] ps ON p.process_id = ps.process_id
			INNER JOIN [ctlfwk].[SourceToIncoming_FilePath_Dtls] sfpd ON so.source_object_id = sfpd.source_object_id
		WHERE so.source_object_name = @SourceObjectName
		END

		IF @ShowCount = 'Y'
		BEGIN
		SELECT
			@SourceObjectName AS dependency,
			COUNT(DISTINCT soa.source_object_attribute_name) AS sourceObjectAttributeName,
			COUNT(DISTINCT p.process_name) AS processes,
			COUNT(DISTINCT ps.process_id) AS processId,
			COUNT(DISTINCT sfpd.source_object_id) AS sourceobjectfilepath
		FROM [ctlfwk].[source_objects] so
			INNER JOIN [ctlfwk].[source_objects_attributes] soa ON so.source_object_id = soa.source_object_id
			INNER JOIN [ctlfwk].[process] p ON soa.source_object_id = p.source_object_id
			INNER JOIN [ctlfwk].[process_status] ps ON p.process_id = ps.process_id
			INNER JOIN [ctlfwk].[SourceToIncoming_FilePath_Dtls] sfpd ON so.source_object_id = sfpd.source_object_id
		WHERE so.source_object_name = @SourceObjectName
		END
	END

	IF @StreamName IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
			SELECT DISTINCT
				@StreamName AS dependency,
				p.process_name AS processName,
				s.stream_id AS streamId,
				ss.stream_status_id AS streamStatusId,
				ss_log.stream_status_id AS streamLogStatusId
			FROM
				ctlfwk.stream as s
					INNER JOIN ctlfwk.process AS p ON p.stream_id = s.stream_id
					INNER JOIN ctlfwk.stream_status AS ss ON ss.stream_id = s.stream_id
					INNER JOIN ctlfwk.stream_status_log AS ss_log ON ss_log.stream_id = s.stream_id
			WHERE s.stream_name = @StreamName
		END

		IF @ShowCount = 'Y'
		BEGIN
			SELECT
				@StreamName AS dependency,
				COUNT(DISTINCT p.process_name) AS processNameCount,
				COUNT(DISTINCT s.stream_id) AS streamIdCount,
				COUNT(DISTINCT ss.stream_status_id) AS streamStatusIdCount,
				COUNT(DISTINCT ss_log.stream_status_id) AS streamLogStatusIdCount
			FROM
				ctlfwk.stream as s
					INNER JOIN ctlfwk.process AS p ON p.stream_id = s.stream_id
					INNER JOIN ctlfwk.stream_status AS ss ON ss.stream_id = s.stream_id
					INNER JOIN ctlfwk.stream_status_log AS ss_log ON ss_log.stream_id = s.stream_id
			WHERE s.stream_name = @StreamName
		END
	END

	IF @ProcessName IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
		SELECT DISTINCT
			@ProcessName AS dependency,
			p.process_id AS processId,
			ps.process_status_id as processStatusId,
			psl.process_status_id as processStatusIdLog
		FROM
			ctlfwk.process AS p
				INNER JOIN ctlfwk.process_status as ps ON ps.process_id = p.process_id
				INNER JOIN ctlfwk.process_status_log as psl ON psl.process_id = p.process_id
		WHERE
			process_name = @ProcessName
		END

		IF @ShowCount = 'Y'
		BEGIN
		SELECT
			@ProcessName AS dependency,
			COUNT(DISTINCT p.process_id) AS processIdCount,
			COUNT(DISTINCT ps.process_status_id) as processStatusIdCount,
			COUNT(DISTINCT psl.process_status_id) as processStatusIdLogCount
		FROM
			ctlfwk.process AS p
				INNER JOIN ctlfwk.process_status as ps ON ps.process_id = p.process_id
				INNER JOIN ctlfwk.process_status_log as psl ON psl.process_id = p.process_id
		WHERE
			process_name = @ProcessName
		END
	END


	IF @BusinessUnit IS NOT NULL 
	BEGIN 
		IF @ShowCount = 'N'
		BEGIN
			-- View all business unit dependencies
			SELECT DISTINCT
				@BusinessUnit AS dependency,
				sa.source_app_name AS sourceAppName,
				so.source_object_name AS sourceObjectName,
				soa.source_object_attribute_name AS sourceObjectAttributeName,
				file_type.File_Pattern_Name AS filePatternName,
				procs.process_name AS processName,
				procs_status.process_status_id AS processStatusId,
				procs_status_l.process_status_id AS processStatusLogId,
				stream.stream_name AS streamName,
				stream_status.stream_status_id AS streamStatusId,
				stream_status_l.stream_status_id AS streamStatusLogId
			FROM ctlfwk.source_app sa
				INNER JOIN [ctlfwk].[business_unit] bu ON sa.business_unit_id = bu.business_unit_id
				INNER JOIN [ctlfwk].[source_objects] so ON sa.source_app_id = so.source_app_id
				INNER JOIN [ctlfwk].[process] procs ON so.source_object_id = procs.source_object_id
				INNER JOIN [ctlfwk].[source_objects_attributes] soa ON so.source_object_id = soa.source_object_id
				INNER JOIN [ctlfwk].[File_Specification_Type] file_type ON so.File_Specification_Type_Id = file_type.File_Specification_Type_Id
				INNER JOIN [ctlfwk].[process_status] procs_status ON procs.process_id = procs_status.process_id
				INNER JOIN [ctlfwk].[process_status_log] procs_status_l ON procs.process_id = procs_status_l.process_id
				INNER JOIN [ctlfwk].[stream] stream ON so.source_app_id = stream.source_app_id
				INNER JOIN [ctlfwk].[stream_status] stream_status ON stream.stream_id = stream_status.stream_id
				INNER JOIN [ctlfwk].[stream_status_log] stream_status_l ON stream.stream_id = stream_status_l.stream_id
			WHERE business_unit_name_code = @BusinessUnit
		END

		IF @ShowCount = 'Y'
		BEGIN
			--  Count the business unit dependencies
			SELECT
				@BusinessUnit AS dependency,
				COUNT(DISTINCT sa.source_app_name) AS sourceAppNameCount,
				COUNT(DISTINCT so.source_object_name) AS sourceObjectNameCount,
				COUNT(DISTINCT soa.source_object_attribute_name) AS sourceObjectAttributeNameCount,
				COUNT(DISTINCT file_type.File_Pattern_Name) AS filePatternNameCount,
				COUNT(DISTINCT procs.process_name) AS processNameCount,
				COUNT(DISTINCT procs_status.process_status_id) AS processStatusIdCount,
				COUNT(DISTINCT procs_status_l.process_status_id) AS processStatusLogIdCount,
				COUNT(DISTINCT stream.stream_name) AS streamNameCount,
				COUNT(DISTINCT stream_status.stream_status_id) AS streamStatusIdCount,
				COUNT(DISTINCT stream_status_l.stream_status_id) AS streamStatusLogIdCount
			FROM ctlfwk.source_app sa
				INNER JOIN [ctlfwk].[business_unit] bu ON sa.business_unit_id = bu.business_unit_id
				INNER JOIN [ctlfwk].[source_objects] so ON sa.source_app_id = so.source_app_id
				INNER JOIN [ctlfwk].[process] procs ON so.source_object_id = procs.source_object_id
				INNER JOIN [ctlfwk].[source_objects_attributes] soa ON so.source_object_id = soa.source_object_id
				INNER JOIN [ctlfwk].[File_Specification_Type] file_type ON so.File_Specification_Type_Id = file_type.File_Specification_Type_Id
				INNER JOIN [ctlfwk].[process_status] procs_status ON procs.process_id = procs_status.process_id
				INNER JOIN [ctlfwk].[process_status_log] procs_status_l ON procs.process_id = procs_status_l.process_id
				INNER JOIN [ctlfwk].[stream] stream ON so.source_app_id = stream.source_app_id
				INNER JOIN [ctlfwk].[stream_status] stream_status ON stream.stream_id = stream_status.stream_id
				INNER JOIN [ctlfwk].[stream_status_log] stream_status_l ON stream.stream_id = stream_status_l.stream_id
			WHERE business_unit_name_code = @BusinessUnit
		END
	END 

   --To Delete Encryption - delete the source_object_attributes
	IF @EncryptionType IS NOT NULL 
	BEGIN 
		IF @ShowCount = 'N'
		BEGIN
			SELECT
				@EncryptionType AS dependency,
				sa.source_app_code AS sourceAppCode,
				source_object_name AS sourceObjectName,
				source_object_attribute_name AS sourceObjectAttributeName
			FROM [ctlfwk].[source_objects] so
				INNER JOIN [ctlfwk].[source_app] sa ON so.source_app_id = sa.source_app_id
				INNER JOIN [ctlfwk].[source_objects_attributes]  soa ON soa.source_object_id = so.source_object_id
				INNER JOIN [ctlfwk].[Encryption_Types] et ON et.Encryption_TypeID = soa.Encryption_TypeID 
			WHERE et.Encryption_Type = @EncryptionType
		END

		IF @ShowCount = 'Y'
		BEGIN
			--  View all encryption type dependencies
			SELECT
				@EncryptionType AS dependency,
				COUNT(DISTINCT sa.source_app_code) AS sourceAppCodeCount,
				COUNT(DISTINCT so.source_object_name) AS sourceObjectNameCount,
				COUNT(DISTINCT soa.source_object_attribute_name) AS sourceObjectAttributeNameCount
			FROM [ctlfwk].[source_objects] so
				INNER JOIN [ctlfwk].[source_app] sa ON so.source_app_id = sa.source_app_id
				INNER JOIN [ctlfwk].[source_objects_attributes]  soa ON soa.source_object_id =so.source_object_id
				INNER JOIN [ctlfwk].[Encryption_Types] et ON et.Encryption_TypeID =soa.Encryption_TypeID 
			WHERE et.Encryption_Type = @EncryptionType 
		END
	END 


	IF @ExecutionStatus IS NOT NULL 
	BEGIN
		IF @ShowCount = 'Y'
		BEGIN
			WITH ps AS (
				SELECT DISTINCT 
					es.execution_status_name AS executionStatusName,
					COUNT(DISTINCT ps.process_id) as processes
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.process_status ps ON es.execution_status_id = ps.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
				GROUP BY es.execution_status_name
			), 
			ss AS (
				SELECT DISTINCT 
					es.execution_status_name,
					COUNT(DISTINCT ss.stream_id) as streams
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.stream_status ss ON es.execution_status_id = ss.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
				GROUP BY es.execution_status_name
			), 
			psl AS (
				SELECT DISTINCT 
					es.execution_status_name,
					COUNT(DISTINCT psl.process_status_id) as processes_log
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.process_status_log psl ON es.execution_status_id = psl.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
				GROUP BY es.execution_status_name
			),
			ss_log AS (
				SELECT DISTINCT
					es.execution_status_name,
					COUNT(DISTINCT ss_log.stream_id) AS streamLog
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.stream_status_log ss_log ON es.execution_status_id = ss_log.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
				GROUP BY es.execution_status_name
			)
			SELECT 
				ps.*, 
				ss.streams, 
				psl.processes_log AS processesLog,
				ss_log.streamLog
			FROM ps, ss, psl, ss_log
		END
	
		IF @ShowCount = 'N'
		BEGIN
			WITH ps AS (
				SELECT DISTINCT 
					es.execution_status_name AS executionStatusName,
					ps.process_id as processes
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.process_status ps ON es.execution_status_id = ps.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
			),
			ss AS (
				SELECT DISTINCT 
					es.execution_status_name,
					ss.stream_id as streams
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.stream_status ss ON es.execution_status_id = ss.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
			),
			psl AS (
				SELECT DISTINCT 
					es.execution_status_name,
					psl.process_status_id as processes_log
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.process_status_log psl ON es.execution_status_id = psl.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
			),
			ss_log AS (
				SELECT DISTINCT
					es.execution_status_name,
					ss_log.stream_id AS streamLog
				FROM ctlfwk.execution_status es
					INNER JOIN ctlfwk.stream_status_log ss_log ON es.execution_status_id = ss_log.execution_status_id
				WHERE es.execution_status_name = @ExecutionStatus
			)
			SELECT 
				ps.*, 
				ss.streams, 
				psl.processes_log AS processesLog
			FROM ps, ss, psl
		END
	END


	IF @FileSpecificationType IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
			--  View all file specification type dependencies
			SELECT DISTINCT
				@FileSpecificationType AS dependency,
				soa.source_object_attribute_name AS sourceObjectAttributes,
				p.process_name AS processes,
				so.source_object_name AS sourceObjects
			FROM ctlfwk.source_objects so
				INNER JOIN ctlfwk.process p ON so.source_object_id = p.source_object_id
				INNER JOIN ctlfwk.source_objects_attributes soa ON so.source_object_id = soa.source_object_id
			WHERE so.File_Specification_Type_Id = @FileSpecificationType
		END

		IF @ShowCount = 'Y'
		BEGIN
			--  Count the file specification type dependencies
			SELECT
				@FileSpecificationType AS dependency,
				COUNT(DISTINCT soa.source_object_attribute_name) AS sourceObjectAttributesCount,
				COUNT(DISTINCT p.process_name) AS processesCount,
				COUNT(DISTINCT so.source_object_name) AS sourceObjectsCount
			FROM ctlfwk.source_objects so
				INNER JOIN ctlfwk.process p ON so.source_object_id = p.source_object_id
				INNER JOIN ctlfwk.source_objects_attributes soa ON so.source_object_id = soa.source_object_id
			WHERE so.File_Specification_Type_Id = @FileSpecificationType
		END
	END

	IF @LoadTypeCode IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
			--  View all load type dependencies
			SELECT DISTINCT
				@LoadTypeCode AS dependency,
				soa.source_object_attribute_name AS sourceObjectAttributes,
				p.process_name AS processes,
				so.source_object_name AS sourceObjects,
				sfpd.load_type_id AS loadTypeFilePath
			FROM ctlfwk.source_objects so
				INNER JOIN ctlfwk.load_types lt ON lt.load_type_id = so.load_type_id
				INNER JOIN ctlfwk.process p ON so.source_object_id = p.source_object_id
				INNER JOIN ctlfwk.source_objects_attributes soa ON so.source_object_id = soa.source_object_id
				INNER JOIN [ctlfwk].[SourceToIncoming_FilePath_Dtls] sfpd ON lt.load_type_id = sfpd.load_type_id
			WHERE lt.load_type_code = @LoadTypeCode
		END

		IF @ShowCount = 'Y'
		BEGIN
			--  Count the load type dependencies
			SELECT
				@LoadTypeCode AS dependency,
				COUNT(DISTINCT lt.load_type_code) AS loadTypeCodeCount,
				COUNT(DISTINCT soa.source_object_attribute_name) AS sourceObjectAttributesCount,
				COUNT(DISTINCT p.process_name) AS processesCount,
				COUNT(DISTINCT so.source_object_name) AS sourceObjectsCount,
				COUNT(DISTINCT sfpd.load_type_id) AS loadTypeFilePath
			FROM ctlfwk.source_objects so
				INNER JOIN ctlfwk.load_types lt ON lt.load_type_id = so.load_type_id
				INNER JOIN ctlfwk.process p ON so.source_object_id = p.source_object_id
				INNER JOIN ctlfwk.source_objects_attributes soa ON so.source_object_id = soa.source_object_id
				INNER JOIN [ctlfwk].[SourceToIncoming_FilePath_Dtls] sfpd ON lt.load_type_id = sfpd.load_type_id
			WHERE lt.load_type_code = @LoadTypeCode
		END
	END

	IF @PoolConfigurationDetailsID IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
			--  View all pool configuration dependencies
			SELECT DISTINCT
				@PoolConfigurationDetailsID AS dependency,
				p.process_name AS processes
			FROM ctlfwk.process p
				INNER JOIN ctlfwk.PoolConfigurationDetails pcd ON pcd.PoolConfigurationDetailsID = p.PoolConfigurationDetailsID
			WHERE p.PoolConfigurationDetailsID = @PoolConfigurationDetailsID
		END

		IF @ShowCount = 'Y'
		BEGIN
			--  Count the pool configuration dependencies
			SELECT
				@PoolConfigurationDetailsID AS dependency,
				COUNT(DISTINCT p.process_name) AS processesCount
			FROM ctlfwk.process p
				INNER JOIN ctlfwk.PoolConfigurationDetails pcd ON pcd.PoolConfigurationDetailsID = p.PoolConfigurationDetailsID
			WHERE p.PoolConfigurationDetailsID = @PoolConfigurationDetailsID
		END
	END

	IF @ProcessType IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
			--  View all process type dependencies
			SELECT DISTINCT
				@ProcessType AS dependency,
				p.process_name AS processes
			FROM ctlfwk.process p
				INNER JOIN ctlfwk.process_type pt ON pt.process_type_id = p.process_type_id
			WHERE pt.process_type = @ProcessType
		END

		IF @ShowCount = 'Y'
		BEGIN
			--  Count the process type dependencies
			SELECT
				@ProcessType AS dependency,
				COUNT(DISTINCT p.process_name) AS processesCount
			FROM ctlfwk.process p
				INNER JOIN ctlfwk.process_type pt ON pt.process_type_id = p.process_type_id
			WHERE pt.process_type = @ProcessType
		END
	END

	IF @SourceSystemDatabaseName IS NOT NULL
	BEGIN
		IF @ShowCount = 'N'
		BEGIN
			-- View SourceSystemDatabaseName dependencies
			SELECT 
				@SourceSystemDatabaseName AS dependency,
				ssdn.SourceSystemDatabaseName_ID AS sourceSystemDatabaseId,
				sa.source_app_id AS sourceAppId,
				sa.source_app_name AS sourceAppName,
				sa.source_app_code AS sourceAppCode,
				sa.business_unit_id AS businessUnitId
			FROM ctlfwk.SourceSystemDatabaseName AS ssdn
				INNER JOIN [ctlfwk].[source_app] AS sa ON sa.SourceSystemDatabaseName_ID = ssdn.SourceSystemDatabaseName_ID
			WHERE ssdn.SourceSystemDatabaseName = @SourceSystemDatabaseName
		END

		IF @ShowCount = 'Y'
		BEGIN
			-- Count the SourceSystemDatabaseName dependencies
			SELECT
				@SourceSystemDatabaseName AS dependency,
				COUNT(DISTINCT ssdn.SourceSystemDatabaseName_ID) AS sourceSystemDatabaseIdCount,
				COUNT(DISTINCT sa.source_app_id) AS sourceAppIdCount,
				COUNT(DISTINCT sa.source_app_name) AS sourceAppNameCount,
				COUNT(DISTINCT sa.source_app_code) AS sourceAppCodeCount,
				COUNT(DISTINCT sa.business_unit_id) AS businessUnitIdCount
			FROM ctlfwk.SourceSystemDatabaseName AS ssdn
				INNER JOIN [ctlfwk].[source_app] AS sa ON sa.SourceSystemDatabaseName_ID = ssdn.SourceSystemDatabaseName_ID
			WHERE ssdn.SourceSystemDatabaseName = @SourceSystemDatabaseName
			GROUP BY SourceSystemDatabaseName
		END
	END


	IF @SourceSystemToSparkDataTypeMapping IS NOT NULL
	BEGIN
		IF @ShowCount = 'Y'
		BEGIN
			SELECT 
				COUNT(DISTINCT source_object_id) AS sourceObjectId,
				COUNT(DISTINCT source_object_attribute_name) AS sourceObjectAttributeName
			FROM ctlfwk.source_objects_attributes
			WHERE source_object_attribute_data_type = @SourceSystemToSparkDataTypeMapping
		END

		IF @ShowCount = 'N'
		BEGIN
			SELECT
				source_object_id AS sourceObjectIdCount,
				source_object_attribute_name AS sourceObjectAttributeNameCount
			FROM ctlfwk.source_objects_attributes
			WHERE source_object_attribute_data_type = @SourceSystemToSparkDataTypeMapping
		END
	END


/*
EXEC [ctlfwk].[sp_get_MasterData_Depenedency]
   @EncryptionType  ='DET'
   --@BusinessUnit  = 'Common'
   --@SouceApp  =''

*/
END
