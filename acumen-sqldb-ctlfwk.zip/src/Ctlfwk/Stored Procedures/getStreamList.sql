﻿
CREATE PROCEDURE [Ctlfwk].[getStreamList]
( 
  @sourceappname VARCHAR(100),
  @sourcesystemname VARCHAR(100)
)
AS

BEGIN

SET NOCOUNT ON

SELECT stream_name FROM ctlfwk.vw_stream where source_app_name = @sourceappname  AND business_unit_name_code= @sourcesystemname
End;