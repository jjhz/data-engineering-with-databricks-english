﻿CREATE PROCEDURE [ctlfwk].[sp_Ops_DeleteProcessStatus]
(
	--V1.1 Modified the order of Input 
	@process_name varchar(200) ,
	@delete_process_status char(1),  --Y/N
	@delete_process_status_log char(1) = NULL --Y/N
)
AS

/* =============================================================================================================================================================

If process_status = Y and process_status_log = NULL then delete process_status 
If process_status = N and process_status_log = Y then delete process_status_log 
If process_status = Y and process_status_log = Y then delete process_status and process_status_log 
(THE ABOVE COMBINATION OF PARAMETERS CAN CLEAR THE ENTIRE LOG HISTORY AND ENABLE A NEW RELOAD OF INGESTION OR EXTRACTION)
If process_status = N and process_status_log = N/NULL then error "Status and status_log records will not be deleted due to given inputs"

Usage Comments if Any :Delete process_status and process_status_log for given process_name  
DATE							ChangesMadeBy			VERSION				COMMENTS  
08-04-2022						Niharika S				 1.0				InitialVersion

-- ========================================================================================================================================================*/

BEGIN 
	declare @ErrorUDT [ctlfwk].[ErrorUDT]
	declare @Returnvalue INT = 0

	IF NOT EXISTS ( SELECT 1 
						FROM ctlfwk.process 
						WHERE process_name = @process_name ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Process name does not exist',	(N'{'+CONCAT('"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
																	+'}' )
				);
				SET @Returnvalue =2 ;
			END

	IF (@delete_process_status NOT IN ('Y', 'N') OR @delete_process_status IS NULL) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Delete_process_status can only have value Y or N', (N'{'+CONCAT('"Delete_Process_Status": "',COALESCE(@delete_process_status ,''))  +'" '
																								+'}' )
			);
			SET @Returnvalue =2 ;
		END

	IF (@delete_process_status = 'N' AND (@delete_process_status_log = 'N' or @delete_process_status_log is NULL)) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Delete_process_status and delete_process_status_log records will not be deleted due to given inputs', (N'{'+CONCAT('"Delete_Process_Status": "',COALESCE(@delete_process_status ,''))  +'" '
																																	 +','+CONCAT('"Delete_Process_Status_Log": "',COALESCE( @delete_process_status_log ,''))  +'" '
																																	 +'}' )
			);
			SET @Returnvalue =2 ;
		END
		
	IF @Returnvalue = 2 
			RAISERROR('sp_Ops_DeleteProcessStatus: ERROR - Refer to Process_Error Table .', 16, -1)

	IF @Returnvalue = 0
			BEGIN --Returnvalue0
				BEGIN TRY
					BEGIN TRANSACTION 
					declare @process_id INT
					SET @process_id=(Select process_id from ctlfwk.process where process_name = @process_name)

					IF (@delete_process_status = 'Y' AND (@delete_process_status_log = 'N' OR @delete_process_status_log IS NULL))
						BEGIN
							DELETE FROM ctlfwk.process_status WHERE process_id = @process_id
						END
					
					IF (@delete_process_status = 'N' AND @delete_process_status_log = 'Y') 
						BEGIN
							DELETE FROM ctlfwk.process_status_log WHERE process_id = @process_id
						END

					IF (@delete_process_status = 'Y' AND @delete_process_status_log = 'Y') 
						BEGIN
							DELETE FROM ctlfwk.process_status WHERE process_id = @process_id
							DELETE FROM ctlfwk.process_status_log WHERE process_id = @process_id
						END
					COMMIT TRANSACTION;
				END TRY

			BEGIN CATCH
		
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION

			END CATCH
			END --Returnvalue0

	IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_Ops_DeleteProcessStatus' 
					FROM @ErrorUDT; 
				
					SELECT * FROM @ErrorUDT 
				END
/* 
EXEC [ctlfwk].[sp_Ops_DeleteProcessStatus] 
	@process_name = 'Hugo_Uplift_Bronze_Person_Membership',
	@delete_process_status = 'Y',
	@delete_process_status_log = NULL
*/

END
