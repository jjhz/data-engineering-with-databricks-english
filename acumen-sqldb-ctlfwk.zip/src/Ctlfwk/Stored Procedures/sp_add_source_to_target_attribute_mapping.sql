CREATE PROCEDURE [ctlfwk].[sp_add_Source_To_Target_Attribute_Mapping]
(      @Target_Schema              Varchar(100)
      ,@Target_Object			   Varchar(100)
      ,@Target_Attribute_Name	   Varchar(100)
      ,@Target_Object_Type		   Varchar(100)
      ,@Source_Schema			   Varchar(100)
      ,@Source_Object			   Varchar(100)
      ,@Source_Attribute_Name	   Varchar(100)
      ,@Column_Sequence			   INT
      ,@Attribute_IS_BK			   Varchar(100)
      
)
AS

/* ==================================================================================================================================================
-- Usage Comments if Any : Used to add/update Source to Target Attribute Mapping
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte				 1.0				InitialVersion
	09-09-2021						Tammy H 				 1.1				New set of unique columns to define existing entry (Target_Schema, Target_Object_ID, Source_Schema, Source_Object_ID, Column Sequence). 
																				Also, making changes to allow updates to existing records and to capture errors/validations/insert/update.
																				**Validations**
																				Error message will be provided when:
																				1. Source_Object provided does not exist in ctlfwk.source_objects
																				2. Target_Object provided does not exist in ctlfwk.source_objects
																				3. Source_Object and Source_attribute_name does not exist together
																				4. Target_Object and Target_attribute_name does not exist together
																				5. For given Source_Object, Target_Object, Source_Schema, Target_Schema, Source_Attribute_Name, Targer_Attribute_Name, the Column_Sequence already exists
																				6. Source_To_Targeting_Mapping_ID does not exist for provided Source_Object, Source_Schema, Target_Object, Target_Schema
																				7. Given Target_Object, Target_Schema, Source_Object, Source_Schema, new record to be inserted must have Column_Sequence value that is the next consecutive value of existing record. If no exisiting record, then column_sequence should be 1
																				**Insert**
																				1. Occurs when record does not exist containing the unique column set provided AND passes all the Validation checks
																				2. Source_To_Target_Mapping_ID will be taken from Ctlfwk.Source_To_Target_Mapping given Source_Object and Target_Object
																				3. If an insert happens, a message contained the inserted Source_To_Target_Mapping_ID number and action "inserted" will appear
																				**Update**
																				1. Occurs when record contains the unique column set already AND passes all Validation checks
																				2. If an update happens, a message containing the updated Source_To_Target_Mapping_ID number and the action "updated" will appear.
	15-09-2021						Tammy H					 1.2			    Capture Error into ctrlfwk.process_errors and key Input Parameters of Error as JSON

-- ===================================================================================================================================================  */

BEGIN


	SET NOCOUNT ON;

    DECLARE @Source_object_id INT
    DECLARE @Target_object_id INT
    DECLARE @Source_To_Target_Mapping_Id INT
	-- Table Variable to Capture Error/Actions 
	DECLARE @ExistingSequence INT
	DECLARE @CurrentMaxSeq INT
	DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	DECLARE @Returnvalue INT = 0 --Success 

--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
		
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_objects WHERE Source_Object_name = @source_object ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Source_Object does not exist',	(N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
																					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
																					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
																					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
																					+','+CONCAT('"Column_Sequence": "',COALESCE(@Column_Sequence ,''))  +'" '
																					+'}' )
				);
			END  
	   
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_objects  WHERE Source_Object_name = @target_object ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Target_Object does not exist', (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
																					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
																					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
																					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
																					+','+CONCAT('"Column_Sequence": "',COALESCE(@Column_Sequence ,''))  +'" '
																					+'}' )
				);
				SET @Returnvalue =2 ;
			END

		IF NOT EXISTS ( SELECT 1 FROM (ctlfwk.source_objects AS so 
										INNER JOIN ctlfwk.source_objects_attributes AS soa
										ON so.source_object_id = soa.source_object_id)
										WHERE source_object_name = @source_object
										AND source_object_attribute_name = @source_attribute_name) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Source_Object) and Source_Attribute_Name provided does not exist together'
					, (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
					+','+CONCAT('"Column_Sequence": "',COALESCE(@Column_Sequence ,''))  +'" '
					+','+CONCAT('"Source_Attribute_Name": "',COALESCE( @Source_Attribute_Name ,''))  +'" '
					+'}' )
				);
				SET @Returnvalue =2 ;
			END

		IF NOT EXISTS ( SELECT 1 FROM (ctlfwk.source_objects AS so 
										INNER JOIN ctlfwk.source_objects_attributes AS soa 
										ON so.source_object_id = soa.source_object_id)
										WHERE source_object_name = @target_object
										AND source_object_attribute_name = @Target_Attribute_Name) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Target_Object) and Target_Attribute_Name does not exist together'
					, (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
					+','+CONCAT('"Column_Sequence": "',COALESCE(@Column_Sequence ,''))  +'" '
					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @Target_Attribute_Name ,''))  +'" '
					+'}' )
				);
				SET @Returnvalue =2 ;
			END 


	   IF EXISTS ( SELECT 1 FROM ctlfwk.Source_To_Target_Attribute_Mapping  WHERE Source_Object = @Source_object
																	and Target_Object = @Target_object
																	and Target_Schema = @Target_Schema
																	and Source_Schema = @Source_Schema
																	and Source_Attribute_Name = @Source_Attribute_Name
																	and Target_Attribute_Name = @Target_Attribute_Name
																	) 
	   AND NOT EXISTS ( SELECT 1 FROM ctlfwk.Source_To_Target_Attribute_Mapping  WHERE Source_Object = @Source_object
																	and Target_Object = @Target_object
																	and Target_Schema = @Target_Schema
																	and Source_Schema = @Source_Schema
																	and Source_Attribute_Name = @Source_Attribute_Name
																	and Target_Attribute_Name = @Target_Attribute_Name
																	and Column_Sequence = @Column_Sequence
																	) 	   		
			
		   BEGIN 
			   SELECT @ExistingSequence = Column_Sequence FROM [ctlfwk].[Source_To_Target_Attribute_Mapping] WHERE Source_Object = @Source_object
																												and Target_Object = @Target_object
																												and Target_Schema = @Target_Schema
																												and Source_Schema = @Source_Schema
																								
			   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			   VALUES ('Error', 'The Column_Sequence provided already exists with value ' + CONVERT(VARCHAR, @ExistingSequence) + ', given Source_Object, Target_Object, Source_Schema, Target_Schema, Source_Attribute_Name, Target_Attribute_Name'
					, (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
						+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
						+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
						+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
						+','+CONCAT('"Column_Sequence": "',COALESCE(@Column_Sequence ,''))  +'" '
						+','+CONCAT('"Source_Attribute_Name": "',COALESCE( @Source_Attribute_Name ,''))  +'" '
						+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @Target_Attribute_Name ,''))  +'" '
						+'}' )
				);
			   SET @Returnvalue =2 ;
		   END 

		IF NOT EXISTS ( SELECT 1 FROM Ctlfwk.Source_To_Target_Mapping 
						WHERE Source_Object = @Source_Object
						and Target_Object = @Target_Object 
						and Target_Schema =@Target_Schema 
						and Source_Schema =@Source_Schema 
						)
			BEGIN
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Source_To_Targeting_Mapping_ID does not exist for provided Source_Object, Source_Schema, Target_Object, Target_Schema', (SELECT N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
																																							+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
																																							+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
																																							+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
																																							+','+CONCAT('"Column_Sequence": "',COALESCE(@Column_Sequence ,''))  +'" '
																																							+'}' )
				); 
				SET @Returnvalue =2 ;
			END
		ELSE
			BEGIN
				SELECT @CurrentMaxSeq = COALESCE(MAX(Column_Sequence),0) FROM Source_To_Target_Attribute_Mapping WHERE Source_Object = @Source_object
																							AND Target_Object = @Target_object
																							AND Source_Schema = @Source_Schema
																							AND Target_Schema = @Target_Schema
				
				IF NOT EXISTS (SELECT 1
								FROM Ctlfwk.Source_To_Target_Attribute_Mapping 
								WHERE Source_Object = @Source_object
								AND Target_Object = @Target_object
								AND Source_Schema = @Source_Schema
								AND Target_Schema = @Target_Schema
								AND Column_Sequence = @Column_Sequence)
					AND (@Column_Sequence != @CurrentMaxSeq + 1) 
					BEGIN
						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						VALUES ('Error', 'Column_Sequence provided is incorrect. For given Target_Object, Target_Schema, Source_Object, Source_Schema, new record to be inserted must have Column_Sequence = ' +  CONVERT(Varchar, @CurrentMaxSeq +1),
							(N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
							+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
							+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
							+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
							+','+CONCAT('"Column_Sequence": "',COALESCE(@Column_Sequence ,''))  +'" '
							+'}' )
						); 
						SET @Returnvalue =2 ;
					END 
			END

	
--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

	
		
		-- If No Errors
		IF @Returnvalue =0
			BEGIN --ReturnValue 0
				SELECT @Source_object_id = Source_object_id  from Ctlfwk.source_objects  where Source_Object_name = @source_object
				SELECT @Target_object_id = Source_object_id from Ctlfwk.source_objects  where Source_Object_name = @target_object

				BEGIN TRY
					BEGIN TRANSACTION
						--Capturing the Action into #Actions Table 
						DROP TABLE IF EXISTS #ActionTable;
						CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT)		

					   --check if record exists, if not, insert the row
					   --source object could have multiple load types						
						IF (NOT EXISTS 
								(
								SELECT 1
								FROM Ctlfwk.Source_To_Target_Attribute_Mapping so
								WHERE so.Source_Object_ID = @Source_object_id
								AND so.Target_Object_ID = @Target_object_id
								AND so.Source_Schema = @Source_Schema
								AND so.Target_Schema = @Target_Schema
								AND so.Column_Sequence = @Column_Sequence
								)
							)
							BEGIN
							
							SELECT @Source_To_Target_Mapping_Id = Source_To_Target_Mapping_Id FROM Ctlfwk.Source_To_Target_Mapping so 
																								WHERE so.Source_Object = @Source_Object
																								and so.Target_Object = @Target_Object
								
								-- Insert record
								INSERT INTO Ctlfwk.Source_To_Target_Attribute_Mapping
									(Source_To_Target_Mapping_ID
									,Target_Object_ID
									,Target_Schema
									,Target_Object
									,Target_Attribute_Name
									,Target_Object_Type
									,Source_Object_ID
									,Source_Schema
									,Source_Object
									,Source_Attribute_Name
									,Column_Sequence
									,Attribute_IS_BK
									)
									OUTPUT 'Inserted', inserted.Source_To_Target_Mapping_ID
									INTO #ActionTable (Act, Id)
									VALUES
									(
									@Source_To_Target_Mapping_ID
									,@Target_Object_ID
									,@Target_Schema
									,@Target_Object
									,@Target_Attribute_Name
									,@Target_Object_Type
									,@Source_Object_ID
									,@Source_Schema
									,@Source_Object
									,@Source_Attribute_Name
									,@Column_Sequence
									,@Attribute_IS_BK
									)
							END
						ELSE
							
							BEGIN

								--Update Record
								UPDATE Ctlfwk.Source_To_Target_Attribute_Mapping
									SET Target_Attribute_Name = @Target_Attribute_Name
									,@Target_Object_Type = @Target_Object_Type
									,Source_Attribute_Name = @Source_Attribute_Name
									,Attribute_IS_BK= @Attribute_IS_BK
									,Last_Modified_Datetime = SYSDATETIME()
									,Last_Modified_By = ORIGINAL_LOGIN()
									OUTPUT 'Updated', inserted.Source_To_Target_Mapping_ID
									INTO #ActionTable (Act, Id)
									WHERE @Source_To_Target_Mapping_Id = @Source_To_Target_Mapping_ID
									AND Target_Object_ID = @Target_Object_ID 
									AND Target_Schema = @Target_Schema
									AND Source_Object_ID = @Source_Object_ID
									AND Source_Schema = @Source_Schema
									AND Column_Sequence = @Column_Sequence
							END

					COMMIT TRANSACTION

				END TRY
				BEGIN CATCH
					INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
					ROLLBACK TRANSACTION 
				END CATCH

			END -- Retun Value 0

		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) --V1.2
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Source_To_Target_Attribute_Mapping' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
			END
			 
		ELSE 
			SELECT CONCAT('Source_To_Target_Mapping_ID ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 
END --end