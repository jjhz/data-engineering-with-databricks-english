﻿-- =============================================
-- Author:      Deloitte
-- Create date: 20/07/2020
-- Description: Adds and updates records in ctlfwk.source_objects table
--
-- Parameters:
--   @source_app_code - unique source app code from ctlfwk.source_app
--   @source_object_name - name of source object
--	 @source_object_description - description of source object
--	 @load_type_code - unique load type code from ctlfwk.load_types
--	 @is_file_mandatory - flag for mandatory files in incoming container
--	 @Schema_Name - flag for source object being Insert/Update/Delete
-- =============================================

CREATE PROCEDURE [Ctlfwk].[sp_add_source_objects_spfl]
(
	@source_app_code varchar(25)
,	@source_object_name varchar(100)
,	@source_object_description varchar(100)
,	@load_type_code varchar(5)
,	@is_file_mandatory bit = 0
,	@Schema_Name	varchar(50) = NULL
)
AS
BEGIN


set nocount on;
    declare @trancount int;
    set @trancount = @@trancount;
    begin try
	print 'Inserting ' + @source_app_code + ', ' + @source_object_name + ', ' + @load_type_code;
        if @trancount = 0
            begin transaction
        else
            save transaction sp_add_source_objects_spfl;

	-- check if record exists, if not, insert the row
	-- source object could have multiple load types
	
	declare @source_app_id int;
	declare @load_type_id int;

	if (not exists 
		(
			select 1 
			from [ctlfwk].[source_objects] so
			left join [ctlfwk].[source_app] sa on
				sa.[source_app_id] = so.[source_app_id]
			left join [ctlfwk].[load_types] lt on
				lt.[load_type_id] = so.[load_type_id]
			where 
				so.[source_object_name] = @source_object_name
			and sa.[source_app_code] = @source_app_code
			and lt.[load_type_code] = @load_type_code
		)
	)
	begin
		set @source_app_id  = (select source_app_id from [ctlfwk].[source_app] where source_app_code = @source_app_code);
		set @load_type_id  = (select load_type_id from [ctlfwk].[load_types] where load_type_code = @load_type_code);

		insert into [ctlfwk].[source_objects]
		(
			[source_object_name]
		,	[source_object_description]
		,	[load_type_id]
		,	[source_app_id]
		,	[start_date_time]
		,	[end_date_time]
		,	[is_file_mandatory]	 
		,	[Schema_Name]
		)
		values
		(
			@source_object_name
		,	@source_object_description
		,	@load_type_id
		,	@source_app_id
		,	GETDATE()
		,	'9999-12-31'
		,	@is_file_mandatory
		,	@Schema_Name
		)

		print 'Entry inserted for ' + @source_app_code + ', ' + @source_object_name + ', ' + @load_type_code
	end
	else
	begin
		
		set @source_app_id = (select source_app_id from [ctlfwk].[source_app] where source_app_code = @source_app_code);
		set @load_type_id = (select load_type_id from [ctlfwk].[load_types] where load_type_code = @load_type_code);

		update [ctlfwk].[source_objects]
		set
			[source_object_description] = @source_object_description
			,[is_file_mandatory] = @is_file_mandatory
		where
			source_object_name = @source_object_name
			and load_type_id = @load_type_id
			and source_app_id = @source_app_id
			and end_date_time > GETDATE()
		;

		print 'Entry updated for ' + @source_app_code + ', ' + @source_object_name + ', ' + @load_type_code
	end

	if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_source_objects_spfl;

        raiserror ('Ctlfwk.sp_add_source_objects_spfl: %d: %s', 16, 1, @error, @message) ;
    end catch

end


