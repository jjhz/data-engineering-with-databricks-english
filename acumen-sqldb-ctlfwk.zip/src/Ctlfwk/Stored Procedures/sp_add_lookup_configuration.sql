﻿
-- =============================================
-- Author:      Deloitte
-- Create date: 22/04/2021
-- Description: Adds and updates records in ctlfwk.lookup_configuration
--
-- Parameters:
--   @TargetDBName - Name of the Target Schema which drives the lookup of surrogate key in the source table
--   @TargetTableName - Name of the Target Table which drives the lookup of surrogate key in the source table
--	 @LookupDBName - Name of the Schema for the table that needs to be looked up to fetch the surrogate key
--	 @LookupTableName - Name of the table that needs to be looked up to fetch the surrogate key
--	 @SourceDBName - Name of the source schema for the table 
--	 @SourceTableName - Name of the source table name
--	 @KeymapDBName - Name of the keymap schema to get list of all the surrogate keys against natural keys
--	 @KeymapTableName - Name of the keymap table (of the lookup) to get list of all the surrogate keys against natural keys
--	 @lookUpKey - Natural key based on which lookup will be performed in the source lookup table
-- =============================================

CREATE PROCEDURE [ctlfwk].[sp_add_lookup_configuration]
(
	@TargetDBName varchar(100)
,	@TargetTableName varchar(100)
,	@LookupDBName varchar(100)
,	@LookupTableName varchar(100)
,	@SourceDBName varchar(100)
,	@SourceTableName varchar(100)
,	@KeymapDBName varchar(100)
,	@KeymapTableName varchar(100)
,	@lookUpKey varchar(500)
)
AS
BEGIN


set nocount on;
    declare @trancount int;
    set @trancount = @@trancount;
    begin try
	print 'Inserting ' + @TargetDBName + ', ' + @TargetTableName + ', ' + @LookupDBName + ', ' + @LookupTableName;
        if @trancount = 0
            begin transaction
        else
            save transaction sp_add_lookup_configuration;

	-- check if record exists, if not, insert the row
	-- source object could have multiple load types
	
	--declare @source_app_id int;
	--declare @load_type_id int;

	if (not exists 
		(
			select 1 
			from [ctlfwk].[lookup_configuration]
			where 
				[TargetDBName] = @TargetDBName
			and [TargetTableName] = @TargetTableName
			and [LookupDBName] = @LookupDBName
			and [LookupTableName] = @LookupTableName
		)
	)
	begin

		insert into [ctlfwk].[lookup_configuration]
		(
			 [TargetDBName]
			,[TargetTableName]
			,[LookupDBName]
			,[LookupTableName]
			,[SourceDBName]
			,[SourceTableName]
			,[KeymapDBName]
			,[KeymapTableName]
			,[lookUpKey]
		)
		values
		(
			 @TargetDBName
			,@TargetTableName
			,@LookupDBName
			,@LookupTableName
			,@SourceDBName
			,@SourceTableName
			,@KeymapDBName
			,@KeymapTableName
			,@lookUpKey
		)

		print 'Entry inserted for ' + @TargetDBName + ', ' + @TargetTableName + ', ' + @LookupDBName + ', ' + @LookupTableName;
	end
	else
	begin
		
		update [ctlfwk].[lookup_configuration]
		set
			 [SourceDBName]	   = @SourceDBName
			,[SourceTableName] = @SourceTableName
			,[KeymapDBName]	   = @KeymapDBName
			,[KeymapTableName] = @KeymapTableName
			,[lookUpKey]	   = @lookUpKey
		where
				[TargetDBName] = @TargetDBName
			and [TargetTableName] = @TargetTableName
			and [LookupDBName] = @LookupDBName
			and [LookupTableName] = @LookupTableName
		;

		print 'Entry updated for ' + @TargetDBName + ', ' + @TargetTableName + ', ' + @LookupDBName + ', ' + @LookupTableName;
	end

	if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_source_objects;

        raiserror ('ctlfwk.sp_add_lookup_configuration: %d: %s', 16, 1, @error, @message) ;
    end catch

end