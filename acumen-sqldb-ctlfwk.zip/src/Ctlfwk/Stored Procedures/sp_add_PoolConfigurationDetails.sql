﻿CREATE PROCEDURE [ctlfwk].[sp_add_PoolConfigurationDetails]
(
	@PoolName varchar(max)
,	@PoolId nvarchar(max)
,   @cluster_type VARCHAR(100) --V1.1
)
AS

-- =============================================
-- Author:      Tammy H
-- Create Date: 22/12/2021
-- Description: Adds and updates records in [ctlfwk].[PoolConfigurationDetails]

-- Usage Comments if Any :
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	22-12-2021						Tammy H				      1.0				InitialVersion
--  24-05-2022						Sheela R				  1.1				Added new parameter cluster_type and updated poolid validation
--  31-05-2022						Sakshi S				  1.2				Removed the cluster_type filter from validation

-- =============================================

BEGIN

set nocount on;
     -- Validations Start 
	declare @PoolConfigurationDetailsID INT ;
	declare @Actiontype varchar(100) ; 

	-- Table Variable to Capture Input Paramters 
	declare @InsertedParameterValues AS TABLE 
	(
		PoolName varchar(max)
	  , PoolId nvarchar(max)
	  , cluster_type VARCHAR(100)   --V1.1
	)
	-- Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 


--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
		
		
	IF (@PoolName IS NULL OR LEN(@PoolName) = 0) --V1.2
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error' , 'PoolName cannot be NULL or Blank', (N'{'+CONCAT('"PoolName": "',COALESCE( @PoolName ,''))  +'" ' 
																			  +',' +CONCAT('"PoolId": "',COALESCE( @PoolId ,''))  +'" ' 
																	   		  +'}' )
			);

			SET @Returnvalue =2 ;
		END 

	--IF (@PoolId IS NULL OR LEN(@PoolId) = 0) AND @cluster_type ='Job' --V1.1
	--V1.2
	IF (@PoolId IS NULL OR LEN(@PoolId) = 0) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error' , 'PoolId cannot be NULL or Blank when Cluster_type = Job', (N'{'+CONCAT('"PoolId": "',COALESCE( @PoolId ,''))  +'" ' 
																			  +',' +CONCAT('"PoolName": "',COALESCE( @PoolName ,''))  +'" ' 
																			  +'}' )
			);

			SET @Returnvalue =2 ;
		END 
   --V1.1 
   IF (@cluster_type IS NULL OR LEN(@cluster_type) = 0) --V1.1
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error' , 'ClusterType cannot be NULL or Blank', (N'{'+CONCAT('"Cluster Type": "',COALESCE( @cluster_type ,''))  +'" ' 
																			  
																	   		  +'}' )
			);

			SET @Returnvalue =2 ;
		END

--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				BEGIN TRY 
					BEGIN TRANSACTION
		 
						INSERT INTO @InsertedParameterValues
						(  
						     PoolName
						   , PoolId 
						   , cluster_type  --V1.1
						)    
						VALUES 
						(
						     @PoolName
						   , @PoolId 
						   , @cluster_type
						)  


--=======================================================================================================================
						 --Check if Encryption Type Already  Exists fetch the Encryption_TypeID to identify the Insert/Update Action 

						 SELECT @PoolConfigurationDetailsID = PoolConfigurationDetailsID
                         FROM [ctlfwk].[PoolConfigurationDetails]
                         WHERE PoolName = @PoolName 
						
--================================Update  Process Table ==============================================			 
						 --Capturing the Merge Action into #MergeActions Table 
						 DROP TABLE IF EXISTS #MergeActions ;
						 CREATE TABLE #MergeActions ([Action] VARCHAR(10), PoolConfigurationDetailsID INT  ) 
						 INSERT INTO #MergeActions ([Action], PoolConfigurationDetailsID)
						 SELECT [Action]  , PoolConfigurationDetailsID
						 FROM ( 
			 
						 MERGE ctlfwk.PoolConfigurationDetails as tgt 
						 USING @InsertedParameterValues as source ON ( tgt.PoolConfigurationDetailsID =ISNULL(@PoolConfigurationDetailsID,0)						  
														  )
						 WHEN MATCHED THEN 
							  UPDATE 
							  SET   tgt.PoolId = source.PoolId
								  , tgt.cluster_type = source.cluster_type  --V1.1
								  , tgt.last_modified_datetime =SYSDATETIME()
								  , tgt.last_modified_by = ORIGINAL_LOGIN()
 

						 WHEN NOT MATCHED THEN 
							 INSERT ( PoolName, PoolId, cluster_type)
							 VALUES ( 
									  source.PoolName
									, source.PoolId
									, source.cluster_type  --V1.1
           						    )
						   
							OUTPUT
								$action as Action ,
								inserted.PoolConfigurationDetailsID
								) MergeOutput 
						--SELECT * FROM #MergeActions ;  

					COMMIT TRANSACTION
	
				END TRY

				BEGIN CATCH
					INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}'));
					ROLLBACK TRANSACTION 
				END CATCH
			END --ReturnValue 0 end

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_PoolConfigurationDetails' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
		  END 
	   ELSE 
	      SELECT CONCAT('PoolConfigurationDetailsID ',+ CONVERT(VARCHAR, PoolConfigurationDetailsID)   + ' Is '+Action +'D')  FROM #MergeActions
END

