﻿CREATE PROCEDURE [Ctlfwk].[sp_add_process_type]
(
	@process_type varchar(20)
)
AS
BEGIN

set nocount on;
    declare @trancount int;
    set @trancount = @@trancount;
    begin try
    print 'Inserting ' + @process_type ;
        if @trancount = 0
            begin transaction
        else
            save transaction sp_add_process_type;

    
	-- check if record exists, if not, insert the row
	if (not exists (select 1 from [ctlfwk].[process_type] where [process_type] = @process_type))
	begin
		insert into [ctlfwk].[process_type]
		(
			[process_type]
		,	[start_date_time]
		,	[end_date_time]
		)
		values
		(
			@process_type
		,	GETDATE()
		,	'9999-12-31'
		)
	end
    else
        print 'Entry already exists for ' + @process_type 

if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_process_type;

        raiserror ('Ctlfwk.sp_add_process_type: %d: %s', 16, 1, @error, @message) ;
    end catch
end