﻿CREATE PROCEDURE [ctlfwk].[sp_add_process]
    @process_name varchar(200)   
,   @process_name_description VARCHAR(100)
,	@is_enabled varchar(1)
,	@stream_name varchar(255) --V2.6
,	@process_type varchar(20)
,	@source_app_code varchar(25) --V2.4
,	@source_object_name varchar(100)
,	@load_type_code varchar(5)  --V2.5
,   @target_object_name varchar(200) 
,   @PoolName VARCHAR(MAX)   --V1.9
,   @NoOfWorkers INT     --V1.9

AS 

/* ==================================================================================================================================================
-- Author:      Deloitte
-- Create date: 20/07/2020
-- Description: Adds and updates records in ctlfwk.process table
--
-- Parameters:
--	 @process_name - name of process
--	 @process_name_description - description of process
--	 @is_enabled - flag to enable/disable process
--	 @stream_name - unique stream name from ctlfwk.stream table
--	 @process_type - unique process_type value from ctlfwk.process_type table
--   @source_app_code - unique source app code from ctlfwk.source_app
--   @source_object_name - name of source object
--	 @load_type_code - unique load type code from ctlfwk.load_types
--   @target_object_name - name of source object

-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte				 1.0				InitialVersion
	02-09-2021						Sheela R 				 1.1				Making Changes to use Merge and remove ProcessName as Input Parameter  
	09-09-2021                      Niharika S               1.2                Adding Target object name to parameters
	14-09-2021						Sheela R                 1.3                Changes to Capture Error into ctlfwk.process_errors
	07-10-2021                      Sheela R                 1.4                Fixing Bug which was raised during creation of new Process    
--	07-10-2021						Niharika S				 1.5				Embedding errors for null check for process_name, process_name_description
	15-11-2021						Tammy H					 1.6				Fix issue with validations not throwing errors for values that should not accept values NULL.
	29-11-2021						Sheela R				 1.7				Adding where cluase to fixe issue with creating processes for multiple source_objects
	21-12-2021						Sheela R				 1.8                Added Cluster Parameters 
	25-01-2022                      Sheela R                 1.9                Changes to capture Cluster Parameters after discussionw with David 
	( 1- Make CLuster Parameters Mandatory 
	  2- Only when  New processes are added CLuster Parameters will be inserted , 
	  3- Any updates to Cluster Parameters will be manual which means  CI-CD will 
	     not overwrite existing parameters when deployed to an environment) 
    01-02-2022						Sheela R 				2.0                 Added Raise Error 
	16-02-2022						Tammy H					2.1					Fixed bug with no error coming up when source_object and source_App does not exist together
	21-02-2022						Tammy H					2.2					Fixed issue with using incorrect rule/parameter in validation
	23-02-2022						Tammy H					2.3					Process_Name Uniqueness -during update, including all other parameters for update
	10-03-2022						Tammy H					2.4				    New req: Change source_app_code varchar(6) to varchar(25)
	15-03-2022						Tammy H					2.5					Change load_type_code varchar(1) to varchar(5)
	18-03-2022						Tammy H					2.6			        New req: Stream_name raised to be varchar(255)
	14-05-2022						Sakshi S				2.7			        NoofWorkers can be 0, if passed as Null will be treated as 0
-- ===================================================================================================================================================  */
BEGIN

set nocount on;
    
	 -- Error Validations Start 
		declare @stream_id int;
		declare @process_type_id int;
		declare @source_object_id int;
		declare @processId int =NULL ;  --V1.1 
		declare @Actiontype varchar(100) ; 
		-- Table Variable to Capture Input Paramters 
		declare @InsertedParameterValues AS TABLE 
		(
	        process_name varchar(200)  
		,	process_name_description VARCHAR(100)
		,	is_enabled varchar(1)
		,	stream_name varchar(255)
		,	process_type varchar(20)
		,	source_app_code varchar(25)
		,	source_object_name varchar(100)
		,	load_type_code varchar(5)  
		,   target_object_name varchar(200) 
		,   PoolName VARCHAR(MAX) NULL --V1.8 
	    ,   NoOfWorkers INT NULL --V1.8 

	   )
	   -- Table Variable to Capture Error 
		declare @ErrorUDT [ctlfwk].[ErrorUDT] 
		declare @Returnvalue INT = 0 --Success 
		declare @TargetObjectId INT = 0 --V1.4 
		-- Table Variable to fetch ID's by doing Looukups to Input into Process  Table 
		declare @FinalValues AS TABLE 
				 ( 
					  process_name VARCHAR(200) 
					, process_name_description  VARCHAR(100) 
					, is_enabled VARCHAR(1) 
					, stream_id INT 
					, process_type_id INT 
					, source_object_id INT 
					, target_object_id INT 
					, start_date_time datetime
					, end_date_time   datetime
					, PoolConfigurationDetailsID VARCHAR(MAX) NULL --V1.8 
				   ,  NoOfWorkers INT NULL --V1.8 
				  ) 
		declare @PoolConfigurationId INT --V1.8
--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 

		--V1.6
		IF (  @is_enabled NOT IN ( 'Y','N') OR  @is_enabled IS NULL) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Is_enabled Cannot have this value' , (N'{' +CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" ' 
																					+',' +CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																					+',' +CONCAT('"source_object_name": "' ,COALESCE( @source_object_name ,'')) +'" '
																					+',' +CONCAT('"IsEnabled": "' ,COALESCE( @is_enabled ,'')) +'" '
																					+ '}')
				   ) ;
			SET @Returnvalue =2 ;
		END
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.stream WHERE stream_name =@stream_name ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'StreamName does not exist' , (N'{' +CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" ' 
																			+',' +CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																			+',' +CONCAT('"source_object_name": "' ,COALESCE( @source_object_name ,'')) +'" '
																			+',' +CONCAT('"IsEnabled": "' ,COALESCE( @is_enabled ,'')) +'" '
																			+ '}')
				   ) ;
			SET @Returnvalue =2 ;
		END  
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.process_type  WHERE process_type =@process_type ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'ProcessType does not exist' , (N'{' +CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" ' 
																				+',' +CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																				+',' +CONCAT('"source_object_name": "' ,COALESCE( @source_object_name ,'')) +'" '
																				+',' +CONCAT('"process_type": "' ,COALESCE( @process_type ,'')) +'" '
																				+ '}')
				   ) ;
			SET @Returnvalue =2 ;
		END 
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app   WHERE source_app_code  =@source_app_code  ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'source_app_code does not exist' ,  (N'{' +CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" ' 
																						+',' +CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																						+',' +CONCAT('"source_object_name": "' ,COALESCE( @source_object_name ,'')) +'" '
																						+',' +CONCAT('"source_app_code": "' ,COALESCE( @source_app_code ,'')) +'" '
																						+ '}')
				   ) ;
			SET @Returnvalue =2 ;
		END 

		--V2.1
		IF NOT EXISTS ( SELECT 1 
						FROM ctlfwk.source_objects so
						INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id 
						WHERE so.source_object_name = @source_object_name AND sa.source_app_code = @source_app_code ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'The provided Source_App_Code and Source_Object_Name does not exist together',	
						(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
						+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
						+'}' )
				);

				SET @Returnvalue =2 ;
		END  

		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.load_types     WHERE load_type_code    =@load_type_code   ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'load_type_code does not exist' , (N'{' +CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" ' 
																					+',' +CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																					+',' +CONCAT('"load_type_code": "' ,COALESCE( @load_type_code ,'')) +'" '	
																					+ '}')
				   ) ;
			SET @Returnvalue =2 ;
		END --V1.2
		 

		IF (@target_object_name IS NOT NULL AND  LEN(@target_object_name ) > 0 ) 
		--V1.4
		BEGIN 
		
		SELECT @TargetObjectId = source_object_id  FROM ctlfwk.source_objects      WHERE source_object_name =@target_object_name 
	 	IF  @TargetObjectId = 0
		BEGIN 
		
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'target_object_name does not exist' , (N'{' +CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" ' 
																							  +',' +CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																							  +',' +CONCAT('"target_object_name": "' ,COALESCE( @target_object_name ,'')) +'" '	
																							  + '}')
				   ) ;
			SET @Returnvalue =2 ;
		END 
		 
	   END 
	 --  SELECT @Returnvalue 

	 		IF (@process_name IS NULL OR LEN(@process_name) = 0) --V1.5
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', ' Process Name cannot be NULL or Blank', (N'{'+CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																			+',' +CONCAT('"source_object_name": "' ,COALESCE( @source_object_name ,'')) +'" '
																			+',' +CONCAT('"source_app_code": "' ,COALESCE( @source_app_code ,'')) +'" '
																			+',' +CONCAT('"process_name": "' ,COALESCE( @process_name ,'')) +'" '
																			+ '}')
			);

			SET @Returnvalue =2 ;
		END 

				IF (@process_name_description IS NULL OR LEN(@process_name_description) = 0) --V1.5
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', ' Process name description cannot be NULL or Blank', (N'{'+CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" '
																			+',' +CONCAT('"Stream_name": "' ,COALESCE( @stream_name ,'')) +'" '
																			+',' +CONCAT('"source_object_name": "' ,COALESCE( @source_object_name ,'')) +'" '
																			+',' +CONCAT('"source_app_code": "' ,COALESCE( @source_app_code ,'')) +'" '
																			+',' +CONCAT('"process_name_description": "' ,COALESCE( @process_name_description ,'')) +'" '
																			+ '}')
			);

			SET @Returnvalue =2 ;
		END 
		--V2.7 NoofWorkers can be 0, if passed as Null will be treated as 0
		--V2.2 mixed parameters used in validation. Changed process_name_description to NoOfWorkers
		--     validation rule change bcos datatype is INT, so len() = 0 won't occur, will change to <1. 
		--V1.8 /V1.9
		IF(@NoOfWorkers  IS NULL)
			SET @NoOfWorkers =0


	   	IF (@PoolName  IS NULL OR LEN(@PoolName) = 0)  
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			    VALUES ('Error', '@PoolName Cannot be Null or Blank' , (N'{' +CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" ' 
																					+',' +CONCAT('"PoolName": "' ,COALESCE( @PoolName ,'')) +'" '
																					+ '}')
				     ) ;
			SET @Returnvalue =2 ;
				  
			END --V1.8/V1.9
	  --V1.8
		IF (@PoolName  IS NOT  NULL OR LEN(@PoolName) > 0) --V1.5
			BEGIN 
				 IF NOT EXISTS ( SELECT 1 FROM Ctlfwk.PoolConfigurationDetails 
				                  WHERE PoolName =@PoolName 
								)
				 BEGIN 
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', ' Pool Name does not exist in PoolConfigurationDetails Table',(N'{'+CONCAT('"process_name": "',COALESCE( @process_name ,''))  +'" '
																			+',' +CONCAT('"Pool Name": "' ,COALESCE( @PoolName ,'')) +'" '
														
																			+ '}')
							)

					SET @Returnvalue =2 ;
				END 
				  
			END
		--V1.8 
--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 
	--V2.0
	IF @Returnvalue = 2 
		RAISERROR('sp_add_process: ERROR - Refer to Process_Error Table .', 16, -1) 
--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				BEGIN TRY 
					BEGIN TRANSACTION
			          
	                    --Fetch PoolconfigurationId 
					   SELECT @PoolConfigurationId= PoolConfigurationDetailsID  FROM ctlfwk.PoolConfigurationDetails
					   WHERE PoolName =@PoolName ;
	   
	         
						INSERT INTO @InsertedParameterValues
						(  
							process_name
						  , process_name_description 
						  , is_enabled 
						  , stream_name 
						  , process_type 
						  , source_app_code 
						  , source_object_name 
						  , load_type_code 
						  , target_object_name
						  , PoolName  --V1.8 
						  , NoOfWorkers --V1.8 
						)
						VALUES 
						(
							 @process_name 
						   , @process_name_description
						   , @is_enabled 
						   , @stream_name 
						   , @process_type 
						   , @source_app_code 
						   , @source_object_name 
						   , @load_type_code 
						   , @target_object_name
						   , @PoolName   --V1.8 
						  ,  @NoOfWorkers --V1.8 

						)
						--Debug 
						 --  SELECT * from @InsertedParameterValues  
						-- Doing Necessary Lookup on tables to fetch the ID's based on Input Values like StreamName , ProcessType 
      
						  INSERT INTO @FinalValues
						  (
							  process_name
							, process_name_description 
							, is_enabled 
							, stream_id 
							, process_type_id 
							, source_object_id 
							, target_object_id
							, start_date_time 
							, end_date_time 
							, PoolConfigurationDetailsID --V1.8 
							, NoOfWorkers --V1.8 
						  )
	  
						  SELECT 
							  -- LTRIM(RTRIM(up.source_object_name))+'_' + LTRIM(RTRIM(up.process_type)) AS ProcessName
							   ipv.process_name 
							 , ipv.process_name_description 
							 , ipv.is_enabled 
							 , st.stream_id 
							 , pt.process_type_id 
							 , so.source_object_id as source_object_id
							 , CASE WHEN @TargetObjectId =0 THEN NULL ELSE @TargetObjectId END as target_object_id --V1.4 
							 , GETDATE()
							 , '9999-12-31'
							 , @PoolConfigurationId    --V1.8 
							 , ipv.NoOfWorkers --V1.8 
						  FROM @InsertedParameterValues ipv
						  JOIN ctlfwk.stream st ON ipv.stream_name =st.stream_name 
						  JOIN ctlfwk.process_type pt ON pt.process_type =ipv.process_type 
						  JOIN [ctlfwk].[source_objects] so ON ipv.source_object_name = so.source_object_name 
						 -- JOIN [ctlfwk].[source_objects] sot  ON ipv.target_object_name = sot.source_object_name --V1.4
						  left join [ctlfwk].[load_types] lt ON lt.load_type_id = so.load_type_id
						  left join [ctlfwk].[source_app] sa on sa.[source_app_id] = so.[source_app_id]
						  WHERE sa.source_app_code =@source_app_code --V1.7
						--Debug 
						-- SELECT * from @FinalValues 
		   --=======================================================================================================================
						 --Check if ProcessName Already  Exists fetch the Process ID to identify the Insert/Update Action 

						 SELECT @processId =Process_id 
						 FROM  @FinalValues fv 
						 LEFT JOIN ctlfwk.process p ON fv.process_name = p.process_name 
						--SELECT @processId 
			 --================================Update  Process Table ==============================================			 
						 --Capturing the Merge Action into #MergeActions Table 
						 
						 DROP TABLE IF EXISTS #MergeActions ;
						 CREATE TABLE #MergeActions ([Action] VARCHAR(10),ProcessId INT  ) 
						 INSERT INTO #MergeActions ([Action],ProcessId)
						 SELECT [Action]  ,process_id
						 FROM ( 
			 
						 MERGE ctlfwk.process as tgt 
						 USING @FinalValues as source ON ( tgt.process_id =ISNULL(@processID,0)						  
														  )
						 WHEN MATCHED THEN 
							  UPDATE 
							  SET   tgt.process_name_description =source.process_name_description
								  , tgt.is_enabled =source.is_enabled
								  , tgt.stream_id =source.stream_id
								  ,	tgt.process_type_id = source.process_type_id --V2.3
								  , tgt.source_object_id = source.source_object_id --V2.3
								  , tgt.start_date_time = source.start_date_time --V2.3
								  , tgt.end_date_time =  source.end_date_time --V2.3
								  , tgt.target_object_id =source.target_object_id
								  , tgt.Last_Modified_Datetime =SYSDATETIME()
								  , tgt.Last_Modified_By = ORIGINAL_LOGIN()
								 -- , tgt.PoolConfigurationDetailsID =source.PoolConfigurationDetailsID  --V1.9
                                 -- , tgt.NoofWorkers=source.NoOfWorkers  --V1.9

						 WHEN NOT MATCHED THEN 
							 INSERT ( process_name,process_name_description,is_enabled,stream_id,process_type_id,source_object_id, target_object_id
									 , start_date_time,end_date_time,PoolConfigurationDetailsID,NoOfWorkers)
							 VALUES ( 
									  source.process_name
									, source.process_name_description
									, source.is_enabled
									, source.stream_id
									, source.process_type_id
									, source.source_object_id
									, source.target_object_id
									, source.start_date_time
									, source.end_date_time
									, source.PoolConfigurationDetailsID
									, source.NoOfWorkers
           						   )
						   
						OUTPUT
							 $action as Action ,
						   inserted.process_id
						  ) MergeOutput 
					--	SELECT * FROM #MergeActions ;    
				COMMIT TRANSACTION	 
			END TRY
        
	  
       
		BEGIN CATCH 
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10),(ERROR_LINE())) + '"}')); 
				ROLLBACK TRANSACTION 
		END CATCH 
	   END  --ReturnValue 0

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) --V1.2
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_process' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
		  END 
	   ELSE 
	      SELECT CONCAT('Process ID ',+CONVERT(VARCHAR,processId)  + ' Is '+Action +'D')  FROM #MergeActions
	 
END
 


