﻿CREATE PROCEDURE [ctlfwk].[getJsonSchema]
  @business_unit_name_code VARCHAR(100), --V1.12
  @source_app_name VARCHAR(100),
  @source_object_name VARCHAR(100)
AS 
/* ==================================================================================================================================================
 
-- Usage Comments if Any : Used to create JSON Schema containing Source Object Details (Source_Object its Source_Object_Attributes)
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	28-09-2021						Tammy H  				 1.0				InitialVersion
	04-10-2021						Tammy H					 1.1				Adding additional parameter (source_object_name) and validations
	12-10-2021						Niharika S				 1.2				Format source_object_attribute_is_BusinessKey for JSON SourceColumns
	18-10-2021						Niharika S				 1.3				Adding Encrytion_Type 
	19-10-2021						Tammy H					 1.4				Adding 2 new columns: file_encoding and escape_character 
	08-11-2021						Tammy H					 1.5				Changes to refer to spark datatypes instead of source_object_attribute_data_types
	08-11-2021						Niharika S				 1.6				Adding new column : Contains_Multiline_Data
	11-11-2021						Niharika S				 1.7				Renaming inputmask to InputFormatString & deleting outputmask
	11-11-2021						Tammy H					 1.8				Adding escape \ to yyyy-MM-dd'T'HH:mm:ss.SSS InputFormatString so that it can be recognised in the ADB that uses this schema
	11-11-2021						Niharika S				 1.9				Removing null validation from source_time_zone
	17-11-2021						Niharika S				 1.10				Referencing SourceSystemDatabaseName table to source_app table
	23-11-2021						Tammy H					 1.11				Fix issue with validation causing error when it's not F/D/IUD load and adding escape \ to yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z[\'z\']\' to be recognises in ADB
	11-01-2022						Tammy H					 1.12				Adding business_unit_name variable to filter
	25-01-2022						Tammy H					 1.13				Switch around scale and precision to match definitions of scale/precision
	25-01-2022						Tammy H					 2.0                Added Raise Error 
	25-01-2022						Vikas P					 2.1                removed (SELECT @error_flag AS Error_Flag, @error_message AS Error_Message) stmt  from Validation 
	21-02-2022						Tammy H					 2.2				Passing spark DECIMAL/DOUBLE as BIGINT instead when scale = 0/null/blank
	13-04-2022						Tammy H					 2.3				Passing to ADB: sqlserver MONEY as DECIMAL(19,4) and SMALLMONEY as DECIMAL(14,4)
	21-04-2022						Niharika S				 2.4				Passing value of scale and precision when sqlserver MONEY,SMALLMONEY is not null
	03-05-2022						Tammy H					 2.5				Including Insert and Truncate load in validation rule requiring at east one Business Key
	06-05-2022						Tammy H					 2.6				Bugfix on MONEY/SMALLMONEY scale rule -if scale = 0, pass as it is instead of defaulting to 4
	12-05-2022						Tammy H					 2.7				Removing the escaping (\) of input_formatstring passed in Json. WIll be dealt in Databricks instead.
	10-10-2022						Musab A					 3.0				Adding additional parameter for IUD Load Types 
	05-11-2022						Musab A					 3.1				Added a flag to be sent as part of JSON schema if hard deletes on source object is enabled to 1
	22-11-2022						Musab A					 4.0				Removed conversion of DOUBLE to BIGINT if scale is not defined
	28-11-2022                      Nivedita T               4.1                Logic to replace special character in source object attribute name (line 233-237) for Project SEW Acumen
	01-12-2022                      Yang X                   4.2                Add logic to rename column name for custom extraction logic for Project SEW Acumen
	12-01-2023						Rohit Kumar				 4.3				Added logic to include RBAC code 
	13-01-2023						Rohit Kumar				 4.4				Logic to check and throw erro if all PII attributes are not mapped to Src_To_RBAC_Mapping table
===================================================================================================================================================*/
BEGIN 

	DECLARE @source_app_id INT 

	-- Table Variable to Capture Error/Actions 
	DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	DECLARE @Returnvalue INT = 0 --Success 
	DECLARE @error_flag VARCHAR(100)
	DECLARE @error_message VARCHAR(200)
	DECLARE @pkcount int --V1.7
	DECLARE @bkcount int --V1.7

--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
	
	--V1.12
	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.business_unit WHERE business_unit_name_code = @business_unit_name_code ) 
	BEGIN 
			
		SET @error_flag = 'Error'
		SET @error_message = 'Business_Unit_Name_Code does not exist'

		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
		VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
												+','+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" '
												+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
												+'}' )
				);

		SET @Returnvalue =2 ;

		--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message  --v2.1
	END 
	
	-- V1.1
	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app sa 
					INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
					WHERE source_app_name = @source_app_name AND business_unit_name_code = @business_unit_name_code ) 
		BEGIN 
			
			SET @error_flag = 'Error'
			SET @error_message = 'Business_Unit_Name_Code and Source_App_Name does not exist together'

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" ' 
													+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
													+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
													+'}' )
					);

			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message 
		END  
	ELSE -- Get the unique id -source_app_id
		BEGIN
			SELECT @source_app_id = source_app_id 
			FROM ctlfwk.source_app sa 
			INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
			WHERE source_app_name = @source_app_name AND business_unit_name_code = @business_unit_name_code
		END

	IF NOT EXISTS ( SELECT 1 
					FROM ctlfwk.source_objects so
					INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id  --V1.1
					WHERE so.source_object_name = @source_object_name AND sa.source_app_id = @source_app_id ) 
		BEGIN 
			Set @error_flag = 'Error'
			Set @error_message = 'Business_Unit_Name, Source_App_Name and Source_Object_Name provided does not exist togetherr'
			
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" ' 
													+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
													+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
													+'}' )
					);

			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message  --v2.1
		END  
		

	-- V1.1 Shouldn't allow a JSON to be created with nothing
	IF NOT EXISTS (SELECT 1 
					FROM [ctlfwk].[source_objects_attributes] soa 
					INNER JOIN [ctlfwk].[source_objects] so ON soa.source_object_id = so.source_object_id
					INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id
					WHERE so.source_object_name = @source_object_name AND sa.source_app_id = @source_app_id )
		BEGIN
			SET @error_flag = 'Error'
			SET @error_message = 'The provided Source_Object_Name does not contain any Source Object Attributes.'

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" ' 
													+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
													+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
													+'}' )
					);
			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message  --v2.1
		END

	--V1.11 Fix issue with validation causing error when it's not F/D/IUD load START
--	--V1.7
--	SELECT @pkcount = count(*) from Ctlfwk.source_objects_attributes
----	SELECT @pkcount

	IF EXISTS (SELECT 1 
					FROM [ctlfwk].[source_objects_attributes] soa 
					INNER JOIN [ctlfwk].[source_objects] so ON soa.source_object_id = so.source_object_id
					INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id
					INNER JOIN Ctlfwk.load_types lt on so.load_type_id = lt.load_type_id
					WHERE so.source_object_name = @source_object_name 
					AND sa.source_app_id= @source_app_id
					--AND soa.source_object_attribute_is_pk ='Y'
					and lt.load_type_code in ('F','D','IUD')
					)
		AND NOT EXISTS (SELECT 1 
					FROM [ctlfwk].[source_objects_attributes] soa 
					INNER JOIN [ctlfwk].[source_objects] so ON soa.source_object_id = so.source_object_id
					INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id
					INNER JOIN Ctlfwk.load_types lt on so.load_type_id = lt.load_type_id
					WHERE so.source_object_name = @source_object_name 
					AND sa.source_app_id= @source_app_id
					AND soa.source_object_attribute_is_pk ='Y'
					)
		BEGIN
			SET @error_flag = 'Error'
			SET @error_message = 'At least one source column for the object must be a primary key column for objects with a Delta, Full or IUD load type'

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" ' 
													+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
													+'}' )
					);
			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message  --v2.1
		END

--	SELECT @bkcount = count(*) from Ctlfwk.source_objects_attributes
----	SELECT @bkcount

	IF EXISTS (SELECT 1 
					FROM [ctlfwk].[source_objects_attributes] soa 
					INNER JOIN [ctlfwk].[source_objects] so ON soa.source_object_id = so.source_object_id
					INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id
					INNER JOIN Ctlfwk.load_types lt on so.load_type_id = lt.load_type_id
					WHERE so.source_object_name = @source_object_name 
					AND sa.source_app_id= @source_app_id
					--AND soa.source_object_attribute_is_BusinessKey ='Y'
					and lt.load_type_code in ('F','D','IUD', 'T', 'I')
					)
		AND NOT EXISTS (SELECT 1 
					FROM [ctlfwk].[source_objects_attributes] soa 
					INNER JOIN [ctlfwk].[source_objects] so ON soa.source_object_id = so.source_object_id
					INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id
					INNER JOIN Ctlfwk.load_types lt on so.load_type_id = lt.load_type_id
					WHERE so.source_object_name = @source_object_name 
					AND sa.source_app_id= @source_app_id 
					AND soa.source_object_attribute_is_BusinessKey ='Y'
					)

		BEGIN
			SET @error_flag = 'Error'
			SET @error_message = 'At least one source column for the object must be a business key column for objects with a Delta, Full, IUD, Truncate, Insert load type' --V2.5

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" ' 
													+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
													+'}' )
					);
			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --v2.1 
		END


	-- V4.4 Check all the PII columns are mapped to Source_Object_Attribute_To_RBAC_Mapping table.
		Declare @source_object_id int
		Select @source_object_id = source_object_id from ctlfwk.source_objects where source_object_name = @source_object_name
		IF EXISTS (SELECT * FROM (SELECT CASE WHEN soa.source_object_attribute_is_PII = 'Y'
			THEN coalesce((Select STRING_AGG(RBAC_Master_Code,',') as RBAC_Code from ctlfwk.Source_Object_Attribute_To_RBAC_Mapping srmp 
			INNER JOIN ctlfwk.RBAC_Master rm ON srmp.RBAC_ID = rm.RBAC_Master_id 
			where srmp.Source_Object_ID = so.source_object_id and srmp.Source_Object_Attribute_Name = soa.source_object_attribute_name),NULL)  -- v4.3 
			END as RBAC_Code
			FROM ctlfwk.source_objects_attributes soa INNER JOIN ctlfwk.source_objects so ON soa.source_object_id = so.source_object_id
			WHERE soa.source_object_attribute_is_PII = 'Y' AND so.source_object_id = @source_object_id) a
			WHERE a.RBAC_Code is NULL
			)
		BEGIN
			SET @error_flag = 'Error'
			SET @error_message = 'At least one PII attribute is not mapped to Source_Object_Attribute_To_RBAC_Mapping table' --V4.4

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" ' 
													+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
													+'}' )
					);
			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --v2.1 
		END

	--V1.11 Fix issue with validation causing error when it's not F/D/IUD load END

--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

	--  If No Errors 
	IF @Returnvalue = 0 
		BEGIN  --ReturnValue 0
			BEGIN TRY
				DROP TABLE IF EXISTS #SourceObjectDetails ;
				DROP TABLE IF EXISTS #FileDetails ;

				/*format the required columns for JSON SourceColumns*/
				SELECT				  
					 soa.source_object_attribute_seq
					 /*Case to handle special characters in source attribute name*/
					,CASE WHEN  soa.source_object_attribute_name IN ('"Min_Continuous_Usage(L/Hr)"') 
						THEN REPLACE(REPLACE(REPLACE(REPLACE(soa.source_object_attribute_name, '(', '_'), '"', ''),'/','_'),')','')
					/*Change column name for extractino custom logic*/
						WHEN ecl.extraction_custom_logic_code = 'extract_year' THEN CONCAT(soa.source_object_attribute_name, '_year')
						WHEN ecl.extraction_custom_logic_code = 'check_null' THEN CONCAT(soa.source_object_attribute_name, '_flag')
					ELSE soa.source_object_attribute_name 
					 END AS ColumnName
					, CASE 	WHEN ss.DataSource = 'SQLSERVER' AND source_object_attribute_data_type IN ('MONEY') 
															 AND (soa.source_object_attribute_precision = 0 OR soa.source_object_attribute_precision IS NULL OR LEN(soa.source_object_attribute_precision) = 0) 
															 AND (soa.source_object_attribute_scale IS NULL OR LEN(soa.source_object_attribute_scale) = 0) 
								THEN 'DECIMAL(19,4)' --V2.3 --2.4 --2.6
							WHEN ss.DataSource = 'SQLSERVER' AND source_object_attribute_data_type IN ('MONEY') 
															 AND (soa.source_object_attribute_precision = 0 OR soa.source_object_attribute_precision IS NULL OR LEN(soa.source_object_attribute_precision) = 0) 
															 AND soa.source_object_attribute_scale IS NOT NULL 
								THEN CONCAT('DECIMAL(', '19', ',', soa.source_object_attribute_scale, ')') --V2.4
							WHEN ss.DataSource = 'SQLSERVER' AND source_object_attribute_data_type IN ('MONEY') 
															 AND soa.source_object_attribute_precision IS NOT NULL 
															 AND (soa.source_object_attribute_scale IS NULL OR LEN(soa.source_object_attribute_scale) = 0) 
								THEN CONCAT('DECIMAL(', soa.source_object_attribute_precision, ',', '4', ')') --V2.4 --2.6
							WHEN ss.DataSource = 'SQLSERVER' AND source_object_attribute_data_type IN ('SMALLMONEY') 
															 AND (soa.source_object_attribute_precision = 0 OR soa.source_object_attribute_precision IS NULL OR LEN(soa.source_object_attribute_precision) = 0) 
															 AND (soa.source_object_attribute_scale IS NULL OR LEN(soa.source_object_attribute_scale) = 0) 
								THEN 'DECIMAL(12,4)' --V2.3 --2.4 --V2.6
							WHEN ss.DataSource = 'SQLSERVER' AND source_object_attribute_data_type IN ('SMALLMONEY') 
															 AND (soa.source_object_attribute_precision = 0 OR soa.source_object_attribute_precision IS NULL OR LEN(soa.source_object_attribute_precision) = 0) 
															 AND soa.source_object_attribute_scale IS NOT NULL 
								THEN CONCAT('DECIMAL(', '12', ',', soa.source_object_attribute_scale, ')') --V2.4
							WHEN ss.DataSource = 'SQLSERVER' AND source_object_attribute_data_type IN ('SMALLMONEY') 
															 AND soa.source_object_attribute_precision IS NOT NULL 
															 AND (soa.source_object_attribute_scale IS NULL OR LEN(soa.source_object_attribute_scale) = 0) 
								THEN CONCAT('DECIMAL(', soa.source_object_attribute_precision, ',', '4', ')') --V2.4 --2.6
							--WHEN ss.SparkSQLDatatype IN ('DECIMAL', 'DOUBLE') AND (source_object_attribute_scale = 0 OR source_object_attribute_scale IS NULL OR LEN(source_object_attribute_scale) = 0)
							WHEN ss.SparkSQLDatatype IN ('DECIMAL') AND (source_object_attribute_scale = 0 OR source_object_attribute_scale IS NULL OR LEN(source_object_attribute_scale) = 0) --V4.0
	
								THEN 'BIGINT' --V2.2
							WHEN ss.SparkSQLDatatype = 'DECIMAL' --AND source_object_attribute_scale IS NOT NULL
								THEN CONCAT('DECIMAL(', soa.source_object_attribute_precision, ',', soa.source_object_attribute_scale, ')') --V1.13 
							ELSE ss.SparkSQLDatatype
					  END AS DataType -- V1.5
					, '' as Description -- TBC. Currently Default
					, CASE WHEN soa.source_object_attribute_is_null = 'Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS Nullable
					--, CASE WHEN soa.input_formatstring = 'yyyy-MM-dd''T''HH:mm:ss.SSS' THEN 'yyyy-MM-dd\''T\''HH:mm:ss.SSS' --V1.8
					--	   WHEN soa.input_formatstring = 'yyyy-MM-dd''T''HH:mm:ss.SSS''Z[''z'']''' THEN 'yyyy-MM-dd\''T\''HH:mm:ss.SSS\''Z[\''z\'']\''' --V1.11 --V2.7 Removed 
					, CASE WHEN soa.input_formatstring IS NULL THEN ''
						   ELSE soa.input_formatstring 
					  END AS 'Format.InputFormatString' --V1.7
					, source_time_zone AS 'Format.TimeZone' --V1.9
					, CAST(0 AS BIT) AS Ignore -- TBC. Currently Default
					, CASE WHEN soa.source_object_attribute_is_pk = 'Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS IsKeyColumn
					, CASE WHEN soa.source_object_attribute_is_BusinessKey = 'Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS IsBusinessColumn --V1.2
					, 0 as StartPosition --always 0
					, 0 as EndPosition --always 0
					, CASE WHEN soa.source_object_attribute_is_historystitch = 'Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS HistoryStitchColumn 
					, CASE WHEN soa.source_object_attribute_is_historystitch_sortkey = 'Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS HistoryStitchSortKey 
					, CASE WHEN soa.source_object_attribute_is_PII = 'Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS IsAttributePII
					, CASE WHEN (et.[Encryption_Type] IS NULL or Len(et.[Encryption_Type]) = 0) THEN 'NA' ELSE et.[Encryption_Type] END AS 'EncryptionType' --V1.3
					, CASE WHEN ss.SparkSQLDatatype = 'STRING' THEN ' ' 
						   WHEN ss.SparkSQLDatatype IN ('DOUBLE', 'BIGINT', 'FLOAT', 'DECIMAL', 'BOOLEAN', 'TINYINT', 'INT', 'SMALLINT') THEN '0'
						   WHEN ss.SparkSQLDatatype = 'TIMESTAMP' THEN '1900-01-01 00:00:00'
						   WHEN ss.SparkSQLDatatype = 'DATE' THEN '1900-01-01'
						   WHEN ss.SparkSQLDatatype IS NULL THEN NULL
					END AS DefaultValueIfNotNull --V1.5
					, CASE WHEN soa.source_object_attribute_is_iud_column = 'Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS IsIUDColumn
					, ISNULL(DataFormat,'') DataFormat
					--, CASE WHEN soa.source_object_attribute_is_PII = 'Y' 
					,coalesce((Select STRING_AGG(RBAC_Master_Code,',') as RBAC_Code from ctlfwk.Source_Object_Attribute_To_RBAC_Mapping srmp INNER JOIN ctlfwk.RBAC_Master rm ON srmp.RBAC_ID = rm.RBAC_Master_id where srmp.Source_Object_ID = so.source_object_id and srmp.Source_Object_Attribute_Name = soa.source_object_attribute_name),NULL) as RBAC_Code -- v4.3
				INTO #SourceObjectDetails
				FROM [ctlfwk].[source_objects_attributes] soa 
				INNER JOIN [ctlfwk].[source_objects] so ON soa.source_object_id = so.source_object_id
				INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id  -- V1.1
				INNER JOIN Ctlfwk.business_unit bu ON bu.business_unit_id = sa.business_unit_id --V.12
				LEFT JOIN ctlfwk.Encryption_Types et ON soa.Encryption_TypeID = et.Encryption_TypeID --V1.3
				INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
				LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss ON soa.source_object_attribute_data_type = ss.DataType  AND sdb.SourceSystemDatabaseName = ss.DataSource --V1.10
				LEFT JOIN ctlfwk.extraction_custom_logic ecl ON soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
				WHERE so.source_object_name = @source_object_name AND sa.source_app_id= @source_app_id
				ORDER BY soa.source_object_attribute_seq ASC
			  --	SELECT * from #SourceObjectDetails 
			  --SELECT * from #SourceObjectDetails where DataType is null ;

				/* format the required columns for JSON Files */
				SELECT
					fs.File_Pattern_Name AS 'FilePatternName'
					, so.source_object_name AS 'ObjectName'
					, CASE WHEN  has_header ='Y' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS 'HasHeader'
					, LOWER(fs.file_extension_type) AS 'FileExtension'
					, fs.field_delimiter AS 'FieldDelimiter'
					, fs.timestamp_filename_pattern AS 'TimeStampFilenamePattern'
					, fs.timestamp_filename_regexpattern AS 'TimeStampFilenameRegexPattern'
					, CASE WHEN (fs.file_encoding IS NULL or Len(fs.file_encoding) = 0) THEN 'AUTO' ELSE fs.file_encoding END AS 'FileEncoding' --V1.4
					, CASE WHEN (fs.escape_character IS NULL or Len(fs.escape_character) = 0) THEN '"' ELSE fs.escape_character END AS 'EscapeCharacter' --V1.4
					, CASE WHEN fs.Contains_Multiline_Data = 'Y' THEN CAST (1 AS BIT) ELSE CAST (0 AS BIT) END AS 'ContainsMultilineData' --V1.6

					, CASE WHEN lt.load_type_code = 'IUD' THEN ISNULL(so_iud_i.source_CDC_record_type_value, 'I') END AS 'InsertCDCValue' --V3.0
					, CASE WHEN lt.load_type_code = 'IUD' THEN ISNULL(so_iud_u.source_CDC_record_type_value, 'U') END AS 'UpdateCDCValue' --V3.0
					, CASE WHEN lt.load_type_code = 'IUD' THEN ISNULL(so_iud_d.source_CDC_record_type_value, 'D') END AS 'DeleteCDCValue' --V3.0
					, CASE WHEN so.detect_hard_deletes = 1 THEN 'Y' else 'N' END AS DetectHardDeletes --V3.1								  

				INTO #FileDetails 
			    FROM ctlfwk.source_objects so
				INNER JOIN ctlfwk.File_Specification_Type fs ON fs.File_Specification_Type_Id = so.File_Specification_Type_Id
				INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id  -- V1.1
				INNER JOIN Ctlfwk.load_types lt on so.load_type_id = lt.load_type_id

				LEFT JOIN [ctlfwk].[Source_IUD_Mapping] so_iud_i
				on sa.IUD_config_id = so_iud_i.config_id and so_iud_i.record_type_name = 'I'   --V3.0

				LEFT JOIN [ctlfwk].[Source_IUD_Mapping] so_iud_u
			    on sa.IUD_config_id = so_iud_u.config_id and so_iud_u.record_type_name = 'U'   --V3.0
				
				LEFT JOIN [ctlfwk].[Source_IUD_Mapping] so_iud_d
			    on sa.IUD_config_id = so_iud_d.config_id and so_iud_d.record_type_name = 'D'   --V3.0
				
				WHERE so.source_object_name = @source_object_name AND sa.source_app_id= @source_app_id
			-- 	SELECT * from #FileDetails
				
			

				/* format query to JSON */
				SELECT --@error_flag AS Error_Flag, @error_message AS Error_Message,
					 (SELECT 
					FilePatternName AS 'File.FilePatternName'
					,ObjectName AS 'File.ObjectName'
					,HasHeader AS 'File.HasHeader'
					,FileExtension AS 'File.FileExtension'
					,FieldDelimiter AS 'File.FieldDelimiter'
					,TimeStampFilenamePattern AS 'File.TimeStampFilenamePattern'
					,TimeStampFilenameRegexPattern AS 'File.TimeStampFilenameRegexPattern'
					,FileEncoding AS 'File.FileEncoding' --V1.4
					,EscapeCharacter AS 'File.EscapeCharacter' --V1.4
					,ContainsMultilineData AS 'File.ContainsMultilineData' --V1.6
					,InsertCDCValue AS 'File.InsertCDCValue' --V3.0
					,UpdateCDCValue AS 'File.UpdateCDCValue' --V3.0
					,DeleteCDCValue AS 'File.DeleteCDCValue' --V3.0
					,DetectHardDeletes AS 'File.DetectHardDeletes' --V3.1
					, (SELECT
							ColumnName
							, DataType
							, [Description]
							, Nullable
							, [Format.InputFormatString] --V1.7
							, [Format.TimeZone]
							, Ignore
							, IsKeyColumn
							, IsBusinessColumn --V1.2
							, StartPosition
							, EndPosition
							, HistoryStitchColumn
							, HistoryStitchSortKey
							, IsAttributePII
							, [EncryptionType] --V1.3
							, DefaultValueIfNotNull
							, IsIUDColumn,DataFormat,RBAC_Code-- v4.3
						FROM #SourceObjectDetails 
						ORDER BY source_object_attribute_seq ASC
						FOR JSON PATH, INCLUDE_NULL_VALUES  ) AS SourceColumns
				FROM #FileDetails 
				FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER) JsonSchema

				

			

			END TRY

			BEGIN CATCH
					
				SET @error_flag = 'Error'
				SET @error_message = ERROR_MESSAGE()

				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 

				--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message  --v2.1

			 END CATCH

		END -- Return Value 0 

		 IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'getJSONSchema' 
				FROM @ErrorUDT; 
				RAISERROR('sp_getJsonSchema: ERROR - Refer to Process_Error Table .' ,17, 1) 
				
			END 
/*
EXEC [ctlfwk].[getJsonSchema]
   @business_unit_name_code = 'HI'
 , @source_app_name = 'Boss'
 , @source_object_name ='Cust_Cntct' 


*/
				  

END
GO


