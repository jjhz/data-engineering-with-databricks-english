﻿CREATE PROCEDURE [ctlfwk].[sp_get_source_job_details]
( 
  @stream_name	VARCHAR(255) , --V1.3
  @process_type	VARCHAR(20) NULL,
  @object_name	VARCHAR(100) NULL
)
AS
/*=================================================================================================
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte				 1.0				InitialVersion
	30-08-2021						Vikas P					 1.1				Added LoadType 
	20-12-2021						Vikas P					 1.2				Added Pool Configuration information
	18-03-2022						Tammy H					 1.3			    New req: Stream_name raised to be varchar(255)
	17-05-2022						Sakshi S				 1.4				To add cluster_type to output

 ================================================================================================= */ 
BEGIN

	SET NOCOUNT ON

	DECLARE 
		@ret_status			VARCHAR(100),
		@record_count		INT,
		@error_flag			VARCHAR(100),
		@error_message		VARCHAR(100)
	--print(@object_name + @stream_name + @process_type)
	IF @object_name IS NOT NULL AND @stream_name IS NOT NULL
	BEGIN
	--print('1')
		select @record_count = count(*) FROM ctlfwk.vw_stream WHERE stream_name = @stream_name;

		if @record_count <= 0
		begin

			SET @error_flag='Error'
			SET @error_message = 'ERROR - Stream does not exists.'
			--select @record_count as rec_count;
			--print @record_count;
			SELECT NULL AS stream_name, 
			NULL AS process_name,
		    NULL AS process_type, 
			@error_flag AS Erro_Flag, 
			@error_message AS ErrorMessage,
			NULL As load_type_code, --V1.1 
			NULL AS NoOfWorkers,
		    NULL AS PoolId, ---v1.2
			NULL AS Cluster_Type --V1.4
			RAISERROR('ERROR - Stream does not exists.' ,16,-1)
			return -1
		end

		select @record_count = count(*) FROM [Ctlfwk].[vw_source_objects] WHERE source_object_name = @object_name
		if @record_count <= 0
		begin

		    SET @error_flag='Error'
			SET @error_message = 'ERROR - Object does not exists.'
			SELECT NULL AS stream_name, 
			NULL AS process_name,
		       NULL AS process_type, 
			@error_flag AS Erro_Flag,
			@error_message AS ErrorMessage,
			NULL As load_type_code,  --V1.1 
			NULL AS NoOfWorkers,
		    NULL AS PoolId,---v1.2
			NULL AS Cluster_Type --V1.4
			RAISERROR('ERROR - Object does not exists.' ,16,-1)
			return -1
		end
	END
--	print @record_count;

	IF @process_type IS NULL AND @object_name IS NULL 
	BEGIN
	--print '2'
		SELECT 
			stream_name,
			process_name,
			process_type,
			source_object_name,
			is_enabled,
			load_type_code , --V1.1 
			NoOfWorkers,
		    PoolId, ---v1.2
			Cluster_Type --V1.4
		FROM
			ctlfwk.vw_process
		WHERE
			stream_name = @stream_name
		AND
			source_object_name IS NOT NULL
	END


	IF @process_type IS NULL AND @object_name IS NOT NULL 
	BEGIN
	--print '3'
		SELECT 
			stream_name,
			process_name,
			process_type,
			source_object_name,
			is_enabled,
			load_type_code,  --V1.1 
			NoOfWorkers,
		    PoolId, ---v1.2
			Cluster_Type --V1.4
		FROM
			ctlfwk.vw_process
		WHERE
			stream_name = @stream_name
		AND
			source_object_name IS NOT NULL
		AND
			source_object_name = @object_name
	END



	IF @process_type IS NOT NULL AND @object_name IS NULL 
	BEGIN
	--print '4'
		SELECT 
			stream_name,
			process_name,
			process_type,
			source_object_name,
			is_enabled,
			load_type_code  --V1.1 
		FROM
			ctlfwk.vw_process
		WHERE
			stream_name = @stream_name
		AND
			source_object_name IS NOT NULL
		AND
			process_type = @process_type
	END

	IF @process_type IS NOT NULL AND @object_name IS NOT NULL 
	BEGIN
	--print '5'
		SELECT 
			stream_name,
			process_name,
			process_type,
			source_object_name,
			is_enabled,
			load_type_code,  --V1.1 
			NoOfWorkers,
		    PoolId, ---v1.2
			Cluster_Type --V1.4
		FROM
			ctlfwk.vw_process
		WHERE
			stream_name = @stream_name
		AND
			source_object_name IS NOT NULL
		AND
			process_type = @process_type
		AND
			source_object_name = @object_name
	END
END


