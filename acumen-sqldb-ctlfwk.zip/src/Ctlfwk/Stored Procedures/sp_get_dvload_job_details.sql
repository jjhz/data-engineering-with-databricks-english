﻿
CREATE PROCEDURE [Ctlfwk].[sp_get_dvload_job_details]
( 
  @stream_name	VARCHAR(255) , 
  @source_app_name	VARCHAR(100) ,
  @process_type	VARCHAR(20) NULL,
  @object_name	VARCHAR(100) NULL
)
AS

BEGIN

	SET NOCOUNT ON

	DECLARE @ret_status VARCHAR(100)
	DECLARE @Source_app_id INT
	DECLARE @business_unit_id INT

	SET @Source_app_id = (Select Source_app_id from [Ctlfwk].[vw_source_app] where source_app_name = @source_app_name )
	SET @business_unit_id = (Select business_unit_id from [Ctlfwk].[vw_source_app] where source_app_name = @source_app_name )
	--Select @Source_app_id
	--Select @business_unit_id

		SELECT 
			 @Source_app_id as source_app_id
			,@business_unit_id as business_unit_id
			,process_name
			,stream_name
			,process_type
			,source_object_name
			,is_enabled

		FROM
			ctlfwk.vw_process
		WHERE
			stream_name = @stream_name
        AND
		    source_object_name = @object_name

END




GO


