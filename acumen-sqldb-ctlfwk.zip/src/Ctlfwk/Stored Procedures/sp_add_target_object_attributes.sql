﻿CREATE PROCEDURE [ctlfwk].[sp_add_target_object_attributes]
(
	@target_object_name varchar(100)
,	@Schema_Name varchar(50)
,	@notebook_name varchar(255)
,	@notebook_path nvarchar(255)
,	@target_attribute_name varchar(100)
,	@target_attribute_seq int
,	@target_attribute_is_active char(1)
,	@target_attribute_data_type varchar(50)
,	@target_attribute_precision varchar(10)
,	@target_attribute_scale varchar(10)
,	@target_attribute_array_name	varchar(100) = NULL --V1.4
,	@target_attribute_is_target_column char(1)
,	@target_attribute_is_null char(1)
,	@target_attribute_is_pk char(1)
,	@target_attribute_is_BusinessKey char(1)
,	@Encryption_Type varchar(10) 
,	@target_attribute_PII_Function varchar(150)
,	@target_attribute_is_historystitch	char(1) 
,	@target_attribute_is_historystitch_sortkey	char(1)
,	@target_attribute_Distributed_On varchar(150) = NULL
,	@target_attribute_Integration_KeyName varchar(500) = NULL
,	@target_attribute_default_value varchar(200) = NULL



)
AS
/* =========================================================================================================================================
	Description: Adds and updates records in ctlfwk.targets_objects_attributes table.
				This stored proc will not all the following below. Manual Inserts/Updates will be required.
				Updates cannot be made on the target_attribute_seq of an existing row.
				Inserts cannot be made if the target_Attribute_seq already exists for a different record containing the same target_object_name.

	Parameters:
		@Schema_Name - schema of target_object
		@notebook_path - part of the path of notebook. Full path: notebook_path+notebook_name
		@notebook_name - notebook name of notebook. Full path: notebook_path+notebook_name
		@target_object_name - name of target object
		@target_attribute_name - attribute name
		@target_attribute_seq - sequence of attribute in source object
		@target_attribute_is_active - flag to indicate if attribute is active
		@target_attribute_data_type - data type of attribute in source object
		@target_attribute_precision - precision of attribute in source object
		@target_attribute_scale - scale of attribute in source object
		@target_attribute_array_name - name of array/json column that attribute is a component of
		@target_attribute_is_target_column - flag to indicate if attribute is a target column 
	    @target_attribute_is_null - flag to indicate if attribute can contain null values
	    @target_attribute_is_pk - flag to indicate if attribute is primary key
		@target_attribute_is_BusinessKey - flag to indicate if attribute is business key 
		@Encryption_Type - Encryption Type from ctlfwk.Encryption_Types table
	    @target_attribute_PII_Function -  PII Function
	    @target_attribute_is_historystitch - flag to indicate if attribute is used for history stitching records
	    @target_attribute_is_historystitch_sortkey - flag to indicate if attribute is used for sorting history stitching records
		@target_attribute_Distributed_On -
		@target_attribute_Integration_KeyName - 
		@target_attribute_default_value - default value if null
		@syanpse_override -
		
	Validations: 
		@Schema_Name - checked exists in ctlfwk.target_objects table along with notebook_path, notebook_name, target_object_name
		@notebook_path - checked exists in ctlfwk.target_objects table along with schema_name, notebook_name, target_object_name
		@notebook_name - checked exists in ctlfwk.target_objects table along with schema_name, notebook_path, target_object_name
		@target_object_name - mchecked exists in ctlfwk.target_objects table along with schema_name, notebook_path, notebook_name
		@target_attribute_name - can't be NULL or Blank
		@target_attribute_seq - can't be NULL or Blank and no duplicates
		@target_attribute_is_active - only 'Y' or 'N'. If Null/Blank, replace with N
		@target_attribute_data_type - must exist for SQLSERVER datasource in Ctlfwk.SourceSystemToSparkDataTypeMapping table
		@target_attribute_precision - Cannot be NULL or Blank when sparkdatatype is 'STRING', 'DOUBLE', 'DECIMAL', 'FLOAT'.	
									  Has to be NULL/Blank if @target_attribute_datatype is 'smalldatetime','date','datetime' 
									  If SQLSERVER datetime2, datetimeoffset, time then replace blank/null with 7
									  IF sparkdatatype is DECIMAL, precision >38 will =38. precision must be between [0,38].
		@target_attribute_scale - Has to be NULL/Blank if @target_attribute_datatype is 'smalldatetime','date','datetime' 
								  If sparkdatatype is DECIMAL and scale is NULL/Blank, replace scale with 0
								  If sparkdatatype is DECIMAl, scale must be between [0, precision]
		@target_attribute_array_name - If blank, replace with NULL
		@target_attribute_is_target_column - only 'Y' or 'N'. If Null/Blank, replace with N
		@target_attribute_is_null - only 'Y' or 'N'. If Null/Blank, replace with N
		@target_attribute_is_pk - only 'Y' or 'N'. If Null/Blank, replace with N
		@target_attribute_is_BusinessKey - only 'Y' or 'N'. If Null/Blank, replace with N. If @target_attribute_is_pk = 'Y', @target_attribute_is_BusinessKey must be 'N'.
		@Encryption_Type - Encryption_Type if not NULL/Blank must exist in the ctlfwk.Encryption_Types table
		@target_attribute_PII_Function - If blank, replace with NULL
		@target_attribute_is_historystitch - only 'Y' or 'N'. If Null/Blank, replace with N
		@target_attribute_is_historystitch_sortkey - only 'Y' or 'N'. If Null/Blank, replace with N
		@target_attribute_Distributed_On - If blank, replace with NULL
		@target_attribute_Integration_KeyName - If blank, replace with NULL
		@target_attribute_default_value - If blank, replace with NULL
		@syanpse_override - If blank, replace with NULL


	Usage Comments if Any :
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	24-01-2022						Tammy H					 1.0				InitialVersion 
	25-01-2022						Tammy H					 1.1				Data Validations, inserts and updates, swapping scale and precision to match definitions
	27-01-2022						Tammy H					 1.2				validations for Encryption_Type, scale/precision for spark decimal data type
	28-01-2022						Tammy H					 1.3				Precision and scale rules specific to SQLSERVER datatypes
	02-02-2022						Tammy H					 1.4				Add Raise Error, new parameter target_attribute_array_name and associated rules
	03-02-2022						Tammy H					 1.5				Setting PK = N when target_attribute_array_name IS NOT NULL
	04-02-2022						Tammy H					 1.6				new parameter target_attribute_is_target_column and it's validations along with Integeration_KeyName validations
	07-02-2022						Tammy H					 1.7				Adding business_unit_name_code & source_app_code parameter, Include it in relevant table filtering and validations
	04-03-2022						Tammy H					 1.8				Update validations and rules to meet new req: Unique set of keys for target object -schema_name, notebook_path, notebook_name, target_object
																				Added new columns: target_attribute_default_value. Blank, set to NULL.
	13-04-2022						Tammy H					 1.9				SQLSERVER datatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY does not require precision or scale
======================================================================================================================================== */

BEGIN

set nocount on;

	-- Table Variable to Capture Error 
	DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	DECLARE @Returnvalue INT = 0 --Success 


	DECLARE @Encryption_TypeID INT 
	DECLARE @source_app_id INT


	-- Variables to capture data type info and spark equivalent data types
	DECLARE @spark_datatype VARCHAR(20)
	DECLARE @has_timezone VARCHAR(20)

	-- Referencing sourcesystemdatabasename to isolate database datatypes in validations
	SELECT @spark_datatype = SparkSQLDataType, @has_timezone = IsDateWithTimezone 
	FROM Ctlfwk.SourceSystemToSparkDataTypeMapping 
	WHERE DataType = @target_attribute_data_type AND DataSource = 'SQLSERVER'


 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 

	--Setting default value if NULL/Blank
	IF (@target_attribute_is_active IS NULL OR LEN(@target_attribute_is_active) = 0)
		SET @target_attribute_is_active = 'N'
	IF (@target_attribute_is_target_column IS NULL OR LEN(@target_attribute_is_target_column) = 0)
		SET @target_attribute_is_target_column = 'N'
	IF (@target_attribute_is_null IS NULL OR LEN(@target_attribute_is_null) = 0)
		SET @target_attribute_is_null = 'N'
	IF (@target_attribute_is_pk IS NULL OR LEN(@target_attribute_is_pk) = 0)
		SET @target_attribute_is_pk = 'N'
	IF (@target_attribute_is_BusinessKey IS NULL OR LEN(@target_attribute_is_BusinessKey) = 0)
		SET @target_attribute_is_BusinessKey = 'N'
	IF (@target_attribute_is_historystitch IS NULL OR LEN(@target_attribute_is_historystitch) = 0)
		SET @target_attribute_is_historystitch = 'N'
	IF (@target_attribute_is_historystitch_sortkey IS NULL OR LEN(@target_attribute_is_historystitch_sortkey) = 0)
		SET @target_attribute_is_historystitch_sortkey = 'N'
	IF ((@target_attribute_data_type IN ('DATETIME2', 'DATETIMEOFFSET', 'TIME')) AND (@target_attribute_precision IS NULL OR LEN(@target_attribute_precision) = 0))
		SET @target_attribute_precision = '7'
	IF (LEN(@Encryption_Type) = 0)
		SET @Encryption_Type = NULL
	IF (LEN(@target_attribute_PII_Function) = 0)
		SET @target_attribute_PII_Function = NULL
	IF (LEN(@target_attribute_array_name) = 0) --V1.4
		SET @target_attribute_array_name = NULL
	IF (LEN(@target_attribute_Integration_KeyName) = 0)--V1.6
		SET @target_attribute_Integration_KeyName = NULL 
	IF (LEN(@target_attribute_default_value) = 0) --V1.8
		SET @target_attribute_default_value = NULL
	

	--V1.5 If attribute is part of an array, PK = N
	IF @target_attribute_array_name IS NOT NULL
		SET @target_attribute_is_pk = 'N'
	--V1.6 Remove all spacing provided so that it's in the expected format to be used in getJsonTargetSchema sp i.e '   K1| K2' becomes 'K1|K2'
	IF (@target_attribute_Integration_KeyName IS NOT NULL)
		SET @target_attribute_Integration_KeyName = REPLACE(@target_attribute_Integration_KeyName, ' ', '') 
 

	/*Validations*/

	----V1.7
	--IF NOT EXISTS ( SELECT 1 FROM ctlfwk.business_unit WHERE business_unit_name_code = @business_unit_name_code ) 
	--	BEGIN 
			
	--		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
	--		VALUES ('Error', 'Business_Unit_Name_Code does not exist', (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
	--																	+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
	--																	+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
	--																	+'}' )
	--				);

	--		SET @Returnvalue =2 ;

	--	END 		
		
	----V1.7 adding business_unit_name_code as source_app_code itself is not unique
	--IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app sa 
	--				INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
	--				WHERE source_app_code = @source_app_code AND business_unit_name_code = @business_unit_name_code)
	--	BEGIN 
	--		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
	--		VALUES ('Error','Business_Unit_Name_Code and Source_App_Name does not exist together' , (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
	--																								+','+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" '
	--																								+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
	--																								+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
	--																								+'}' )
	--				) ;
	--		SET @Returnvalue =2 ;
	--	END 
	--ELSE -- Get the unique id -source_app_id
	--	BEGIN
	--		SELECT @source_app_id = source_app_id 
	--		FROM ctlfwk.source_app sa 
	--		INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
	--		WHERE source_app_code = @source_app_code AND business_unit_name_code = @business_unit_name_code
	--	END

	--V1.8 replace source_app_id with schema_name, notebook_path, notebook_name
	--V1.7
	IF NOT EXISTS (SELECT 1 FROM Ctlfwk.target_objects where target_object_name = @target_object_name AND [Schema_Name] = @Schema_Name AND notebook_path = @notebook_path AND notebook_name = @notebook_name)
		BEGIN
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_Object_Name must exist in ctlfwk.target_objects with Schema_Name, Notebook_Path, Notebook_Name', 
					(N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
					+',' +CONCAT('"Schema_Name": "' ,COALESCE( @schema_name ,'')) +'" '
					+',' +CONCAT('"Notebook_Path": "' ,COALESCE( @notebook_path ,'')) +'" '
					+',' +CONCAT('"Notebook_Name": "' ,COALESCE( @notebook_name ,'')) +'" '
					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
					+'}' )
			);

			SET @Returnvalue =2 ;
		END

	IF (@target_attribute_name IS NULL OR LEN(@target_attribute_name) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_Attribute_Name cannot be NULL or Blank', (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																				+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																				+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	IF (@target_attribute_seq IS NULL OR @target_attribute_seq < 1)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_Attribute_Seq cannot be NULL or <1',	(N'{'+CONCAT('"Target_Attribute_Seq": "',COALESCE( @target_attribute_seq ,''))  +'" ' 
																					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																					+'}' )
			);

			SET @Returnvalue =2 ;
		END

	IF (@target_attribute_is_active NOT IN ('Y', 'N')) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_attribute_Is_Active can only have value Y or N', (N'{'+CONCAT('"Target_Attribute_Is_Active": "',COALESCE(@target_attribute_is_active ,''))  +'" '
																								+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																								+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																								+'}' )
			);
			SET @Returnvalue =2 ;
		END

	IF NOT EXISTS (SELECT 1 FROM Ctlfwk.SourceSystemToSparkDataTypeMapping ss
					WHERE DataType = @target_attribute_data_type AND DataSource = 'SQLSERVER') 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_Attribute_Data_Type cannot have this value',  (N'{'+CONCAT('"Target_Attribute_Data_Type": "',COALESCE(@target_attribute_data_type ,''))  +'" '
																					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																					+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.3
	IF @target_attribute_data_type IN  ('smalldatetime','date','datetime') --These datatypes will not have precision and scale 
	   AND NOT ((@target_attribute_precision IS NULL OR LEN(@target_attribute_precision) = 0) AND (@target_attribute_scale IS NULL OR LEN(@target_attribute_scale) = 0)) 
		BEGIN
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'SMALLDATETIME, DATE, DATETIME provided should have NULL Values as Target_Attribute_Precision and Target_Attribute_Scale', 
					(N'{'+CONCAT('"Target_Attribute_Data_Type": "',COALESCE(@target_attribute_data_type ,''))  +'" '
					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
						+'}' )
			);

			SET @Returnvalue =2 ;
		END


	IF (@spark_datatype IN ('STRING', 'DOUBLE', 'DECIMAL', 'FLOAT') 
		AND NOT (@target_attribute_data_type IN ('TEXT', 'NTEXT', 'TIMESTAMP', 'UNIQUEIDENTIFIER', 'MONEY', 'SMALLMONEY')) --V1.9
		AND (@target_attribute_precision IS NULL OR LEN(@target_attribute_precision) = 0))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Precision cannot be NULL/Blank for spark equivalent datatypes STRING, DOUBLE, DECIMAL, FLOAT except  datatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY', 
					(N'{'+CONCAT('"Target_Attribute_Data_Type": "',COALESCE(@target_attribute_data_type ,''))  +'" '
					+','+CONCAT('"Target_Attribute_Precison": "',COALESCE( @target_attribute_precision ,''))  +'" '
					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
					+'}' )
			);

			SET @Returnvalue =2 ;
		END
	
	--V1.2
	IF (@spark_datatype = 'DECIMAL') AND NOT (@target_attribute_data_type IN ('MONEY', 'SMALLMONEY')) --V1.9
		BEGIN
			IF (CAST(@target_attribute_precision AS INT) > 38)
				SET @target_attribute_precision = 38

			--V1.9 Changing to 0 so that validations can be checked when casting to INT. NULL casted is still NULL which cannot be mathematically compared. 
			IF (@target_attribute_precision IS NULL OR LEN(@target_attribute_precision) = 0)
				SET @target_attribute_precision = 0

			IF (@target_attribute_scale IS NULL OR LEN(@target_attribute_scale) = 0)
				SET @target_attribute_scale = 0
			
			IF CAST(@target_attribute_precision AS INT) NOT BETWEEN 1 AND 38 
				BEGIN
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Precision has to be between 1 and 38 for spark equivalent DECIMAL datatypes except datatypes MONEY, SMALLMONEY', 
							(N'{'+CONCAT('"Target_Attribute_Data_Type": "',COALESCE(@target_attribute_data_type ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Precison": "',COALESCE( @target_attribute_precision ,''))  +'" '
							+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
							+'}' )
					);
					SET @Returnvalue =2 ;						
				END

			IF CAST(@target_attribute_scale AS INT) NOT BETWEEN 0 AND CAST(@target_attribute_precision AS INT)
				BEGIN
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Scale has to be between [0, Precision] for spark equivalent DECIMAL datatypes except datatypes MONEY, SMALLMONEY', 
							(N'{'+CONCAT('"Target_Attribute_Data_Type": "',COALESCE(@target_attribute_data_type ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Precison": "',COALESCE( @target_attribute_precision ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Precison": "',COALESCE( @target_attribute_scale ,''))  +'" '
							+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
							+'}' )
					);

					SET @Returnvalue =2 ;
				END
		
		END 

	IF (@target_attribute_is_target_column NOT IN ('Y', 'N'))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_Attribute_is_target_column can only have value Y or N', (N'{'+CONCAT('"Target_Attribute_Is_Target_Column": "',COALESCE(@target_attribute_is_target_column ,''))  +'" '
																					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																					+'}' )
			);

			SET @Returnvalue =2 ;
		END			

	IF (@target_attribute_is_null NOT IN ('Y', 'N'))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_Attribute_is_null can only have value Y or N', (N'{'+CONCAT('"Target_Attribute_Is_Null": "',COALESCE(@target_attribute_is_null ,''))  +'" '
																					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																					+'}' )
			);

			SET @Returnvalue =2 ;
		END

	IF (@target_attribute_is_pk NOT IN ('Y', 'N'))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_Attribute_Is_PK can only have value Y or N',  (N'{'+CONCAT('"Target_Attribute_Is_Pk": "',COALESCE(@target_attribute_is_pk ,''))  +'" '
																					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																					+'}' )
						);

			SET @Returnvalue =2 ;
		END

	IF (@target_attribute_is_BusinessKey NOT IN ('Y', 'N')) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_attribute_Is_BusinessKey can only have value Y or N', (N'{'+CONCAT('"Target_Attribute_Is_BusinessKey": "',COALESCE(@target_attribute_is_BusinessKey ,''))  +'" '
																							+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																							+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																							+'}' )
			);
			SET @Returnvalue =2 ;
		END

	IF (@target_attribute_is_pk = 'Y' AND @target_attribute_is_BusinessKey = 'Y')
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_attribute_Is_BusinessKey has to be N when target_attribute_is_pk = Y', 
					(N'{'+CONCAT('"Target_Attribute_Is_BusinessKey": "',COALESCE(@target_attribute_is_BusinessKey ,''))  +'" '
					+','+CONCAT('"Target_Attribute_Is_Pk": "',COALESCE(@target_attribute_is_pk ,''))  +'" '
					+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
					+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
					+'}' )
			);
			SET @Returnvalue =2 ;
		END

	--V1.2
	IF (NOT EXISTS (SELECT 1 FROM Ctlfwk.Encryption_Types WHERE [Encryption_Type] = @Encryption_Type) AND (@Encryption_Type IS NOT NULL)) 
		BEGIN					
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Encryption_Type does not exist', (N'{'+CONCAT('"Encryption_Type": "',COALESCE(@Encryption_Type ,''))  +'" '
																+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" ' 
																+'}' )
			);
			SET @Returnvalue =2 ;
		END

	IF (@target_attribute_is_historystitch NOT IN ('Y', 'N')) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_attribute_Is_Historystitch can only have value Y or N', (N'{'+CONCAT('"Target_Attribute_Is_Historystitch": "',COALESCE(@target_attribute_is_historystitch ,''))  +'" '
																								+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																								+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																								+'}' )
			);
			SET @Returnvalue =2 ;
		END

	IF (@target_attribute_is_historystitch_sortkey NOT IN ('Y', 'N')) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Target_attribute_Is_Historystitch_Sortkey can only have value Y or N',   (N'{'+CONCAT('"Target_Attribute_Is_Historystitch_Sortkey": "',COALESCE(@target_attribute_is_historystitch_sortkey ,''))  +'" '
																										+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																										+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
																										+'}' )
			);
			SET @Returnvalue =2 ;
		END


 --===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

 --V1.1 start
 --===========================-- Data Validation and Setting Return Value   ====================================================================

	DROP TABLE IF EXISTS #temp;
	DROP TABLE IF EXISTS #temp1;
	DROP TABLE IF EXISTS #temp2;
 
	-- V1.8 replace source_app_id with schema_name, notebook_path, notebook_name
	-- #temp table to store rows that have matching values as provided: (schema_name, notebook_path, notebook_name, target_object_name, target_attribute_name) -keys meant to be unique
	-- used later to check if rows with these matching provided parameters already exists in the DB
	SELECT toa.* INTO #temp FROM ctlfwk.target_objects_attributes toa
	INNER JOIN ctlfwk.target_objects so ON so.target_object_id = toa.target_object_id
	WHERE so.target_object_name = @target_object_name
	AND so.[Schema_Name] = @Schema_Name 
	AND so.notebook_path = @notebook_path 
	AND so.notebook_name = @notebook_name
	AND toa.target_attribute_name = @target_attribute_name

	-- V1.8 replace source_app_id with schema_name, notebook_path, notebook_name
	-- #temp1 table to store rows that have matching values as provided: (schema_name, notebook_path, notebook_name, target_object_name, target_attribute_name, target_attribute_seq)
	-- used later to check if rows with these matching provided parameters already exists in the DB. We do not allow update of an existing row's sequence in this stored proc
	SELECT toa.* INTO #temp1 FROM ctlfwk.target_objects_attributes toa
	INNER JOIN ctlfwk.target_objects so ON so.target_object_id = toa.target_object_id
	WHERE so.target_object_name = @target_object_name
	AND so.[Schema_Name] = @Schema_Name 
	AND so.notebook_path = @notebook_path 
	AND so.notebook_name = @notebook_name
	AND toa.target_attribute_name = @target_attribute_name
	AND toa.target_attribute_seq = @target_attribute_seq

	-- V1.8 replace source_app_id with schema_name, notebook_path, notebook_name
	-- temp2 table to store ONLY the sequence numbers that having matching values as provided: (schema_name, notebook_path, notebook_name, target_object_name, target_attribute_name, target_attribute_seq)
	-- used later to check if the sequence exists. We do not allow insert of a new row containing an exisiting sequence in this stored proc
	SELECT distinct toa.target_attribute_seq INTO #temp2
	FROM ctlfwk.target_objects_attributes toa
	INNER JOIN ctlfwk.target_objects so ON so.target_object_id = toa.target_object_id
	WHERE so.target_object_name = @target_object_name
	AND so.[Schema_Name] = @Schema_Name 
	AND so.notebook_path = @notebook_path 
	AND so.notebook_name = @notebook_name


	/* Data Validation Starts Here */
	IF EXISTS (SELECT * FROM #temp ) -- attribute exists
	   AND NOT EXISTS ( SELECT * FROM #temp1 ) -- matching seq does not exist
			BEGIN
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Manual Insert/Update required. Provided target_object_name, target_attribute_name already exists with a DIFFERENT target_attribute_seq',	
							(N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Seq": "',COALESCE(@target_attribute_seq ,''))  +'" '
							+'}' )
				);
				SET @Returnvalue = 2
			END

	IF NOT EXISTS (SELECT * FROM #temp ) -- attribute does not exist
	   AND EXISTS ( SELECT * FROM #temp2 WHERE target_attribute_seq =@target_attribute_seq ) -- seq exists 
			BEGIN
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Manual Insert/Update required. Provided target_attribute_seq already exists with a DIFFERENT target_object_name, target_attribute_name',	
							(N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Name": "',COALESCE( @target_attribute_name ,''))  +'" '
							+','+CONCAT('"Target_Attribute_Seq": "',COALESCE(@target_attribute_seq ,''))  +'" '
							+'}' )
				);
				SET @Returnvalue = 2
			END

--===========================-- Data Validation and Setting Return Value ENDS ====================================================================

 	-- V1.4
	IF @Returnvalue = 2 
		RAISERROR('sp_add_target_object_attributes: ERROR - Refer to Process_Error Table .', 16, -1)

	-- V1.8 replace source_app_id with schema_name, notebook_path, notebook_name
	-- If No Errors
	IF @Returnvalue =0
		BEGIN --ReturnValue 0
			BEGIN TRY
				BEGIN TRANSACTION
				
					SELECT @Encryption_TypeID = Encryption_TypeID FROM ctlfwk.Encryption_Types WHERE Encryption_Type = @Encryption_Type;
					
				    -- Capturing the Action into #Actions Table 
					DROP TABLE IF EXISTS #ActionTable;
					CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT, [Name] VARCHAR(100))	

					IF (NOT EXISTS (SELECT * FROM #temp)) -- no record exists matching schema_name, notebook_path, notebook_name,, target_object_name, target_attribute_name; INSERT
						BEGIN
							INSERT INTO [ctlfwk].[target_objects_attributes]
							(
								[target_object_id]
							,	[target_attribute_name]
							,	[target_attribute_seq]
							,	[target_attribute_is_active]
							,	[target_attribute_data_type]
							,	[target_attribute_precision] 
							,	[target_attribute_scale]
							,	[target_attribute_array_name]
							,	[target_attribute_is_target_column]
							,	[target_attribute_is_null]
							,	[target_attribute_is_pk]
							,	[target_attribute_is_BusinessKey]
							,	[Encryption_TypeID]
							,	[target_attribute_PII_Function]
							,	[target_attribute_is_historystitch]
							,	[target_attribute_is_historystitch_sortkey]
							,	[target_attribute_Distributed_On]
							,	[target_attribute_Integration_KeyName]
							)
							OUTPUT 'Inserted', inserted.target_object_id, inserted.target_attribute_name
							INTO #ActionTable (Act, Id, [Name])
							SELECT
								so.[target_object_id]
							,	@target_attribute_name
							,	@target_attribute_seq
							,	@target_attribute_is_active
							,	@target_attribute_data_type
							,	@target_attribute_precision 
							,	@target_attribute_scale
							,	@target_attribute_array_name
							,	@target_attribute_is_target_column
							,	@target_attribute_is_null
							,	@target_attribute_is_pk
							,	@target_attribute_is_BusinessKey
							,	@Encryption_TypeID 
							,	@target_attribute_PII_Function
							,	@target_attribute_is_historystitch
							,	@target_attribute_is_historystitch_sortkey
							,	@target_attribute_Distributed_On
							,	@target_attribute_Integration_KeyName
							FROM [ctlfwk].[target_objects] so
							WHERE so.[target_object_name] = @target_object_name
							AND so.[Schema_Name] = @Schema_Name 
							AND so.notebook_path = @notebook_path 
							AND so.notebook_name = @notebook_name
						END
					ELSE -- record exists matching schema_name, notebook_path, notebook_name,, target_object_name, target_attribute_name; UPDATE
						BEGIN
							
							DECLARE @target_object_id INT;

							SET @target_object_id = (SELECT so.[target_object_id]
													 FROM [ctlfwk].[target_objects] so
													 WHERE so.[target_object_name] = @target_object_name
													 AND so.[Schema_Name] = @Schema_Name 
													 AND so.notebook_path = @notebook_path 
													 AND so.notebook_name = @notebook_name
													);

							UPDATE [ctlfwk].[target_objects_attributes]
							SET
									[target_attribute_seq] = @target_attribute_seq
								,	[target_attribute_is_active] = @target_attribute_is_active
								,	[target_attribute_data_type] = @target_attribute_data_type
								,	[target_attribute_precision] = @target_attribute_precision 
								,	[target_attribute_scale] = @target_attribute_scale
								,	[target_attribute_array_name] = @target_attribute_array_name
								,	[target_attribute_is_target_column] = @target_attribute_is_target_column
								,	[target_attribute_is_null] = @target_attribute_is_null
								,	[target_attribute_is_pk] = @target_attribute_is_pk
								,	[target_attribute_is_BusinessKey] = @target_attribute_is_BusinessKey
								,	[Encryption_TypeID] = @Encryption_TypeID
								,	[target_attribute_PII_Function] = @target_attribute_PII_Function
								,	[target_attribute_is_historystitch] = @target_attribute_is_historystitch
								,	[target_attribute_is_historystitch_sortkey] = @target_attribute_is_historystitch_sortkey
								,	[target_attribute_Distributed_On] = @target_attribute_Distributed_On
								,	[target_attribute_Integration_KeyName] = @target_attribute_Integration_KeyName
								,	[Last_Modified_Datetime] = SYSDATETIME()
								,	[Last_Modified_By] = ORIGINAL_LOGIN()
							OUTPUT 'Updated', inserted.target_object_id, inserted.target_attribute_name
							INTO #ActionTable (Act, Id, [Name])
							where
								target_object_id = @target_object_id
								and target_attribute_name = @target_attribute_name
							;
						END
				COMMIT TRANSACTION
			END TRY
			BEGIN CATCH

				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION 

			END CATCH
		END -- Return Value 0


		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_target_object_attributes' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
			END 
		ELSE 
			SELECT CONCAT('Target_Attribute_Name ' + [Name] + ' for Target_Object_Id ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 

 --V1.1 end
END
