﻿CREATE PROCEDURE [ctlfwk].[getJsonReferenceSchema]
 -- @business_unit_name_code VARCHAR(100),  --V1.5 
 -- @source_app_name VARCHAR(100),   --V1.5 
    @target_object_name VARCHAR(100) ,   --V1.5 
    @NotebookName VARCHAR(255), --V1.4 
    @NotebookPath NVARCHAR(255)  --V1.4 
  , @Schema_Name VARCHAR(50) --V1.6 
 
  AS
  /* ==================================================================================================================================================
 
-- Usage Comments if Any : Used to create JSON Schema for Reference objects containing Target Object Details (target_object, target_object_attributes)
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	15-02-2022						Sakshi S  				1.0					InitialVersion		
	21-02-2022						Sakshi S				1.1					Pass source_app_name as Key_domain_name 
	23-02-2022						Sakshi S				1.2					Renaming code_set_name as reference_type_name
	01-03-2022						Tammy H					1.3					Remove all target columns in Json passed to ADF
	05-03-2022                      Sheela R                1.4                 Remove Reference_Type_Name
	08-03-2022                      Sheela R                1.5                 Changes to Input Parameter
	20-04-2022                      Sheela R                1.6                 Changes to Input Parameter to include Schema Name 
	===================================================================================================================================================*/
BEGIN 

	DECLARE @source_app_id INT 

	-- Table Variable to Capture Error/Actions 
	DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	DECLARE @Returnvalue INT = 0 --Success 
	DECLARE @error_flag VARCHAR(100)
	DECLARE @error_message VARCHAR(200)

--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 

	IF NOT EXISTS (SELECT 1 FROM Ctlfwk.target_objects WHERE @NotebookName =notebook_name and @NotebookPath =notebook_path
	               AND @target_object_name=target_object_name AND @Schema_Name =[Schema_Name])
		BEGIN 
			Set @error_flag = 'Error'
			Set @error_message = 'NotebookName and NotebookPath and Schema NAme for the Reference Load  provided does not exist together' 
			
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('" NotebookName": "',COALESCE( @NotebookName ,''))  +'" ' 
												+','+CONCAT('"NotebookPath": "',COALESCE( @NotebookPath ,''))  +'" '
												+'}' )
					);

			SET @Returnvalue =2 ;

		END


--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

	--  If No Errors 
	IF @Returnvalue = 0 
		BEGIN  --ReturnValue 0
			BEGIN TRY
				
				DROP TABLE IF EXISTS #TargetObjectDetails ;

				

				/* format the required columns for JSON target_object_details */

				SELECT DISTINCT	
				
			        [sa].source_app_code AS [source_application_name] --v1.4
			    ,   [sa].source_app_name  AS [source_application_description] --V1.4
			    ,   [to].Schema_Name as [schema_name] --V1.4
				,   [to].target_object_name as [object_name]  --V1.4 
				,   '' AS [target_columns] --V1.4
					INTO #TargetObjectDetails
					FROM [ctlfwk].[target_objects] [to]
					INNER JOIN ctlfwk.source_app sa ON [to].source_app_id = sa.source_app_id  
					INNER JOIN Ctlfwk.business_unit bu ON bu.business_unit_id = sa.business_unit_id
					WHERE [to].notebook_name = @NotebookName 
					--AND sa.source_app_id = @source_app_id  --V1.5 
					AND [to].target_object_name =@target_object_name -- V1.5 
					AND [to].notebook_path =@NotebookPath 
					AND [to].[Schema_Name]=@Schema_Name --V1.6 

				--V1.3 Removed target_columns
				/* format query to JSON */
					SELECT 
						(SELECT 
					--		[source_object] --V1.4
							[source_application_name]
						,	[source_application_description]
						,	[schema_name] 
						,	[object_name] 
						,   [target_columns]
						
					FROM #TargetObjectDetails
					FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER) JsonSchema
			END TRY

			BEGIN CATCH
					
				SET @error_flag = 'Error'
				SET @error_message = ERROR_MESSAGE()

				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 

				SELECT @error_flag AS Error_Flag, @error_message AS Error_Message 

			END CATCH

		END -- Return Value 0 

		 IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'getJsonReferenceSchema' 
				FROM @ErrorUDT; 
				
				RAISERROR('sp_getJsonReferenceSchema: ERROR - Refer to Process_Error Table .' ,17, 1) 
				
		 END 
/*
EXEC [ctlfwk].[getJsonReferenceSchema]
@target_object_name = 'RFRNC_CD' 
,@NotebookName = 'rfrnc_cd_rfrnc_type_src_app'
, @NotebookPath ='rfrnc_cd_rfrnc_type_src_app'
 , @Schema_Name ='Reference'

*/
				  

END
