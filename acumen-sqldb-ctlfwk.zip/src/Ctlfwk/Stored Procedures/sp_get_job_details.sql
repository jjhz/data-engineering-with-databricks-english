﻿
CREATE PROCEDURE [ctlfwk].[sp_get_job_details]
( 
   @source_object_name	VARCHAR(100) =NULL,
   @target_object_name	VARCHAR(100) =NULL,
   @process_type		VARCHAR(100)= NULL 
 --  @stream_name			VARCHAR(255) NULL
)
AS
/* ==================================================================================================================================================
-- Description: This proc can be used to find the Stream, process and Pool Config details for a given object 
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	04-04-2022						Sheela R				 1.0				InitialVersion
=======================================================================================================================================*/
BEGIN

	SET NOCOUNT ON

	DECLARE @ret_status VARCHAR(100)

	IF @source_object_name IS NOT NULL
	BEGIN
		SELECT source_object_name,pc.PoolId,pc.PoolName,p.NoOfWorkers,s.stream_name,p.process_type AS process_Type,process_name

		FROM ctlfwk.vw_process p 
		JOIN vw_stream  s ON p.stream_name=s.stream_name
		JOIN ctlfwk.PoolConfigurationDetails pc ON p.PoolId=pc.PoolId
		WHERE source_object_name = @source_object_name
		AND	(( process_type = @process_type )
		       OR @process_type IS NULL 
		     )
	END

	IF @target_object_name IS NOT NULL
	BEGIN
		SELECT source_object_name ,pc.PoolId,pc.PoolName,p.NoOfWorkers,s.stream_name,p.process_type AS process_Type,process_name
		FROM ctlfwk.vw_process p 
		JOIN vw_stream  s ON p.stream_name=s.stream_name
		JOIN ctlfwk.PoolConfigurationDetails pc ON p.PoolId=pc.PoolId
		WHERE target_object_name = @target_object_name
		AND	(( process_type = @process_type )
		       OR @process_type IS NULL 
		     )

	END
END
