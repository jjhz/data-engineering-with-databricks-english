﻿CREATE PROCEDURE [ctlfwk].[sp_Ops_UpdateSynapseReplicationType]
(
	-- Modified the order of Input 
	@target_object_name varchar(100)
,	@Schema_Name varchar(50)
,	@notebook_path nvarchar(255)
,	@notebook_name nvarchar(255)
,	@replication_type varchar(20)
)
AS

-- =================================================================================================================
-- Usage Comments if Any :Used to update replication_type for target_objects table 
-- Replciation Type can be updated only for Delta Merge Load Type
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	25-03-2022						Niharika S				 1.0				InitialVersion
--	14-04-2022						Niharika S				 1.1				Adding null validations for all input variables
-- ==================================================================================================================

BEGIN 

	declare @ErrorUDT [ctlfwk].[ErrorUDT]
	declare @Returnvalue INT = 0

			IF NOT EXISTS ( SELECT 1 FROM ctlfwk.target_objects WHERE target_object_name = @target_object_name 
																	AND [Schema_Name] = @Schema_Name 
																	AND notebook_path = @notebook_path 
																	AND notebook_name = @notebook_name ) 
				BEGIN 
			
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Target object name does not exist with given notebook_name, notebook_path and schema_name', (N'{'+CONCAT('"Notebook_Name": "',COALESCE( @notebook_name ,''))  +'" ' 
																			+','+CONCAT('"Notebook_Path": "',COALESCE( @notebook_path ,''))  +'" '
																			+','+CONCAT('"Schema_Name": "',COALESCE( @Schema_Name ,''))  +'" '
																			+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																		 	+'}' )
						);

					SET @Returnvalue = 2 ;

				END 
	--V1.1	  
		  IF (@target_object_name IS NULL OR LEN(@target_object_name) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', ' Target_object_name cannot be NULL or Blank', (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" ' 
																					+'}' )
						);

				SET @Returnvalue =2 ;
			END 
		 
		  IF (@Schema_Name IS NULL OR LEN(@Schema_Name) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', ' Schema_Name cannot be NULL or Blank', (N'{'+CONCAT('"Schema_Name": "',COALESCE( @Schema_Name ,''))  +'" ' 
																					+'}' )
						);

				SET @Returnvalue =2 ;
			END 

		  IF (@notebook_path IS NULL OR LEN(@notebook_path) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', ' Notebook_Path cannot be NULL or Blank', (N'{'+CONCAT('"Notebook_Path": "',COALESCE( @notebook_path ,''))  +'" ' 
																					+'}' )
						);

				SET @Returnvalue =2 ;
			END 

		 IF (@notebook_name IS NULL OR LEN(@notebook_name) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', ' Notebook_Name cannot be NULL or Blank', (N'{'+CONCAT('"Notebook_Name": "',COALESCE( @notebook_name ,''))  +'" ' 
																					+'}' )
						);

				SET @Returnvalue =2 ;
			END 

		 IF (@replication_type IS NULL OR LEN(@replication_type) = 0)
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', ' Replication_Type cannot be NULL or Blank', (N'{'+CONCAT('"Replication_Type": "',COALESCE( @replication_type ,''))  +'" ' 
																					+'}' )
						);

				SET @Returnvalue =2 ;
			END 
 --V1.1
		 IF @replication_type NOT IN ('DI', 'CTAS') 
				BEGIN 
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error','Replication_Type does not exist' ,  (N'{' +',' +CONCAT('"Replication_Type": "',COALESCE(@replication_type, ''))	+'" '
																	 +','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
																    + '}')  
						 ) ;
					SET @Returnvalue =2 ;
				END 

		IF @Returnvalue = 2 
			RAISERROR('sp_Ops_UpdateSynapseReplicationType: ERROR - Refer to Process_Error Table .', 16, -1)

		IF @Returnvalue = 0
			BEGIN --Returnvalue0
				BEGIN TRY
					BEGIN TRANSACTION 


						UPDATE tobj 
						SET replication_type = @replication_type
							, Last_Modified_Datetime =SYSDATETIME()
						    , Last_Modified_By = ORIGINAL_LOGIN()
					   FROM ctlfwk.target_objects tobj
					   JOIN ctlfwk.load_types lt ON lt.load_type_id =tobj.load_type_id 
					   WHERE 	target_object_name = @target_object_name
								AND lt.load_type_code ='D' --DeltaLoad
								AND [Schema_Name] = @Schema_Name
								AND notebook_path = @notebook_path
								AND notebook_name = @notebook_name

					COMMIT TRANSACTION;
				END TRY
	
			BEGIN CATCH
		
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION

			END CATCH
		END --Returnvalue0

	IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_Ops_UpdateSynapseReplicationType' 
					FROM @ErrorUDT; 
				
					SELECT * FROM @ErrorUDT 
				END

END 

/*
EXEC [ctlfwk].[sp_Ops_UpdateSynapseReplicationType] 
@target_object_name = 'Hugo_Member'
,	@Schema_Name = 'hugo_uplift'
,	@notebook_path = '../templates/hugo'
,	@notebook_name = 'Hugo_Member'
,	@replication_type = 'CTAS'
*/
