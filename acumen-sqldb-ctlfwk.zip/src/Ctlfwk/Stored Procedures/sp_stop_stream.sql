﻿
CREATE PROCEDURE [ctlfwk].[sp_stop_stream]
( 
  @stream_name  VARCHAR(255) NULL --V1.5
)
AS

/*===============================================================================================================================================================================
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte 				 1.0				InitialVersion
	15-09-2021						Tammy H					 1.1				Changes to Capture Error (those that RAISERROR()) into ctrlfwk.process_errors 
																				and key Input Parameters of Error as JSON
	09-12-2021						Vikas p					 1.2				Changes to have stream restart_from_beginning column always 1
	22-02-2022					    Vikas P					 1.3				@ret_status updated to ERROR if it is failed ,so that it will be easy to handle in adf
	08-03-2022						Vikas P					 1.4				Added @ret_status as failed no fatal is stream is in success/fail state
	18-03-2022						Tammy H					 1.5			    New req: Stream_name raised to be varchar(255)
	23-03-2022						Tammy H					 1.6				Added milliseconds to timestamps: fff
 ================================================================================================================================================================================ */  

SET NOCOUNT ON


BEGIN TRY
	DECLARE 
		@execution_status_id	INT,
        @execution_status_name	VARCHAR(50),
        @stream_id              VARCHAR(50),
        @stream_status_id       VARCHAR(50),
		@ret_status             VARCHAR(100),
        @error_flag			    VARCHAR(100),
		@ret_message		    VARCHAR(100),
        @success_process_count  INT,
        @fail_process_count     INT,
        @running_process_count  INT,
        @all_process_count      INT,
		@Additional_Data        NVARCHAR(4000),    --V1.1
		@restart_from_beginning int 



    /* Error Condition Check, if stream name is not provided or null */
    IF (@stream_name IS NULL OR @stream_name = '')
		BEGIN
			SET @ret_status ='ERROR'
            SET @ret_message ='ERROR - Strem name not provided.'
			SET @Additional_Data = N'{"Stream_Name": ""' + ', "Stream_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}' --V1.6

           (SELECT NULL as Stream_Status_Id, @ret_status AS Return_Status,@ret_message AS Return_Message, format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') AS Stream_Stop_TimeStamp) --V1.6
			RAISERROR('ERROR - Stream name not provided.' ,16,-1)

			---- V1.1 Statements throughout to store Errors in ErrorUDT to capture in ctfwk.process_Error 
			--INSERT INTO @ErrorUDT (error_flag,error_message,additional_message)
			--VALUES( @ret_status, @ret_message, (N'{"Stream_Name": ""' + ', "Stream_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss') + '"}')
			--);

			return -1
		END

	/* Error Condition Check, if steam name is correct */
    SELECT @stream_id = stream_id,@restart_from_beginning=restart_from_beginning FROM ctlfwk.stream WHERE stream_name = @stream_name
	IF (@stream_id IS NULL)
		BEGIN
			SET @ret_status ='ERROR'
            SET @ret_message ='ERROR - Stream name incorrect.'
			SET @Additional_Data = N'{"Stream_Status_ID": ""' + ', "Stream_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}' --V1.6

           (SELECT NULL as Stream_Status_Id, @ret_status AS Return_Status,@ret_message AS Return_Message, format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') AS Stream_Stop_TimeStamp) --V1.6
			RAISERROR('ERROR - Stream name incorrect.' ,16,-1)

			--INSERT INTO @ErrorUDT (error_flag,error_message,additional_message)
			--VALUES( @ret_status, @ret_message, (N'{"Stream_Status_ID": ""' + ', "Stream_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss') + '"}')
			--);
			return -1
		END

    /* Fetch stream status, execution status */
    SELECT @stream_status_id = stream_status_id FROM ctlfwk.stream_status WHERE stream_id = @stream_id
	SELECT @execution_status_id = execution_status_id FROM ctlfwk.stream_status WHERE stream_id = @stream_id
    SELECT @execution_status_name = execution_status_name from Ctlfwk.execution_status where execution_status_id = @execution_status_id
--------------------------------------------v1.2------------------------------------------------------
	IF @restart_from_beginning=0
		BEGIN
			UPDATE Ctlfwk.stream SET restart_from_beginning=1 WHERE stream_id=@stream_id
		END
			
--------------------------------------------v1.2------------------------------------------------------

	IF (@execution_status_name = 'Success'   or         @execution_status_name = 'Failed'    or         @execution_status_name = 'Cancelled' or         @stream_status_id IS NULL)
	    BEGIN
			SET @ret_status ='Failed'--v1.3/v1.4
            SET @ret_message ='Non fatal ERROR - Stream not running, can not stop.'
			SET @Additional_Data = N'{'+CONCAT('"Stream_Status_ID": "',COALESCE( @stream_status_id ,''))  +'" '
									+','+CONCAT('"Execution_Status_Name": "',COALESCE( @execution_status_name ,''))  +'" '
									+ ', "Stream_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}' --V1.6

           (SELECT @stream_status_id as Stream_Status_Id, @ret_status AS Return_Status,@ret_message AS Return_Message, format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') AS Stream_Stop_TimeStamp) --V1.6
			RAISERROR(@ret_message,16,-1)
			return -1
	    END
    
    IF (@execution_status_name = 'Running' or         @execution_status_name = 'Restart')
	    BEGIN
            /* Fetch count of jobs in Running, Failed and Success status under the given stream */
            SELECT @running_process_count = COUNT(*) FROM [Ctlfwk].[process] p
            INNER JOIN [Ctlfwk].[stream] s
            ON p.stream_id = s.stream_id
            INNER JOIN [Ctlfwk].[process_status] ps
            ON ps.process_id = p.process_id
            WHERE s.stream_id = @stream_id AND ps.execution_status_id IN 
            (SELECT execution_status_id FROM ctlfwk.execution_status WHERE execution_status_name = 'Running')
            
            SELECT @success_process_count = COUNT(*) FROM [Ctlfwk].[process] p
            INNER JOIN [Ctlfwk].[stream] s
            ON p.stream_id = s.stream_id
            INNER JOIN [Ctlfwk].[process_status] ps
            ON ps.process_id = p.process_id
            WHERE s.stream_id = @stream_id AND ps.execution_status_id IN 
            (SELECT execution_status_id FROM ctlfwk.execution_status WHERE execution_status_name = 'Success')
            
            SELECT @fail_process_count = COUNT(*) FROM [Ctlfwk].[process] p
            INNER JOIN [Ctlfwk].[stream] s
            ON p.stream_id = s.stream_id
            INNER JOIN [Ctlfwk].[process_status] ps
            ON ps.process_id = p.process_id
            WHERE s.stream_id = @stream_id AND ps.execution_status_id IN 
            (SELECT execution_status_id FROM ctlfwk.execution_status WHERE execution_status_name = 'Failed')
            
            SELECT @all_process_count = COUNT(*) FROM [Ctlfwk].[process] p
            INNER JOIN [Ctlfwk].[stream] s
            ON p.stream_id = s.stream_id
            INNER JOIN [Ctlfwk].[process_status] ps
            ON ps.process_id = p.process_id
            WHERE s.stream_id = @stream_id 

            IF (@running_process_count > 0)
                BEGIN
                    SET @ret_status ='ERROR'
                    SET @ret_message ='ERROR - Can not stop Stream, Some process running under it.'
					SET @Additional_Data = N'{'+CONCAT('"Stream_Status_ID": "',COALESCE( @stream_status_id ,''))  +'" '
											+','+CONCAT('"Execution_Status_Name": "',COALESCE( @execution_status_name ,''))  +'" '
											+ ', "Stream_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}' --V1.6

                   (SELECT @stream_status_id as Stream_Status_Id, @ret_status AS Return_Status,@ret_message AS Return_Message, format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') AS Stream_Stop_TimeStamp) --V1.6
                    RAISERROR('ERROR - Can not stop Stream, Some process running under it.' ,16,-1)


                    return -1
                END
            IF (@fail_process_count > 0)
                BEGIN
                    UPDATE [ctlfwk].[stream_status]
                    SET execution_status_id = (SELECT execution_status_id FROM ctlfwk.execution_status WHERE execution_status_name = 'Failed'), 
                    end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') --V1.6
                    WHERE stream_id = @stream_id
                    
                    SET @ret_status ='ERROR'
                    SET @ret_message ='Stream Stopped Successfully - BUT- Some process under stream is failed.'

                END

            IF (@success_process_count = @all_process_count)
                BEGIN
                    UPDATE [ctlfwk].[stream_status]
                    SET execution_status_id = (SELECT execution_status_id FROM ctlfwk.execution_status WHERE execution_status_name = 'Success'), 
                    end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') --V1.6
                    WHERE stream_id = @stream_id
                    
                    SET @ret_status ='SUCCESS'
                    SET @ret_message ='Success - Stream status updated to Success.'
                END
            
            (SELECT @stream_status_id as Stream_Status_Id, 
                    @ret_status AS Return_Status,
                    @ret_message AS Return_Message, 
                    format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') AS Stream_Stop_TimeStamp) --V1.6
	    END
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()
	
	--V1.1
	INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  )  
	SELECT 'Error' ,@ret_message ,@Additional_Data ,'sp_stop_stream' ;

	RAISERROR	(@ret_message,
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;
