﻿CREATE  PROCEDURE [Ctlfwk].[usp_Process_Parameters_Row_Output]
       @process_name VARCHAR(100),
       @source_object_name VARCHAR(100) = NULL,
       @target_object_name VARCHAR(100) = NULL

AS
BEGIN


-- Declare the variables to hold the dynamic SQL statement, and the two lists of columns

IF (OBJECT_ID('tempdb..#tmp') IS NOT NULL) DROP TABLE #tmp;

CREATE TABLE #tmp ( Process_Name varchar(100), [label] varchar(500)
                  ,[value] varchar(500), row_num int);

DECLARE @stmt nvarchar(max);
DECLARE @pivot_select_list nvarchar(max);
DECLARE @pivot_column_list nvarchar(max);


-- Turn the original data into a table with "Item" and "Qty" column names

WITH numbered AS
     (SELECT Process_Name, Parameter_Name, Parameter_Value as amtsold
            ,ROW_NUMBER() OVER (PARTITION BY Process_Name ORDER BY Parameter_Name) as row_num
        FROM ctlfwk.vw_Process_Parameters
              WHERE Process_Name=@process_name
              AND ISNULL(Source_Object_Name,'') = ISNULL(@source_object_name,'')
              AND ISNULL(Target_Object_Name,'') = ISNULL(@target_object_name,'')
      -- GROUP BY Job_Name, Parameter_Name
     )

INSERT INTO #tmp (Process_Name, [label], [value], row_num)
SELECT Process_Name,
--      ,'Qty' + CAST(row_num as varchar(10)) as [label]
          Parameter_Name as [label]
      ,CAST(amtsold as varchar(500)) as [value]
      ,row_num
  FROM numbered
;

--SELECT * FROM #tmp;

-- Build the simple column list for the PIVOT statement

SET @pivot_column_list
         = STUFF((SELECT ',' + QUOTENAME([label]) 
                    from #tmp
                   group by row_num, [label]
                   order by row_num, [label]
                     FOR XML PATH(''), TYPE
                 ).value('.', 'NVARCHAR(MAX)') 
                 ,1,1,'')
;

-- Build the list of columns for the SELECT list, checking for NULL values

SET @pivot_select_list
         = STUFF((SELECT ',ISNULL(' + QUOTENAME([label]) + ','''') as ' + QUOTENAME([label])
                    from #tmp
                   group by row_num, [label]
                   order by row_num, [label]
                     FOR XML PATH(''), TYPE
                 ).value('.', 'NVARCHAR(MAX)') 
                 ,1,1,'')
;
--select @pivot_select_list


-- Build the actual SQL PIVOT statement

SELECT @stmt = N'SELECT Process_Name, '
              +@pivot_select_list
              +'  FROM
       (SELECT Process_Name, [label], [value]
          FROM #tmp
       ) t
       PIVOT
       (MAX([value]) FOR [label] IN (' + @pivot_column_list + ')
       ) p'
;

--SELECT @pivot_column_list AS [column list];



-- Run the statement to get the desired output
EXECUTE sp_executesql @stmt;

--SELECT * FROM #a 
END