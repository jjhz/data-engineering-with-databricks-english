﻿
CREATE PROCEDURE [ctlfwk].[sp_start_process]
( 
  @process_name VARCHAR(200)
)
AS

/*===============================================================================================================================================================================
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						BUPA 				     1.0				InitialVersion
	02-09-2021						Tammy H				     1.1				Added Logic to skip of Enabled Flag is N or Null 
	15-09-2021						Tammy H					 1.2				Changes to Capture Error (those that RAISERROR()) into ctrlfwk.process_errors 
																				and key Input Parameters of Error as JSON
	10-13-2021						Vikas P					 1.3                Added block for re-run on failure to pick only failure process to run
	14-10-2021                      Sheela R                 1.4                Added Addtional Condition to Scenario 2  to Enable Failed Process to rerun 
	27-10-2021						Tammy H					 1.5				Setting Prev_Process_Start_TimeStamp to 19000101000000 when NULL during restart after process and 2nd last stream failed to allow a timestamp to be passed still
	12-11-2021						Vikas P					 1.6				Added data doc column in Process status and process_status_table
	22-11-2021						Vikas P					 1.7				Added src_file_count column in Process status and process_status_log_table
	23-11-2021						Vikas P					 1.8				Reomved @prev_process_start_ts <= @Stream_2nd_Last_start_ts becouse its not valid 
	01-12-2021						vikas p					 1.9				Added IF (@last_succ_process_start_ts IS NULL) then set to 19000101000000
	01-12-2021						vikas p					 1.10				Added restart from monitor logic
	18-03-2022						Tammy H					 2.0			    New req: Stream_name raised to be varchar(255)
	23-03-2022						Tammy H					 2.1				Added milliseconds to timestamps: fff
 ================================================================================================================================================================================ */  

SET NOCOUNT ON
SET XACT_ABORT ON
BEGIN
BEGIN TRY

	DECLARE 
		@Last_Execution_Status VARCHAR(10),
		@Execution_Status_ID	INT,
		@Process_ID				INT,
		@Stream_Last_Execution_Status VARCHAR(10), -- new variable to check last stream status
		@Stream_Last_start_ts         VARCHAR(100),
		@Stream_2nd_Last_Execution_Status VARCHAR(10), -- new variable to check 2nd last stream status
		@Stream_2nd_Last_start_ts         VARCHAR(100) ,
		@Is_Enabled				VARCHAR(5),  --V1.1
		@Additional_Data        NVARCHAR(4000)    --V1.2 

	DECLARE 
		@error_flag						 VARCHAR(100),
		@error_message					 VARCHAR(100),
		@process_status_id				 VARCHAR(50),
		@process_start_ts				 VARCHAR(100),
		@prev_process_start_ts			 VARCHAR(100),
		@last_succ_process_start_ts		 VARCHAR(100),
		@Source_object_id    			 INT,
		@stream_last_successful_start_ts VARCHAR(100),
		@stream_last_successful_end_ts   VARCHAR(100),
		@last_succ_process_end_ts       VARCHAR(100),
		@Stream_name VARCHAR(255), --v1.10 --2.0
		@stream_Id int, --v1.10
		@restart_from_beginning int --v1.10
 

	/* Fetch Execution_Status_ID From Execution_Status Table */
	SELECT @Execution_Status_ID = Execution_Status_ID FROM ctlfwk.execution_status WHERE execution_status_name = 'Running'

	/* Fetch Process_ID From process Table */
	SELECT @Process_ID = process_id, @Is_Enabled =is_enabled  FROM ctlfwk.vw_process WHERE process_name = @process_name --V1.1 added to capture isenabled
	
	IF @Process_ID IS NULL
	BEGIN
	  
		SET @error_flag = 'Error'
		SET @error_message = 'ERROR - Job Cannot Start. Process does not exist.' 
		SET @process_status_id = 'None'
		SET @process_start_ts = 'None'
		SET @Additional_Data = N'{"Process_Status_ID": "" , "Process_Start_TimeStamp": "", "Prev_Process_Start_TimeStamp": ""}' 
		

		SELECT NULL AS Process_Status_ID, NULL AS Process_Start_TimeStamp,
		       NULL AS Prev_Process_Start_TimeStamp, 
			   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		
		RAISERROR('ERROR - Process does not exist.', 16, -1) 

    END

	-- V1.1 This will skip the process if the Is_Enabled is not 'Y' 
	IF @Is_Enabled <> 'Y'
	BEGIN
		SET @error_flag = 'SKIP'
		SET @error_message = 'SKIP - Process cannot Start , Process Flag is not Enabled' 
		SET @process_status_id = 'None'
		SET @process_start_ts = 'None'
		
		SELECT NULL AS Process_Status_ID, NULL AS Process_Start_TimeStamp,
		       NULL AS Prev_Process_Start_TimeStamp, 
			   @error_flag AS Erro_Flag, @error_message AS ErrorMessage
		
		

    END
    
	 
	 -- V1.1 Run below only if Is_Enabled is 'Y'
	 IF @Is_Enabled = 'Y' 
	 BEGIN -- Is_Enabled  = 'Y'
/*******************************************************************************************************************************************************************
*************************FETCHING METADATA FOR LAST AND SECOND LAST STREAMS FROM 'STREAM_STATUS' AND 'STREAM_STATUS_LOG'********************************************
*******************************************************************************************************************************************************************/

		/* Get Last Execution Status and start time Information of Stream to which process belong */
		SELECT 
			@Stream_Last_Execution_Status = execution_status_name,
			@Stream_Last_start_ts = FORMAT(start_date_time,'yyyyMMddHHmmssfff'), --V2.1
			@Stream_name=stream_name, --v1.10
			@stream_Id=stream_id --v1.10
		FROM 
			ctlfwk.vw_stream_status
		WHERE
			stream_id = (Select Stream_id from Ctlfwk.process where process_id=@Process_ID)

		/*Get restart_from_beginning from stream*/

		SELECT @restart_from_beginning=restart_from_beginning from Ctlfwk.stream where stream_id=@stream_Id

		/* GET Second Last Execution Status and start time Information of Stream to which process belong */

		SELECT  @Stream_2nd_Last_Execution_Status=execution_status_name,
				@Stream_2nd_Last_start_ts=start_date_time
			  FROM (select row_number() over (order by max(FORMAT(ss.start_date_time, 'yyyyMMddHHmmssfff')) desc) rownum, --V2.1
					ss.execution_status_name as execution_status_name, 
					max(FORMAT(ss.start_date_time, 'yyyyMMddHHmmssfff')) as start_date_time --V2.1
					 from	
					   ctlfwk.stream s
						 INNER JOIN	
					   Ctlfwk.vw_stream_status_log ss
						 ON s.stream_id = ss.stream_id
						AND s.stream_id=  (Select Stream_id from Ctlfwk.process where process_id=@Process_ID)
						 Group by s.stream_id,ss.execution_status_name
					 )X
						 where X.rownum=1
	--Used in Restart scenario 0 to handle the between statements
		SELECT
			@stream_last_successful_start_ts = start_date_time
			,@stream_last_successful_end_ts = end_date_time
		FROM (
			select 
				row_number() over (order by max(FORMAT(ss.start_date_time, 'yyyyMMddHHmmssfff')) desc) rownum --V2.1
			,	ss.execution_status_name as execution_status_name
			,	max(FORMAT(ss.start_date_time, 'yyyyMMddHHmmssfff')) as start_date_time  --V2.1
			,	max(FORMAT(ss.end_date_time, 'yyyyMMddHHmmssfff')) as end_date_time --V2.1
			
			from ctlfwk.stream s
			INNER JOIN	Ctlfwk.vw_stream_status_log ss ON
				s.stream_id = ss.stream_id
			AND s.stream_id = (Select Stream_id from Ctlfwk.process where process_id = @Process_ID)
			where
				-- return the most recent successful stream start timestamp
				ss.execution_status_id = (select execution_status_id from ctlfwk.execution_status where execution_status_name = 'Success')
			Group by s.stream_id,ss.execution_status_name
		) X
		where X.rownum = 1

	/*******************************************************************************************************************************************************************
	************************                  FETCHING METADATA FOR LAST PROCESS FROM 'PROCESS_STATUS' *****************************************************************
	*******************************************************************************************************************************************************************/

		/* GET Last Execution Status Information of process For Given Stream Name */
		SELECT 
			@Last_Execution_Status = execution_status_name, -- any status
			@prev_process_start_ts = FORMAT(start_date_time,'yyyyMMddHHmmssfff') --V2.1
		FROM 
			ctlfwk.vw_process_status
		WHERE
			process_name = @process_name

	/*******************************************************************************************************************************************************************	
	*****************************************         INSERT PROCESS METDATA AS PER SCENARIOS          *****************************************************************
	*******************************************************************************************************************************************************************/	
--	print (@Stream_Last_Execution_Status + @Stream_2nd_Last_Execution_Status + @Last_Execution_Status)
	
	/****************************EXECUTION OF PROCESSES WHEN STREAM IS NOT RUNNING**************************************/

		IF (@Stream_Last_Execution_Status IN ('SUCCESS') or @Stream_Last_Execution_Status is NULL)
		BEGIN
		--  SELECT 'LINE 165 IF' 
			SET @error_flag = 'ERROR'
			SET @error_message = 'ERROR - STREAM is not running, cant start the process'
			SET @Additional_Data = N'{"Process_Status_ID": "" , "Process_Start_TimeStamp": "", "Prev_Process_Start_TimeStamp": ""}'

			SELECT NULL AS Process_Status_ID, 
				   NULL AS Process_Start_TimeStamp,
				   NULL AS Prev_Process_Start_TimeStamp, 
				   @error_flag AS Erro_Flag, 
				   @error_message AS ErrorMessage
			RAISERROR('ERROR - STREAM is not running, cant start the process', 16, -1)


		END

		-------------------------------------------------v 1.10 Vikas version , restart from monitor-----------------------------------------------------------
	
	/* this can happen when bronze load is successful and silver load has failed (Stream will be in faild status) it will skip the bronze load when @restart_from_beginning=0 */
	  IF (@Stream_Last_Execution_Status IN ('failed') and @Last_Execution_Status  in ('SUCCESS') and @restart_from_beginning=0)
		
		BEGIN
		
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name)A)
			SET @process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name)B)
			SET @error_flag ='SKIP'
			SET @error_message ='SKIP - Process cannot restart because process executed successfully in previous instance'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @prev_process_start_ts AS Prev_Process_Start_TimeStamp, 
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		 
		END

	
/* this can happen when bronze/silver load is successful/failed and  if stream is be in faild status it will Start the process based on restart_from_beginning flag */

		IF (@Stream_Last_Execution_Status IN ('failed') and @Last_Execution_Status  in ('Failed')) OR 
		   (@Stream_Last_Execution_Status IN ('failed') and (@Last_Execution_Status  in ('SUCCESS')) and @restart_from_beginning=1)
		BEGIN
			INSERT INTO ctlfwk.process_status_log 
				(process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count,Is_restart_from_monitor)--V 1.6/1.7/1.10
			SELECT 
				process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count,Is_restart_from_monitor----V 1.6/1.7//1.10
			FROM
				ctlfwk.vw_process_status
			WHERE
				process_name = @process_name	
			
			/* GET PREVIOUS SUCCESSFUL PROCESS START TIME */
			SET @last_succ_process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
								  FROM (select p.process_id, max(ps.Start_Date_Time) as start_date_time from    
								  ctlfwk.process p
								  INNER JOIN [Ctlfwk].[vw_process_status_log] ps
								  ON p.process_id = ps.Process_id
								  AND ps.execution_status_name = 'Success'
								  AND p.process_name = @process_name
								  Group by p.process_id) X )
			--v1.9
			IF (@last_succ_process_start_ts IS NULL)
				SET @last_succ_process_start_ts = '19000101000000000' --V2.1

	
			/* DELETE RECORD FROM PROCESS_STATUS Table*/

			DELETE FROM ctlfwk.process_status WHERE process_id = @Process_ID 

			/* INSERT NEW EXECUTION in Process_Status Table */

			INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time,Is_restart_from_monitor) --v1.10
			VALUES
			(@Process_ID,@Execution_Status_ID,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff'),1) --v1.10 --V2.1
			
			
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name) A)
			SET @process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name) B)
			SET @error_flag = 'Success'
			SET @error_message = 'Success'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @last_succ_process_start_ts AS Prev_Process_Start_TimeStamp, -- last successful process will be picked
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

			/*Start thr stream on rerun*/

			EXEC [Ctlfwk].[sp_start_stream] ---V1.10
	      	@stream_name = @Stream_name


		END

/* this can happen when bronze load fails during first run of pipeline and there are no records in process status for silver */

		IF @Stream_Last_Execution_Status IN ('failed') AND @Last_Execution_Status IS NULL
		BEGIN

			INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time,Is_restart_from_monitor)
			VALUES
			(@Process_ID,1,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff'),1) --V2.1
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name)A)
			SET @process_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name)B)
			SET @error_flag ='Success'
			SET @error_message ='Success'


			SET @prev_process_start_ts = '19000101000000000' --V2.1

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @prev_process_start_ts AS Prev_Process_Start_TimeStamp, 
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage
			
			/*Start thr stream on rerun*/

			EXEC [Ctlfwk].[sp_start_stream] ---V1.10
	      	@stream_name = @Stream_name


		END
--------------------------------------v 1.10-------------------------------------------------------------------------------------------------------------------------------------------------


	/****************************EXECUTION OF PROCESSES WHEN STREAM IS RUNNING**************************************/

		IF @Stream_Last_Execution_Status IN ('Running') AND @Last_Execution_Status IN ('Success' ,'Cancelled','Failed')    --NORMAL EXECUTION OF PROCESSES IN SEQUENCE
		BEGIN

			/* COPY PREVIOUS SUCCESSFUL/COMPLETED RUN VALUES FROM PROCESS_STATUS Table to PROCESS_STATUS_LOG */
			--  SELECT 'LINE 186 IF' 
			INSERT INTO ctlfwk.process_status_log 
				(process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count)--V 1.6/1.7
			SELECT 
				process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count----V 1.6/1.7
			FROM
				ctlfwk.vw_process_status
			WHERE
				process_name = @process_name	
			
			/* GET PREVIOUS SUCCESSFUL PROCESS START TIME */
			SET @last_succ_process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
								  FROM (select p.process_id, max(ps.Start_Date_Time) as start_date_time from    
								  ctlfwk.process p
								  INNER JOIN [Ctlfwk].[vw_process_status_log] ps
								  ON p.process_id = ps.Process_id
								  AND ps.execution_status_name = 'Success'
								  AND p.process_name = @process_name
								  Group by p.process_id) X )
			--v1.9
			IF (@last_succ_process_start_ts IS NULL)
				SET @last_succ_process_start_ts = '19000101000000000' --V2.1
	
			/* DELETE RECORD FROM PROCESS_STATUS Table*/

			DELETE FROM ctlfwk.process_status WHERE process_id = @Process_ID 

			/* INSERT NEW EXECUTION in Process_Status Table */

			INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time)
			VALUES
			(@Process_ID,@Execution_Status_ID,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')) --V2.1
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name) A)
			SET @process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name) B)
			SET @error_flag = 'Success'
			SET @error_message = 'Success'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @last_succ_process_start_ts AS Prev_Process_Start_TimeStamp, -- last successful process will be picked
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		END

	/****************************EXECUTION OF PROCESSES WHEN STREAM IS RESTARTED**************************************/

	IF  @Stream_Last_Execution_Status IN ('Restart') --NORMAL EXECUTION OF PROCESSES IN SEQUENCE
	BEGIN
			--print('hi')
	
	/* 
		This block is entered when: restart_from_beginning = 0 AND last stream_status = 'Failed' => Restart (when sp_start_stream is executed)

		run 1 = process load ready A = failed.
		run 1 = process persisted staging A = did not run (stream = failed, 8:55) -- 9:00

		run 2 = process load ready A = success
		run 2 = process persisted staging A = success (stream = failed, 9:55) -- 10:00
		run 2 = process load ready B = failed

		run 3 = process load ready A = SHOULD NOT RUN (current process_status = 'Success')
		run 3 = process persisted staging A = SHOULD NOT RUN (current process_status = 'Success')
		run 3 = process load ready B = SHOULD RUN

	*/


	/* Updated on 2-Oct-2020 
	RESTART SCENARIO 0
	-- LAST PROCESS DIDN'T RUN since the stream last failed. There is no enry in the Processs status table since the last successful execution of the stream 
	--> Explanation of the scenario - 
	--> Say Load ready failed for a table on 2-oct and did not get any forward from talend, Persisted Staging last successfuly ran only on 1-oct. 
	--> So when in restart mode of the stream, the load ready had na entry in teh process status and it would get triggered to fix the failed process but because persisted Staging did not have an entry it would not run that step at all. 
	--> The below will cover that scenario to make an entry into the process status for the new persisted staging process for this stream execution.
	*/
		 -- SELECT 'LINE 265 IF' 
		IF (@Last_Execution_Status IN ('Success') AND @Stream_2nd_Last_Execution_Status IN ('Failed') AND @prev_process_start_ts between @stream_last_successful_start_ts and  @stream_last_successful_end_ts
		)
		BEGIN

		/* COPY PREVIOUS SUCCESSFUL/COMPLETED RUN VALUES FROM PROCESS_STATUS Table to PROCESS_STATUS_LOG */

			INSERT INTO ctlfwk.process_status_log
				(process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count)--V 1.6/1.7
			SELECT 
				process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count--V 1.6/1.7
			FROM
				ctlfwk.vw_process_status
			WHERE
				process_name = @process_name	
			
			/* GET PREVIOUS SUCCESSFUL PROCESS START TIME */
			SET @last_succ_process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
								  FROM (select p.process_id, max(ps.Start_Date_Time) as start_date_time from    
								  ctlfwk.process p
								  INNER JOIN [Ctlfwk].[vw_process_status_log] ps
								  ON p.process_id = ps.Process_id
								  AND ps.execution_status_name = 'Success'
								  AND p.process_name = @process_name
								  Group by p.process_id) X )

			--v1.9
			IF (@last_succ_process_start_ts IS NULL)
				SET @last_succ_process_start_ts = '19000101000000000' --V2.1
							  
			/* DELETE RECORD FROM PROCESS_STATUS Table*/

			DELETE FROM ctlfwk.process_status WHERE process_id = @Process_ID 

			/* INSERT NEW EXECUTION in Process_Status Table */

			INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time)
			VALUES
			(@Process_ID,@Execution_Status_ID,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')) --V2.1
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name)A)
			SET @process_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name)B)
			SET @error_flag ='Success'
			SET @error_message ='Success'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @last_succ_process_start_ts AS Prev_Process_Start_TimeStamp, -- last Successful process required for all the executions
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		END

	/* SCENARIO 1
	   LAST PROCESS EXECUTION WAS SUCCESSFUL SO DO NOTHING */

		ELSE IF (@Last_Execution_Status IN ('Success') AND @Stream_2nd_Last_Execution_Status IN ('Failed') AND @prev_process_start_ts > @stream_last_successful_start_ts)
		BEGIN
	--	 SELECT 'LINE 323 IF'  
		--DO NOTHING EXCEPT LOGGING LAST PROCESS STATUS AND START TIME		
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name)A)
			SET @process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name)B)
			SET @error_flag ='SKIP'
			SET @error_message ='SKIP - Process cannot restart because process executed successfully in previous instance'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @prev_process_start_ts AS Prev_Process_Start_TimeStamp, 
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		 
		END
	
		--End for Else

	/* SCENARIO 2
	   LAST PROCESS EXECUTION WAS FAILED/CANCELLED SO RUN PROCESS */

	-- 20200930 added Cancelled process check (which Cancelled is set manually if a process is stuck in 'Running' because network issue, etc)

		
	   --V1.4 starts 
	   --IF (@Last_Execution_Status IN ('Failed', 'Cancelled') AND @Stream_2nd_Last_Execution_Status IN ('Failed') 
		--AND @prev_process_start_ts >= @Stream_2nd_Last_start_ts ) --V1.4 
	--	print (@prev_process_start_ts + @Stream_2nd_Last_start_ts)
		IF
		( 
		(@Last_Execution_Status IN ('Failed', 'Cancelled') AND @Stream_2nd_Last_Execution_Status IN ('Failed') 
		 --AND @prev_process_start_ts <= @Stream_2nd_Last_start_ts --v 1.8
) 
		OR   
		 (  @Last_Execution_Status IN ('Failed') and (@Stream_2nd_Last_Execution_Status is  NULL or @Stream_2nd_Last_Execution_Status='Failed') 
		and @stream_last_successful_end_ts is null and @stream_last_successful_start_ts is NULL--NORMAL EXECUTION OF PROCESSES IN SEQUENCE
		)  

		) 
		--V1.4  Ends 
		BEGIN
		--	print ('hi')
	--	 SELECT 'LINE 353 IF'  
		/* COPY PREVIOUS SUCCESSFUL/COMPLETED RUN VALUES FROM PROCESS_STATUS Table to PROCESS_STATUS_LOG */
			INSERT INTO ctlfwk.process_status_log
				(process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count)--V 1.6/1.7
			SELECT 
				process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count--V 1.6/1.7
			FROM
				ctlfwk.vw_process_status
			WHERE
				process_name = @process_name	
            
				 
			
			/* GET PREVIOUS SUCCESSFUL PROCESS START TIME */
			SET @last_succ_process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
								  FROM (select p.process_id, max(ps.Start_Date_Time) as start_date_time from    
								  ctlfwk.process p
								  INNER JOIN [Ctlfwk].[vw_process_status_log] ps
								  ON p.process_id = ps.Process_id
								  AND ps.execution_status_name = 'Success'
								  AND p.process_name = @process_name
								  Group by p.process_id) X )
			--V1.5		  
			IF (@last_succ_process_start_ts IS NULL)
				SET @last_succ_process_start_ts = '19000101000000000' --V2.1

			/* DELETE RECORD FROM PROCESS_STATUS Table*/

			DELETE FROM ctlfwk.process_status WHERE process_id = @Process_ID 

			/* INSERT NEW EXECUTION in Process_Status Table */

			INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time)
			VALUES
			(@Process_ID,@Execution_Status_ID,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')) --V2.1
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name)A)
			SET @process_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name)B)
			SET @error_flag ='Success'
			SET @error_message ='Success'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @last_succ_process_start_ts AS Prev_Process_Start_TimeStamp, -- last successful process 20200930
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		END

	/* SCENARIO 3
	   LAST PROCESS DIDN'T RUN SO RUN PROCESS */

	/* Special handling */
	-- the comparison is to @stream_last_successful_start_ts

		IF (@Last_Execution_Status IN ('Success','Failed') AND @Stream_2nd_Last_Execution_Status IN ('Failed') AND @prev_process_start_ts < @stream_last_successful_start_ts)
		BEGIN

		/* COPY PREVIOUS SUCCEssful/COMPLETED RUN VALUES FROM PROCESS_STATUS Table to PROCESS_STATUS_LOG */
	--	SELECT 'LINE 414 IF' 
			INSERT INTO ctlfwk.process_status_log
				(process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count)--V 1.6/1.7
			SELECT 
				process_status_id, process_id, execution_status_id, start_date_time, end_date_time,data_doc_link,src_file_count--V 1.6/1.7
			FROM
				ctlfwk.vw_process_status
			WHERE
				process_name = @process_name	
				 
			
			/* GET PREVIOUS SUCCESSFUL PROCESS START TIME */
			SET @last_succ_process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
								  FROM (select p.process_id, max(ps.Start_Date_Time) as start_date_time from    
								  ctlfwk.process p
								  INNER JOIN [Ctlfwk].[vw_process_status_log] ps
								  ON p.process_id = ps.Process_id
								  AND ps.execution_status_name = 'Success'
								  AND p.process_name = @process_name
								  Group by p.process_id) X )
							  
			--v1.9
			IF (@last_succ_process_start_ts IS NULL)
				SET @last_succ_process_start_ts = '19000101000000000' --V2.1
			/* DELETE RECORD FROM PROCESS_STATUS Table*/

			DELETE FROM ctlfwk.process_status WHERE process_id = @Process_ID 

			/* INSERT NEW EXECUTION in Process_Status Table */

			INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time)
			VALUES
			(@Process_ID,@Execution_Status_ID,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')) --V2.1
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name)A)
			SET @process_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name)B)
			SET @error_flag ='Success'
			SET @error_message ='Success'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @last_succ_process_start_ts AS Prev_Process_Start_TimeStamp, -- last Successful process required for all the executions
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		END

	-----------------------------------------------------Vikas version 1.3---------------------------------------------------------------
		--Scenario  When the Process table(@Last_Execution_Status) has a Success Status 
		--and Stream_status_Log (@Stream_2nd_Last_Execution_Status) has no record for  the stream  or has no Failed Status for the Stream 
		 -- i.e NO Last Successful run of the Stream 

		IF  @Last_Execution_Status IN ('Success') and (@Stream_2nd_Last_Execution_Status is  NULL or @Stream_2nd_Last_Execution_Status='Failed') and @stream_last_successful_end_ts is null and @stream_last_successful_start_ts is NULL--NORMAL EXECUTION OF PROCESSES IN SEQUENCE
		BEGIN

			/* COPY PREVIOUS SUCCESSFUL/COMPLETED RUN VALUES FROM PROCESS_STATUS Table to PROCESS_STATUS_LOG */
			  --SELECT 'LINE 186 IF' 
			--INSERT INTO ctlfwk.process_status_log 
			--	(process_status_id, process_id, execution_status_id, start_date_time, end_date_time)
			--SELECT 
			--	process_status_id, process_id, execution_status_id, start_date_time, end_date_time
			--FROM
			--	ctlfwk.vw_process_status
			--WHERE
			--	process_name = @process_name	
			
			/* GET PREVIOUS SUCCESSFUL PROCESS START TIME */
			SET @last_succ_process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
								  FROM (select p.process_id, max(ps.Start_Date_Time) as start_date_time from    
								  ctlfwk.process p
								  INNER JOIN [Ctlfwk].[vw_process_status_log] ps
								  ON p.process_id = ps.Process_id
								  AND ps.execution_status_name = 'Success'
								  AND p.process_name = @process_name
								  Group by p.process_id) X )

	
			--v1.9
			IF (@last_succ_process_start_ts IS NULL)
				SET @last_succ_process_start_ts = '19000101000000000' --V2.1
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name) A)
			SET @process_start_ts = (SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name) B)
			SET @error_flag = 'Skip'
			SET @error_message = 'Skip the flow'

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @last_succ_process_start_ts AS Prev_Process_Start_TimeStamp, -- last successful process will be picked
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage

		END
		
	-----------------------------------------------------Vikas version 1.3---------------------------------------------------------------

	END

	/****************************THROW ERROR WHEN BOTH STREAM AND SAME PROCESS ARE RUNNING**************************************/

		IF @Stream_Last_Execution_Status IN ('Running', 'Restart') AND  @Last_Execution_Status IN ('Running')  --added 'Restart' for @Stream_Last_Execution_Status

		BEGIN
	--	   SELECT 'LINE 470 IF' 
				SET @error_flag='Error'
				SET @error_message = 'ERROR - Job Cannot Start. Previous Process Is Still Running.'
				SET @process_status_id ='None'
				SET @process_start_ts ='None'
				SET @Additional_Data = N'{"Process_Status_ID": "" , "Process_Start_TimeStamp": "", "Prev_Process_Start_TimeStamp": ""}'
			
			SELECT NULL AS Process_Status_ID, NULL AS Process_Start_TimeStamp,
				   NULL AS Prev_Process_Start_TimeStamp, 
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage
		
			RAISERROR('ERROR - Job Cannot Start. Previous Process Is  Still Running.' ,16,-1)

		

		END

	/****************************ADD A NEW PROCESS ID IN PROCESS_STATUS IF THE PROCESS IS RUNNING FOR FIRST TIME**************************************/

		IF @Stream_Last_Execution_Status IN ('Running', 'Restart') AND @Last_Execution_Status IS NULL
		BEGIN
	--	 SELECT 'LINE 491 IF' 
			/* INSERT NEW EXECUTION in Process_Status Table */
			INSERT INTO ctlfwk.process_status (process_id, execution_status_id, start_date_time)
			VALUES
			(@Process_ID,1,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')) --V2.1
	
			SET	@process_status_id = (SELECT MAX(A.process_status_id) 
										FROM (	SELECT process_status_id
												FROM [ctlfwk].[vw_process_status] 
												WHERE process_name = @process_name)A)
			SET @process_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V2.1
										FROM (	SELECT MAX(start_date_time) as start_date_time
												FROM [ctlfwk].[vw_process_status]
												WHERE process_name = @process_name)B)
			SET @error_flag ='Success'
			SET @error_message ='Success'


			SET @prev_process_start_ts = '19000101000000000' --V2.1

			SELECT @process_status_id AS Process_Status_ID, @process_start_ts AS Process_Start_TimeStamp,
				   @prev_process_start_ts AS Prev_Process_Start_TimeStamp, 
				   @error_flag AS Erro_Flag, @error_message AS ErrorMessage
		END

	END -- Is_Enabled  = 'Y' v1.1		
	
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()
	
	--V1.2
	 INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  )  
	 SELECT @error_flag ,@error_message ,@Additional_Data ,'sp_start_process' ;

	RAISERROR	(@error_message,
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;
END