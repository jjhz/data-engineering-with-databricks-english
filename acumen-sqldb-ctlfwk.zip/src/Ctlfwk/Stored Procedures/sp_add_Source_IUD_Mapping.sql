﻿CREATE PROCEDURE [ctlfwk].[sp_add_Source_IUD_Mapping]
(
	@config_type varchar(7)
,	@record_type_name varchar(10)
,   @source_CDC_record_type_value varchar(10)
)
AS

-- ==============================================================================================
 -- Parameters:
--   @config_type -  config type for IUD based on IUD Config table
--   @record_type_name - record type name (I or U or D)
--   @source_CDC_record_type_value = Equivalent source record type (I or U or D - 1 or 2 or 4 etc)
-- Description:	Insert IUD config type record if it does not exist, update if it does exist
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	08-07-2021						Musab | Deloitte		 1.0				InitialVersion
-- =================================================================================================

BEGIN

set nocount on;
	

	declare @config_type_id int;
	-- V1.3 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 



 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 
 IF NOT EXISTS ( SELECT 1 FROM [ctlfwk].[IUD_config_types] WHERE config_type = @config_type ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'config_type does not exist',	(N'{'+CONCAT('"@config_type": "',COALESCE( @config_type ,''))  +'" ' 
																			+'}' )
			);

			SET @Returnvalue =2 ;
		END 

		
IF  (@record_type_name NOT IN  ('I', 'U', 'D') ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'incorrect record_type name - permitted values(I, U, D) ',	(N'{'+CONCAT('"@record_type_name": "',COALESCE( @config_type ,''))  +'" ' 
																			+'}' )
			);

			SET @Returnvalue =2 ;
		END 
 --===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 
 	IF @Returnvalue = 2 
		RAISERROR('sp_add_source_app: ERROR - Refer to Process_Error Table .', 16, -1)

	
	IF @Returnvalue =0
		BEGIN --ReturnValue 0
			BEGIN TRY
				SET @config_type_id = (select ict.config_type_id from [ctlfwk].[IUD_config_types] ict where ict.config_type = @config_type) 

				BEGIN TRANSACTION
					-- V1.1 Capturing the Action into #Actions Table 
					DROP TABLE IF EXISTS #ActionTable;
					CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT)	

					-- check if record exists, if not, insert the row
					if (not exists 
						(
							select 1 
							from [ctlfwk].[Source_IUD_Mapping] sim
							where 
								sim.config_id = @config_type_id
								and sim.record_type_name = @record_type_name
						)
					)
						begin
							insert into [ctlfwk].[Source_IUD_Mapping]
							(
								[config_id]
							 ,	[record_type_id]
							 ,  [record_type_name]
							 ,  [record_type_description]
							 ,	[source_CDC_record_type_value]
							-- ,  last_modified_datetime
							-- ,  last_modified_by
							)
							OUTPUT 'Inserted', inserted.config_IUD_type_id
							INTO #ActionTable (Act, Id)
							select
								@config_type_id
							 ,	CASE 
								   when @record_type_name = 'I' then 1
								   when @record_type_name = 'U' then 2
								   when @record_type_name = 'D' then 3
								 END AS [record_type_id]
							 ,	@record_type_name
							 ,  CASE 
								   when @record_type_name = 'I' then 'Insert'
								   when @record_type_name = 'U' then 'Update'
								   when @record_type_name = 'D' then 'Delete'
								END AS [record_type_description] 
							 ,  @source_CDC_record_type_value
							--,   SYSDATETIME() 
							--,   ORIGINAL_LOGIN()
						end
					else
						begin

							--set @config_type_id = (
							--	select
							--		config_type_id
							--	from [ctlfwk].[IUD_config_types] ict

							--	where 
							--		ict.config_type = @config_type
							--);

							

							update [ctlfwk].[Source_IUD_Mapping]
							set record_type_id = CASE 
													when @record_type_name = 'I' then 1
													when @record_type_name = 'U' then 2
													when @record_type_name = 'D' then 3
												 END
								 , record_type_name = @record_type_name 
								 --, record_type_description = CASE 
									--							when @record_type_name = 'I' then 'Insert'
									--							when @record_type_name = 'U' then 'Update'
									--							when @record_type_name = 'D' then 'Delete'
									--						END 
								 --, last_modified_datetime = SYSDATETIME() 
								 --, last_modified_by = ORIGINAL_LOGIN()
							OUTPUT 'Updated', inserted.config_IUD_type_id
							INTO #ActionTable (Act, Id)
							where 
								 config_id = @config_type_id
								 and record_type_name = @record_type_name
						end
				COMMIT TRANSACTION
			END TRY

			BEGIN CATCH

				--V1.3
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION 

			END CATCH
		END

		--V1.3
		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Source_IUD_Mapping' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
			END 
		ELSE 
			SELECT CONCAT('Config_IUD_Type_ID ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 
END