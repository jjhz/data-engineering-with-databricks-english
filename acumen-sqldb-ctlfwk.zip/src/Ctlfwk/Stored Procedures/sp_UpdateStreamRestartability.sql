﻿
CREATE PROCEDURE [ctlfwk].[sp_UpdateStreamRestartability]
( 
  
  @stream_name VARCHAR(100), 
  @restart_from_beginning bit = 0
)
AS

/*=======================================================================================================================

-- Usage Comments if Any :
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	13-10-2021						Sheela R 				 1.0				InitialVersion
	 
-- ===================================================================================================================================================  */

BEGIN

set nocount on;
 
	-- V1.1 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 

 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 
 	

	IF (@stream_name IS NULL OR LEN(@stream_name) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Stream_Name cannot be NULL or Blank',	(N'{' 
																+CONCAT('"Stream_Name": "',COALESCE( @stream_name ,''))  +'" '
																+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	-- Precaution check. Since restart_from_beginning is BIT, SQL should auto convert values to 1 or 0 unless it is a NULL, which is the previous validation. So this error should not occut at all.
	IF (@restart_from_beginning NOT IN (1,0))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Restart_From_Beginning can only have values 1 or 0',	(N'{' +CONCAT('"Stream_Name": "',COALESCE( @stream_name ,''))  +'" '
																+','+CONCAT('"Restart_From_Beginning": "',COALESCE( CONVERT(VARCHAR(1), @restart_from_beginning) ,''))  +'" '
																+'}' )
			);

			SET @Returnvalue =2 ;
		END 		





 --===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 


 	-- If No Errors
	IF @Returnvalue =0
		BEGIN --ReturnValue 0
			BEGIN TRY
				BEGIN TRANSACTION
					 
					 		UPDATE ctlfwk.stream
							SET
								
								restart_from_beginning = @restart_from_beginning,
								Last_Modified_Datetime = SYSDATETIME(),
								Last_Modified_By = ORIGINAL_LOGIN()
							
							WHERE
								stream_name = @stream_name
								 

					 

				COMMIT TRANSACTION
			END TRY
			BEGIN CATCH
			
				--V1.1
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION 

				--raiserror ('Ctlfwk.sp_add_stream: %d: %s', 16, 1, @error, @message) ;
			END CATCH
		END -- ReturnValue 0

		--V1.1
		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Stream' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
			END 
		--ELSE 
		--	SELECT CONCAT('Stream_Id ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 
END

 
