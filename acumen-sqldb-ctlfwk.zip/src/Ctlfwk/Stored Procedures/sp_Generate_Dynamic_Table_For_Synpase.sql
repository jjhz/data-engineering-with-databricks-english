﻿
CREATE PROC [ctlfwk].[sp_Generate_Dynamic_Table_For_Synpase] 
(
	@Target_Object_Name [VARCHAR](100) ,
	@Source_app_name  [VARCHAR](250),
	@Schema_name VARCHAR(50),
	@Notebook_name VARCHAR(255),
	@Notebook_path VARCHAR(255),
	@Target_Object_prefix [VARCHAR](250),
	@Target_Object_suffix [VARCHAR](250) 
	
)

/*===============================================================================================================================================================================
-- Usage Comments if Any :Used to Fetch DDL from Ctlw  
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-01-2022						Vikas P 				   1.0				InitialVersion
	20-04-2022						Sakshi S				   1.1				Add Notebook_name, Notebook_path and Schema_name as input parameters
	--Testing EXEC Sample 
	Exec [Ctlfwk].[sp_Generate_Dynamic_Table_For_Synpase] 'Hugo_Customer','Hugo_uplift','Hugo_uplift','Hugo_Customer','../templates/hugo',NULL,NULL
 ================================================================================================================================================================================ */  

AS
BEGIN 
 
  DECLARE 
	  @ProcName          VARCHAR(500),
	@ConvertedColumnList NVARCHAR(MAX),
	@ConvertedColumnList_Json NVARCHAR(MAX),
	@ConvertedColumnList_IK NVARCHAR(MAX),
	@ConvertedColumnList_wip NVARCHAR(MAX),
	@Synapse_distribution_type VARCHAR(250),
	@Target_attribute_PII_Function VARCHAR(250),
	@Target_attribute_Distributed_On NVARCHAR(MAX),
	@Create_table_statement   NVARCHAR(MAX),
	@Create_table_statement_wip NVARCHAR(MAX),
	@Target_Object_Name_Pre_Suff  VARCHAR(250),
	@exectution_status_id	INT,
	@ret_status VARCHAR(100),
	@Business_Unit VARCHAR(100),
	--@Schema_name VARCHAR(50),
	@Target_Object_schema VARCHAR(100),
	@Additional_Data        NVARCHAR(4000), 
	@synapse_override        NVARCHAR(4000)     
	DECLARE  @ErrorUDT [ctlfwk].[ErrorUDT] ;
	DECLARE @Returnvalue INT = 0 --Success 
	
	
					
	
	IF @Target_Object_Name IS NULL OR LEN(@Target_Object_Name)=0
		BEGIN
		    SET @ret_status ='ERROR - Target_Object_Name is null.'
			SET @Additional_Data = N'{"Process_Status_Id": ""' + ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss') + '"}' 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ( 'Error' , @ret_status ,@Additional_Data ) 
			--RAISERROR('Target_Object_schema_ERROR - Target_Object_schema is null',17, 1);
			SET @Returnvalue = 2 
	
	  END
	 
	--V1.1    
	IF NOT EXISTS (SELECT TOP 1 target_object_name FROM Ctlfwk.target_objects AS TON INNER JOIN Ctlfwk.target_objects_attributes
					TOA on TOA.target_object_id=TON.target_object_id INNER JOIN Ctlfwk.source_app  AS SA on SA.source_app_id=TON.source_app_id 
					WHERE target_object_name=@Target_Object_Name AND Schema_Name=@Schema_name AND notebook_name=@Notebook_name AND notebook_path=@Notebook_path	
					AND sa.source_app_name=@Source_app_name) 
		BEGIN
			SET @ret_status ='ERROR - target_object is not linked with target_objects_attributes or source_app'
			SET @Additional_Data = N'{"Process_Status_Id": ""' + ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss') + '"}' 
		--	RAISERROR('target_object_name_ERROR - target_object_name is not exit in Target object table.' ,17, 1);
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ( 'Error' , @ret_status ,@Additional_Data ) 
			SET @Returnvalue = 2 
		END
	
	--IF NOT EXISTS (SELECT TOP 1 target_object_name FROM Ctlfwk.target_objects AS TON INNER JOIN Ctlfwk.target_objects_attributes
	--				TOA on TOA.target_object_id=TON.target_object_id 
	--				INNER JOIN Ctlfwk.source_app  AS SA on SA.source_app_id=TON.source_app_id 
	--				where target_object_name=@Target_Object_Name and Target_attribute_Distributed_On='Y'  AND sa.source_app_name=@Source_app_name
	--				AND synapse_distribution_type='HASH') 
				  
	--	BEGIN
	--		SET @ret_status ='ERROR - Target_attribute_Distributed_On must be Y for atleast one column.'
	--		SET @Additional_Data = N'{"Process_Status_Id": ""' + ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss') + '"}' 
	--	--	RAISERROR('target_object_name_ERROR - target_object_name is not exit in Target object table.' ,17, 1);
	--		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
	--		VALUES ( 'Error' , @ret_status ,@Additional_Data ) 
	--		SET @Returnvalue = 2 
	--	END

--Get required param
	--V1.1
	SELECT @Synapse_distribution_type=o.synapse_distribution_type ,
		   @Schema_name=Lower(o.[Schema_name]),
		   @Business_Unit=LOWER(bu.business_unit_name_code),
		   @synapse_override=CASE WHEN o.synapse_override is NULL OR LEN(o.synapse_override)=0 then ' ' ELSE ','+o.synapse_override  End
						FROM ctlfwk.target_objects o INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=o.source_app_id
													 INNER JOIN Ctlfwk.business_unit as bu on bu.business_unit_id=sa.business_unit_id	
						where o.target_object_name = @target_object_name AND o.Schema_Name=@Schema_name AND o.notebook_name=@Notebook_name 
						AND o.notebook_path=@Notebook_path AND sa.source_app_name=@Source_app_name
	
	--V1.1
	---When Synapse override is blank  and if there is Varchar(Max) column in table-then cluster index should get created on PK Hash
	IF  EXISTS(SELECT TOP 1 target_attribute_array_name
				  FROM ctlfwk.target_objects o INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=o.source_app_id
				  INNER JOIN ctlfwk.target_objects_attributes toa
				  ON  o.target_object_id = toa.target_object_id
				  where o.target_object_name = @target_object_name AND o.Schema_Name=@Schema_name AND o.notebook_name=@Notebook_name AND o.notebook_path=@Notebook_path AND sa.source_app_name=@Source_app_name
				  AND (toa.target_attribute_array_name IS NOT NULL OR toa.target_attribute_precision='Max') 
				  )
	
		BEGIN
			SET @synapse_override=',CLUSTERED INDEX([Pk_Hash])'	
		END
	----set schema name
	
	SET @Target_Object_schema=@Business_Unit+'_gld_'+@Schema_name
	SET @Target_Object_Name=LOWER(@Target_Object_Name)
	
	--====================================Input VAlidation Parameter Check Complete=======================	
	  -- Setting Prefix and Suffix to the @Target_Object_Name based on input Parameter if not null or not blank 
	
	 IF @Returnvalue = 0 
	 BEGIN --@Returnvalue = 0 
		  BEGIN TRY
			  IF (@Target_Object_prefix ='' AND @Target_Object_suffix !='') OR (@Target_Object_prefix IS NULL AND @Target_Object_suffix IS NOT NULL)
				 BEGIN
					SET @Target_Object_Name_Pre_Suff=@Target_Object_Name+'_'+@Target_Object_suffix
			
				 END
				 ELSE IF (@Target_Object_suffix ='' AND @Target_Object_prefix!='') OR (@Target_Object_suffix IS NULL AND @Target_Object_prefix IS NOT NULL)
					BEGIN
						SET @Target_Object_Name_Pre_Suff=@Target_Object_prefix+'_'+@Target_Object_Name
					END
				ELSE IF (@Target_Object_prefix!='' AND @Target_Object_suffix !='')
					BEGIN
						SET @Target_Object_Name_Pre_Suff=@Target_Object_prefix+'_'+@Target_Object_Name+'_'+@Target_Object_suffix
					END  
				ELSE 
					BEGIN
						SET @Target_Object_Name_Pre_Suff=@Target_Object_Name
					 END
		--====================================Fetch Data Type and Concatenate=======================	
		  /* Get Column name and datatype along with PII funcation */
	
		  SELECT     @ConvertedColumnList =  STRING_AGG(CONCAT('['+toa.target_attribute_name+'] ',
								   CASE
											  WHEN toa.target_attribute_data_type = 'BINARY' THEN Concat('BINARY(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'CHAR' THEN Concat('CHAR(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'DATETIME2' THEN Concat('DATETIME2(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'DATETIMEOFFSET' THEN Concat('DATETIMEOFFSET(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'DECIMAL' THEN Concat('DECIMAL(', toa.target_attribute_precision, ',', target_attribute_scale, ')')
											  WHEN toa.target_attribute_data_type = 'NUMERIC' THEN Concat('NUMERIC(', toa.target_attribute_precision, ',', target_attribute_scale, ')')
											  WHEN toa.target_attribute_data_type = 'NCHAR' THEN Concat('NCHAR(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'NVARCHAR' THEN Concat('NVARCHAR(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'VARBINARY' THEN Concat('VARBINARY(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'VARCHAR' THEN Concat('VARCHAR(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'TIME' THEN Concat('TIME(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'FLOAT' THEN Concat('FLOAT(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'REAL' THEN ('REAL')
											  WHEN toa.target_attribute_data_type like '%array%'THEN 'NVARCHAR(Max)'
											  ELSE toa.target_attribute_data_type
								   END,
								 
								 CASE WHEN target_attribute_PII_Function IS NULL THEN  '' 
									  WHEN LEN(target_attribute_PII_Function )>0 THEN ' MASKED WITH (FUNCTION = '''+ target_attribute_PII_Function+''')'
								 ELSE '' END,CASE WHEN target_attribute_is_null ='Y' THEN ' NULL ' ELSE ' NOT NULL ' END
								 ),',') within GROUP (ORDER BY toa.target_attribute_seq)
						FROM       ctlfwk.target_objects o
						INNER JOIN ctlfwk.target_objects_attributes toa
						ON         o.target_object_id = toa.target_object_id
						INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=o.source_app_id	 --V1.1
						WHERE      o.target_object_name = @target_object_name AND o.Schema_Name=@Schema_name AND o.notebook_name=@Notebook_name  --V1.1
						AND o.notebook_path=@Notebook_path AND sa.source_app_name=@Source_app_name and toa.target_attribute_is_target_column='Y'
	---Wip column list
				SELECT     @ConvertedColumnList_wip =  STRING_AGG(CONCAT('['+toa.target_attribute_name+'] ',
								   CASE
											  WHEN toa.target_attribute_data_type like '%array%'THEN 'NVARCHAR(Max)'
											  WHEN toa.target_attribute_data_type = 'BINARY' THEN Concat('BINARY(', toa.target_attribute_precision, ')')
											  WHEN toa.target_attribute_data_type = 'VARBINARY' THEN Concat('VARBINARY(', toa.target_attribute_precision, ')')
											  ELSE 'VARCHAR(8000)'
								   END,
								 
								 CASE WHEN target_attribute_PII_Function IS NULL THEN  '' 
									  WHEN LEN(target_attribute_PII_Function )>0 THEN ' MASKED WITH (FUNCTION = '''+ target_attribute_PII_Function+''')'
								 ELSE '' END,CASE WHEN target_attribute_is_null ='Y' THEN ' NULL ' ELSE ' NOT NULL ' END
								 ),',') within GROUP (ORDER BY toa.target_attribute_seq)
						FROM       ctlfwk.target_objects o
						INNER JOIN ctlfwk.target_objects_attributes toa
						ON         o.target_object_id = toa.target_object_id
						INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=o.source_app_id	--V1.1
						WHERE      o.target_object_name = @target_object_name AND o.Schema_Name=@Schema_name AND o.notebook_name=@Notebook_name  --V1.1
						AND o.notebook_path=@Notebook_path AND sa.source_app_name=@Source_app_name and toa.target_attribute_is_target_column='Y'
	
	---Get Json column name			
	
				Select @ConvertedColumnList_Json=	STRING_AGG(CONCAT('['+toa.target_attribute_array_name+'] ',
								   ' NVARCHAR(Max) '+
								 
								 CASE WHEN target_attribute_PII_Function IS NULL THEN  '' 
									  WHEN LEN(target_attribute_PII_Function )>0 THEN ',MASKED WITH (FUNCTION = '''+ target_attribute_PII_Function+''') NULL'
								 ELSE '' END
								 ),',') within GROUP (ORDER BY toa.target_attribute_array_name)
														FROM   (
									SELECT target_attribute_array_name,target_attribute_PII_Function from(
									SELECT  target_attribute_array_name+'_Json' as target_attribute_array_name
									,target_attribute_PII_Function,ROW_NUMBER() Over (Partition by target_attribute_array_name order by target_attribute_seq ) rn
									 from
									ctlfwk.target_objects o
						INNER JOIN ctlfwk.target_objects_attributes toa
						ON         o.target_object_id = toa.target_object_id
						INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=o.source_app_id	 --V1.1
						WHERE      o.target_object_name = @target_object_name AND o.Schema_Name=@Schema_name AND o.notebook_name=@Notebook_name  --V1.1
						AND o.notebook_path=@Notebook_path AND sa.source_app_name=@Source_app_name and target_attribute_array_name is not null
						) as temp where temp.rn=1 --and toa.target_attribute_is_target_column='N'
					) toa
	----Get Distributed column
						SELECT      @Target_attribute_Distributed_On=ISNULL(STRING_AGG('['+oa.target_attribute_name+']',',') within GROUP (ORDER BY oa.target_attribute_seq),'Pk_Hash')
						FROM       ctlfwk.target_objects o
						INNER JOIN ctlfwk.target_objects_attributes oa
						ON         o.target_object_id = oa.target_object_id
						INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=o.source_app_id	 --V1.1
						WHERE      o.target_object_name = @target_object_name AND o.Schema_Name=@Schema_name AND o.notebook_name=@Notebook_name  --V1.1
						AND o.notebook_path=@Notebook_path AND sa.source_app_name=@Source_app_name AND Target_attribute_Distributed_On='Y'
	
	---get IK column and Year_Month
						SELECT      @ConvertedColumnList_IK=STRING_AGG('['+oa.target_attribute_Integration_KeyName+']  [BINARY](32) NULL ',',') within GROUP (ORDER BY oa.target_attribute_seq)	
									+', [Year_Month] INT NOT NULL'
						FROM       ctlfwk.target_objects o
						INNER JOIN (
									Select  target_attribute_Integration_KeyName,target_attribute_seq ,target_object_id
									FROM (
									SELECT  target_attribute_Integration_KeyName,ta.target_object_id,target_attribute_seq,
											ROW_NUMBER() Over (Partition by target_attribute_Integration_KeyName order by target_attribute_seq) dup
								    FROM ctlfwk.target_objects_attributes ta
									INNER JOIN Ctlfwk.target_objects as toa on toa.target_object_id=ta.target_object_id
									INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=toa.source_app_id	
									WHERE      toa.target_object_name = @target_object_name AND toa.Schema_Name=@Schema_name AND toa.notebook_name=@Notebook_name  --V1.1
									AND toa.notebook_path=@Notebook_path
									)as s where s.dup=1) oa ON o.target_object_id = oa.target_object_id
						INNER JOIN Ctlfwk.source_app as sa on sa.source_app_id=o.source_app_id	
						WHERE      o.target_object_name = @target_object_name AND o.Schema_Name=@Schema_name AND o.notebook_name=@Notebook_name AND o.notebook_path=@Notebook_path AND sa.source_app_name=@Source_app_name --V1.1
									 AND target_attribute_Integration_KeyName is not NULL or target_attribute_Integration_KeyName!=''
					
	
		   IF @ConvertedColumnList IS NULL OR @ConvertedColumnList_IK IS NULL OR @ConvertedColumnList_wip IS NULL
			BEGIN 
		        SET @ret_status ='ERROR -  ConvertedColumnList is null OR ConvertedColumnList_IK Is null '
				SET @Additional_Data = N'{"Process_Status_Id": ""' + ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss') + '"}' 
			--	RAISERROR('target_object_name_ERROR - target_object_name is not exit in Target object table.' ,17, 1);
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ( 'Error' , @ret_status ,@Additional_Data ) 
				SET @Returnvalue = 2 
			END	
		
		  SET @ConvertedColumnList=CONCAT(@ConvertedColumnList,','+@ConvertedColumnList_Json,','+@ConvertedColumnList_IK)
		  SET @ConvertedColumnList_wip=CONCAT(@ConvertedColumnList_wip,','+@ConvertedColumnList_Json,','+@ConvertedColumnList_IK)
	
		  SET @Create_table_statement_wip='IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(''['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+']'') AND type in (N''U''))
												BEGIN
													CREATE  TABLE ['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+'] 
													(  
														  [Pk_Hash] [BINARY](32) NOT NULL
														 ,[Row_Hash] [BINARY](32) NOT NULL
														 ,[Effective_Dttm] DATETIME2 NOT NULL
														 ,[Expiry_Dttm] DATETIME2 NOT NULL
														 ,[Source_App_Name] VARCHAR(250) NOT NULL
														 ,[Record_Type] VARCHAR(4) NOT NULL
														 ,[Record_Insert_Dttm] DATETIME2 NOT NULL
														 ,[Record_Update_Dttm] DATETIME2 NULL
														 ,[Process_Instance_ID] VARCHAR(250)  NOT NULL
														 ,[Update_Process_Instance_ID] VARCHAR(250) NULL
														 ,[Is_Current] BIT NOT NULL ,
														 '+@ConvertedColumnList_wip+'
													 )
														WITH  
													(
														DISTRIBUTION = HASH([Pk_Hash]),
														CLUSTERED INDEX ([Pk_Hash])
													)
											  END;'
	
	
		  IF(@Synapse_distribution_type='HASH')
					BEGIN
			
	
						SET @Create_table_statement = 
											'IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(''['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+']'') AND type in (N''U''))
												BEGIN
													CREATE  TABLE ['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+'] 
													(  
														  [Pk_Hash] [BINARY](32) NOT NULL
														 ,[Row_Hash] [BINARY](32) NOT NULL
														 ,[Effective_Dttm] DATETIME2 NOT NULL
														 ,[Expiry_Dttm] DATETIME2 NOT NULL
														 ,[Source_App_Name] VARCHAR(250) NOT NULL
														 ,[Record_Type] VARCHAR(4) NOT NULL
														 ,[Record_Insert_Dttm] DATETIME2 NOT NULL
														 ,[Record_Update_Dttm] DATETIME2 NULL
														 ,[Process_Instance_ID] VARCHAR(250)  NOT NULL
														 ,[Update_Process_Instance_ID] VARCHAR(250) NULL
														 ,[Is_Current] BIT NOT NULL ,
														 '+@ConvertedColumnList+'
													 )
														WITH  
													(
														DISTRIBUTION = HASH('+@Target_attribute_Distributed_On+')
														'+@synapse_override+'
													)
											  END;'
					END		
			IF(@Synapse_distribution_type='ROUND_ROBIN')
				BEGIN
					SET @Create_table_statement = 
											'IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(''['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+']'') AND type in (N''U''))
											 BEGIN
													CREATE  TABLE ['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+'] 
													(  
														  [Pk_Hash] [BINARY](32) NOT NULL
														 ,[Row_Hash] [BINARY](32) NOT NULL
														 ,[Effective_Dttm] DATETIME2 NOT NULL
														 ,[Expiry_Dttm] DATETIME2 NOT NULL
														 ,[Source_App_Name] VARCHAR(250) NOT NULL
														 ,[Record_Type] VARCHAR(4) NOT NULL
														 ,[Record_Insert_Dttm] DATETIME2 NOT NULL
														 ,[Record_Update_Dttm] DATETIME2 NULL
														 ,[Process_Instance_ID] VARCHAR(250)  NOT NULL
														 ,[Update_Process_Instance_ID] VARCHAR(250) NULL
														 ,[Is_Current] BIT NOT NULL ,
														 '+@ConvertedColumnList+'
													 )
														WITH  
													(
														DISTRIBUTION = ROUND_ROBIN
														'+@synapse_override+'
													)
											  END;'
				END
	
			IF(@Synapse_distribution_type='REPLICATE')
				BEGIN	
					SET @Create_table_statement = 
											'IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(''['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+']'') AND type in (N''U''))
											 BEGIN
													CREATE  TABLE ['+@Target_Object_schema+'].['+@Target_Object_Name_Pre_Suff+'] 
													(  
														  [Pk_Hash] [BINARY](32) NOT NULL
														 ,[Row_Hash] [BINARY](32) NOT NULL
														 ,[Effective_Dttm] DATETIME2 NOT NULL
														 ,[Expiry_Dttm] DATETIME2 NOT NULL
														 ,[Source_App_Name] VARCHAR(250) NOT NULL
														 ,[Record_Type] VARCHAR(4) NOT NULL
														 ,[Record_Insert_Dttm] DATETIME2 NOT NULL
														 ,[Record_Update_Dttm] DATETIME2 NULL
														 ,[Process_Instance_ID] VARCHAR(250)  NOT NULL
														 ,[Update_Process_Instance_ID] VARCHAR(250) NULL
														 ,[Is_Current] BIT NOT NULL ,
														 '+@ConvertedColumnList+'
													 )
														WITH  
													(
														DISTRIBUTION = REPLICATE
														'+@synapse_override+'
													)
											  END;'
				END	
	
			--Print @Create_table_statement
				
				
			 
					--EXEC sp_executesql @Create_table_statement	
	
		
			/*********************************************************************************************************/
			/* RETURN SUCCESS IF COMPLETED  */
			/*********************************************************************************************************/
			SELECT 'Success' AS ErrorFlag, '[UTILITY].[usp_create_Silver_table] Completed Successfully' AS ErrorMessage,
					@Create_table_statement AS Gld_DDL,
					REPLACE(REPLACE(@Create_table_statement_wip,@Target_Object_schema,@Business_Unit+'_gld_work'),@Target_Object_Name_Pre_Suff,@Target_Object_Name_Pre_Suff+'_wip')  as Wip_DDL,
					REPLACE(REPLACE(@Create_table_statement,@Target_Object_schema,@Business_Unit+'_gld_work'),@Target_Object_Name_Pre_Suff,@Target_Object_Name_Pre_Suff+'_stg')   as Stg_DDL,
				    'TRUNCATE TABLE ['+@Business_Unit+'_gld_work'+'].['+@Target_Object_Name_Pre_Suff+'_wip'+'];' as Truncate_wip_tbl
		
		END TRY 
		  --Error catch block 
		BEGIN CATCH 
		  IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION
	
			DECLARE @ErrorSeverity VARCHAR(2500) = ERROR_SEVERITY()
			DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
			DECLARE @ErrorState	NVARCHAR(4000)	=	ERROR_STATE();
	
			INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
		    VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10),(ERROR_LINE())) + '"}')); 
			--V1.1
			--INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  )  
			--SELECT 'Error' ,@ret_status ,@Additional_Data ,'sp_Generate_Dynamic_Table_For_Synpase' ;
	
			--RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
	
			--RETURN -1;
	
	
		END CATCH;
	END--@Returnvalue = 0 
	 IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) --V1.2
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_Generate_Dynamic_Table_For_Synpase' 
			  FROM @ErrorUDT; 

			 -- SELECT * FROM @ErrorUDT ;
			  RAISERROR('sp_Generate_Dynamic_Table_For_Synpase: ERROR - Refer to Process_Error Table .' ,17, 1)
		  END 

	
END 
