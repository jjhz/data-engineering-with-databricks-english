﻿CREATE PROCEDURE [Ctlfwk].[getJsonTargetSchemaWrapper]
(
  @business_unit_name_code VARCHAR(100), 
  @source_app_name VARCHAR(100),
  @target_object_name VARCHAR(100) =Null,
  @code_set_name VARCHAR(100) = Null,
  @load_type VARCHAR(1)
)
AS

  /* ==================================================================================================================================================
 
-- Usage Comments if Any : This Stored Proc executes stored proc to generate Json Schema  
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	15-02-2022						Sakshi S  				1.0					InitialVersion

	===================================================================================================================================================*/

BEGIN

    SET NOCOUNT ON

    DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	DECLARE @Returnvalue INT = 0 --Success 
	DECLARE @error_flag VARCHAR(100)
	DECLARE @error_message VARCHAR(200)

	BEGIN TRY
		IF (@code_set_name IS NOT NULL AND @load_type='R')
		/* Generate Json for Reference Objects*/
		BEGIN
			EXEC [Ctlfwk].[getJsonReferenceSchema] @business_unit_name_code, @source_app_name , @target_object_name=@target_object_name , @code_set_name=@code_set_name
		END
		ELSE
		/* Generate Json for all other Objects*/
		BEGIN
			EXEC [Ctlfwk].[getJsonTargetSchema] @business_unit_name_code, @source_app_name , @target_object_name=@target_object_name
		END
	END TRY

	BEGIN CATCH
					
		SET @error_flag = 'Error'
		SET @error_message = ERROR_MESSAGE()

		INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
		VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 

		SELECT @error_flag AS Error_Flag, @error_message AS Error_Message 

	END CATCH

	IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
		BEGIN
			INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			SELECT error_flag ,error_message AS Error_Description,additional_message,  'getJsonTargetSchemaWrapper' 
			FROM @ErrorUDT; 
			
			RAISERROR('sp_getJsonTargetSchemaWrapper: ERROR - Refer to Process_Error Table .' ,17, 1) 
			
		END
END

/*
EXEC [ctlfwk].[getJsonTargetSchemaWrapper]
@business_unit_name_code = 'HI'
,@source_app_name = 'Hugo_Uplift'
,@target_object_name =Null
,@code_set_Name='Hugo_Contact_Type'
,@load_type='D'
*/
