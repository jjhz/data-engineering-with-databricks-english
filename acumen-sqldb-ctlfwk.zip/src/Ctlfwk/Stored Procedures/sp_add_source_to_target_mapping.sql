﻿
CREATE  PROCEDURE [ctlfwk].[sp_add_Source_To_Target_Mapping]
(
       @Target_Schema             varchar(100)
      ,@Target_Object             varchar(100)
      ,@Target_Object_Type        varchar(100)
      ,@Source_Schema             varchar(100)
      ,@Source_Object             varchar(100)
      ,@Source_BK_Column_Sequence INT
      ,@Source_BK_Column          varchar(100)
      ,@Query_Filter              varchar(100)
      ,@Truncate_Flag             varchar(1) -- Y, N, null (null allowed according to table)
      ,@Hash_key_Name             varchar(100)
      ,@Key_Source_Name           varchar(100)
      ,@load_type                 varchar(100)
	  ,@Change_Detection_Column   varchar(100)
)
AS

/* ============================================================================================================================================================================================================================================
-- Usage Comments if Any : Used to add/update Source to Target Mapping
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte				 1.0				InitialVersion
	07-09-2021						Tammy H 				 1.1				New set of unique columns to define existing entry (Target_Schema, Target_Object_ID, Source_Schema, Source_Object_ID, Source_BK_Sequence). 
																				Also, making changes to allow updates to existing records and to capture errors/validations. 
																				**Validations**
																				Error message will be provided when:
																				1. Source_Object provided does not exist in ctlfwk.source_objects
																				2. Target_Object provided does not exist in ctlfwk.source_objects
																				3. Truncate flag does not have the value Y, N OR null 
																				4. Load_type does not exist in ctlfwk.load_types
																				5. If Source_BK_Column provided already exists for the given Target_Object, Source_Object, Target_Schema, Source_Schema, but the Source_BK_Column_Sequence provided does not match that of existing record.
																				**Insert**
																				1. Occurs when record does not exist containing the unique column set AND passes all Validations
																				2. If Source_To_Target_Mapping_ID exists for the given source_objects, target_object, will pick up the same ID, else create a new one
																				3. If an insert happens, a message containing the inserted Source_To_Target_Mapping_ID number and the action "inserted" will appear
																				**Update**
																				1. Occurs when record contains the unique column set already AND passes all Validation checks
																				2. If an update happens, a message containing the inserted Source_To_Target_Mapping_ID number and the action "updated" will appear.
	15-09-2021						Tammy H					 1.2				Changes to Capture Error into ctrlfwk.process_errors and key Input Parameters of Error as JSON
-- ===========================================================================================================================================================================================================================================  */

BEGIN


       SET NOCOUNT ON;

       DECLARE @Source_object_id INT
       DECLARE @Target_object_id INT
       DECLARE @Source_To_Target_Mapping_Id INT
	   -- Table Variable to Capture Error/Actions 
	   DECLARE @ExistingBKSequence INT
	   DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	   DECLARE @Returnvalue INT = 0 --Success 

--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 

		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_objects WHERE Source_Object_name = @source_object ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','Source_Object does not exist',	(N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
																					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
																					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
																					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
																					+','+CONCAT('"Source_BK_Column_Sequence": "',COALESCE(@Source_BK_Column_Sequence ,''))  +'" '
																					+'}' )
				);
				SET @Returnvalue =2 ;
			END  

		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_objects  WHERE Source_Object_name = @target_object ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Target_Object does not exist', (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
																					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
																					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
																					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
																					+','+CONCAT('"Source_BK_Column_Sequence": "',COALESCE(@Source_BK_Column_Sequence ,''))  +'" '
																					+'}' )
				);
				SET @Returnvalue =2 ;
			END 

		IF ( @Truncate_Flag NOT IN ( 'Y','N', NULL)) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Truncate_Flag cannot have this value', (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
																					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
																					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
																					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
																					+','+CONCAT('"Source_BK_Column_Sequence": "',COALESCE(@Source_BK_Column_Sequence ,''))  +'" '
																					+','+CONCAT('"Truncate_Flag": "',COALESCE(@Truncate_Flag ,''))  +'" '
																					+'}' )
				); 
				SET @Returnvalue =2 ;
			END

		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.load_types WHERE load_type_code = @load_type) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Load_Type does not exist', (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
																					+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
																					+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
																					+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
																					+','+CONCAT('"Source_BK_Column_Sequence": "',COALESCE(@Source_BK_Column_Sequence ,''))  +'" '
																					+','+CONCAT('"Load_Type": "',COALESCE(@Load_Type ,''))  +'" '
																					+'}' )
				); 
				SET @Returnvalue =2 ;
			END 

		IF EXISTS ( SELECT 1 FROM ctlfwk.Source_To_Target_Mapping  WHERE Source_Object = @Source_object
																	and Target_Object = @Target_object
																	and Target_Schema = @Target_Schema
																	and Source_Schema = @Source_Schema
																	and Source_BK_Column = @Source_BK_Column
																	) 
		AND NOT EXISTS ( SELECT 1 FROM ctlfwk.Source_To_Target_Mapping  WHERE Source_Object = @Source_object
																	and Target_Object = @Target_object
																	and Target_Schema = @Target_Schema
																	and Source_Schema = @Source_Schema
																	and Source_BK_Column = @Source_BK_Column
																	and Source_BK_Column_Sequence =@Source_BK_Column_Sequence 
																	) 	   		
			
			BEGIN 
				SELECT @ExistingBKSequence = Source_BK_Column_Sequence FROM [ctlfwk].[Source_To_Target_Mapping] WHERE Source_Object = @Source_object
																												and Target_Object = @Target_object
																												and Target_Schema = @Target_Schema
																												and Source_Schema = @Source_Schema
																												and Source_BK_Column = @Source_BK_Column
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'The Source_BK_Column value provided already exists with Source_BK_Column_Sequence ' + CONVERT(VARCHAR, @ExistingBKSequence) + ', given Source_Object, Target_Object, Source_Schema, Target_Schema'
					, (N'{'+CONCAT('"Target_Schema": "',COALESCE( @Target_Schema ,''))  +'" ' 
						+','+CONCAT('"Target_Object": "',COALESCE( @Target_Object ,''))  +'" '
						+','+CONCAT('"Source_Schema": "',COALESCE( @Source_Schema ,''))  +'" '
						+','+CONCAT('"Source_Object": "',COALESCE(@Source_Object ,''))  +'" '
						+','+CONCAT('"Source_BK_Column_Sequence": "',COALESCE(@Source_BK_Column_Sequence ,''))  +'" '
						+','+CONCAT('"Source_BK_Column": "',COALESCE(@Source_BK_Column ,''))  +'" '
						+'}' )
				); 
				SET @Returnvalue =2 ;
			END 
--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

		

		--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				SELECT @Source_object_id = Source_object_id  from [Ctlfwk].[source_objects]  where Source_Object_name = @source_object
				SELECT @Target_object_id = Source_object_id from [Ctlfwk].[source_objects]  where Source_Object_name = @target_object

				BEGIN TRY
					BEGIN TRANSACTION
						--Capturing the Action into #Actions Table 
						DROP TABLE IF EXISTS #ActionTable;
						CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT)

						--Checks if record exists. If not, will do an insert. If yes, will do an update.
						IF (not exists
								(
								SELECT 1
								FROM [Ctlfwk].[Source_To_Target_Mapping] so
								WHERE so.Source_Object_ID = @Source_object_id
								and so.Target_Object_ID = @Target_object_id
								and so.Target_Schema = @Target_Schema
								and so.Source_Schema = @Source_Schema
								and so.Source_BK_Column_Sequence = @Source_BK_Column_Sequence
								)
							)
							BEGIN
								-- Picks up the same Source_To_Target_Mapping_Id if exists or creates a new ID if not
								IF (not exists 
										(
										SELECT 1 
										FROM [Ctlfwk].[Source_To_Target_Mapping] so
										WHERE so.Source_Object_ID = @Source_object_id
										and so.Target_Object_ID = @Target_object_id
										)
									)
									-- Source_To_Target_Mapping_Id doesn't exist, creates new
									BEGIN
										SELECT @Source_To_Target_Mapping_Id = (Increment.pointer + 1)
										FROM
											(SELECT COALESCE(MAX(Source_To_Target_Mapping_Id),0) pointer
											FROM [Ctlfwk].[Source_To_Target_Mapping]
											)  Increment
									END
								ELSE
									-- Picks up the same Source_To_Target_Id that exists
									BEGIN
										SELECT @Source_To_Target_Mapping_Id = Source_To_Target_Mapping_Id
										FROM [Ctlfwk].[Source_To_Target_Mapping] so
										WHERE so.Source_Object_ID = @Source_object_id
										and so.Target_Object_ID = @Target_object_id
									END
								
	   --=======================================================================================================================
								-- Insert record
							
									INSERT INTO [Ctlfwk].[Source_To_Target_Mapping]
										([Source_To_Target_Mapping_ID]
										,[Target_Object_ID]
										,[Target_Schema]
										,[Target_Object]
										,[Target_Object_Type]
										,[Source_Object_ID]
										,[Source_Schema]
										,[Source_Object]
										,[Source_BK_Column_Sequence]
										,[Source_BK_Column]
										,[Query_Filter]
										,[Truncate_Flag]
										,[Hash_key_Name]
										,[Key_Source_Name]
										,[load_type]
										,[Change_Detection_Column]
										)
									OUTPUT 'Inserted', inserted.Source_To_Target_Mapping_ID
									INTO #ActionTable (Act, Id)
									VALUES
										(@Source_To_Target_Mapping_Id
										,@Target_Object_ID
										,@Target_Schema
										,@Target_Object
										,@Target_Object_Type
										,@Source_Object_ID
										,@Source_Schema
										,@Source_Object
										,@Source_BK_Column_Sequence
										,@Source_BK_Column
										,@Query_Filter
										,@Truncate_Flag
										,@Hash_key_Name
										,@Key_Source_Name
										,@load_type
										,@Change_Detection_Column
										)



							
							END
	   --=======================================================================================================================
						ELSE
							BEGIN
							-- Updating Record
						

								UPDATE [Ctlfwk].[Source_To_Target_Mapping]
								SET Target_Object_Type = @Target_Object_Type 
								,Source_BK_Column = @Source_BK_Column
								,Query_Filter = @Query_Filter
								,Truncate_Flag = @Truncate_Flag
								,Hash_key_Name = @Hash_key_Name
								,Key_Source_Name = @Key_Source_Name
								,Load_Type = @load_type
								,Change_Detection_Column = @Change_Detection_Column
								,Last_Modified_Datetime = SYSDATETIME()
								,Last_Modified_By = ORIGINAL_LOGIN()
								OUTPUT 'Updated', inserted.Source_To_Target_Mapping_ID
								INTO #ActionTable (Act, Id)
								WHERE Source_Object_ID = @Source_object_id
								and Target_Object_ID = @Target_object_id
								and Target_Schema = @Target_Schema
								and Source_Schema = @Source_Schema
								and Source_BK_Column_Sequence = @Source_BK_Column_Sequence
							END
					COMMIT TRANSACTION
					
				END TRY
				BEGIN CATCH
					INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
					ROLLBACK TRANSACTION 
				END CATCH

			END -- Retun Value 0

			IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) --V1.2
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Source_To_Target_Mapping' 
					FROM @ErrorUDT; 
				
					SELECT * FROM @ErrorUDT 
				END
			ELSE 
				SELECT CONCAT('Source_To_Target_Mapping_ID ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 
END