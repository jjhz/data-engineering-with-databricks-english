﻿CREATE PROCEDURE [ctlfwk].[sp_add_IUD_config_types]
(
	@config_type varchar(7)
,	@config_type_description varchar(100)
)
AS

-- ==============================================================================================
 -- Parameters:
--   @config_type - unique config type for IUD per source
--   @config_type_Description - description of the configuration type for IUD
-- Description:	Insert IUD config type record if it does not exist, update if it does exist
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	08-07-2021						Musab | Deloitte		 1.0				InitialVersion
-- =================================================================================================

BEGIN

set nocount on;
	

	declare @config_type_id int;
	-- V1.3 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 



 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 
 

 --===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 


	
		BEGIN --ReturnValue 0
			BEGIN TRY
				
				BEGIN TRANSACTION
					-- V1.1 Capturing the Action into #Actions Table 
					DROP TABLE IF EXISTS #ActionTable;
					CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT)	

					-- check if record exists, if not, insert the row
					-- source app could be multiple instances but different business unit
					if (not exists 
						(
							select 1 
							from [ctlfwk].[IUD_config_types] iut
							
							where 
								iut.config_type = @config_type
						)
					)
						begin
							insert into [ctlfwk].[IUD_config_types]
							(
								[config_type]
							 ,	[config_type_description]
							 ,  last_modified_datetime
							 ,  last_modified_by
							)
							OUTPUT 'Inserted', inserted.config_type_id
							INTO #ActionTable (Act, Id)
							select
								@config_type
							,	@config_type_Description
							,   SYSDATETIME() 
							,   ORIGINAL_LOGIN()
						end
					else
						begin

							set @config_type_id = (
								select
									config_type_id
								from [ctlfwk].[IUD_config_types] ict

								where 
									ict.config_type = @config_type
							);

							

							update [ctlfwk].[IUD_config_types]
							set 
								   [config_type] = @config_type
								 , [config_type_description] = @config_type_Description 
								 , last_modified_datetime = SYSDATETIME() 
								 , last_modified_by = ORIGINAL_LOGIN()
							OUTPUT 'Updated', inserted.config_type_id
							INTO #ActionTable (Act, Id)
							where 
								 config_type_id = @config_type_id
						end
				COMMIT TRANSACTION
			END TRY

			BEGIN CATCH

				--V1.3
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION 

			END CATCH
		END

		--V1.3
		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_IUD_config_types' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
			END 
		ELSE 
			SELECT CONCAT('Config_Type_ID ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 
END