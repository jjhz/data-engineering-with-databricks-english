-- =============================================
-- Author:		Deloitte
-- Create date: 2020-07-08
-- Description:	Insert payload into API_Queue table
-- =============================================
CREATE PROCEDURE [ctlfwk].[sp_send_api_payload]
(
	 @process_status_id VARCHAR(100)
)
AS
BEGIN

set nocount on;
    declare @trancount int;
    set @trancount = @@trancount;
    begin try
	print 'Inserting payload for ' +  @process_status_id  + ' in queue ' ;
        if @trancount = 0
            begin transaction
        else
            save transaction sp_add_load_types;
	

	/* Get payload information for current process instance */
	
	Declare @payload varchar(4000)
	
	SET  @payload = (Select 'tracking_id='+cast(ps.process_status_id as varchar(1000))+'|'
	                       +'process_id='+cast(ps.process_id as varchar(1000))+'|'
	                       + 'job='+ps.process_name+'|'
						   + 'data_object='+p.source_object_name+'|'
						   + 'status='+Case when ps.execution_status_name = 'Success' Then 'FN'
						                    when ps.execution_status_name = 'Failed'  Then 'F'
											when ps.execution_status_name = 'Running'  Then 'R'
											Else 'A' End +'|'
						   + 'start_timestamp='+convert(varchar,ps.start_date_time,121)+'|'
						   + 'end_timestamp='+convert(varchar,coalesce(ps.end_date_time,''),121)+'|'
						   +  'period_code='+convert(varchar,coalesce(dateadd(dd,0,cast(ss.start_date_time as date)),'1900-01-01'),121) 
                     from ctlfwk.vw_process_status ps
                     Inner join ctlfwk.vw_process p
                     on ps.process_id = p.process_id
					 Inner join [ctlfwk].[vw_stream_status] ss 
					 on p.stream_name = ss.stream_name
                     Where ps.process_status_id = @process_status_id) 
	
	/* Insert into API_Queue table */
		INSERT INTO [ctlfwk].[API_Queue]
           ([api_path]
           ,[api_method]
           ,[payload]
           ,[status])
		values
		(
			'process/job-instances',
			'POST',
			@payload,
			'Queue'
		)
	

if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_load_types;

        raiserror ('Ctlfwk.sp_send_api_payload: %d: %s', 16, 1, @error, @message) ;
    end catch

end
GO


