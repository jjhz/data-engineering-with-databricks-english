-- =============================================
-- Author:      Deloitte
-- Create date: 20/07/2020
-- Description: Adds and updates records in ctlfwk.process table
--
-- Parameters:
--	 @process_name - name of process
--	 @process_name_description - description of process
--	 @is_enabled - flag to enable/disable process
--	 @stream_name - unique stream name from ctlfwk.stream table
--	 @process_type - unique process_type value from ctlfwk.process_type table
--   @source_app_code - unique source app code from ctlfwk.source_app
--   @source_object_name - name of source object
--	 @load_type_code - unique load type code from ctlfwk.load_types
-- =============================================
CREATE PROCEDURE [Ctlfwk].[sp_add_process_spfl]
( 
	@process_name varchar(200)
,	@process_name_description VARCHAR(100)
,	@is_enabled varchar(1)
,	@stream_name varchar(255)
,	@process_type varchar(20)
,	@source_app_code varchar(25)
,	@source_object_name varchar(100)
,	@load_type_code varchar(5)
)
AS
BEGIN

set nocount on;
    declare @trancount int;
    set @trancount = @@trancount;
    begin try
	print 'Inserting ' + @process_name;
        if @trancount = 0
            begin transaction
        else
            save transaction sp_add_process;
	
	declare @stream_id int;
	declare @process_type_id int;
	declare @source_object_id int;
	
	if (not exists 
		(
			select 1 
			from [ctlfwk].[process] p
			left join [ctlfwk].[stream] s on
				s.stream_id = p.stream_id
			left join [ctlfwk].[process_type] pt on
				pt.process_type_id = p.process_type_id
			left join [ctlfwk].[source_objects] so on
				so.source_object_id = p.source_object_id
			left join [ctlfwk].[load_types] lt on
				lt.load_type_id = so.load_type_id
			left join [ctlfwk].[source_app] sa on
				sa.[source_app_id] = so.[source_app_id]
			where
				p.[process_name] = @process_name
			and pt.process_type = @process_type
			and so.source_object_name = @source_object_name
			and lt.load_type_code = @load_type_code
			and sa.source_app_code = @source_app_code
		)
	)
	begin 

		set @stream_id = (select stream_id from [ctlfwk].[stream] where stream_name = @stream_name)
		set @process_type_id = (select process_type_id from [ctlfwk].[process_type] where process_type = @process_type)

		-- source object dependent on load type, so also factor this in
		set @source_object_id = (
			select so.source_object_id
			from [ctlfwk].[source_objects] so 
			left join [ctlfwk].[load_types] lt on 
				lt.load_type_id = so.load_type_id
			left join [ctlfwk].[source_app] sa on
				sa.[source_app_id] = so.[source_app_id]
			where 
				so.source_object_name = @source_object_name 
			and lt.load_type_code = @load_type_code
			and sa.source_app_code = @source_app_code
		)

		insert into [ctlfwk].[process]
		(
			[process_name]
		,	[process_name_description]
		,	[is_enabled]
		,	[stream_id]
		,	[process_type_id]
		,	[source_object_id]
		,	[target_object_id]
		,	[start_date_time]
		,	[end_date_time]
		) 
		values
		(
			@process_name
		,	@process_name_description
		,	@is_enabled
		,	@stream_id
		,	@process_type_id
		,	@source_object_id
		,	null
		,	GETDATE()
		,	'9999-12-31'
		)

		print 'Entry inserted for ' + @process_name
	end
	else
	begin
		
		set @stream_id = (select stream_id from [ctlfwk].[stream] where stream_name = @stream_name)
		set @process_type_id = (select process_type_id from [ctlfwk].[process_type] where process_type = @process_type)
		
		-- source object dependent on load type, so also factor this in
		set @source_object_id = (
			select so.source_object_id
			from [ctlfwk].[source_objects] so 
			left join [ctlfwk].[load_types] lt on 
				lt.load_type_id = so.load_type_id
			left join [ctlfwk].[source_app] sa on
				sa.[source_app_id] = so.[source_app_id]
			where 
				so.source_object_name = @source_object_name 
			and lt.load_type_code = @load_type_code
			and sa.source_app_code = @source_app_code
		)
		;

		update [ctlfwk].[process]
		set
			 [process_name_description] = @process_name_description
			,[is_enabled] = @is_enabled
			,[stream_id] = @stream_id
		where
			process_name = @process_name
			and process_type_id = @process_type_id
			and source_object_id = @source_object_id
			and end_date_time > GETDATE()
		;

		print 'Entry updated for ' + @process_name
	end

if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback;
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_process;

        raiserror ('Ctlfwk.sp_add_process_spfl: %d: %s', 16, 1, @error, @message) ;
    end catch
END
