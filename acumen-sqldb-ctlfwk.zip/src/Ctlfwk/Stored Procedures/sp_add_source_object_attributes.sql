﻿
CREATE PROCEDURE [ctlfwk].[sp_add_source_object_attributes]
(
	@source_app_code varchar(100)
,	@source_object_name varchar(100)
,	@source_object_attribute_name varchar(100)
,	@source_object_attribute_seq int
,	@source_object_attribute_data_type varchar(50)
,	@source_object_attribute_precision varchar(10)
,	@source_object_attribute_scale varchar(10)
,	@source_object_attribute_is_null varchar(1)
,	@source_object_attribute_is_pk varchar(1)
,	@source_object_attribute_is_BusinessKey varchar(1) --V1.6
,	@source_object_attribute_is_PII varchar(1)
,	@source_object_attribute_is_historystitch	char(1) 
,	@source_object_attribute_is_iud_column	varchar(1) 
,	@source_object_attribute_is_historystitch_sortkey	varchar(1)
,	@input_formatstring	varchar(100) = NULL
,	@dynamic_masking_function varchar(500) = NULL
,	@default_value_if_not_nullable varchar(500) = NULL
,	@source_time_zone varchar(50) = NULL --V1.1
,	@Encryption_Type varchar(10) --V1.7
,	@extraction_custom_logic_code varchar(20) = NULL
)
AS

/* =========================================================================================================================================
-- Author:      Deloitte
-- Create date: 20/07/2020
-- Description: Adds and updates records in ctlfwk.source_objects_attributes table. 
				This stored procs will not allow the following below. Manual Insert/Updates will be required.
                Updates cannot be made on the source_object_attribute_seq of an existing row. 
				Inserts cannot be made if the source_object_attribute_seq already exists for a different record containing the same source_app_code and source_object_name.
--
-- Parameters:
--   @source_app_code - unique source app code from ctlfwk.source_app 
--   @source_object_name - name of source object
--	 @source_object_attribute_name - attribute name
--	 @source_object_attribute_seq - sequence of attribute in source object
--	 @source_object_attribute_data_type - data type of attribute in source object
--   @source_object_attribute_precision - precision of attribute in source object
--	 @source_object_attribute_scale - scale of attribute in source object
--   @source_object_attribute_is_null - flag to indicate if attribute can contain null values
--   @source_object_attribute_is_pk - flag to indicate if attribute is primary key
--	 @source_object_attribute_is_BusinessKey - flag to indicate if attribute is business key --V1.6
--   @source_object_attribute_is_PII -  flag to indicate if attribute is personal identifying information
--   @source_object_attribute_is_historystitch - flag to indicate if attribute is used for history stitching records
--   @source_object_attribute_is_iud_column - flag to indicate if attribute is used to mark records as Inserts, Updates and Deletes
--   @source_object_attribute_is_historystitch_sortkey - flag to indicate if attribute is used for sorting history stitching records
--   @source_object_attribute_is_historystitch_dateformat - date format of the attribute used for history stitching records
--	 @dynamic_masking_function - function used for masking fields
--	 @default_value_if_not_nullable - default value to enter dummy records while using referential integrity augmentation pattern
--	 @output_time_zone - timezone of the attribute used for history stitching records -- V1.1
--   @Encryption_Type - Encryption Type

-- Validations: 
--   @source_app_code - must exist in ctlfwk.source_app 
--   @source_object_name - must exist in ctlfwk.source_objects where source_app_id is associated with @source_app_code
--	 @source_object_attribute_name - can't be NULL or Blank
--	 @source_object_attribute_seq - can't be NULL or Blank
--	 @source_object_attribute_data_type - datatypes recognised is now retrieved from Ctlfwk.SourceSystemToSparkDataTypeMapping table
--	 @source_object_attribute_precision - Cannot be NULL or Blank when sparkdatatype is 'STRING', 'DOUBLE', 'DECIMAL', 'FLOAT'.	
										  For oracle source: associated sparkdatatype LIKE date%/timestamp%, precision has to be NULL/Blank
										  For SQLSERVER/other source: source system 'smalldatetime','date','datetime' has to be NULL/Blank
										  IF sparkdatatype is DECIMAL, precision >38 will =38. precision must be between [0,38]
--   @source_object_attribute_scale - For oracle source: associatedsparkdatatype LIKE date%/timestamp%, precision has to be NULL/Blank
									  For SQLSERVER/other source: source system 'smalldatetime','date','datetime' has to be NULL/Blank
									  If sparkdatatype is DECIMAL and scale is NULL/Blank, replace scale with 0
									  If sparkdatatype is DECIMAl, scale must be between [0, precision]
--   @source_object_attribute_is_null - only 'Y' or 'N'
--   @source_object_attribute_is_pk - only 'Y' or 'N'
--	 @source_object_attribute_is_BusinessKey - only 'Y' or 'N'. If @source_object_attribute_is_pk = 'Y', @source_object_attribute_is_BusinessKey must be 'N'
--   @source_object_attribute_is_PII -  only 'Y' or 'N'
--   @source_object_attribute_is_historystitch - only 'Y' or 'N'
--   @source_object_attribute_is_iud_column - only 'Y' or 'N'
--   @source_object_attribute_is_historystitch_sortkey - only 'Y' or 'N'
--   @input_formatstring - If Source_Object_Attribute_Data_Type is date related, Input_FormatString cannot be NULL/Blank. Else Input_FormatString should be Null/Blank
						   InputFormatString for Oracle Databases in Bupa: 
						    	(IF @source_object_attribute_data_type ='TIMESTAMPWITHTIMEZONE'
								   SET @input_formatstring ='yyyy-mm-dd HH:mm:ss.SSSSSS z' ;
								IF @source_object_attribute_data_type ='Timestamp'
								   SET @input_formatstring ='yyyy-mm-dd HH:mm:ss.SSSSSS' ;
								IF @source_object_attribute_data_type ='Date'
								   SET @input_formatstring ='yyyy-MM-dd HH:mm:ss' ;)
--	 @dynamic_masking_function - TBC
--	 @default_value_if_not_nullable - TBC
--	 @output_time_zone - If datatype is timestamp related AND data does not include timezone, source_time_zone should NOT be blank. If datatype is timestamp related AND data include timezone, source_time_zone should be Blank.
--   @Encryption_Type - Encryption_Type must exist in the ctlfwk.Encryption_Types table if @source_object_attribute_is_PII = 'Y'


-- Usage Comments if Any :
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	20-07-2020						Deloitte				 1.0				InitialVersion
	28-09-2021						Tammy H 				 1.1				Adding @output_time_zone parameter & its column in insert/update table  
	29-09-2021						Tammy H					 1.2				Adding input parameter validations that references other tables and inserting errors [ctlfwk].[process_errors] and key Input Parameters of Error as JSON
																				and capturing actions
	05-10-2021						Tammy H					 1.3				Adding input parameter validations for each parameter 
	08-10-2021						Tammy H					 1.4				Removing Load_Type and adding data validations prior to inset/update. 
	11-10-2021						Tammy H					 1.5				Data Length cannot be NULL or Blank when data type is VARCHAR, NVARCHAR,CHAR
	12-10-2021						Niharika S				 1.6				Adding new column source_object_attribute_is_BusinessKey
	14-10-2021						Niharika S				 1.7				Adding new column Encryption_Type
	21-10-2021						Tammy H					 1.8				Removing default encryption_typeID = 0
	03-11-2021						Tammy H					 1.9				Renaming source_object_attribute_length to source_object_attribute_scale, adding source_object_Attribute_precision column and associated validations.
	04-11-2021						Tammy H					 1.10				Renaming source_object_attribute_IS_Historystitch_Dateformat to input_formatstring. Validations checks associated to the new data mapping table created for datatypes (ctlfwk.SourceSystemToSparkDataTypeMapping)
	12-11-2021						Tammy H					 1.11				Fix issue with validations not throwing errors for values that should not accept values NULL.
	16-11-2021						Tammy H					 1.12				Passing precision = 0 when input value is NULL/blank and sparkdatatype = DECIMAL
	23-11-2021						Tammy H					 1.13				Referencing sourcesystemdatabasename to isolate database datatypes in validations
	26-11-2021						Sheela RN				 1.14				To match the requirements of ADB where the source_time_zone must be Null and not blank where the datatype is not with timezone
	23-12-2021						Tammy H					 1.15				Encryption Type validation to check on Encryption table
	17-01-2022						Tammy H					 1.16               Removing date's requirement to have source_time_zone
	25-01-2022						Tammy H					 1.17				Switch scale and precision rules around to match definitions of scale/precision. Add If PK='Y', BK must = 'N' validation
	27-01-2022						Tammy H					 1.18				Instead of Blank which changes to 0 because of INT, source_object_attribute_seq cannot be <1
	28-01-2022                      Sheela R                 2.0                Syncing changes of Utility COnfig 
	29-01-2022						Tammy H					 2.1				CAST to int when comparing scale/precision numbers for DECIMAL sparkdatatype
	31-01-2022						Tammy H					 2.2				Syncing changes of Utility Config -Oracle stores date with Timestamp hence modified to match 
	01-02-2022						Tammy H					 2.3				Add Raise Error
	02-02-2022                      Sheela R                 2.4                Added Attunity specific Input format conversion
	24-02-2022						Tammy H					 2.5				Setting precision as max when sqlserver/other source and datatype = timestamp/uniqueidentifier
	24-02-2022						Tammy H					 2.6				New req updating V2.5: setting precision sqlserver/other source and datatype = timestamp (then 64) and uniqueidentifier (then 128)
	12-02-2022						Tammy H					 2.7				SQLSERVER datatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY does not require precision or scale
	02-05-2022					    Tammy H					 2.8				New req: Throw an error if the history stitch key, history stitch sort key and IUD tag are not marked as business keys in an IUD load
    05-12-2022					    Arunava D                3.0                Add additional logic for extraction custom logic for project Acumen SEW
-- ===================================================================================================================================================  */

BEGIN

set nocount on;

	-- V1.2 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 

	--V1.8 Removing default encryption_typeID = 0
	--declare @Encryption_TypeID INT = 0  --V1.7
	declare @Encryption_TypeID INT 
	declare @extraction_custom_logic_id INT
	declare @SourceDB varchar(50) --V2.0 
	declare @Load_Type_Code varchar(5)

	-- V1.13 Referencing sourcesystemdatabasename to isolate database datatypes in validations
	--V1.9 variables to capture data type info and spark equivalent data types
	declare @spark_datatype varchar(20)
	declare @has_timezone varchar(20)

	SELECT @spark_datatype = SparkSQLDataType, @has_timezone = IsDateWithTimezone 
	FROM Ctlfwk.SourceSystemToSparkDataTypeMapping ss
	INNER JOIN Ctlfwk.SourceSystemDatabaseName ssdn ON ss.DataSource = ssdn.SourceSystemDatabaseName
	INNER JOIN Ctlfwk.source_app sa ON ssdn.SourceSystemDatabaseName_ID = sa.SourceSystemDatabaseName_ID
	WHERE DataType = @source_object_attribute_data_type AND sa.source_app_code = @source_app_code

	--V2.0 
	SELECT @SourceDB=sd.SourceSystemDatabaseName FROM SourceSystemDatabaseName  sd
	JOIN Ctlfwk.source_app sa ON sd.SourceSystemDatabaseName_ID =sa.SourceSystemDatabaseName_ID
	WHERE sa.source_app_code=@source_app_code ;
	IF @SourceDB ='Oracle' 
	BEGIN 
	    --V2.9 modified 'yyyy-MM-dd HH:mm:ss.SSSSSSSSS z'  changed 6S to 9S 
		--V2.9 modified 'yyyy-MM-dd HH:mm:ss.SSSSSSSSS'  changed 6S to 9S 
		-- InputFormatString for Oracle Databases in Bupa 
		IF @source_object_attribute_data_type ='TIMESTAMPWITHTIMEZONE'
		   SET @input_formatstring ='yyyy-MM-dd HH:mm:ss.SSSSSSSSS z' ;
		IF @source_object_attribute_data_type ='Timestamp'
		   SET @input_formatstring ='yyyy-MM-dd HH:mm:ss.SSSSSSSSS' ;
		IF @source_object_attribute_data_type ='Date'
		   SET @input_formatstring ='yyyy-MM-dd HH:mm:ss' ; --2.2

	END 
	--V2.0
	--V2.4 Bupa Specific changes for Attunity Columns 
	IF @SourceDB ='Oracle' AND LTRIM(RTRIM(@source_object_attribute_name)) ='Eventhub_Enqueued_Time_Utc' 
	BEGIN 
		-- InputFormatString for Oracle Databases in Bupa 
		 
		IF @source_object_attribute_data_type ='Timestamp'
		   SET @input_formatstring ='M/d/yyyy h:mm:ss a' ;
	END 
	IF @SourceDB ='Oracle' AND LTRIM(RTRIM(@source_object_attribute_name)) ='Attunity_Timestamp' 
	BEGIN 
		-- InputFormatString for Oracle Databases in Bupa 
		 
		IF @source_object_attribute_data_type ='Timestamp'
		   SET @input_formatstring ='yyyy-MM-dd''T''HH:mm:ss.SSS' ;
	END  
	--V2.4 Bupa Specific changes for Attunity Columns  

	----V2.5 start
	----V2.5
	--IF @SourceDB IN ('SQLSERVER', 'OTHER') AND @source_object_attribute_data_type IN ('TIMESTAMP')
	--	SET @source_object_attribute_precision = '64'
	--IF @SourceDB IN ('SQLSERVER', 'OTHER') AND @source_object_attribute_data_type IN ('UNIQUEIDENTIFIER')
	--	SET @source_object_attribute_precision = '128'
	----V2.5 end

	--V2.8 Retriving the Load Type Code of the Source Object that the attribute belongs to
	SELECT @Load_Type_Code = load_type_code 
	FROM ctlfwk.source_objects so 
	INNER JOIN ctlfwk.load_types lt ON so.load_type_id = lt.load_type_id
	INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id
	WHERE so.source_object_name = @source_object_name AND sa.source_app_code = @source_app_code


 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 


	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app WHERE source_app_code = @source_app_code ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_App_Code does not exist',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																+'}' )
			);

			SET @Returnvalue =2 ;
		END  

	IF NOT EXISTS ( SELECT 1 
					FROM ctlfwk.source_objects so
					INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id 
					WHERE so.source_object_name = @source_object_name AND sa.source_app_code = @source_app_code ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'The provided Source_App_Code and Source_Object_Name does not exist together',	
					(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
					+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
					+'}' )
			);

			SET @Returnvalue =2 ;
		END  



	IF (@source_object_attribute_name IS NULL OR LEN(@source_object_attribute_name) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', ' Source_Object_Attribute_Name cannot be NULL or Blank', (N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																						+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																						+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																						+'}' )
			);

			SET @Returnvalue =2 ;
		END 


	IF (@source_object_attribute_seq IS NULL OR @source_object_attribute_seq < 1) --V1.18
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_Seq cannot be NULL or Blank',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																					+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																					+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																					+','+CONCAT('"Source_Object_Attribute_Seq": "',COALESCE(@source_object_attribute_seq ,''))  +'" '
																					+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	-- V1.13 Referencing sourcesystemdatabasename to isolate database datatypes in validations
	-- V1.9 datatypes recognised is now retrieved from Ctlfwk.SourceSystemToSparkDataTypeMapping table
	---- V1.3 Databricks down the pipeline that uses the JSON this sp produces only recognises these datatypes. S/N: DATETIMEOFFSET not used/recognised
	--IF @source_object_attribute_data_type NOT IN ('CHAR', 'VARCHAR', 'NVARCHAR', 'DECIMAL', 'NUMERIC', 'MONEY', 'NUMBER', 'FLOAT', 'BIGINT', 'INT', 'DATETIME', 'DATETIME2', 'DATE', 'TIMESTAMP', 'VARCHAR2')
	IF NOT EXISTS (SELECT 1 FROM Ctlfwk.SourceSystemToSparkDataTypeMapping ss
					INNER JOIN Ctlfwk.SourceSystemDatabaseName ssdn ON ss.DataSource = ssdn.SourceSystemDatabaseName
					INNER JOIN Ctlfwk.source_app sa ON ssdn.SourceSystemDatabaseName_ID = sa.SourceSystemDatabaseName_ID
					WHERE DataType = @source_object_attribute_data_type AND sa.source_app_code = @source_app_code) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_Data_Type cannot have this value',   (N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																							+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
																							+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	-- V1.17 Replaced scale with precision
	-- V1.9 changing data length to data scale. Will now refer to spark datatypes
	-- V1.5 Data Length cannot be NULL or Blank when data type is VARCHAR, NVARCHAR,CHAR
	IF (@spark_datatype IN ('STRING', 'DOUBLE', 'DECIMAL', 'FLOAT') 
		AND NOT (@source_object_attribute_data_type IN ('TEXT', 'NTEXT', 'TIMESTAMP', 'UNIQUEIDENTIFIER', 'MONEY', 'SMALLMONEY') AND @SourceDB = 'SQLSERVER') --V2.7
		AND (@source_object_attribute_precision IS NULL OR LEN(@source_object_attribute_precision) = 0))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Precision cannot be NULL/Blank for spark equivalent datatypes STRING, DOUBLE, DECIMAL, FLOAT except SQLSERVER datatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY', 
					(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
					+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Precision": "',COALESCE(@source_object_attribute_precision ,''))  +'" '
					+'}' )
			);

			SET @Returnvalue =2 ;
		END
	
	-- V1.9
	 
    IF @SourceDB ='Oracle'  -- V2.0 
		BEGIN -- V2.0 @sourceDB Oracle
			IF ((@spark_datatype LIKE 'date%%' OR @spark_datatype LIKE 'timestamp%%') 
				AND NOT ((@source_object_attribute_precision IS NULL OR LEN(@source_object_attribute_precision) = 0) AND (@source_object_attribute_scale IS NULL OR LEN(@source_object_attribute_scale) = 0)))
				BEGIN
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Spark equivalent DATE%%/TIMESTAMP%% provided for Oracle Source should have NULL Values as Source_Object_Attribute_Scale and Source_Object_Attribute_Precision', 
							(N'{'+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Precision": "',COALESCE(@source_object_attribute_precision ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Scale": "',COALESCE(@source_object_attribute_precision ,''))  +'" '
							+'}' )
					);

					SET @Returnvalue =2 ;
				END
		END -- V2.0 @sourceDB Oracle 

	--V2.0 Non Oracle DB Date Condtions 
	IF @SourceDB !='Oracle'  -- V2.0 
		BEGIN -- V2.0 @sourceDB Non Oracle
			IF @source_object_attribute_data_type IN  ('smalldatetime','date','datetime') --These datatypes will not have precision and scale 
				AND NOT ((@source_object_attribute_precision IS NULL OR LEN(@source_object_attribute_precision) = 0) AND (@source_object_attribute_scale IS NULL OR LEN(@source_object_attribute_scale) = 0)) 
				BEGIN
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'SMALLDATETIME, DATE, DATETIME provided for SQL/Other Source should have NULL Values as Source_Object_Attribute_Scale and Source_Object_Attribute_Precision', 
							(N'{'+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
							 +'}' )
					);

					SET @Returnvalue =2 ;
				END
		END -- V2.0 @sourceDB Non Oracle 

	--- V2.0 Decimal precison check 
	IF (@spark_datatype = 'DECIMAL') AND NOT (@source_object_attribute_data_type IN ('MONEY', 'SMALLMONEY') AND @SourceDB = 'SQLSERVER') --V2.7
		BEGIN
			IF (CAST(@source_object_attribute_precision AS INT) > 38) --V2.1 CAST to INT
				SET @source_object_attribute_precision = 38

			--V2.7 Changing to 0 so that validations can be checked when casting to INT. NULL casted is still NULL which cannot be mathematically compared.
			IF (@source_object_attribute_precision IS NULL OR LEN(@source_object_attribute_precision) = 0) 
				SET @source_object_attribute_precision = 0
			
			--V2.7 Moving from the Insert/Update section and excluding money/smallmoney
			IF (@source_object_attribute_scale IS NULL OR LEN(@source_object_attribute_scale) = 0) 
				SET @source_object_attribute_scale = 0

			IF CAST(@source_object_attribute_precision AS INT) NOT BETWEEN 1 AND 38 --V2.1 CAST to INT 
				BEGIN
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Precision has to be between 1 and 38 for spark equivalent DECIMAL datatypes except SQLSERVER datatypes MONEY, SMALLMONEY', 
							(N'{'+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@Source_Object_attribute_data_type ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Precison": "',COALESCE( @Source_Object_attribute_precision ,''))  +'" '
							+','+CONCAT('"Source_Object_Name": "',COALESCE( @Source_object_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @Source_Object_attribute_name ,''))  +'" '
							+'}' )
					);
					SET @Returnvalue =2 ;						
				END

			IF CAST(@source_object_attribute_scale AS INT) NOT BETWEEN 0 AND CAST(@source_object_attribute_precision AS INT) --V2.1 CAST to INT
				BEGIN
					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					VALUES ('Error', 'Scale has to be between [0, Precision] for spark equivalent DECIMAL datatypes except SQLSERVER datatypes MONEY, SMALLMONEY', 
							(N'{'+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@Source_Object_attribute_data_type ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Precison": "',COALESCE( @Source_Object_attribute_precision ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Precison": "',COALESCE( @Source_Object_attribute_scale ,''))  +'" '
							+','+CONCAT('"Source_Object_Name": "',COALESCE( @Source_object_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @Source_Object_attribute_name ,''))  +'" '
							+'}' )
					);

					SET @Returnvalue =2 ;
				END
		
		END 
	--V2.0 Decimal Precision check 


	--V1.11 Covering NULL for error scenario
	IF (@source_object_attribute_is_pk NOT IN ('Y', 'N') OR @source_object_attribute_is_pk IS NULL)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_Is_PK can only have value Y or N',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																							+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Is_PK": "',COALESCE(@source_object_attribute_is_pk ,''))  +'" '
																							+'}' )
						);

			SET @Returnvalue =2 ;
		END

	--V1.11 Covering NULL for error scenario
	IF (@source_object_attribute_is_null NOT IN ('Y', 'N') OR @source_object_attribute_is_null IS NULL)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_is_null can only have value Y or N',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																							+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Is_Null": "',COALESCE(@source_object_attribute_is_null ,''))  +'" '
																							+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.11 Covering NULL for error scenario
	IF (@source_object_attribute_is_PII NOT IN ('Y', 'N') OR @source_object_attribute_is_PII IS NULL)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_is_PII can only have value Y or N',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																							+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																							+','+CONCAT('"Source_Object_Attribute_Is_PII": "',COALESCE(@source_object_attribute_is_PII ,''))  +'" '
																							+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.11 Covering NULL for error scenario
	IF (@source_object_attribute_is_historystitch NOT IN ('Y', 'N') OR @source_object_attribute_is_historystitch IS NULL)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_is_Historystitch can only have value Y or N',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																									+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																									+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																									+','+CONCAT('"Source_Object_Attribute_Is_Historystitch": "',COALESCE(@source_object_attribute_is_historystitch ,''))  +'" '
																									+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.10
	IF (@source_object_attribute_is_historystitch = 'Y' AND NOT @spark_datatype = 'TIMESTAMP')
		BEGIN
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_Data_Type should be equivalent to Spark TIMESTAMP datatype when Source_Object_Attribute_is_Historystitch = Y',	
					(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
					+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Is_Historystitch": "',COALESCE(@source_object_attribute_is_historystitch ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
					+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.11 Covering NULL for error scenario
	IF (@source_object_attribute_is_historystitch_sortkey NOT IN ('Y', 'N') OR @source_object_attribute_is_historystitch_sortkey IS NULL)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_is_Historystitch_Sortkey can only have value Y or N',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																											+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																											+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																											+','+CONCAT('"Source_Object_Attribute_Is_Historystitch_Sortkey": "',COALESCE(@source_object_attribute_is_historystitch_sortkey ,''))  +'" '
																											+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.11 Covering NULL for error scenario
	IF (@source_object_attribute_is_iud_column NOT IN ('Y', 'N') OR @source_object_attribute_is_iud_column IS NULL)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_Is_IUD_Column can only have value Y or N', (N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																								+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																								+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																								+','+CONCAT('"Source_Object_Attribute_Is_IUD_Column": "',COALESCE(@source_object_attribute_is_iud_column ,''))  +'" '
																								+'}' )
			);

			SET @Returnvalue =2 ;
		END
	
	--V1.10 If Source_Object_Attribute_Data_Type is date related, Input_FormatString cannot be NULL/Blank. Else Input_FormatString should be Null/Blank
	---- if source_object_attribute_data_type is date related, history_stitch_dateformat should not be null
	---- if source_object_attribute_data_type is NOT date related, history_stitch_dateformat should be null
	--IF (((@source_object_attribute_data_type LIKE 'date%%' OR @source_object_attribute_data_type LIKE 'timestamp%%') AND (@source_object_attribute_is_historystitch_dateformat IS NULL OR LEN(@source_object_attribute_is_historystitch_dateformat) = 0 ))
	--	OR
	--	((@source_object_attribute_data_type NOT LIKE 'date%%' AND @source_object_attribute_data_type NOT LIKE 'timestamp%%') AND NOT (@source_object_attribute_is_historystitch_dateformat IS NULL OR LEN(@source_object_attribute_is_historystitch_dateformat) = 0 ))
	--   )	
	IF (((@spark_datatype LIKE 'date%%' OR @spark_datatype LIKE 'timestamp%%') AND (@input_formatstring IS NULL OR LEN(@input_formatstring) = 0 ))
		OR
		((@spark_datatype NOT LIKE 'date%%' AND @spark_datatype NOT LIKE 'timestamp%%') AND NOT (@input_formatstring IS NULL OR LEN(@input_formatstring) = 0 )) 
	   )	
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'If Source_Object_Attribute_Data_Type is date/timestamp related, Input_FormatString cannot be Blank. Else Input_FormatString should be NULL/Blank ',	
					(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
						+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
						+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
						+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
						+','+CONCAT('"Input_FormatString": "',COALESCE(@input_formatstring ,''))  +'" '
						+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.16 Removing date's requirement to have source_time_zone
	-- V1.10 If datatype is timestamp related AND data does not include timezone, source_time_zone should not be blank
	---- if source_object_attribute_data_type is date related, source_time_zone should not be null
	---- if source_object_attribute_data_type is NOT date related, source_time_zone should be null
	--IF (((@source_object_attribute_data_type LIKE 'date%%' OR @source_object_attribute_data_type LIKE 'timestamp%%') AND (@source_time_zone IS NULL OR LEN(@source_time_zone) = 0 )) 
	--	OR 
	--	((@source_object_attribute_data_type NOT LIKE 'date%' AND @source_object_attribute_data_type NOT LIKE 'timestamp%%') AND NOT (@source_time_zone IS NULL OR LEN(@source_time_zone) = 0 )))

	IF ((@spark_datatype LIKE 'timestamp%%') AND  @has_timezone = 'N' AND (@source_time_zone IS NULL OR LEN(@source_time_zone) = 0 )) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Time_Zone cannot be Null/Blank for given Source_Object_Attribute_Data_Type',	
						(N'{'+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" ' 
						+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
						+','+CONCAT('"Source_Time_Zone": "',COALESCE(@source_time_zone ,''))  +'" '
						+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.10 If datatype is timestamp related AND data include timezone, source_time_zone should be Blank
	IF (@has_timezone = 'Y' AND NOT (@source_time_zone IS NULL OR LEN(@source_time_zone) = 0 ))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_Object_Attribute_Data_Type contains timezone already so Source_Time_Zone should be Null/Blank',	
						(N'{'+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" ' 
						+','+CONCAT('"Source_Object_Attribute_Data_Type": "',COALESCE(@source_object_attribute_data_type ,''))  +'" '
						+','+CONCAT('"Source_Time_Zone": "',COALESCE(@source_time_zone ,''))  +'" '
						+'}' )
			);

			SET @Returnvalue =2 ;
		END

	--V1.11 Covering NULL for error scenario
	IF (@source_object_attribute_is_BusinessKey NOT IN ('Y', 'N') OR @source_object_attribute_is_BusinessKey IS NULL) --V1.6
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_object_attribute_is_BusinessKey can only have value Y or N',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																											+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
																											+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
																											+','+CONCAT('"Source_object_attribute_is_BusinessKey": "',COALESCE(@source_object_attribute_is_BusinessKey ,''))  +'" '
																											+'}' )
			);
			SET @Returnvalue =2 ;
		END

	--V2.8 Throw an error if the history stitch key, history stitch sort key and IUD tag are not marked as business keys in an IUD load
	IF (@Load_Type_Code = 'IUD' AND @source_object_attribute_is_BusinessKey = 'N' 
		AND (@source_object_attribute_is_historystitch = 'Y' OR @source_object_attribute_is_historystitch_sortkey = 'Y' OR @source_object_attribute_is_iud_column = 'Y'))
		BEGIN
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'For Source Object with IUD Load Type: If attribute is History Stitch (Y), Sortkey (Y) OR Is Iud Column (Y), it must also be a Business Key (Y)',	
					(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
						+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
						+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
						+','+CONCAT('"Source_object_attribute_is_BusinessKey": "',COALESCE(@source_object_attribute_is_BusinessKey ,''))  +'" '
						+','+CONCAT('"Source_object_attribute_is_historystitch": "',COALESCE(@source_object_attribute_is_historystitch ,''))  +'" '
						+','+CONCAT('"Source_object_attribute_is_historystitch_sortkey": "',COALESCE(@source_object_attribute_is_historystitch_sortkey ,''))  +'" '
						+','+CONCAT('"Source_object_attribute_is_iud_column": "',COALESCE(@source_object_attribute_is_iud_column ,''))  +'" '
						+'}' )
);
			SET @Returnvalue =2 ;
		END

	--V1.17
	IF (@source_object_attribute_is_pk = 'Y' AND @source_object_attribute_is_BusinessKey = 'Y')
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_attribute_is_BusinessKey has to be N when source_object_is_pk = Y', 
					(N'{'+CONCAT('"Source_Object_Attribute_Is_BusinessKey": "',COALESCE(@source_object_attribute_is_BusinessKey ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Is_Pk": "',COALESCE(@source_object_attribute_is_pk ,''))  +'" '
					+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
					+'}' )
			);
			SET @Returnvalue =2 ;
		END

	--V1.15 Encryption Type validation to check on Encryption table
	--V1.11 Covering NULL for error scenario
	IF (NOT EXISTS (SELECT 1 FROM Ctlfwk.Encryption_Types WHERE [Encryption_Type] = @Encryption_Type) AND @source_object_attribute_is_PII ='Y')
		BEGIN
					
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Encryption_Type does not match data in ctlfwk.Encryption_Types table when Source_Object_Attribute_IS_PII = Y',	
					(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
					+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_is_PII": "',COALESCE(@source_object_attribute_is_PII ,''))  +'" '
					+','+CONCAT('"Encryption_Type": "',COALESCE(@Encryption_Type ,''))  +'" '
					+'}' )
			);
			SET @Returnvalue =2 ;
		END

		--extraction_custom_logic_code validation to check on Extraction_custom_logic table
		IF (@extraction_custom_logic_code IS NOT NULL AND NOT EXISTS (SELECT 1 FROM [ctlfwk].[extraction_custom_logic] WHERE [extraction_custom_logic_code] = @extraction_custom_logic_code))
		BEGIN
					
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'extraction_custom_logic_code does not match data in ctlfwk.extraction_custom_logic table',	
					(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
					+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
					+','+CONCAT('"Source_Object_Attribute_is_PII": "',COALESCE(@source_object_attribute_is_PII ,''))  +'" '
					+','+CONCAT('"extraction_custom_logic_code": "',COALESCE(@extraction_custom_logic_code ,''))  +'" '
					+'}' )
			);
			SET @Returnvalue =2 ;
		END
	
--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

--===========================-- Data Validation and Setting Return Value   ====================================================================

	DROP TABLE IF EXISTS #temp;
	DROP TABLE IF EXISTS #temp1;
	DROP TABLE IF EXISTS #temp2;
 

	-- #temp table to store rows that have matching values as provided: (source_app_code, source_object_name, source_object_attribute_name)
	-- used later to check if rows with these matching provided parameters already exists in the DB
	SELECT soa.* INTO #temp FROM ctlfwk.source_objects_attributes soa
	INNER JOIN ctlfwk.source_objects so ON so.source_object_id = soa.source_object_id
	INNER JOIN ctlfwk.source_app sa ON sa.source_app_id = so.source_app_id
	WHERE sa.source_app_code = @source_app_code
	AND so.source_object_name = @source_object_name
	AND soa.source_object_attribute_name = @source_object_attribute_name


	-- #temp1 table to store rows that have matching values as provided: (source_app_code, source_object_name, source_object_attribute_name, source_object_attribute_seq)
	-- used later to check if rows with these matching provided parameters already exists in the DB. We do not allow update of an existing row's sequence in this stored proc
	SELECT soa.* INTO #temp1 FROM ctlfwk.source_objects_attributes soa
	INNER JOIN ctlfwk.source_objects so ON so.source_object_id = soa.source_object_id
	INNER JOIN ctlfwk.source_app sa ON sa.source_app_id = so.source_app_id
	WHERE sa.source_app_code = @source_app_code
	AND so.source_object_name = @source_object_name
	AND soa.source_object_attribute_name = @source_object_attribute_name
	AND soa.source_object_attribute_seq = @source_object_attribute_seq


	-- temp2 table to store ONLY the sequence numbers that having matching values as provided: (source_app_code, source_object_name, source_object_attribute_name, source_object_attribute_seq)
	-- used later to check if the sequence exists. We do not allow insert of a new row containing an exisiting sequence in this stored proc
	SELECT distinct soa. source_object_attribute_seq INTO #temp2
	FROM ctlfwk.source_objects_attributes soa
	INNER JOIN ctlfwk.source_objects so ON so.source_object_id = soa.source_object_id
	INNER JOIN ctlfwk.source_app sa ON sa.source_app_id = so.source_app_id
	WHERE sa.source_app_code = @source_app_code
	AND so.source_object_name = @source_object_name

	/* Data Validation Starts Here */
	IF EXISTS (SELECT * FROM #temp ) -- attribute exists
	   AND NOT EXISTS ( SELECT * FROM #temp1 ) -- matching seq does not exist
			BEGIN
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Manual Insert/Update required. Provided source_app_code, source_object_name, source_object_attribute_name already exists with a DIFFERENT source_object_attribute_seq',	
							(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
							+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Seq": "',COALESCE(@source_object_attribute_seq ,''))  +'" '
							+'}' )
				);
				SET @Returnvalue = 2
			END

	IF NOT EXISTS (SELECT * FROM #temp ) -- attribute does not exist
	   AND EXISTS ( SELECT * FROM #temp2 WHERE source_object_attribute_seq =@source_object_attribute_seq ) -- seq exists 
			BEGIN
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Manual Insert/Update required. Provided source_object_attribute_seq already exists with a DIFFERENT source_app_code, source_object_name, source_object_attribute_name',	
							(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
							+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( @source_object_attribute_name ,''))  +'" '
							+','+CONCAT('"Source_Object_Attribute_Seq": "',COALESCE(@source_object_attribute_seq ,''))  +'" '
							+'}' )
				);
				SET @Returnvalue = 2
			END


--===========================-- Data Validation and Setting Return Value ENDS ====================================================================

	-- V2.3
	IF @Returnvalue = 2 
		RAISERROR('sp_add_source_object_attributes: ERROR - Refer to Process_Error Table .', 16, -1)

	-- If No Errors
	IF @Returnvalue =0
		BEGIN --ReturnValue 0
			BEGIN TRY
				BEGIN TRANSACTION
				
					--V1.7 
					SELECT @Encryption_TypeID = Encryption_TypeID FROM ctlfwk.Encryption_Types WHERE Encryption_Type = @Encryption_Type;
					SELECT @extraction_custom_logic_id = extraction_custom_logic_id FROM ctlfwk.extraction_custom_logic WHERE extraction_custom_logic_code = @extraction_custom_logic_code;

					-- V1.1 Capturing the Action into #Actions Table 
					DROP TABLE IF EXISTS #ActionTable;
					CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT, [Name] VARCHAR(100))	
					

					/*	
						check if record exists, if not, insert the row
						source object can only have 1 instance of a source_object_attribute_name (column)
					*/
					IF @source_time_zone = '' 
					      SET @source_time_zone = NULL --V1.14
					IF (NOT EXISTS (SELECT * FROM #temp)) -- V1.4 no record exists matching source_app_code, source_object_name, source_object_attribute_name; INSERT
						BEGIN
							insert into [ctlfwk].[source_objects_attributes]
							(
								[source_object_id]
							,	[source_object_attribute_name]
							,	[source_object_attribute_seq]
							,	[source_object_attribute_data_type]
							,	[source_object_attribute_precision] --V1.9
							,	[source_object_attribute_scale] --V1.9
							,	[source_object_attribute_is_null]
							,	[source_object_attribute_is_pk]
							,	[source_object_attribute_is_BusinessKey] --V1.6
							,	[source_object_attribute_is_PII]
							,	[source_object_attribute_is_historystitch]
							,	[source_object_attribute_is_iud_column]
							,	[source_object_attribute_is_historystitch_sortkey]
							,	[input_formatstring] --V1.10
							,	[dynamic_masking_function]
							,	[default_value_if_not_nullable]
							,	[source_time_zone] 
							,	[Encryption_TypeID] --V1.7
							,   [extraction_custom_logic_id]
							)
							OUTPUT 'Inserted', inserted.source_object_id, inserted.source_object_attribute_name
							INTO #ActionTable (Act, Id, [Name])
							select
								so.[source_object_id]
							,	@source_object_attribute_name
							,	@source_object_attribute_seq
							,	@source_object_attribute_data_type
							,	@source_object_attribute_precision --V1.9
							,	@source_object_attribute_scale -- V1.12 --V1.17
							,	@source_object_attribute_is_null
							,	@source_object_attribute_is_pk
							,	@source_object_attribute_is_BusinessKey --V1.6
							,	@source_object_attribute_is_PII
							,	@source_object_attribute_is_historystitch
							,	@source_object_attribute_is_iud_column
							,	@source_object_attribute_is_historystitch_sortkey
							,	@input_formatstring --V1.10
							,	@dynamic_masking_function
							,   @default_value_if_not_nullable
							,	@source_time_zone
							,	@Encryption_TypeID --V1.7
							,   @extraction_custom_logic_id
							from [ctlfwk].[source_objects] so
							left join [ctlfwk].[source_app] sa on
								sa.[source_app_id] = so.[source_app_id]
								
							where
								so.[source_object_name] = @source_object_name
							and sa.[source_app_code] = @source_app_code
						END
					ELSE -- record exists matching source_app_code, source_object_name, source_object_attribute_name; UPDATE
						BEGIN
							
							declare @source_object_id int;

							set @source_object_id = (
							select
								so.[source_object_id]
							from [ctlfwk].[source_objects] so
							left join [ctlfwk].[source_app] sa on
								sa.[source_app_id] = so.[source_app_id]
							where
								so.[source_object_name] = @source_object_name
							and sa.[source_app_code] = @source_app_code
							);

							update [ctlfwk].[source_objects_attributes]
							set
									[source_object_attribute_seq] = @source_object_attribute_seq
								,	[source_object_attribute_data_type] = @source_object_attribute_data_type
								,	[source_object_attribute_precision] = @source_object_attribute_precision --V1.9 --V1.17
								,	[source_object_attribute_scale] =  @source_object_attribute_scale --V1.12 --V1.17
								,	[source_object_attribute_is_null] = @source_object_attribute_is_null
								,	[source_object_attribute_is_pk] = @source_object_attribute_is_pk
								,	[source_object_attribute_is_BusinessKey] = @source_object_attribute_is_BusinessKey --V1.6
								,	[source_object_attribute_is_PII] = @source_object_attribute_is_PII
								,	[source_object_attribute_is_iud_column]	= @source_object_attribute_is_iud_column
								,	[source_object_attribute_is_historystitch] = @source_object_attribute_is_historystitch
								,	[source_object_attribute_is_historystitch_sortkey] = @source_object_attribute_is_historystitch_sortkey
								,	[input_formatstring] = @input_formatstring --V1.10
								,	[dynamic_masking_function] = @dynamic_masking_function
								,	[default_value_if_not_nullable] = @default_value_if_not_nullable
								,	[source_time_zone] = @source_time_zone
								,	[Encryption_TypeID] = @Encryption_TypeID --V1.7
								,   [extraction_custom_logic_id] = @extraction_custom_logic_id
								,	[Last_Modified_Datetime] = SYSDATETIME()
								,	[Last_Modified_By] = ORIGINAL_LOGIN()
							OUTPUT 'Updated', inserted.source_object_id, inserted.source_object_attribute_name
							INTO #ActionTable (Act, Id, [Name])
							where
								source_object_id = @source_object_id
								and source_object_attribute_name = @source_object_attribute_name
							;
						END
				COMMIT TRANSACTION
			END TRY
			BEGIN CATCH

				--V1.2
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION 

			END CATCH
		END -- Return Value 0

		--V1.2
		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Source_Object_Attributes' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
			END 
		ELSE 
			SELECT CONCAT('Source_Object_Attribute_Name ' + [Name] + ' for Source_Object_Id ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 

END

