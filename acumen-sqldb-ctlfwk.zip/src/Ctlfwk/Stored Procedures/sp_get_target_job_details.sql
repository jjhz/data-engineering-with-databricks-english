﻿
CREATE PROCEDURE [ctlfwk].[sp_get_target_job_details]
( 
	@stream_name	VARCHAR(255), --V1.5
	@process_type	VARCHAR(20),
	@Schema_Name VARCHAR(50),
	@notebook_path varchar(255) = NULL,
	@notebook_name varchar(255) = NULL,
	@source_app_name varchar(100) = NULL,
	@Target_object_name	VARCHAR(100) 
)
AS
/*=================================================================================================
-- Usage Comments if Any :Used to Fetch target Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	17-01-2022						vikas p				 1.0				InitialVersion
	01-02-2022						vikas p				 1.1				Change the target table from vw_process to vw_target_process
	04-03-2022						vikas P              1.2				Added process type validation
	04-03-2022						Tammy H			     1.3				Update validations and rules to meet new req: Unique set of keys for target object -schema_name, notebook_path, notebook_name, target_object
	10-03-2022                      Sheela R             1.4                Fixing Bug 
	18-03-2022						Tammy H				 1.5			    New req: Stream_name raised to be varchar(255)
	19-03-2022						Tammy H				 1.6				To accomodate for new process_Type: Ref_Replication
	17-05-2022						Sakshi S			 1.7				To add cluster_type to output

 ================================================================================================= */ 
BEGIN

	SET NOCOUNT ON

	DECLARE 
		@ret_status			VARCHAR(100),
		@record_count		INT,
		@error_flag			VARCHAR(100),
		@error_message		VARCHAR(100)
	--print(@Target_object_name + @stream_name + @process_type)
	IF @Target_object_name IS NOT NULL AND @stream_name IS NOT NULL AND @process_type IS NOT NULL
	BEGIN
	--print('1')
		select @record_count = count(*) FROM ctlfwk.vw_stream WHERE stream_name = @stream_name;

		if @record_count <= 0
		begin

			SET @error_flag='Error'
			SET @error_message = 'ERROR - Stream does not exists.'
			--select @record_count as rec_count;
			--print @record_count;
			SELECT NULL AS stream_name, 
			NULL AS process_name,
		    NULL AS process_type, 
			@error_flag AS Erro_Flag, 
			@error_message AS ErrorMessage,
			NULL As load_type_code,
			NULL AS NoOfWorkers,
		    NULL AS PoolId,
			NULL AS Cluster_Type --V1.7
			RAISERROR('ERROR - Stream does not exists.' ,17,1)
			return -1
		end

		IF @process_type != 'Ref_Replication'
			BEGIN
				select @record_count = count(*) FROM [Ctlfwk].[target_objects] WHERE target_object_name = @Target_object_name AND [Schema_Name] = @Schema_Name AND notebook_path = @notebook_path AND notebook_name = @notebook_name
				if @record_count <= 0
				begin

					SET @error_flag='Error'
					SET @error_message = 'ERROR -Target Object does not exists.'
					SELECT NULL AS stream_name, 
					NULL AS process_name,
					   NULL AS process_type, 
					@error_flag AS Erro_Flag,
					@error_message AS ErrorMessage,
					NULL As load_type_code, 
					NULL AS NoOfWorkers,
					NULL AS PoolId,
					NULL AS Cluster_Type --V1.7
					RAISERROR('ERROR - Target Object does not exists.' ,17,1)
					return -1
				end
			END
		ELSE -- V1.6 process_type = 'Ref_Replication'
			BEGIN
				SELECT @record_count = count(*) FROM [Ctlfwk].[target_objects] so 
				INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id 
				WHERE so.target_object_name = @Target_object_name AND so.[Schema_Name] = @Schema_Name AND sa.source_app_name = @source_app_name
				if @record_count <= 0
				begin

					SET @error_flag='Error'
					SET @error_message = 'ERROR -Target Object does not exists.'
					SELECT NULL AS stream_name, 
					NULL AS process_name,
					   NULL AS process_type, 
					@error_flag AS Erro_Flag,
					@error_message AS ErrorMessage,
					NULL As load_type_code, 
					NULL AS NoOfWorkers,
					NULL AS PoolId,
					NULL AS Cluster_Type --V1.7
					RAISERROR('ERROR - Target Object does not exists.' ,17,1)
					return -1
				end				
			END

		select @record_count = count(*) FROM [Ctlfwk].process_type WHERE process_type = @process_type --V1.2
		if @record_count <= 0
		begin

		    SET @error_flag='Error'
			SET @error_message = 'ERROR -Process type does not exists.'
			SELECT NULL AS stream_name, 
			NULL AS process_name,
		       NULL AS process_type, 
			@error_flag AS Erro_Flag,
			@error_message AS ErrorMessage,
			NULL As load_type_code, 
			NULL AS NoOfWorkers,
		    NULL AS PoolId,
			NULL AS Cluster_Type --V1.7
			RAISERROR('ERROR -Process type does not exists.' ,17,1)
			return -1
		end
	END

	IF @process_type != 'Ref_Replication'
		BEGIN
			IF NOT EXISTS(SELECT TOP 1 * FROM [Ctlfwk].[vw_target_process] --V1.1
				WHERE stream_name = @stream_name
				AND process_type = @process_type
				AND target_object_name = @Target_object_name
				AND [Schema_Name] = @Schema_Name 
				AND notebook_path = @notebook_path 
				AND notebook_name = @notebook_name)
				BEGIN
					RAISERROR('ERROR - stream_name Or process_type or Target_object_name  not tied up with process please correct the process entry .' ,17,1)
				END
		END
	ELSE -- V1.6 process_type = 'Ref_Replication'
		BEGIN
			IF NOT EXISTS(SELECT TOP 1 * FROM [Ctlfwk].[vw_target_process] --V1.1
				WHERE stream_name = @stream_name
				AND process_type = @process_type
				AND target_object_name = @Target_object_name
				AND [Schema_Name] = @Schema_Name
				AND source_app_name = @source_app_name)
				BEGIN
					RAISERROR('ERROR - stream_name Or process_type or Target_object_name  not tied up with process please correct the process entry .' ,17,1)
				END
		END


	IF @process_type IS NOT NULL AND @Target_object_name IS NOT NULL AND @stream_name IS NOT NULL
		BEGIN
			IF @process_type != 'Ref_Replication'
				BEGIN
	
					SELECT 
						stream_name,
						process_name,
						process_type,
						target_object_name,
						is_enabled,
						load_type_code,  
						NoOfWorkers,
						PoolId,
						Cluster_Type --V1.7
					FROM
						[Ctlfwk].[vw_target_process] --V1.1
					WHERE
						stream_name = @stream_name

					AND
						process_type = @process_type
					AND
						target_object_name = @Target_object_name
				   -- V1.4
					AND  notebook_name =@notebook_name 
					AND  notebook_path  =@notebook_path
					AND  [Schema_Name] = @Schema_Name
				END
			ELSE -- V1.6 process_type = 'Ref_Replication' 
				BEGIN
					SELECT 
						stream_name,
						process_name,
						process_type,
						target_object_name,
						is_enabled,
						load_type_code,  
						NoOfWorkers,
						PoolId,
						Cluster_Type --V1.7
					FROM
						[Ctlfwk].[vw_target_process] --V1.1
					WHERE
						stream_name = @stream_name
					AND process_type = @process_type
					AND target_object_name = @Target_object_name
					AND [Schema_Name] = @Schema_Name
					AND source_app_name = @source_app_name
				END
		END
/*	EXEC  
	[ctlfwk].[sp_get_target_job_details]
	@stream_name='Hugo_U_SilverToGold_Reference_Load',
	@process_type ='Reference'	,
	@Schema_Name ='Core',
	@notebook_path ='../templates/hugo',
	@notebook_name ='Hugo_Digital_Card_Type_Reference',
	@Target_object_name	='Enterprise_Reference'
	*/
END

