﻿CREATE PROCEDURE [ctlfwk].[sp_add_source_objects]
(
	@source_app_code varchar(25) --V1.8
,	@source_object_name varchar(100)
,	@source_object_description varchar(1000) --V2.0
,	@load_type_code varchar(5) --SRN 
,	@is_file_mandatory bit = 0
,	@Schema_Name	VARCHAR(50) --   V1.6 @is_source_iud is replaced with Schema_Name
,   @File_Pattern_Name varchar (50) --V1.2
,	@Detect_Hard_Deletes bit = 0 --V3.0
)
AS
-- =============================================
-- Description: Adds and updates records in ctlfwk.source_objects table
--
-- Parameters:
--   @source_app_code - unique source app code from ctlfwk.source_app
--   @source_object_name - name of source object
--	 @source_object_description - description of source object
--	 @load_type_code - unique load type code from ctlfwk.load_types
--	 @is_file_mandatory - flag for mandatory files in incoming container
--	 @is_source_iud - flag for source object being Insert/Update/Delete
--   @File_Pattern_Name - Included to fect the File_Specification_Type_Id

-- Usage Comments if Any :
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	20-07-2021						Deloitte				 1.0				InitialVersion
--	28-09-2021						Niharika S				 1.1				Adding  File_Specification_Type_Id column 
--  28-09-2021	                    Niharika S				 1.2				Embedding error handling and key Input Parameters of Error		
--  07-10-2021						Niharika S				 1.3				Embedding errors for null check for source_object_name, source_object_desc, is_file_mandaory, is_source_iud
--  11-10-2021						Sheela R 				 1.4				Remove Load_Type from requirement to determining insert/update
--  15-11-2021						Tammy H					 1.5				Fix issue with validations not throwing errors for values that should not accept values NULL.
--  18-01-2022                      Sheela R 				 1.6	            Removed @Source_IUD and added  SchemaName 
--	01-02-2022						Tammy H					 1.7				Add Raise Error
--	10-03-2022						Tammy H					 1.8				New req: Change source_app_code varchar(6) to varchar(25)
--	02-05-2022						Tammy H					 1.9				Schema_Name(100) to Schema_Name(50) to match PK constraint in target_objects
--	09-05-2022						Tammy H					 2.0				New req: Increasing source_object_description varchar(100) to varchar(1000)
--	02-11-2022						Musab A					 3.0				Adding Detect Hard Deletes flag to indicate whether hard deletes need to be detected on source
-- =============================================

BEGIN


set nocount on;
--V1.2

	-- check if record exists, if not, insert the row
	-- source object could have multiple load types
	
	declare @ErrorUDT [ctlfwk].[ErrorUDT]
	declare @source_app_id int;
	declare @load_type_id int;
	declare @Returnvalue int =0;
	declare @File_Specification_Type_Id int --V1.1
--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
		
		--V1.2
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app WHERE source_app_code = @source_app_code ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error',' : source_app_code does not exist' , (N'{' + CONCAT('"source_app_code": "',COALESCE(@source_app_code,'' ))	+'" '
																	 +',' +CONCAT('"source_object_name": "',COALESCE(@source_object_name, ''))	+'" '
																	 + '}')
						) ;
				SET @Returnvalue =2 ;
			END 

		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.load_types WHERE load_type_code = @load_type_code ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error',' : load_type_code does not exist' ,  (N'{' +',' +CONCAT('"load_type_code ": "',COALESCE(@load_type_code, ''))	+'" '
																	 + CONCAT('"source_object_name": "',COALESCE(@source_object_name,'' ))	+'" '
																	 +',' +CONCAT('"source_app_code": "',COALESCE(@source_app_code, ''))	+'" '
																     + '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END 


		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.File_Specification_Type WHERE File_Pattern_Name = @File_Pattern_Name ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error',' : File_Pattern_Name  does not exist' , (N'{' +',' +CONCAT('"File_Pattern_Name ": "',COALESCE(@File_Pattern_Name, ''))	+'" '
																		 + CONCAT('"source_object_name": "',COALESCE(@source_object_name,'' ))	+'" '
																		 +',' +CONCAT('"source_app_code": "',COALESCE(@source_app_code, ''))	+'" '
																		 +',' +CONCAT('"load_type_code ": "',COALESCE(@load_type_code, ''))	+'" '
																		 
																		 + '}')

						 ) ;
				SET @Returnvalue =2 ;
			END 


		IF (@source_object_name IS NULL OR LEN(@source_object_name) = 0) --V1.3
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Source object name cannot be NULL or Blank', (N'{'+CONCAT('"source_app_code": "',COALESCE( @source_app_code ,''))  +'" ' 
																						+','+CONCAT('"Source_Object_Description": "',COALESCE( @source_object_description ,''))  +'" '
																						 +','+CONCAT('"source_object_name": "',COALESCE( @source_object_name ,''))  +'" '
																						+'}' )
						);

				SET @Returnvalue =2 ;
			END 

		IF (@source_object_description IS NULL OR LEN(@source_object_description) = 0) --V1.3
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Source object description cannot be NULL or Blank', (N'{'+CONCAT('"source_app_code": "',COALESCE( @source_app_code ,''))  +'" ' 
																						+','+CONCAT('"source_object_name": "',COALESCE( @source_object_name ,''))  +'" '
																						 +','+CONCAT('"Source_Object_Description": "',COALESCE( @source_object_description ,''))  +'" '
																						+'}' )
						);

				SET @Returnvalue =2 ;
			END 
		--If Null/blank is given, value = 0
		IF (@is_file_mandatory IS NULL OR LEN(@is_file_mandatory) = 0)
			BEGIN 
				SET @is_file_mandatory = 0 ;
			END
		-- Precaution check. Since restart_from_beginning is BIT, SQL should auto convert values to 1 or 0 unless it is a NULL, which is the previous validation. So this error should not occur at all.
		IF (  @is_file_mandatory NOT IN ( 0,1)) --V1.3
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Is_file_mandatory can only have values 0 or 1' , (N'{'+CONCAT('"source_app_code": "',COALESCE( @source_app_code ,''))  +'" ' 
																					+','+CONCAT('"source_object_name": "',COALESCE( @source_object_name ,''))  +'" '
																				    +','+CONCAT('"Source_Object_Description": "',COALESCE( @source_object_description ,''))  +'" '
																					+','+CONCAT('"is_file_mandatory": "',COALESCE(convert(VARCHAR(2),@is_file_mandatory) ,'')) +'" '
																					+'}' )
						);

				SET @Returnvalue =2 ;
			END  
			--V1.6
		IF (    @Schema_Name IS NULL OR LEN(@Schema_Name) = 0) 
			BEGIN 
			    SET @Schema_Name = NULL 
			END

			--If Null/blank is given, value = 0
		IF (@Detect_Hard_Deletes IS NULL OR LEN(@Detect_Hard_Deletes) = 0)
			BEGIN 
				SET @Detect_Hard_Deletes = 0 ;
			END
		-- Precaution check. Since @Detect_Hard_Deletes is BIT, SQL should auto convert values to 1 or 0 unless it is a NULL, which is the previous validation. So this error should not occur at all.
		IF (  @Detect_Hard_Deletes NOT IN ( 0,1)) --V1.3
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Detect_Hard_Deletes can only have values 0 or 1' , (N'{'+CONCAT('"source_app_code": "',COALESCE( @source_app_code ,''))  +'" ' 
																					+','+CONCAT('"source_object_name": "',COALESCE( @source_object_name ,''))  +'" '
																				    +','+CONCAT('"Source_Object_Description": "',COALESCE( @source_object_description ,''))  +'" '
																					+','+CONCAT('"Detect_Hard_Deletes": "',COALESCE(convert(VARCHAR(2),@Detect_Hard_Deletes) ,'')) +'" '
																					+'}' )
						);

				SET @Returnvalue =2 ;
			END  
--===========================-- Input Paramter Validation and  Setting Return Value ENDS ====================================================
 	-- V1.7
	IF @Returnvalue = 2 
		RAISERROR('sp_add_source_objects: ERROR - Refer to Process_Error Table .', 16, -1)

--V1.2
		IF @Returnvalue = 0
			BEGIN --Retrunvalue0
	            set @source_app_id  = (select source_app_id from [ctlfwk].[source_app] where source_app_code = @source_app_code);
				set @load_type_id  = (select load_type_id from [ctlfwk].[load_types] where load_type_code = @load_type_code);
				SELECT  TOP 1 @File_Specification_Type_Id =File_Specification_Type_Id  from ctlfwk .File_Specification_Type where File_Pattern_Name  =@File_Pattern_Name 
				--SELECT @File_Specification_Type_Id 
				--SELECT @source_app_id 
				--SELECT @load_type_id 
			BEGIN TRY
			BEGIN TRANSACTION 
			--Capturing the Action into #Actions Table 
			DROP TABLE IF EXISTS #ActionTable;
			CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT)
			IF (NOT EXISTS 
				(
					SELECT 1 
					FROM [ctlfwk].[source_objects] so
					LEFT JOIN [ctlfwk].[source_app] sa on
						sa.[source_app_id] = so.[source_app_id]
					LEFT JOIN [ctlfwk].[load_types] lt on
						lt.[load_type_id] = so.[load_type_id]
					where 
						so.[source_object_name] = @source_object_name
					and sa.[source_app_code] = @source_app_code
					--and lt.[load_type_code] = @load_type_code --V1.4
				)
				)
				BEGIN
				 
					--SELECT 'in'
					INSERT INTO [ctlfwk].[source_objects]
					(
					[source_object_name]
				,	[source_object_description]
				,   [Schema_Name] --V1.6 
				,	[load_type_id]
				,	[source_app_id]
				,	[start_date_time]
				,	[end_date_time]
				,	[is_file_mandatory]	 
				--,	[is_source_iud] --V1.6 
				,   [File_Specification_Type_Id] --V1.1
				,   [detect_hard_deletes] --V3.0
					)
					OUTPUT 'Inserted', inserted.source_object_id 
									INTO #ActionTable (Act, Id)
					values
					(
					@source_object_name
				,	@source_object_description
				,   @Schema_Name --V1.6 
				,	@load_type_id
				,	@source_app_id
				,	GETDATE()
				,	'9999-12-31'
				,	@is_file_mandatory
				--,	@is_source_iud  --V1.6 
				,   @File_Specification_Type_Id --V1.1
				,   @Detect_Hard_Deletes --V3.0
					)

				--print 'Entry inserted for ' + @source_app_code + ', ' + @source_object_name + ', ' + @load_type_code
				end
				else
				begin
		
				
				--select 'up'
				--SELECT @load_type_id 
				--SELECT @File_Specification_Type_Id 
				update [ctlfwk].[source_objects]
				set
					[source_object_description] = @source_object_description
					,[is_file_mandatory] = @is_file_mandatory
					,[File_Specification_Type_Id] = @File_Specification_Type_Id  --V1.1
					,load_type_id =@load_type_id 
					, detect_hard_deletes = @Detect_Hard_Deletes --V3.0
					,Last_Modified_Datetime =SYSDATETIME()
					,Last_Modified_By = ORIGINAL_LOGIN()
					,[Schema_Name]=@Schema_Name--V1.6 
					OUTPUT 'Updated', inserted.source_object_id 
								INTO #ActionTable (Act, Id)
				where
					source_object_name = @source_object_name
				--	and load_type_id = @load_type_id  --SRN 
					and source_app_id = @source_app_id
					and end_date_time > GETDATE()
				;

			--	print 'Entry updated for ' + @source_app_code + ', ' + @source_object_name + ', ' + @load_type_code
				end
 
					commit;
				end try
	
				begin catch
		
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION
			--	raiserror ('Ctlfwk.sp_add_source_objects: %d: %s', 16, 1, @error, @message) ; --V1.2
				end catch
				END--Retrunvalue0
	IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) --V1.2
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_source_objects' 
					FROM @ErrorUDT; 
				
					SELECT * FROM @ErrorUDT 
				END

		ELSE 
				SELECT CONCAT('source_object_id ', + CONVERT(VARCHAR, Id)  + ' is ' + Act )  FROM #ActionTable 
end