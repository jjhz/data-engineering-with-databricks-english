﻿CREATE PROCEDURE [Ctlfwk].[sp_add_Encryption_Types]
(
	@Encryption_Type varchar(10)
,	@Encryption_Name varchar(100)
)
AS

-- =============================================
-- Author:      Niharika S
-- Create Date: 14/10/2021
-- Description: Adds and updates records in [ctlfwk].[Encryption_Types]

-- Usage Comments if Any :
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	14-10-2021						Niharika S				 1.0				InitialVersion
--	01-02-2022						Tammy H					 1.1				Add Raise Error
-- =============================================

BEGIN

set nocount on;
     -- Error Validations Start 
	    declare @Encryption_TypeID INT ;
		declare @Actiontype varchar(100) ; 
		-- Table Variable to Capture Input Paramters 
		declare @InsertedParameterValues AS TABLE 
		(
	        Encryption_Type VARCHAR(10) 
		  , Encryption_Name VARCHAR(100)
	   )
	   -- Table Variable to Capture Error 
		declare @ErrorUDT [ctlfwk].[ErrorUDT] 
		declare @Returnvalue INT = 0 --Success 

		-- Table Variable to fetch ID's by doing Looukups to Input into File_Specification_Type Table 
		declare @FinalValues AS TABLE 
				 (
                          Encryption_TypeID INT IDENTITY (1,1)
						, Encryption_Type VARCHAR(10) 
						, Encryption_Name VARCHAR (100)   
				  ) 

--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
		
		
		IF (@Encryption_Type IS NULL OR LEN(@Encryption_Type) = 0) --V1.2
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error' , 'Encryption_Type cannot be NULL or Blank', (N'{'+CONCAT('"Encryption_Name": "',COALESCE( @Encryption_Name ,''))  +'" ' 
																			  +',' +CONCAT('"Encryption_Type": "',COALESCE( @Encryption_Type ,''))  +'" ' 
																	   		  +'}' )
			);

			SET @Returnvalue =2 ;
		END 

				IF (@Encryption_Name IS NULL OR LEN(@Encryption_Name) = 0) --V1.2
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error' , 'Encryption_Name cannot be NULL or Blank', (N'{'+CONCAT('"Encryption_Type": "',COALESCE( @Encryption_Type ,''))  +'" ' 
																			  +',' +CONCAT('"Encryption_Name": "',COALESCE( @Encryption_Name ,''))  +'" ' 
																			  +'}' )
			);

			SET @Returnvalue =2 ;
		END 

--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

 	-- V1.1
	IF @Returnvalue = 2 
		RAISERROR('sp_add_Encryption_Types: ERROR - Refer to Process_Error Table .', 16, -1)


--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				BEGIN TRY 
					BEGIN TRANSACTION
			
	 
	         
						INSERT INTO @InsertedParameterValues
						(  
						     Encryption_Type
						   , Encryption_Name 
						)    
						VALUES 
						(
						     @Encryption_Type
						   , @Encryption_Name 
						)  


--=======================================================================================================================
						 --Check if Encryption Type Already  Exists fetch the Encryption_TypeID to identify the Insert/Update Action 

						 SELECT @Encryption_TypeID  =Encryption_TypeID
                         FROM [ctlfwk].[Encryption_Types]
                         WHERE Encryption_Type = @Encryption_Type
						
--================================Update  Process Table ==============================================			 
						 --Capturing the Merge Action into #MergeActions Table 
						 DROP TABLE IF EXISTS #MergeActions ;
						 CREATE TABLE #MergeActions ([Action] VARCHAR(10),Encryption_TypeID INT  ) 
						 INSERT INTO #MergeActions ([Action],Encryption_TypeID)
						 SELECT [Action]  ,Encryption_TypeID
						 FROM ( 
			 
						 MERGE ctlfwk.Encryption_Types as tgt 
						 USING @InsertedParameterValues as source ON ( tgt.Encryption_TypeID =ISNULL(@Encryption_TypeID,0)						  
														  )
						 WHEN MATCHED THEN 
							  UPDATE 
							  SET   tgt.Encryption_Name =source.Encryption_Name
								  , tgt.last_modified_datetime =SYSDATETIME()
								  , tgt.last_modified_by = ORIGINAL_LOGIN()
 

						 WHEN NOT MATCHED THEN 
							 INSERT ( Encryption_Type, Encryption_Name)
							 VALUES ( 
									  source.Encryption_Type
									, source.Encryption_Name
           						   )
						   
						OUTPUT
							 $action as Action ,
						   inserted.Encryption_TypeID
						  ) MergeOutput 
						SELECT * FROM #MergeActions ;  
				COMMIT TRANSACTION	 
			END TRY
        
	  
       
		BEGIN CATCH 
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}'));
				ROLLBACK TRANSACTION 
		END CATCH 
	   END  --ReturnValue 0

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Encryption_Types' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
		  END 
	   ELSE 
	      SELECT CONCAT('Encryption_TypeID ',+ CONVERT(VARCHAR, Encryption_TypeID)   + ' Is '+Action +'D')  FROM #MergeActions
	 
END
