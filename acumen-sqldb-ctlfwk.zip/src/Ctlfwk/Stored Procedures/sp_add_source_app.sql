﻿CREATE PROCEDURE [ctlfwk].[sp_add_source_app]
(
	@business_unit_name_code varchar(7)
,	@source_app_name varchar(100)
,	@source_app_code varchar(25) --V1.5
,	@retention_days int = NULL
,	@SourceSystemDatabaseName varchar(50) --V1.2
,   @IUD_config_type varchar(10) = NULL --V2.0
)
AS

-- ==============================================================================================
 -- Parameters:
--   @busines_unit_name_code - unique business unit code from ctlfwk.business_unit
--   @source_app_name - name of source application
--	 @source_app_code - unique name of source application
--	 @retention_days - number of days to retain files
--	 @retention_days - number of days to retain files
-- Description:	Insert business unit record if it does not exist
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	08-07-2021						Deloitte				 1.0				InitialVersion
--	11-10-2021						Sheela R 				 1.1				Made changes to update Retentiondays 
--  16-11-2021						Tammy H					 1.2				Included @SourceSystemDatabaseName variable and SourceSystemDatabaseName_ID column
--  17-11-2021						Tammy H					 1.3				Input Parameter Validations, updated output message format, inserting errors to error table
--	01-02-2022						Tammy H					 1.4				Add Raise Error
--	10-03-2022						Tammy H					 1.5				New req: Change source_app_code varchar(6) to varchar(25)
--	10-05-2022						Musab A					 2.0				Adding IUD configuration type for sources with IUD load type
-- =================================================================================================

BEGIN

set nocount on;
	

	declare @source_app_id int;
	declare @business_unit_id int;
	declare @SourceSystemDatabaseName_ID INT; --V1.2
	declare @IUD_config_type_id int = NULL;
	-- V1.3 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 



 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 
 	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.business_unit WHERE business_unit_name_code = @business_unit_name_code ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Business_Unit_Name_Code does not exist',	(N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
																			+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.SourceSystemDatabaseName WHERE SourceSystemDatabaseName = @SourceSystemDatabaseName ) 
	BEGIN 
		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
		VALUES ('Error', 'SourceSystemDatabaseName does not exist',	(N'{'+CONCAT('"SourceSystemDatabaseName": "',COALESCE( @SourceSystemDatabaseName ,''))  +'" ' 
																		+'}' )
		);

		SET @Returnvalue =2 ;
	END 

	-- V3.0
	IF(@IUD_config_type IS NOT NULL)
	BEGIN 
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.IUD_config_types WHERE config_type = @IUD_config_type) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'IUD Config Type does not exist',	(N'{'+CONCAT('"IUD_Config_Type": "',COALESCE( @IUD_config_type ,''))  +'" ' 
																		+'}' )
		);

			SET @Returnvalue =2 ;
		END
	END	
 --===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 


 	-- V1.4
	IF @Returnvalue = 2 
		RAISERROR('sp_add_source_app: ERROR - Refer to Process_Error Table .', 16, -1)

 	-- If No Errors
	IF @Returnvalue =0
		BEGIN --ReturnValue 0
			BEGIN TRY
				
				--V1.2
				SET @business_unit_id = (select bu.[business_unit_id] from [ctlfwk].[business_unit] bu where bu.[business_unit_name_code] = @business_unit_name_code) 
				SET @SourceSystemDatabaseName_ID = (select SourceSystemDatabaseName_ID from Ctlfwk.SourceSystemDatabaseName where SourceSystemDatabaseName = @SourceSystemDatabaseName)
				--V3.0
				IF(@IUD_config_type IS NOT NULL)
					BEGIN 
						SET @IUD_config_type_id = (select ict.config_type_id from [ctlfwk].[IUD_config_types] ict where ict.config_type = @IUD_config_type) 
					END	
				BEGIN TRANSACTION
					-- V1.1 Capturing the Action into #Actions Table 
					DROP TABLE IF EXISTS #ActionTable;
					CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT)	

					-- check if record exists, if not, insert the row
					-- source app could be multiple instances but different business unit
					if (not exists 
						(
							select 1 
							from [ctlfwk].[source_app] sa
							left join [ctlfwk].[business_unit] bu on
								bu.[business_unit_id] = sa.[business_unit_id]
							where 
								sa.[source_app_code] = @source_app_code
							and bu.[business_unit_name_code] = @business_unit_name_code
						)
					)
						begin
							insert into [ctlfwk].[source_app]
							(
								[source_app_name]
							,	[source_app_code]
							,	[business_unit_id]
							,	[start_date_time]
							,	[end_date_time]
							,	[retention_days]
							,	[SourceSystemDatabaseName_ID] --V1.2
							,   [IUD_config_id] --V3.0
							)
							OUTPUT 'Inserted', inserted.source_app_id
							INTO #ActionTable (Act, Id)
							select
								@source_app_name
							,	@source_app_code
							,	@business_unit_id
							,	GETDATE()
							,	'9999-12-31'
							,	@retention_days
							,	@SourceSystemDatabaseName_ID --V1.2
							,	@IUD_config_type_id --V3.0

						end
					else
						begin

							set @source_app_id = (
								select
									source_app_id
								from [ctlfwk].[source_app] sa
								left join [ctlfwk].[business_unit] bu on
									bu.[business_unit_id] = sa.[business_unit_id]
								where 
									sa.[source_app_code] = @source_app_code
								and bu.[business_unit_name_code] = @business_unit_name_code
							);

							

							update ctlfwk.source_app
							set 
								   source_app_name = @source_app_name
								 , retention_days =@retention_days 
								 , SourceSystemDatabaseName_ID = @SourceSystemDatabaseName_ID --V1.2
								 , IUD_config_id = @IUD_config_type_id--V3.0
								 , last_modified_datetime =SYSDATETIME() 
								 , last_modified_by =ORIGINAL_LOGIN()
							OUTPUT 'Updated', inserted.source_app_id
							INTO #ActionTable (Act, Id)
							where 
								 source_app_id = @source_app_id
							and  business_unit_id = @business_unit_id
							and  end_date_time > GETDATE();

						end
				COMMIT TRANSACTION
			END TRY

			BEGIN CATCH

				--V1.3
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION 

			END CATCH
		END

		--V1.3
		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_source_app' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
			END 
		ELSE 
			SELECT CONCAT('Source_App_Id ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 
END