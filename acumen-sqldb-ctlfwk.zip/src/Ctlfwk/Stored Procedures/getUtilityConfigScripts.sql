﻿CREATE PROCEDURE [ctlfwk].[getUtilityConfigScripts]
(
 @input_filename VARCHAR (200) = '' --V1.6
)
AS

/* =============================================
-- Author:      <Author, , Name>
-- Create Date: <Create Date, , >
-- Description: <Description, , >
-- Order of script:
-- 1. Business Unit
-- 2. Source App
-- 3. Stream
-- 4. File_specification_type 
-- 5. Process
-- 6. Object
-- 7. Object Attribute
						*****************************IMPORTANT NOTE*****************
						Only SQL data types except datetimeoffset are being checked in Source_Object_Attribute_Data_Type
						The data type will need to be updated 



-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte				 1.0				InitialVersion
	06-09-2021						Tammy H 				 1.1				Changing order of script: 4. Object, 5. Object Attribute, 6. Process  
	30-09-2021                      Niharika S               1.2                Adding columns File_Exension_type_id and srouce_time_zone 
	30-09-2021						Niharika S			     1.3				Adding File_Specification_type to script & changing order of script 4. File_specification_type, 5. Proces, 6. Object, 7. Object Attribute
	04-10-2021                      Niharika S               1.4                Adding COALESCE function to column names + making exec statements for BU and source app as comments
	05-10-2021                      Niharika S               1.5                Erroring out 
	08-10-2021                      Niharika S               1.6                Added input_filename to Config
	08-10-2021                      Sheela R				 1.7                Removed LoadTypecode from SourceAttributeObjects 
	11-10-2021						Niharika S				 1.8				Data Length cannot be zero or NULL  when data type is VARCHAR, NVARCHAR,CHAR
	12-10-2021						Niharika S				 1.9				Adding col source_object_attribute_is_BusinessKey to source_object_attributes section
	14-10-2021						Niharika S				 1.10				Adding col Encryption_Type to source_object_attributes section
	19-10-2021						Tammy H					 1.11				Adding 2 new columns to File_Specification_type section: file_encoding and escape_character  
	25-10-2021						Niharika S				 1.12				Changing null check for field_Delimiter and has_header col to allow null/blank
	25-10-2021						Tammy H					 1.13				Adding TIMESTAMP to source_object_attribute_data_type, source_object_attribute_is_history_stitch_dataformat, source_time_zone validations and bugfixes
	04-11-2021						Tammy H					 1.14				Renaming source_object_attribute_length to source_object_attribute_scale, adding source_object_Attribute_precision column and associated validations
	08-11-2021						Niharika S				 1.15				Adding new column to File)Specification_Type section : Contains_Multiline_Data		
	09-11-2021						Tammy H					 1.16				Renaming source_object_attribute_IS_Historystitch_Dateformat to input_formatstring. Validations checks associated to the new data mapping table created for datatypes (ctlfwk.SourceSystemToSparkDataTypeMapping)
	11-11-2021						Tammy H					 1.17				Removing business_unit_name, storage_account, secret_name, source_app_name, retention_days. Split up validations to have individual validation and error message for stream, file_Specification_type, objects, process
	12-11-2021						Tammy H					 1.18				Fix issue with validations not throwing errors for values that should not accept values NULL. Align validations that do not match associated stored proc
	23-11-2021						Tammy H					 1.19				Referencing sourcesystemdatabasename to isolate database datatypes in validations. Modifications to deal with timestamp yyyy-MM-dd'T'HH:mm:ss.SSS'Z['z']'
	23-11-2021						Sheela R 				 1.20				Updating 'NULL' to NULL 
    23-11-2021						Sheela R 				 1.21				Encryption Type validation to check on Encryption table
	22-12-2021						Niharika S				 1.22				Adding 2 new cols to : PoolName, NoOfWorkers to process
	13-01-2022						Vikas P 				 1.23				Updating ='NULL' to like 'NULL' to NoOfWorkers as it was not allowing to compare and casted
	17-01-2022						Tammy H					 1.24				Removing date's requirement to have source_time_zone
	18-01-2022						Sheela R 				 1.25               Renamed Is_source_IUD as Schema_Name
	25-01-2022						Tammy H					 1.26				Switch Scale & Precision rules to match definitions of scale/precision. Add If PK='Y', BK must = 'N' validation
	25-01-2022                      Sheela R                 1.27               Changes to capture Cluster Parameters after discussionw with David 
	( 1- Make CLuster Parameters Mandatory 
	  2- Only when  New processes are added CLuster Parameters will be inserted , 
	  3- Any updates to Cluster Parameters will be manual which means  CI-CD will 
	     not overwrite existing parameters when deployed to an environment) 
	25-01-2022						Tammy H					1.28				Target_object_name will not be used in this utility but in another utility for gold layer instead.
																				To prevent any big changes, any value passed will be set to NULL/blank
    26-01-2022						Sheela R                1.29                 Some Validation changes 
	26-01-2022						Sheela R                2.0                 Some Validation changes
	26-01-2022						Sheela R                2.1                 Input Format Changes for Oracle -Bupa Specific 
	28-01-2022					    Tammy H					2.2					Instead of Blank which changes to 0 because of INT, source_object_attribute_seq cannot be <1
	28-01-2022						Tammy H					2.3					CAST to int when comparing scale/precision numbers for DECIMAL sparkdatatype
	31-01-2022						Sheela R                2.4					Oracle stores date with Timestamp hence modified to match 
																				--  Attunity Extraction 
    02-02-2022						Sheela R                2.5                 Bupa Specific InputFormatString for Eventhub_Enqueued_Time_Utc/Attunity_Timestamp
    04-02-2022						Sheela R                2.6                 This is to handle multi user capability 0 input_filename
	08-02-2022						Tammy H					2.7					Fix issue with filtering for Spark Decimal Datatype validations
	24-02-2022						Tammy H					2.8					Setting precision as max when sqlserver/other source and datatype = timestamp/uniqueidentifier
	24-02-2022						Tammy H					2.9					New req updating V2.8: setting precision sqlserver/other source and datatype = timestamp (then 64) and uniqueidentifier (then 128)
	18-03-2022						Tammy H					3.0					New req: Stream_name and stream_description raised to be varchar(255)
	12-04-2022						Tammy H					3.1					SQLSERVER datatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY does not require precision or scale and bugfixes
-- =================================================================================================================================== */ 
-- ============================================= */
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
     SET NOCOUNT ON

    -- Insert statements for procedure here
	
--	 TRUNCATE TABLE [ctlfwk].[Utility_Config_Scripts]  -- V2.6 
  --   UPDATE [ctlfwk].[Utility_Config_Scripts] SET input_filename =@input_filename
  --   WHERE  input_filename IS NULL ;
     DELETE FROM [ctlfwk].[Utility_Config_Scripts] WHERE LTRIM(RTRIM(input_filename)) = @input_filename --V2.6 

	 --Delete data older than 15 days
	 DELETE FROM [ctlfwk].[Utility_Config_Scripts] WHERE CONVERT(DATE, Last_modified_datetime) < CONVERT(DATE, GETDATE() - 15)
	--V1.5
	-- Table Variable to Capture Error/Actions 
	 DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	 DECLARE @Returnvalue INT = 0 --Success 
	 DECLARE @error_flag VARCHAR(100)
	 DECLARE @error_message VARCHAR(200)
--=================================V1.20SETTING data as Null if Excel has 'NULL'=============================================================================================

UPDATE ctlfwk.Utility_Config
	  SET Business_Unit_Name_code =NULL WHERE Business_Unit_Name_code = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_App_Code =NULL WHERE Source_App_Code = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Stream_Name =NULL WHERE Stream_Name = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename;
	UPDATE ctlfwk.Utility_Config
	  SET Stream_Name =NULL WHERE Stream_Name = 'NULL'AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Stream_Description =NULL WHERE Stream_Description = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Restart_From_Beginning =NULL WHERE Restart_From_Beginning = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Process_Name =NULL WHERE Process_Name = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Process_Name_Description =NULL WHERE Process_Name_Description = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Is_Enabled =NULL WHERE Is_Enabled = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename;
	UPDATE ctlfwk.Utility_Config
	  SET Process_Type =NULL WHERE Process_Type = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Name =NULL WHERE Source_Object_Name = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Load_Type_Code =NULL WHERE Load_Type_Code = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Description =NULL WHERE Source_Object_Description = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Is_File_Mandatory =NULL WHERE Is_File_Mandatory = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_Name =NULL WHERE Source_Object_Attribute_Name = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_Seq =NULL WHERE Source_Object_Attribute_Seq = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_Data_Type =NULL WHERE Source_Object_Attribute_Data_Type = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_Scale = '' WHERE (Source_Object_Attribute_Scale = 'NULL' OR Source_Object_Attribute_Scale = NULL) AND LTRIM(RTRIM(input_filename)) = @input_filename ; --V3.1
    UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_Precision = '' WHERE (Source_Object_Attribute_Precision='NULL' OR Source_Object_Attribute_Precision=NULL) AND LTRIM(RTRIM(input_filename)) = @input_filename ; --V3.1
    UPDATE ctlfwk.Utility_Config
	  SET Input_FormatString  =NULL WHERE Input_FormatString='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
    UPDATE ctlfwk.Utility_Config
	  SET source_time_zone  =NULL WHERE source_time_zone='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
    UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_IS_Null =NULL WHERE Source_Object_Attribute_IS_Null='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
    UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_IS_PK =NULL WHERE Source_Object_Attribute_IS_PK='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_IS_BusinessKey =NULL WHERE Source_Object_Attribute_IS_BusinessKey='NULL'  AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_IS_PII =NULL WHERE Source_Object_Attribute_IS_PII='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_IS_History_Stitch =NULL WHERE Source_Object_Attribute_IS_History_Stitch='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename  ;
    UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Attribute_IS_HistoryStitch_SortKey =NULL WHERE Source_Object_Attribute_IS_HistoryStitch_SortKey='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename  ;
	UPDATE ctlfwk.Utility_Config
	  SET Source_Object_Is_IUD_Column =NULL WHERE Source_Object_Is_IUD_Column='NULL'AND LTRIM(RTRIM(input_filename)) = @input_filename  ;
    UPDATE ctlfwk.Utility_Config
	  SET dynamic_masking_function =NULL WHERE dynamic_masking_function='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET default_value_if_not_nullable =NULL WHERE default_value_if_not_nullable='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET target_object_name =NULL WHERE target_object_name='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET File_Pattern_Name =NULL WHERE File_Pattern_Name='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET target_object_name =NULL WHERE target_object_name='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
    UPDATE ctlfwk.Utility_Config
	  SET Has_Header =NULL WHERE Has_Header='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET File_Extension_Type =NULL WHERE File_Extension_Type='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Field_Delimiter =NULL WHERE Field_Delimiter='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET TimeStamp_Filename_Pattern =NULL WHERE TimeStamp_Filename_Pattern='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET TimeStamp_Filename_RegexPattern =NULL WHERE TimeStamp_Filename_RegexPattern='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Encryption_Type =NULL WHERE Encryption_Type='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET File_Encoding ='AUTO' WHERE File_Encoding='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET Contains_Multiline_Data =NULL WHERE Contains_Multiline_Data='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Config
	  SET Escape_Character ='"' WHERE Escape_Character='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Config
	  SET PoolName =NULL WHERE PoolName='NULL' ; --V1.22
	UPDATE ctlfwk.Utility_Config
	  SET NoOfWorkers =1 WHERE NoOfWorkers like 'NULL' OR NoOfWorkers IS NULL or  NoOfWorkers like '' 
	  AND LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.22/v1.23
	UPDATE ctlfwk.Utility_Config
	  SET [Schema_Name] =NULL WHERE [Schema_Name]='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.25
	UPDATE ctlfwk.Utility_Config
	  SET target_object_name = NULL  --V1.28
	  --V2.5 
	UPDATE Ctlfwk.Utility_Config 
	SET input_formatstring ='M/d/yyyy h:mm:ss a'
	WHERE LTRIM(RTRIM(source_object_attribute_name)) ='Eventhub_Enqueued_Time_Utc'
	AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Config 
	SET input_formatstring ='yyyy-MM-dd''T''HH:mm:ss.SSS'  
	WHERE LTRIM(RTRIM(source_object_attribute_name)) ='Attunity_Timestamp' 
	AND LTRIM(RTRIM(input_filename)) = @input_filename;
	 --V2.5	 
	
	----V2.9 start
	----V2.8
	--UPDATE Ctlfwk.Utility_Config
	--SET Source_Object_Attribute_Precision = '64'
	--FROM Ctlfwk.Utility_Config ug
	--INNER JOIN Ctlfwk.source_app sa ON sa.source_app_code = ug.Source_App_Code
	--INNER JOIN Ctlfwk.SourceSystemDatabaseName ssdn ON sa.SourceSystemDatabaseName_ID = ssdn.SourceSystemDatabaseName_ID
	--WHERE Source_Object_Attribute_Data_Type IN ('Timestamp') AND ssdn.SourceSystemDatabaseName IN ('SQLSERVER', 'OTHER')

	--UPDATE Ctlfwk.Utility_Config
	--SET Source_Object_Attribute_Precision = '128'
	--FROM Ctlfwk.Utility_Config ug
	--INNER JOIN Ctlfwk.source_app sa ON sa.source_app_code = ug.Source_App_Code
	--INNER JOIN Ctlfwk.SourceSystemDatabaseName ssdn ON sa.SourceSystemDatabaseName_ID = ssdn.SourceSystemDatabaseName_ID
	--WHERE Source_Object_Attribute_Data_Type IN ('Uniqueidentifier') AND ssdn.SourceSystemDatabaseName IN ('SQLSERVER', 'OTHER')
	----V2.9 end
--==================================V1.20===============================================================================================


--===========================-- Business Unit Processing   ==================================================== 

-- 1. Business Unit

	--V1.17 Removed Business_Unit_Name, Storage_Account, Secret_Name
   ; WITH bu AS(
				SELECT DISTINCT COALESCE(Business_Unit_Name_code,'') AS Business_Unit_Name_code
				FROM [ctlfwk].[Utility_Config] 
				WHERE LTRIM(RTRIM(input_filename)) = @input_filename
				)
	SELECT ROW_NUMBER()OVER(ORDER BY Business_Unit_Name_code ASC) AS row_num,*
	INTO #temp_bu 
	FROM bu
	
	
	--V1.12
	IF NOT EXISTS (
					SELECT 1 fROM #temp_bu tbu
					JOIN ctlfwk.business_unit cbu ON cbu.business_unit_name_code = tbu.Business_Unit_Name_code
					WHERE row_num = 1
	              )
	  BEGIN 
		   SET @error_flag = 'Error'
		   SET @error_message = 'Business_unit_code does not exist '

           INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
		   SELECT @error_flag, @error_message, (N'{'+CONCAT('"business_unit_Name_code": "',COALESCE( business_unit_Name_code ,''))  +'" ' 
												+'}' )
          FROM #temp_bu 
		  WHERE row_num = 1

		  SET @Returnvalue =2 ;
		--SELECT * from @ErrorUDT 
    END  
--===========================--    SourceApp    ==================================================== 
-- 2. Source App

	--V1.17 Removed Source_App_Name, retention_days
   ; WITH sa AS(
				SELECT DISTINCT Business_Unit_Name_code, Source_App_Code
				FROM [ctlfwk].[Utility_Config]
				WHERE LTRIM(RTRIM(input_filename)) = @input_filename --V2.6 
				)
	SELECT ROW_NUMBER()OVER(ORDER BY Business_Unit_Name_code ASC) AS row_num,*
	INTO #temp_sa
	FROM sa
    DECLARE @sql_sa varchar(MAX)  --, @source_app_name varchar(100), @retention_days varchar(100)

	IF NOT EXISTS (
					SELECT 1 fROM #temp_sa tsa
					JOIN ctlfwk.source_app csa ON csa.source_app_code = tsa.Source_App_Code		
					WHERE row_num = 1
				  )
	BEGIN 
			SET @error_flag = 'Error'
			SET @error_message =   'Source_App_code does not exist'

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			SELECT @error_flag, @error_message, (N'{'+CONCAT('"source_app_code": "',COALESCE( source_app_code ,''))  +'" '
													+'}' )
			FROM #temp_sa   
			WHERE row_num = 1	 

			SET @Returnvalue =2 ;
    END 

--===========================--      Stream      ==================================================== 

   ; WITH stream AS(
					SELECT DISTINCT Source_App_Code, Stream_Name, Stream_Description,Restart_From_Beginning
					FROM [ctlfwk].[Utility_Config]
					WHERE LTRIM(RTRIM(input_filename)) = @input_filename --V2.6
					)
	 SELECT ROW_NUMBER()OVER(ORDER BY Stream_Name ASC) AS row_num,*
	 INTO #temp_stream
	 FROM stream
	 		--Deleting Duplicate data 
			;WITH dups (  source_app_code ,Stream_name,
				          DuplicateCount)
			AS (SELECT Source_App_Code,Stream_Name,
					   ROW_NUMBER() OVER(PARTITION   BY source_app_code ,Stream_Name  ORDER BY row_num) AS DuplicateCount
				FROM #temp_stream)
			DELETE FROM dups
			WHERE DuplicateCount > 1;

			-- V1.17 Split up all validations to have their own validations START
			IF EXISTS (SELECT 1 FROM #temp_stream WHERE--row_num = 1
						Stream_Name IS NULL OR LEN(Stream_Name) = 0
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Stream_Name cannot be Null/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Stream_Name": "',COALESCE( Stream_Name ,''))  +'" ' 
																	+'}' )
					 FROM #temp_stream   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				 END 

			IF EXISTS (SELECT 1 FROM #temp_stream
					   WHERE Stream_Description IS NULL OR LEN(Stream_Description) =0
			          )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Stream_Description cannot be Null/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Stream_Name": "',COALESCE( Stream_Name ,''))  +'" ' 
															+',' +CONCAT('"Stream_Description": "',COALESCE( Stream_Description ,''))  +'" ' 
															+'}' )
					 FROM #temp_stream   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				 END 
			-- V1.17 Split up all validations to have their own validations END
--===========================--    File_specification_type    ==================================================== 
			
	; WITH FileSpecificationType AS(
									SELECT DISTINCT  
					                                File_Pattern_Name 
												  , Has_Header 
												  , File_Extension_Type 
												  , Field_Delimiter 
												  , TimeStamp_Filename_Pattern 
												  , TimeStamp_Filename_RegexPattern 
												  , File_Encoding -- V1.11 Allows NULL/Blanks
												  , Escape_Character -- V1.11 Allows NULL/Blanks
												  , Contains_Multiline_Data --V1.15 Allows NULL/Blanks
									FROM [ctlfwk].[Utility_Config]
									WHERE LTRIM(RTRIM(input_filename)) = @input_filename --V2.6
								   )
			SELECT ROW_NUMBER()OVER(ORDER BY File_Pattern_Name ASC) AS row_num,*
			INTO #temp_FileSpecifications
			FROM FileSpecificationType


			-- V1.17 Split up all validations to have their own validations START
			IF EXISTS (SELECT 1 FROM #temp_FileSpecifications 
						WHERE (File_Pattern_Name IS NULL OR LEN(File_Pattern_Name) =0)
					  )
				BEGIN
				  SET  @error_flag = 'Error'
				  SET @error_message =   'File_Pattern_Name cannot be NULL/Blank.'

				  INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				  SELECT @error_flag, @error_message, (N'{'+CONCAT('"File_Pattern_Name": "',COALESCE( File_Pattern_Name ,''))  +'" ' 
															+'}' )
				  FROM #temp_FileSpecifications   
				  WHERE row_num = 1	 

				  SET @Returnvalue =2 ;
				END 

			IF EXISTS (SELECT 1 FROM #temp_FileSpecifications 
						WHERE NOT (Has_Header IS NULL OR Has_Header IN ('Y', 'N') OR LEN(Has_Header) = 0)  --V1.12
					  )
				BEGIN
				  SET  @error_flag = 'Error'
				  SET @error_message =   'Has_Header can only have values Y or N or be NULL/Blank.'

				  INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				  SELECT @error_flag, @error_message, (N'{'+CONCAT('"File_Pattern_Name": "',COALESCE( File_Pattern_Name ,''))  +'" ' 
															+',' +CONCAT('"Has_Header": "',COALESCE( Has_Header ,''))  +'" ' 
															+'}' )
				  FROM #temp_FileSpecifications   
				  WHERE row_num = 1	 

				  SET @Returnvalue =2 ;
				END 
						

			IF EXISTS (SELECT 1 FROM #temp_FileSpecifications 
						WHERE (File_Extension_Type IS NULL OR LEN(File_Extension_Type) =0)
					  )
				BEGIN
				  SET  @error_flag = 'Error'
				  SET @error_message =   'File_Extension_Type cannot be NULL/Blank.'

				  INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				  SELECT @error_flag, @error_message, (N'{'+CONCAT('"File_Pattern_Name": "',COALESCE( File_Pattern_Name ,''))  +'" ' 
																+',' +CONCAT('"File_Extension_Type": "',COALESCE( File_Extension_Type ,''))  +'" ' 
																+'}' )
				  FROM #temp_FileSpecifications   
				  WHERE row_num = 1	 

				  SET @Returnvalue =2 ;
				END 

			IF EXISTS (SELECT 1 FROM #temp_FileSpecifications 
						WHERE (TimeStamp_Filename_Pattern IS NULL OR LEN(TimeStamp_Filename_Pattern) =0)
					  )
				BEGIN
				  SET  @error_flag = 'Error'
				  SET @error_message =   'TimeStamp_Filename_Pattern cannot be NULL/Blank.'

				  INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				  SELECT @error_flag, @error_message, (N'{'+CONCAT('"File_Pattern_Name": "',COALESCE( File_Pattern_Name ,''))  +'" ' 
																+',' +CONCAT('"TimeStamp_Filename_Pattern": "',COALESCE( TimeStamp_Filename_Pattern ,''))  +'" ' 
																+'}' )
				  FROM #temp_FileSpecifications   
				  WHERE row_num = 1	 

				  SET @Returnvalue =2 ;
				END 

			IF EXISTS (SELECT 1 FROM #temp_FileSpecifications 
						WHERE (TimeStamp_Filename_RegexPattern IS NULL OR LEN(TimeStamp_Filename_RegexPattern) =0)
					  )
				BEGIN
				  SET  @error_flag = 'Error'
				  SET @error_message =   'TimeStamp_Filename_RegexPattern cannot be NULL/Blank.'

				  INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				  SELECT @error_flag, @error_message, (N'{'+CONCAT('"File_Pattern_Name": "',COALESCE( File_Pattern_Name ,''))  +'" ' 
																+',' +CONCAT('"TimeStamp_Filename_RegexPattern": "',COALESCE( TimeStamp_Filename_RegexPattern ,''))  +'" ' 
																+'}' )
				  FROM #temp_FileSpecifications   
				  WHERE row_num = 1	 

				  SET @Returnvalue =2 ;
				END 

			IF EXISTS (SELECT 1 FROM #temp_FileSpecifications 
						WHERE NOT (Contains_Multiline_Data IS NULL OR Contains_Multiline_Data IN ('Y', 'N') OR LEN(Contains_Multiline_Data) = 0)  --V1.15
					  )
				BEGIN
				  SET  @error_flag = 'Error'
				  SET @error_message =   'Contains_Multiline_Data can only have values Y or N or be NULL/Blank.'

				  INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				  SELECT @error_flag, @error_message, (N'{'+CONCAT('"File_Pattern_Name": "',COALESCE( File_Pattern_Name ,''))  +'" ' 
															+',' +CONCAT('"Contains_Multiline_Data": "',COALESCE( Contains_Multiline_Data ,''))  +'" ' 
															+'}' )
				  FROM #temp_FileSpecifications   
				  WHERE row_num = 1	 

				  SET @Returnvalue =2 ;
				END 

			-- V1.17 Split up all validations to have their own validations END

--===========================--    Object    ==================================================== 

		--	SELECT * FROM ctlfwk.source_objects
	; WITH source_object AS(
			               SELECT DISTINCT Source_App_Code
										 , Source_Object_Name
										 , Source_Object_Description
										 , Load_Type_Code
										 , Is_File_Mandatory
										 , [Schema_Name]
										 , File_Pattern_Name --V1.2 
							FROM [ctlfwk].[Utility_Config]  
							WHERE LTRIM(RTRIM(input_filename)) = @input_filename --V2.6
	
						)
			SELECT ROW_NUMBER()OVER(ORDER BY Source_App_Code ASC) AS row_num,*
			INTO #temp_source_object
			FROM source_object

			--Deleting Duplicate data 
			;WITH dups (  source_app_code ,Source_Object_Name,
				          DuplicateCount)
			AS (SELECT Source_App_Code,Source_Object_Name,
					   ROW_NUMBER() OVER(PARTITION   BY source_app_code ,Source_Object_Name  ORDER BY row_num) AS DuplicateCount
				FROM #temp_source_object)
			DELETE FROM dups
			WHERE DuplicateCount > 1;

			 --V1.18 If Null/blank is given, value = 0
			UPDATE #temp_source_object
			SET is_file_mandatory = 0
			WHERE (is_file_mandatory IS NULL OR LEN(is_file_mandatory) =0)

			-- V1.17 Split up all validations to have their own validations START
			IF EXISTS ( SELECT 1 FROM #temp_source_object 
						WHERE (Source_Object_Name IS NULL OR LEN(Source_Object_Name) = 0)
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Source_Object_Name cannot be NULL/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Name": "',COALESCE( Source_Object_Name ,''))  +'" ' 
																	+'}' )
					 FROM #temp_source_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END 

			IF EXISTS ( SELECT 1 FROM #temp_source_object 
						WHERE Source_Object_Description IS NULL OR LEN(Source_Object_Description) =0
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Source_Object_Description cannot be NULL/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Name": "',COALESCE( Source_Object_Name ,''))  +'" ' 
																+',' +CONCAT('"Source_Object_Description": "',COALESCE( Source_Object_Description ,''))  +'" ' 
																+'}' )
					 FROM #temp_source_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END 

			-- V1.18 checking with load_type table that the load_type_code exists
			IF NOT EXISTS ( SELECT 1 FROM #temp_source_object so 
							INNER JOIN Ctlfwk.load_types lt 
							ON so.Load_Type_Code = lt.load_type_code
						  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Load_Type_Code does not exist.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Name": "',COALESCE( Source_Object_Name ,''))  +'" ' 
																+',' +CONCAT('"Load_Type_Code": "',COALESCE( Load_Type_Code ,''))  +'" ' 
																+'}' )
					 FROM #temp_source_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END 

			-- V1.18 Precaution check. Since restart_from_beginning is BIT, SQL should auto convert values to 1 or 0 unless it is a NULL, which is the previous validation. So this error should not occur at all.
			IF EXISTS ( SELECT 1 FROM #temp_source_object 
						WHERE (is_file_mandatory NOT IN ( 0,1)) 
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'is_file_mandatory can only have values 0 or 1.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Name": "',COALESCE( Source_Object_Name ,''))  +'" ' 
																+',' +CONCAT('"is_file_mandatory": "',COALESCE( is_file_mandatory ,''))  +'" ' 
																+'}' )
					 FROM #temp_source_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END 
			
		 
			-- V1.17 Split up all validations to have their own validations END		 



--===========================--    Object Attribute   ==================================================== 

	; WITH source_object_attributes AS(
									  SELECT DISTINCT Source_App_Code
													, Source_Object_Name
													--, Load_Type_Code --V1.7   
													, Source_Object_Attribute_Name
													, Source_Object_Attribute_Seq
													, Source_Object_Attribute_Data_Type
													, Source_Object_Attribute_Precision --V1.14
													, Source_Object_Attribute_Scale --V1.14
													, Source_Object_Attribute_IS_PK
													, Source_Object_Attribute_IS_Null
													, Source_Object_Attribute_IS_PII
													, Source_Object_Attribute_IS_History_Stitch
													, Source_Object_Attribute_IS_HistoryStitch_SortKey
													, Source_Object_Is_IUD_Column
													, Input_FormatString --V1.16
													, dynamic_masking_function
													, default_value_if_not_nullable
													, source_time_zone --V1.2
													, Source_Object_Attribute_IS_BusinessKey --V1.9
													, [Encryption_Type] --V1.10
										FROM [ctlfwk].[Utility_Config]
										WHERE LTRIM(RTRIM(input_filename)) = @input_filename --V2.6
									    )
			SELECT ROW_NUMBER()OVER(ORDER BY Source_App_Code ASC, Source_Object_Name ASC, CAST(Source_Object_Attribute_Seq AS INT) ASC) 
			AS row_num,*
			INTO #temp_source_object_attributes
			FROM source_object_attributes

			-- V2.7 table containing only DECIMAL spark datatypes attributes used to check precision/scale rules
			SELECT DISTINCT soa.Source_App_Code
						, Source_Object_Name
						--, Load_Type_Code --V1.7   
						, Source_Object_Attribute_Name
						, Source_Object_Attribute_Seq
						, Source_Object_Attribute_Data_Type
						, Source_Object_Attribute_Precision --V1.14
						, Source_Object_Attribute_Scale --V1.14
						, Source_Object_Attribute_IS_PK
						, Source_Object_Attribute_IS_Null
						, Source_Object_Attribute_IS_PII
						, Source_Object_Attribute_IS_History_Stitch
						, Source_Object_Attribute_IS_HistoryStitch_SortKey
						, Source_Object_Is_IUD_Column
						, Input_FormatString --V1.16
						, dynamic_masking_function
						, default_value_if_not_nullable
						, source_time_zone --V1.2
						, Source_Object_Attribute_IS_BusinessKey --V1.9
						, [Encryption_Type] --V1.10
						INTO #temp_decimal_source_object_attributes 
						FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype 
						AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE ss.SparkSQLDatatype IN ('DECIMAL') AND NOT (soa.source_object_Attribute_data_type IN ('MONEY', 'SMALLMONEY') AND ss.DataSource = 'SQLSERVER') --V3.1 money/smallmoney doesn't require precision/scale


			--SELECT REPLACE(Input_FormatString,'?','''') FROM #temp_source_object_attributes WHERE Input_FormatString LIKE '%?%'
			UPDATE #temp_source_object_attributes
			SET Input_FormatString = REPLACE(Input_FormatString,'?','''')
			WHERE Input_FormatString LIKE '%?%'


			--V1.16 reformatting input yyyy-mm-dd'T'hh:mm:ss.SSS to yyyy-mm-dd''T''hh:mm:ss.SSS so that it can maintain form in string EXEC statement below
			--The string EXEC statement will revert it back to yyyy-mm-dd'T'hh:mm:ss.SSS when executed
			UPDATE #temp_source_object_attributes
			SET Input_FormatString = 'yyyy-MM-dd''''T''''HH:mm:ss.SSS' 
			WHERE Input_FormatString = 'yyyy-MM-dd''T''HH:mm:ss.SSS';
			
			--V1.19
			UPDATE #temp_source_object_attributes
			SET Input_FormatString = 'yyyy-MM-dd''''T''''HH:mm:ss.SSS''''Z[''''z'''']'''''
			WHERE Input_FormatString = 'yyyy-MM-dd''T''HH:mm:ss.SSS''Z[''z'']'''

			-- V2.1 
			-- InputFormatString for Oracle Databases in Bupa 
			
			UPDATE soa 
			SET soa.Input_FormatString = 
			CASE WHEN soa.Source_Object_Attribute_Data_Type ='TIMESTAMPWITHTIMEZONE' 
			     THEN 'yyyy-MM-dd HH:mm:ss.SSSSSS z'
				 WHEN soa.Source_Object_Attribute_Data_Type ='Timestamp' 
			     THEN 'yyyy-MM-dd HH:mm:ss.SSSSSS'
				 WHEN soa.Source_Object_Attribute_Data_Type ='Date' 
			     --THEN 'dd/MMM/yy'
				 THEN 'yyyy-MM-dd HH:mm:ss'  -- Oracle stores date with Timestamp hence modified to match 
				 --  Attunity Extraction --V2.4 
			 END
		  
			FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						WHERE sdb.SourceSystemDatabaseName ='Oracle' ;
			-- V2.1 
			   
  			--Removing duplicates
			IF EXISTS (
			SELECT Source_App_Code, Source_Object_Name, Source_Object_Attribute_Seq , count(*) from #temp_source_object_attributes
			GROUP BY Source_App_Code, Source_Object_Name,Source_Object_Attribute_Seq
			HAVING COUNT(*) > 1
			)
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_Seq has incorrect values.'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Attribute_Name": "',COALESCE( Source_Object_Attribute_Name ,''))  +'" ' 
														+',' +CONCAT('"Source_Object_Attribute_Seq": "', COALESCE ( Source_Object_Attribute_Seq, '')) +'" '
															+'}' )
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	 

					SET @Returnvalue =2 ;

				END
			
			--Removed Loadtype from validation V1.7 
			IF EXISTS (
				SELECT Source_App_Code, Source_Object_Name , Source_Object_Attribute_Name , count(*) from #temp_source_object_attributes
				GROUP BY Source_App_Code, Source_Object_Name , Source_Object_Attribute_Name
				HAVING COUNT(*) > 1
			)
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_Name has incorrect values.' 

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Attribute_Seq": "',COALESCE( Source_Object_Attribute_Seq ,''))  +'" ' 
															+',' +CONCAT('"Source_Object_Attribute_Name": "', COALESCE ( Source_Object_Attribute_Name, '')) +'" '
															+'}' )
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	 

					SET @Returnvalue =2 ;

				END

		
			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Attribute_Name IS NULL OR LEN(Source_Object_Attribute_Name) =0))
			   BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_Name cannot be NULL/Blank'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	 

					SET @Returnvalue =2 ;

				END 

			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Attribute_Seq IS NULL OR Source_Object_Attribute_Seq <1) --2.2
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Incorrect Source_Object_Attribute_Seq cannot be NULL/Blank'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	 

					SET @Returnvalue =2 ;

				 END 
			
			--V1.19 Referencing sourcesystemdatabasename to isolate database datatypes in validations
			--V1.16 datatypes recognised/accepted is now retrieved from Ctlfwk.SourceSystemToSparkDataTypeMapping table
			IF EXISTS( SELECT * FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE ss.SourceSystemToSparkDataTypeMappingID IS NULL
					 )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Incorrect Source_Object_Attribute_Data_Type'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	

					SET @Returnvalue =2 ;

				END 
           --V2.0 --SRN
		   	IF  EXISTS ( 
			           
						SELECT 1 FROM #temp_decimal_source_object_attributes soa --V2.7
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype 
						AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE (CAST(soa.Source_object_Attribute_Precision AS INT) > 38 ) --V2.3 CAST TO INT
				     )
				BEGIN

						UPDATE soa 
						SET Source_Object_Attribute_Precision = 38 
						FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						INNER JOIN #temp_decimal_source_object_attributes dsoa --V2.7 
						ON soa.Source_Object_Attribute_Seq = dsoa.Source_Object_Attribute_Seq
						WHERE (CAST(dsoa.Source_Object_Attribute_Precision AS INT) > 38) ;  --V2.3 CAST TO INT

						--V3.1 To also update the DECIMAL only table for downstream validations
						UPDATE dsoa
						SET Source_Object_Attribute_Precision = 38 
						FROM #temp_decimal_source_object_attributes dsoa
						WHERE (CAST(dsoa.Source_Object_Attribute_Precision AS INT) > 38)
				END

			IF EXISTS ( SELECT 1 FROM #temp_decimal_source_object_attributes soa --V2.7
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE (CAST(soa.Source_Object_Attribute_Precision AS INT)   NOT BETWEEN 1 AND 38 --V2.3 CAST TO INT
				     ))
				BEGIN --Inner

					SET @error_flag = 'Error'
					SET @error_message =   'Precision has to be between 1 and 38 for spark equivalent DECIMAL datatypes except SQLSERVER datatypes MONEY, SMALLMONEY'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	

					SET @Returnvalue =2 ;
					 					
				END
            
			IF EXISTS ( SELECT 1 FROM #temp_decimal_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE ((CAST(soa.Source_Object_Attribute_scale AS INT) > CAST(soa.Source_Object_Attribute_Precision AS INT)
								OR 
								CAST(soa.Source_Object_Attribute_scale AS INT) <0)) --V2.3 CAST TO INT
						)
			BEGIN

					SET @error_flag = 'Error'
					SET @error_message =   'Scale has to be between [0, Precision] for spark equivalent DECIMAL datatypes except SQLSERVER datatypes MONEY, SMALLMONEY'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	

					SET @Returnvalue =2 ;

			END 
		
		        

		   --V2.0
			--V1.19 Referencing sourcesystemdatabasename to isolate database datatypes in validations
			--V1.14
			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE (ss.SparkSQLDatatype IN ('STRING', 'DOUBLE', 'DECIMAL','FLOAT') 
								AND NOT (soa.source_object_Attribute_data_type IN ('TEXT', 'NTEXT', 'TIMESTAMP', 'UNIQUEIDENTIFIER', 'MONEY', 'SMALLMONEY') AND ss.DataSource = 'SQLSERVER') --V3.1
								AND (soa.Source_Object_Attribute_Precision IS NULL OR LEN(soa.Source_Object_Attribute_Precision) = 0))
					   
					  )
				BEGIN
				
					SET @error_flag = 'Error' 
					SET @error_message ='Precision cannot be NULL/Blank for spark equivalent datatypes STRING, DOUBLE, DECIMAL, FLOAT except SQLSERVER datatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY' 

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	

					SET @Returnvalue =2 ;
				END
			
			-- V1.26 replace scale with precision
			-- V1.19 Referencing sourcesystemdatabasename to isolate database datatypes in validations
			-- V1.14
			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						--WHERE ((ss.SparkSQLDatatype LIKE 'date%%' OR ss.SparkSQLDatatype LIKE 'timestamp%%') --V1.29 
						WHERE (
						        (ss.SparkSQLDatatype LIKE 'date%%' OR ss.SparkSQLDatatype LIKE 'timestamp%%')
								AND NOT ((soa.source_object_attribute_precision IS NULL OR LEN(soa.source_object_attribute_precision) = 0) 
								        AND (soa.source_object_attribute_scale IS NULL OR LEN(soa.source_object_attribute_scale) = 0)
										)
								) AND ss.DataSource ='Oracle' 
	    					  )
				BEGIN

					SET @error_flag = 'Error'
					SET @error_message =   'Spark equivalent DATE%%/TIMESTAMP%% provided for Oracle Source should have NULL Values as Source_Object_Attribute_Scale and Source_Object_Attribute_Precision'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	

					SET @Returnvalue =2 ;
				END
		--  V1.29 
		    IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						--WHERE ((ss.SparkSQLDatatype LIKE 'date%%' OR ss.SparkSQLDatatype LIKE 'timestamp%%') --V1.29 
						WHERE (
						        soa.Source_Object_Attribute_Data_Type  IN  ('smalldatetime','date','datetime') --These datatypes will not have precision and scale 
								AND NOT ((soa.source_object_attribute_precision IS NULL OR LEN(soa.source_object_attribute_precision) = 0) 
								        AND (soa.source_object_attribute_scale IS NULL OR LEN(soa.source_object_attribute_scale) = 0)
										)
								) AND ss.DataSource in ('SQLSERVER' ,'other')
	    					  )
				BEGIN

					SET @error_flag = 'Error'
					SET @error_message =   'SMALLDATETIME, DATE, DATETIME provided for SQL/Other should have NULL Values as Source_Object_Attribute_Scale and Source_Object_Attribute_Precision'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	

					SET @Returnvalue =2 ;
				END

		--V1.2 9
			--V1.18 Covering NULL for error scenario
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Attribute_IS_PK NOT IN ('Y','N') OR Source_Object_Attribute_IS_PK IS NULL)
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_IS_PK can only have values Y/N'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 

					SET @Returnvalue =2 ;

				END 

			--V1.18 Covering NULL for error scenario
			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes
						WHERE (Source_Object_Attribute_IS_Null NOT IN ('Y','N') OR Source_Object_Attribute_IS_Null IS NULL)	
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_IS_Null can only have values Y/N'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 	 

					SET @Returnvalue =2 ;

				END 

			--V1.18 Covering NULL for error scenario
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Attribute_IS_PII NOT IN ('Y','N') OR Source_Object_Attribute_IS_PII IS NULL)
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_IS_PII can only have values Y/N'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 

					SET @Returnvalue =2 ;

				END 

			--V1.18 Covering NULL for error scenario
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Attribute_IS_History_Stitch NOT IN ('Y','N') OR Source_Object_Attribute_IS_History_Stitch IS NULL)
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_IS_History_Stitch can only have values Y/N'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 

					SET @Returnvalue =2 ;

				END 

			--V1.19 Referencing sourcesystemdatabasename to isolate database datatypes in validations
			--V1.16
			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes soa
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE soa.Source_Object_Attribute_IS_History_Stitch = 'Y' AND ss.SparkSQLDatatype != 'TIMESTAMP'
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_Data_Type should be equivalent to Spark TIMESTAMP datatype when Source_Object_Attribute_is_Historystitch = Y'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1	

					SET @Returnvalue =2 ;
				END

			--V1.18 Covering NULL for error scenario
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Attribute_IS_HistoryStitch_SortKey NOT IN ('Y','N') OR Source_Object_Attribute_IS_HistoryStitch_SortKey IS NULL)
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_IS_HistoryStitch_SortKey can only have values Y/N'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 

					SET @Returnvalue =2 ;
				END 

			--V1.18 Covering NULL for error scenario
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Is_IUD_Column NOT IN ('Y','N') OR Source_Object_Is_IUD_Column IS NULL)
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Is_IUD_Column can only have values Y/N'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 

					SET @Returnvalue =2 ;

				END 
			
			--V1.19 Referencing sourcesystemdatabasename to isolate database datatypes in validations
			--V1.16 Referencing from Ctlfwk.SourceSystemToSparkDataTypeMapping Spark datatypes instead of source_object_attribute_data_type
			--V1.13 Adding timestamp
			IF EXISTS (
						SELECT 1 FROM #temp_source_object_attributes soa 
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE (
								((ss.SparkSQLDatatype LIKE 'date%%' OR ss.SparkSQLDatatype LIKE 'timestamp%%') AND (Input_FormatString IS NULL OR LEN(Input_FormatString) =0)) --checking for date/timestamp spark datatype with null values for input_formatstring to fail 
								OR
								((Source_Object_Attribute_Data_Type NOT LIKE 'date%%' AND Source_Object_Attribute_Data_Type NOT LIKE 'timestamp%%') AND NOT (Input_FormatString IS NULL OR LEN(Input_FormatString) =0)) --checking for non date/timestamp spark datatype with not null values for input_formatstring to fail 
							 )
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'If Source_Object_Attribute_Data_Type is Spark date/timestamp related, Input_FormatString cannot be Blank. Else Input_FormatString should be NULL/Blank'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		  

					SET @Returnvalue =2 ;

				END
		
		    --V1.24 Removing date's requirement to have source_time_zone
			--V1.19 Referencing sourcesystemdatabasename to isolate database datatypes in validations
			--V1.16
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes soa 
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE ((ss.SparkSQLDatatype LIKE 'timestamp%%') 
								AND ss.IsDateWithTimezone = 'N' 
								AND (soa.source_time_zone IS NULL OR LEN(soa.source_time_zone) = 0 ))
					)
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Time_Zone cannot be Null/Blank for given Source_Object_Attribute_Data_Type'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 	 

					SET @Returnvalue =2 ;
				END 

			--V1.19 Referencing sourcesystemdatabasename to isolate database datatypes in validations
			--V1.16
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes soa 
						INNER JOIN Ctlfwk.source_app sa 
						ON soa.Source_App_Code = sa.source_app_code
						INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb 
						ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID
						LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
						ON soa.source_object_Attribute_data_type = ss.datatype AND sdb.SourceSystemDatabaseName = ss.DataSource
						WHERE (ss.IsDateWithTimezone = 'Y' 
								AND NOT(soa.source_time_zone IS NULL OR LEN(soa.source_time_zone) = 0 ))
					)
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_Data_Type contains timezone already so Source_Time_Zone should be NULL/Blank'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 	 

					SET @Returnvalue =2 ;
				END 

			--V1.18 Covering NULL for error scenario
			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes 
						WHERE (Source_Object_Attribute_IS_BusinessKey NOT IN ('Y','N') OR Source_Object_Attribute_IS_BusinessKey IS NULL) --V1.9
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Source_Object_Attribute_IS_BusinessKey can only have values Y/N'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 

					SET @Returnvalue =2 ;

				END 

			--V1.26
			IF EXISTS (SELECT 1 FROM #temp_source_object_attributes
						WHERE (Source_Object_Attribute_IS_PK = 'Y' AND Source_Object_Attribute_IS_BusinessKey = 'Y')
					   )
				BEGIN 
					SET @error_flag = 'Error'
					SET @error_message =   'Source_attribute_is_BusinessKey has to be N when source_object_is_pk = Y'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		 

					SET @Returnvalue =2 ;
				END

			--V1.18 Covering NULL for error scenario
			IF EXISTS ( SELECT 1 FROM #temp_source_object_attributes tso 
			            LEFT JOIN ctlfwk.Encryption_Types ec ON tso.Encryption_Type =ec.Encryption_Type
						WHERE (Source_Object_Attribute_IS_PII = 'Y' AND ec.Encryption_Type IS NULL  )--V1.21 
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'Encryption_Type does not match data in ctlfwk.Encryption_Types table when Source_Object_Attribute_IS_PII = Y' --V1.17

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_source_object_attributes   
					WHERE row_num = 1		  

					SET @Returnvalue =2 ;

				END 

--===========================--    Process    ==================================================== 

	; WITH Process AS(
					SELECT DISTINCT Process_Name
								  , Process_Name_Description
								  , Is_Enabled
								  , Stream_Name
								  , Process_Type
								  , Source_App_Code
								  , Source_Object_Name
								  , Load_Type_Code
								  , COALESCE(target_object_name,'') as  target_object_name--SRN 
								  , PoolName --V1.22
								  , NoOfWorkers --V1.22
					FROM [ctlfwk].[Utility_Config]
					WHERE LTRIM(RTRIM(input_filename)) = @input_filename --V2.6
				)
			SELECT ROW_NUMBER()OVER(ORDER BY Process_Name ASC) AS row_num,*
			INTO #temp_Process
			FROM Process

						--Deleting Duplicate data 
			;WITH dups (  Process_Name ,Process_Name_Description,
				          DuplicateCount)
			AS (SELECT  Process_Name, Process_Name_Description,
					   ROW_NUMBER() OVER(PARTITION   BY Process_Name ,Process_Name_Description  ORDER BY row_num) AS DuplicateCount
				FROM #temp_Process)
			DELETE FROM dups
			WHERE DuplicateCount > 1;

			-- V1.17 Split up all validations to have their own validations START
			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (Process_Name IS NULL OR LEN(Process_Name) = 0)
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Process_Name cannot be NULL/Blank.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (Process_Name_Description IS NULL OR LEN(Process_Name_Description) =0)
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Process_Name_Description cannot be NULL/Blank.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" ' 
																+',' +CONCAT('"Process_Name_Description": "',COALESCE( Process_Name_Description ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END

			--V1.18 Covering NULL for error scenario
			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (Is_Enabled NOT IN ('Y','N') OR Is_Enabled IS NULL)
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Is_Enabled can only have values Y/N.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" '
																+',' +CONCAT('"Is_Enabled": "',COALESCE( Is_Enabled ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (Process_Type IS NULL OR LEN(Process_Type) =0)
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Process_Type cannot be NULL/Blank.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" ' 
																+',' +CONCAT('"Process_Type": "',COALESCE( Process_Type ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END
				-- V1.17 Split up all validations to have their own validations END		
		--V1.22
			IF EXISTS ( SELECT 1 FROM #temp_Process tp
			            LEFT JOIN ctlfwk.PoolConfigurationDetails pc ON tp.PoolName = pc.PoolName
						WHERE pc.PoolName IS NULL  
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'PoolName does not match data in ctlfwk.PoolConfigurationDetails table' --V1.17

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_Process  
					WHERE row_num = 1		  

					SET @Returnvalue =2 ;

				END 
		--V1.27 Starts 
			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (NoOfWorkers  IS NULL OR LEN(NoOfWorkers) =0)
					  )
			BEGIN 
				    SET @error_flag = 'Error'
					SET @error_message =   'NoOfWorkers Cannot be Null or Blank' --V1.17

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_Process  
					WHERE row_num = 1		  

					SET @Returnvalue =2 ;
			  
			END 
	   	IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (PoolName  IS NULL OR LEN(PoolName) =0)
					  )
			BEGIN 
				 SET @error_flag = 'Error'
					SET @error_message =   'PoolName Cannot be Null or Blank' --V1.17

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_Process  
					WHERE row_num = 1		  

					SET @Returnvalue =2 ;
				  
			END --V1.27 Ends 
--==============================Generate Execute Statement==============================================================================

IF @Returnvalue = 0 
	BEGIN --RetrunValue 0 
	      BEGIN TRY 
	   
-- 3. Stream
			DECLARE @count_stream int;

			SELECT @count_stream = COUNT(*)
			FROM #temp_stream

			DECLARE @counter_stream int = 1
			--V3.0
			DECLARE @sql_stream varchar(MAX), @source_app_code varchar(100), @stream_name varchar(255), @stream_description varchar(255), @restart_from_beginning varchar(100)
	
			WHILE @counter_stream <= @count_stream
				BEGIN
					  SELECT @source_app_code = COALESCE(Source_App_Code,''), --V1.4
					         @stream_name = COALESCE(Stream_Name, ''), --V1.4
							 @stream_description = COALESCE(Stream_Description,''), --V1.4
							 @restart_from_beginning = COALESCE(Restart_From_Beginning,'')
					  FROM #temp_stream
					  WHERE row_num = @counter_stream

				      SET @sql_stream = 'EXEC [ctlfwk].[sp_add_stream] @source_app_code = '''+@source_app_code+''', @stream_name = '''+@stream_name+''', @stream_description = '''+@stream_description+''', @restart_from_beginning = '''+@restart_from_beginning+''';'
					  --V2.6 Added Input_Filename in 	Utility_Config_Scripts
					  INSERT INTO [ctlfwk].[Utility_Config_Scripts](utility_row_num,script_seq,utility_exec_script,input_filename )
					  VALUES(1,@counter_stream,@sql_stream,@input_filename );

					  SET @counter_stream = @counter_stream + 1

			 END


-- 4. File_specification_type --V1.3
			DECLARE @count_FileSpecificationType int;

			SELECT @count_FileSpecificationType = COUNT(*)
			FROM #temp_FileSpecifications

			DECLARE @counter_FileSpecificationType int = 1
			DECLARE @sql_FileSpecificationType varchar(MAX), @File_Pattern_Name varchar(100) , @Has_Header CHAR(1) , @File_Extension_Type varchar(50)  , @Field_Delimiter varchar(5) , @TimeStamp_Filename_Pattern varchar(50) , @TimeStamp_Filename_RegexPattern varchar(100), @File_Encoding varchar(100), @Escape_Character char(1), @Contains_Multiline_Data varchar(1)
	
			WHILE @counter_FileSpecificationType <= @count_FileSpecificationType
			BEGIN
				SELECT @File_Pattern_Name = COALESCE(File_Pattern_Name,''), --V1.4
					   @Has_Header = COALESCE(Has_Header,''), --V1.4
					   @File_Extension_Type = COALESCE(File_Extension_Type,''), --V1.4
					   @Field_Delimiter = COALESCE(Field_Delimiter, ''), --V1.4
					   @TimeStamp_Filename_Pattern = COALESCE(TimeStamp_Filename_Pattern,''), --1.4
					   @TimeStamp_Filename_RegexPattern = COALESCE(TimeStamp_Filename_RegexPattern,''), --1.4
					   @File_Encoding = COALESCE(File_Encoding, ''), --V1.11
					   @Escape_Character = COALESCE(Escape_Character, ''), --V1.11
					   @Contains_Multiline_Data = COALESCE(Contains_Multiline_Data, '') --V1.15
				FROM #temp_FileSpecifications
				WHERE row_num = @counter_FileSpecificationType
			
			    SET @sql_FileSpecificationType = 'EXEC [ctlfwk].[sp_add_File_Specification_type] @File_Pattern_Name = '''+@File_Pattern_Name+''', @Has_Header  = '''+@Has_Header+''', @File_Extension_Type  = '''+@File_Extension_Type +''', @Field_Delimiter  = '''+@Field_Delimiter +''', @TimeStamp_Filename_Pattern   = '''+@TimeStamp_Filename_Pattern +''', @TimeStamp_Filename_RegexPattern   = '''+@TimeStamp_Filename_RegexPattern  + ''', @File_Encoding   = '''+@File_Encoding  + ''', @Escape_Character   = '''+@Escape_Character  +''', @Contains_Multiline_Data   = '''+@Contains_Multiline_Data  +''';'
			  -- SELECT @sql_FileSpecificationType
				INSERT INTO [ctlfwk].[Utility_Config_Scripts](utility_row_num,script_seq,utility_exec_script,input_filename )
				VALUES(2,@counter_FileSpecificationType,@sql_FileSpecificationType,@input_filename );

				SET @counter_FileSpecificationType = @counter_FileSpecificationType + 1

			END

	
-- 5. Object
			DECLARE @count_so int;
			
			SELECT @count_so = COUNT(*)
			FROM #temp_source_object

			DECLARE @k int = 1
			DECLARE @sql_so varchar(MAX)
			DECLARE  @source_object_name varchar(100), @source_object_description varchar(100), @load_type_code varchar(100)
					 , @Schema_Name varchar(100), @is_file_mandatory varchar(100)  --V1.25 

			WHILE @k <= @count_so
			BEGIN
				SELECT @source_app_code = COALESCE(Source_App_Code, '') --V1.4
					 , @source_object_name = COALESCE(Source_Object_Name,'') --V1.4
					 , @source_object_description = COALESCE(Source_Object_Description,'') --V1.4
					 , @load_type_code = COALESCE(Load_Type_Code,'') --V1.4
					 , @Schema_Name = COALESCE([Schema_Name],'') --V1.4 --V1.25
					 , @is_file_mandatory = COALESCE(Is_File_Mandatory,'') --V1.4
					 , @File_Pattern_Name = COALESCE(File_Pattern_Name,'') --V1.2 V1.4
				FROM #temp_source_object
				WHERE row_num = @k
				--V1.25 IS_Source_IUD replaced with Schema_Name
 				SET @sql_so = 'EXEC [ctlfwk].[sp_add_source_objects] @source_app_code = '''+@source_app_code+''', @source_object_name = '''+@source_object_name+''', @source_object_description = '''+@source_object_description+''', @load_type_code = '''+@load_type_code+''', @is_file_mandatory = '''+@is_file_mandatory+''', @Schema_Name = '''+@Schema_Name+'' +''' , @File_Pattern_Name=''' +@File_Pattern_Name+''';'
	
				INSERT INTO [ctlfwk].[Utility_Config_Scripts](utility_row_num,script_seq,utility_exec_script,input_filename)
				VALUES(3,@k,@sql_so,@input_filename);

				SET @k = @k + 1

			END

			-- 6. Object Attribute

			DECLARE @count_soa int;

			SELECT @count_soa = COUNT(*)
			FROM #temp_source_object_attributes

			DECLARE @l int = 1
			DECLARE @sql_soa varchar(MAX)
			DECLARE @source_object_attribute_name varchar(100), @source_object_attribute_seq varchar(100), @source_object_attribute_data_type varchar(100), 
				    @source_object_attribute_scale varchar(100), @source_object_attribute_precision varchar(100), @source_object_attribute_is_pk varchar(100), @source_object_attribute_is_null varchar(100),
				    @source_object_attribute_is_pii varchar(100), @source_object_attribute_is_history_stitch varchar(100), @source_object_attribute_is_history_stitch_sort_key varchar(100),
				    @source_object_attribute_is_iud_column varchar(100), @Input_FormatString varchar(100),
				    @dynamic_masking_function varchar(100),@default_value_if_not_nullable varchar(100),
				    @source_time_zone varchar (100), 
					@source_object_attribute_is_BusinessKey varchar (100), --V1.9
					@Encryption_Type varchar (10) --V1.10


			WHILE @l <= @count_soa
			BEGIN
				SELECT @source_app_code = Source_App_Code
					 , @source_object_name = Source_Object_Name
					-- , @load_type_code = load_type_code -- V1.7 
					 , @source_object_attribute_name = Source_Object_Attribute_Name
					 , @source_object_attribute_seq = Source_Object_Attribute_Seq
					 , @source_object_attribute_data_type = Source_Object_Attribute_Data_Type
					 , @source_object_attribute_precision =  COALESCE(Source_Object_Attribute_Precision,'')  --V1.14
					 , @source_object_attribute_scale =  COALESCE(Source_Object_Attribute_Scale,'')  --V1.14
					 , @source_object_attribute_is_pk = Source_Object_Attribute_IS_PK
					 , @source_object_attribute_is_null = Source_Object_Attribute_IS_Null
					 , @source_object_attribute_is_pii = Source_Object_Attribute_IS_PII
					 , @source_object_attribute_is_history_stitch = Source_Object_Attribute_IS_History_Stitch
					 , @source_object_attribute_is_history_stitch_sort_key = Source_Object_Attribute_IS_HistoryStitch_SortKey
					 , @source_object_attribute_is_iud_column = Source_Object_Is_IUD_Column
					 , @Input_FormatString =  COALESCE(Input_FormatString,'')
					 , @dynamic_masking_function = COALESCE(dynamic_masking_function,'')
					 , @default_value_if_not_nullable = COALESCE(default_value_if_not_nullable,'')
					 , @source_time_zone =  COALESCE(source_time_zone,'')  --V1.4
					 , @source_object_attribute_is_BusinessKey = Source_Object_Attribute_IS_BusinessKey --V1.9
					 , @Encryption_Type = COALESCE(Encryption_Type, '') --V1.10
				FROM #temp_source_object_attributes
				WHERE row_num = @l

				--V1.14 Added source_object_attribute_precision
				--V1.7 Removed @load_type_code from the EXEC Statement 
			--	SET @sql_soa = 'EXEC [ctlfwk].[sp_add_source_object_attributes] @source_app_code = '''+@source_app_code+''', @source_object_name = '''+@source_object_name+''', @load_type_code = '''+@load_type_code+''', @source_object_attribute_name = '''+@source_object_attribute_name+''', @source_object_attribute_seq = '+@source_object_attribute_seq+', @source_object_attribute_data_type = '''+@source_object_attribute_data_type+''', @source_object_attribute_length = '''+@source_object_attribute_data_length+''', @source_object_attribute_is_pk = '''+@source_object_attribute_is_pk+''', @source_object_attribute_is_null = '''+@source_object_attribute_is_null+''', @source_object_attribute_is_PII = '''+@source_object_attribute_is_pii+''', @source_object_attribute_is_historystitch = '''+@source_object_attribute_is_history_stitch+''', @source_object_attribute_is_iud_column = '''+@source_object_attribute_is_iud_column+''', @source_object_attribute_is_historystitch_sortkey = '''+@source_object_attribute_is_history_stitch_sort_key+''', @source_object_attribute_is_historystitch_dateformat = '''+@Input_FormatString+''', @dynamic_masking_function ='''+@dynamic_masking_function+''' , @default_value_if_not_nullable = '''+@default_value_if_not_nullable+''', @source_time_zone ='''+@source_time_zone+''' ;'
				SET @sql_soa = 'EXEC [ctlfwk].[sp_add_source_object_attributes] @source_app_code = '''+@source_app_code+''', @source_object_name = '''+@source_object_name+''', @source_object_attribute_name = '''+@source_object_attribute_name+''', @source_object_attribute_seq = '+@source_object_attribute_seq+', @source_object_attribute_data_type = '''+@source_object_attribute_data_type+''', @source_object_attribute_precision = '''+@source_object_attribute_precision+''', @source_object_attribute_scale = '''+@source_object_attribute_scale+''', @source_object_attribute_is_pk = '''+@source_object_attribute_is_pk+''', @source_object_attribute_is_null = '''+@source_object_attribute_is_null+''', @source_object_attribute_is_PII = '''+@source_object_attribute_is_pii+''', @source_object_attribute_is_historystitch = '''+@source_object_attribute_is_history_stitch+''', @source_object_attribute_is_iud_column = '''+@source_object_attribute_is_iud_column+''', @source_object_attribute_is_historystitch_sortkey = '''+@source_object_attribute_is_history_stitch_sort_key+''', @Input_FormatString = '''+@Input_FormatString+''', @dynamic_masking_function ='''+@dynamic_masking_function+''' , @default_value_if_not_nullable = '''+@default_value_if_not_nullable+''', @source_time_zone ='''+@source_time_zone+''', @source_object_attribute_is_BusinessKey = '''+@source_object_attribute_is_BusinessKey+''', @Encryption_Type = '''+@Encryption_Type+''' ;'

				--SELECT @sql_soa
				INSERT INTO [ctlfwk].[Utility_Config_Scripts](utility_row_num,script_seq,utility_exec_script,input_filename)
				VALUES(4,@l,@sql_soa,@input_filename);

				SET @l = @l + 1

			END


-- 7. Process
			DECLARE @count_process int;

			SELECT @count_process = COUNT(*)
			FROM #temp_Process

			DECLARE @counter_process int = 1
			DECLARE @sql_process varchar(MAX), @process_name varchar(100), @proces_name_description varchar(100), @is_enabled varchar(100), @process_type varchar(100)
				   , @target_object_name varchar(200) --SRN 
				   , @PoolName varchar(MAX) --V1.22
				   , @NoOfWorkers int --V1.22
			WHILE @counter_process <= @count_process
			BEGIN
	  
				SELECT @process_name = COALESCE(Process_Name,''), --V1.4
					   @proces_name_description = COALESCE(Process_Name_Description,''), --V1.4
					   @is_enabled = COALESCE(Is_Enabled,''), --V1.4
					   @stream_name = COALESCE(Stream_Name,''), --V1.4
					   @process_type = COALESCE(Process_Type, ''), --V1.4
					   @source_app_code = COALESCE(Source_App_Code,''), --V1.4
					   @source_object_name = COALESCE(Source_Object_Name,''), --V1.4
					   @load_type_code = COALESCE(Load_Type_Code,''), --V1.4
					   @target_object_name = COALESCE(target_object_name,''), --SRN V1.4
					   @PoolName = COALESCE(PoolName,''), --V1.22
					   @NoOfWorkers = ISNULL(@NoOfWorkers,1) --V1.22/V1.23

				FROM #temp_Process
	 			WHERE row_num = @counter_process
		 
				SET @sql_process = 'EXEC [ctlfwk].[sp_add_process] @process_name = '''+@process_name+''', @process_name_description = '''+@proces_name_description+''', @is_enabled = '''+@is_enabled+''', @stream_name = '''+@stream_name+''', @process_type = '''+@process_type+''', @source_app_code = '''+@source_app_code+''', @source_object_name = '''+@source_object_name+''', @load_type_code = '''+@load_type_code+''' ,@target_object_name =''' +@target_object_name  +'''  , @PoolName = '''+@PoolName+''', @NoOfWorkers = '+CAST(@NoOfWorkers as VARCHAR)+';' --V1.22/v1.23
		  
				INSERT INTO [ctlfwk].[Utility_Config_Scripts](utility_row_num,script_seq,utility_exec_script,input_filename)
				VALUES(5,@counter_process,@sql_process,@input_filename);

				SET @counter_process = @counter_process + 1

			END
			SET @error_flag = 'Success'
			SET @error_message = 'Success - Exec Statements  has been created'
			END TRY 
			BEGIN CATCH 
				SET @error_flag = 'Error'
				SET @error_message = ERROR_MESSAGE()

				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 

				SELECT @error_flag AS Error_Flag, @error_message AS Error_Message 

			END CATCH 
END  --RetrunValue 0 
			IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'getUtilityScripts_' + COALESCE(@input_filename,'')
					FROM @ErrorUDT; 
				END 
			SELECT @error_flag AS Error_Flag, @error_message AS Error_Message

		--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 

			DROP TABLE #temp_bu
			DROP TABLE #temp_sa
			DROP TABLE #temp_stream
			DROP TABLE #temp_Process
			DROP TABLE #temp_source_object
			DROP TABLE #temp_source_object_attributes
			DROP TABLE #temp_decimal_source_object_attributes --V2.7

/*
EXEC [ctlfwk].[getUtilityConfigScripts]
@input_filename = 'Geo_Base_Anc_Claims.csv'
*/

 


END
