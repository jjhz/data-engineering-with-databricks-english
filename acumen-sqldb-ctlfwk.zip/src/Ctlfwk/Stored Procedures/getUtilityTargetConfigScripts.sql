﻿
CREATE PROCEDURE [ctlfwk].[getUtilityTargetConfigScripts]
(
 @input_filename VARCHAR (200) = '' 
)
AS

/*=============================================

   Order of script:
-- 1. Stream
-- 2. Object
-- 3. Object Attribute
-- 4. Process



-- Usage Comments if Any : Used to Fetch Target Job Details and is called in ADF. Data is deleted older than 15 days.
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	03-02-2022						Sakshi S 				 1.0				InitialVersion
	17-02-2022						Tammy H					 1.1				Incl. Code_Set_Name and Input_Source_Type columns, validations and where required. 
																				Validation change -load_type_code can only be D/T/R
	21-02-2022						Tammy H					 1.2				changing EXEC add_process to new add_target_process sp
	23-02-2022						Tammy H					 1.3				Code_Set_Name renamed to reference_type_name
	04-03-2022						Tammy H					 1.4				Update validations and rules to meet new req: Unique set of keys for target object -schema_name, notebook_path, notebook_name, target_object
																				Added two new columns: target_attribute_default_value, synapse_override. Blank, set to NULL.
	04-03-2022						Sakshi S				 1.5				Removed Reference_type_name 
	08-03-2022						Tammy H					 1.6				Changing existing validation rules to accomodate for the removal of reference_type_name 
																				Adding new validations to meet new req for reference type objects		
	18-03-2022						Tammy H					 1.7				New req: Stream_name and stream_description raised to be varchar(255)
	24-03-2022						Niharika S				 1.8				Adding replication_type to target_objects
	08-04-2022						Niharika S				 1.9				Setting default value for replication_type = NULL when load_type_code = R		
	13-04-2022						Tammy H					 2.0				SQLSERVER datatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY does not require precision or scale and bugfix
	06-05-2022						Tammy H					 2.1				Matching validation in getTargetJsonSchema: D must contain at least one Primary Key and one Business Key, T must contain at least one Business Key
	09-05-2022						Tammy H					 2.2				New req: Increasing target_object_description varchar(100) to varchar(1000)
    23-05-2022						Tammy H					 2.3				Process_Type validation changed from checking if NULL to checking whether exists in ctlfwk.process_type table
 ================================================================================================= */ 

 BEGIN

SET NOCOUNT ON;
	
	DELETE FROM [ctlfwk].[Utility_Target_Config_Scripts] WHERE LTRIM(RTRIM(input_filename)) = @input_filename

	--Delete data older than 15 days
	 DELETE FROM [ctlfwk].[Utility_Target_Config_Scripts] WHERE CONVERT(DATE, Last_modified_datetime) < CONVERT(DATE, GETDATE() - 15)

	 DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	 DECLARE @Returnvalue INT = 0 --Success 
	 DECLARE @error_flag VARCHAR(100)
	 DECLARE @error_message VARCHAR(200)

	--=================================V1.0SETTING data as Null if Excel has 'NULL'=============================================================================================

	UPDATE ctlfwk.Utility_Target_Config
	  SET Business_Unit_Name_code =NULL WHERE Business_Unit_Name_code = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Source_App_Code =NULL WHERE Source_App_Code = 'NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Target_Config
	  SET Stream_Name =NULL WHERE Stream_Name = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Stream_Description =NULL WHERE Stream_Description = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Restart_From_Beginning =NULL WHERE Restart_From_Beginning = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Process_Name =NULL WHERE Process_Name = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Process_Name_Description =NULL WHERE Process_Name_Description = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Is_Enabled =NULL WHERE Is_Enabled = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Process_Type =NULL WHERE Process_Type = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET PoolName =NULL WHERE PoolName='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET NoOfWorkers =1 WHERE (NoOfWorkers like 'NULL' OR NoOfWorkers IS NULL or  NoOfWorkers like '') AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	 
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_object_name =NULL WHERE target_object_name = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_object_description =NULL WHERE target_object_description = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET [Schema_Name] =NULL WHERE [Schema_Name]='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Load_Type_Code =NULL WHERE Load_Type_Code = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	  UPDATE ctlfwk.Utility_Target_Config
	  SET notebook_name =NULL WHERE notebook_name='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET notebook_path =NULL WHERE notebook_path='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET synapse_distribution_type =NULL WHERE synapse_distribution_type='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_name =NULL WHERE target_attribute_name = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_Seq =NULL WHERE target_attribute_Seq = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_is_active =NULL WHERE target_attribute_is_active = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_data_type =NULL WHERE target_attribute_data_type = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_precision ='' WHERE (target_attribute_precision = 'NULL' OR target_attribute_precision =NULL) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	--V2.0
    UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_scale ='' WHERE (target_attribute_scale='NULL' OR target_attribute_scale =NULL) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	--V2.0
    UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_array_name =NULL WHERE target_attribute_array_name='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
    UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_is_target_column =NULL WHERE target_attribute_is_target_column='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
    UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_is_null =NULL WHERE target_attribute_is_null='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
    UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_is_pk =NULL WHERE target_attribute_is_pk='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_is_BusinessKey =NULL WHERE target_attribute_is_BusinessKey='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET Encryption_Type =NULL WHERE Encryption_Type='NULL' AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_PII_Function =NULL WHERE target_attribute_PII_Function='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_is_historystitch =NULL WHERE target_attribute_is_historystitch='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
    UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_is_historystitch_sortkey =NULL WHERE target_attribute_is_historystitch_sortkey='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_Distributed_On =NULL WHERE target_attribute_Distributed_On='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
    UPDATE ctlfwk.Utility_Target_Config
	  SET target_attribute_Integration_KeyName =NULL WHERE target_attribute_Integration_KeyName='NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	/*UPDATE Ctlfwk.Utility_Target_Config
		SET reference_type_name = NULL WHERE reference_type_name = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	*/ -- V1.5
	UPDATE Ctlfwk.Utility_Target_Config
		SET Input_Source_Type = NULL WHERE Input_Source_Type = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE Ctlfwk.Utility_Target_Config
		SET synapse_override = NULL WHERE synapse_override = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	--V1.5
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_default_value = NULL WHERE target_attribute_default_value = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	--V1.5
	UPDATE Ctlfwk.Utility_Target_Config
		SET replication_type = NULL WHERE replication_type = 'NULL' AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	--V1.8

	--Setting default values
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_active = 'N' WHERE (target_attribute_is_active = NULL OR LEN(target_attribute_is_active) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_target_column = 'N' WHERE (target_attribute_is_target_column = NULL OR LEN(target_attribute_is_target_column) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_null = 'N' WHERE (target_attribute_is_null = NULL OR LEN(target_attribute_is_null) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_pk = 'N' WHERE (target_attribute_is_pk = NULL OR LEN(target_attribute_is_pk) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_BusinessKey = 'N' WHERE (target_attribute_is_BusinessKey = NULL OR LEN(target_attribute_is_BusinessKey) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_historystitch = 'N' WHERE (target_attribute_is_historystitch = NULL OR LEN(target_attribute_is_historystitch) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_historystitch_sortkey = 'N' WHERE (target_attribute_is_historystitch_sortkey= NULL OR LEN(target_attribute_is_historystitch_sortkey) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_precision = '7' WHERE (target_attribute_data_type IN ('DATETIME2', 'DATETIMEOFFSET', 'TIME') AND (target_attribute_precision IS NULL OR LEN(target_attribute_precision) = 0)) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET [Encryption_Type] = NULL WHERE LEN([Encryption_Type]) = 0 AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_PII_Function = NULL WHERE LEN(target_attribute_PII_Function) = 0 AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_array_name = NULL WHERE LEN(target_attribute_array_name) = 0 AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_Integration_KeyName = NULL WHERE LEN(target_attribute_Integration_KeyName) = 0	AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_is_pk = 'N' WHERE target_attribute_array_name IS NOT NULL AND LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_Integration_KeyName = REPLACE(target_attribute_Integration_KeyName, ' ', '')  WHERE target_attribute_Integration_KeyName IS NOT NULL AND  LTRIM(RTRIM(input_filename)) = @input_filename ;
	UPDATE Ctlfwk.Utility_Target_Config
		SET replication_type = NULL  WHERE Load_Type_Code = 'R' AND  LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.9
	/*UPDATE Ctlfwk.Utility_Target_Config
		SET reference_type_name = NULL WHERE LEN(reference_type_name) = 0 AND  LTRIM(RTRIM(input_filename)) = @input_filename ;*/ --V1.5
	UPDATE ctlfwk.Utility_Target_Config
		SET Input_Source_Type = 'ADB' WHERE (Input_Source_Type = NULL OR LEN(Input_Source_Type) = 0) AND  LTRIM(RTRIM(input_filename)) = @input_filename ;	
	UPDATE Ctlfwk.Utility_Target_Config
		SET target_attribute_default_value = NULL WHERE LEN(target_attribute_default_value) = 0	AND  LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.4
	UPDATE Ctlfwk.Utility_Target_Config
		SET synapse_override = NULL WHERE LEN(synapse_override) = 0	AND  LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.4
	UPDATE Ctlfwk.Utility_Target_Config
		SET replication_type = NULL WHERE LEN(replication_type) = 0	AND  LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.8
	UPDATE Ctlfwk.Utility_Target_Config
		SET replication_type = 'UI' WHERE Load_Type_Code = 'R' AND LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.9
	UPDATE Ctlfwk.Utility_Target_Config
		SET replication_type = 'DI' WHERE (Load_Type_Code = 'D' AND replication_type IS NULL) AND LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.9
	UPDATE Ctlfwk.Utility_Target_Config
		SET replication_type = 'T' WHERE (Load_Type_Code = 'T' AND replication_type IS NULL) AND LTRIM(RTRIM(input_filename)) = @input_filename ; --V1.9




--===========================--      Stream      ==================================================== 

   ; WITH stream AS(
					SELECT DISTINCT Business_Unit_Name_Code, Source_App_Code, Stream_Name, Stream_Description,Restart_From_Beginning
					FROM [ctlfwk].[Utility_Target_Config]
					WHERE LTRIM(RTRIM(input_filename)) = @input_filename
					)
	 SELECT ROW_NUMBER()OVER(ORDER BY Stream_Name ASC) AS row_num,*
	 INTO #temp_stream
	 FROM stream
	 		--Deleting Duplicate data 
			;WITH dups ( Business_Unit_Name_Code, source_app_code ,Stream_name,DuplicateCount)
			AS (SELECT Business_Unit_Name_Code, Source_App_Code,Stream_Name,
					   ROW_NUMBER() OVER(PARTITION   BY source_app_code ,Stream_Name  ORDER BY row_num) AS DuplicateCount
				FROM #temp_stream)
			DELETE FROM dups
			WHERE DuplicateCount > 1;


			IF NOT EXISTS (
				SELECT 1 fROM #temp_stream tsa
				JOIN ctlfwk.business_unit cbu ON cbu.business_unit_name_code = tsa.Business_Unit_Name_code
				WHERE row_num = 1
	            )
				BEGIN 
					SET @error_flag = 'Error'
					SET @error_message = 'Business_unit_code does not exist '

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message, (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( business_unit_name_code ,''))  +'" ' 
																					+','+CONCAT('"Target_Object_Name": "',COALESCE( target_object_name ,''))  +'" '
																					+'}' )
					FROM #temp_stream 
					WHERE row_num = 1

					SET @Returnvalue =2 ;
				--SELECT * from @ErrorUDT 
			END  


			IF NOT EXISTS (SELECT 1 FROM #temp_stream tsa
					   JOIN ctlfwk.source_app csa ON csa.source_app_code = tsa.Source_App_Code	
					   INNER JOIN Ctlfwk.business_unit bu ON csa.business_unit_id = bu.business_unit_id AND tsa.business_unit_name_code = bu.business_unit_name_code
					   WHERE row_num = 1 
					  )
				BEGIN 
					 SET @error_flag = 'Error'
					 SET @error_message =   'Source_App_code does not exist'
					 
					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"source_app_code": "',COALESCE( source_app_code ,''))  +'" '
													+'}' )
					 FROM #temp_stream   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				 END
			--ELSE
			--	BEGIN
			--		DECLARE @source_app_id INT

			--		SELECT @source_app_id = source_app_id FROM #temp_stream tsa
			--		JOIN ctlfwk.source_app csa ON csa.source_app_code = tsa.Source_App_Code	
			--		INNER JOIN Ctlfwk.business_unit bu ON csa.business_unit_id = bu.business_unit_id AND tsa.business_unit_name_code = bu.business_unit_name_code
			--		WHERE row_num = 1
			--	END


			IF EXISTS (SELECT 1 FROM #temp_stream WHERE
						Stream_Name IS NULL OR LEN(Stream_Name) = 0
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Stream_Name cannot be Null/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Stream_Name": "',COALESCE( Stream_Name ,''))  +'" ' 
																	+'}' )
					 FROM #temp_stream   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				 END 

			IF EXISTS (SELECT 1 FROM #temp_stream
					   WHERE Stream_Description IS NULL OR LEN(Stream_Description) =0
			          )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Stream_Description cannot be Null/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Stream_Name": "',COALESCE( Stream_Name ,''))  +'" ' 
															+',' +CONCAT('"Stream_Description": "',COALESCE( Stream_Description ,''))  +'" ' 
															+'}' )
					 FROM #temp_stream   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				 END 


--===========================--  Target  Object    ==================================================== 

; WITH Target_object AS(
			               SELECT DISTINCT business_unit_name_code
										 , Source_App_Code
										 , Target_Object_Name
										 , Target_Object_Description
										 ,[Schema_Name]
										 , Load_Type_Code
										 , notebook_name
										 , notebook_path
										 , synapse_distribution_type
										 , synapse_override
										-- , reference_type_name --V1.5
										 , Input_Source_Type
										 , replication_type --V1.8
									FROM [ctlfwk].[Utility_Target_Config]  
									WHERE LTRIM(RTRIM(input_filename)) = @input_filename
	
						)
			SELECT ROW_NUMBER()OVER(ORDER BY Source_App_Code ASC) AS row_num,*
			INTO #temp_Target_object
			FROM Target_object
			--DROP TABLE #temp_Target_object
			--Deleting Duplicate data 
			;WITH dups (  source_app_code ,Target_Object_Name,
				          DuplicateCount)
			AS (SELECT Source_App_Code,Target_object_name,
					   ROW_NUMBER() OVER(PARTITION   BY source_app_code ,target_object_name  ORDER BY row_num) AS DuplicateCount
				FROM #temp_Target_object)
			DELETE FROM dups
			WHERE DuplicateCount > 1;

			--DECLARE @source_app_code varchar(100)

			--V1.2 instead of checking load_Type table, load type can only be D/T/R
			IF EXISTS ( SELECT 1 FROM #temp_Target_object 
							WHERE Load_Type_Code NOT IN ('D', 'T', 'R')
						  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'Load_Type_Code does not exist.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( Target_Object_Name ,''))  +'" ' 
																+',' +CONCAT('"Load_Type_Code": "',COALESCE( Load_Type_Code ,''))  +'" ' 
																+'}' )
					 FROM #temp_Target_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END

			--V1.6 Changing existing validation rules to accomodate for the removal of reference_type_name START
			IF EXISTS ( SELECT 1 FROM #temp_Target_object 
			WHERE (Target_Object_Name IS NULL OR LEN(Target_Object_Name) = 0) --AND ( load_type_code != 'R')
			)
				BEGIN
						SET  @error_flag = 'Error'
						SET @error_message =   'Target_Object_Name cannot be NULL/Blank.'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( Target_Object_Name ,''))  +'" ' 
																	+'}' )
						FROM #temp_Target_object   
						WHERE row_num = 1	 

						SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Target_object 
						WHERE (Target_Object_Description IS NULL OR LEN(Target_Object_Description) =0) --AND ( load_type_code != 'R')
						)
				BEGIN
						SET  @error_flag = 'Error'
						SET @error_message =   'Target_Object_Description cannot be NULL/Blank.'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( Target_Object_Name ,''))  +'" ' 
																+',' +CONCAT('"Target_Object_Description": "',COALESCE( Target_Object_Description ,''))  +'" ' 
																+'}' )
						FROM #temp_Target_object   
						WHERE row_num = 1	 

						SET @Returnvalue =2 ;
				END						
			--V1.6 Changing existing validation rules to accomodate for the removal of reference_type_name END
				



			----V1.5
			----IF EXISTS (SELECT 1 FROM #temp_Target_object WHERE reference_type_name IS NULL AND load_type_code != 'R') --target_object
			--IF EXISTS (SELECT 1 FROM #temp_Target_object
			--			WHERE load_type_code != 'R')	
			--	BEGIN
			--		/*IF EXISTS ( SELECT 1 FROM #temp_Target_object 
			--					WHERE (Target_Object_Name IS NULL OR LEN(Target_Object_Name) = 0) AND ( reference_type_name IS NULL AND load_type_code != 'R')
			--				  )*/  --V1.5
			--		IF EXISTS ( SELECT 1 FROM #temp_Target_object 
			--					WHERE (Target_Object_Name IS NULL OR LEN(Target_Object_Name) = 0) AND ( load_type_code != 'R')
			--				  )
			--			BEGIN
			--				 SET  @error_flag = 'Error'
			--				 SET @error_message =   'Target_Object_Name cannot be NULL/Blank.'

			--				 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			--				 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( Target_Object_Name ,''))  +'" ' 
			--																+'}' )
			--				 FROM #temp_Target_object   
			--				 WHERE row_num = 1	 

			--				 SET @Returnvalue =2 ;
			--			END

			--		/*IF EXISTS ( SELECT 1 FROM #temp_Target_object 
			--					WHERE (Target_Object_Description IS NULL OR LEN(Target_Object_Description) =0) AND ( reference_type_name IS NULL AND load_type_code != 'R')
			--				  )*/  --V1.5
			--		IF EXISTS ( SELECT 1 FROM #temp_Target_object 
			--					WHERE (Target_Object_Description IS NULL OR LEN(Target_Object_Description) =0) AND ( load_type_code != 'R')
			--				  )
			--			BEGIN
			--				 SET  @error_flag = 'Error'
			--				 SET @error_message =   'Target_Object_Description cannot be NULL/Blank.'

			--				 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			--				 SELECT @error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( Target_Object_Name ,''))  +'" ' 
			--															+',' +CONCAT('"Target_Object_Description": "',COALESCE( Target_Object_Description ,''))  +'" ' 
			--															+'}' )
			--				 FROM #temp_Target_object   
			--				 WHERE row_num = 1	 

			--				 SET @Returnvalue =2 ;
			--			END
			--	END
			
			--V1.2 Reference Object changes START
			/*
			IF EXISTS (SELECT 1 FROM #temp_Target_object
						WHERE reference_type_name IS NOT NULL AND load_type_code = 'R')
				BEGIN
					--checks if reference_type_name (reference object) exists in the source_object table
					IF EXISTS (SELECT 1 FROM #Temp_Target_object tto
									LEFT JOIN ctlfwk.source_objects so ON tto.reference_type_name = so.source_object_name
									LEFT JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id
									WHERE so.source_object_name IS NULL AND sa.source_app_id IS NULL AND tto.reference_type_name IS NOT NULL AND tto.Load_Type_Code = 'R'
									)
						BEGIN
							SET  @error_flag = 'Error'
							SET @error_message =   'reference_type_name does not exist'

							INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
							SELECT @error_flag, @error_message, (N'{'+CONCAT('"Source_App_Code": "',COALESCE( source_app_code ,''))  +'" '
																				+','+CONCAT('"reference_type_name": "',COALESCE( reference_type_name ,''))  +'" '
																				+'}' ) 
							FROM #temp_Target_object
							WHERE row_num = 1	 

							SET @Returnvalue =2 ;								
						END
					ELSE --reference object exists
						BEGIN
							UPDATE #temp_Target_object
							SET target_object_name = reference_type_name, [Schema_Name] = 'gld_core'
							WHERE reference_type_name IS NOT NULL AND Load_Type_Code = 'R'

							IF EXISTS (SELECT 1 FROM #temp_Target_object 
							WHERE target_object_description IS NULL OR LEN(target_object_description)=0)
								BEGIN
									UPDATE #temp_Target_object
									SET target_object_description = source_object_description
									FROM (#temp_Target_object tto INNER JOIN Ctlfwk.source_objects so ON tto.reference_type_name = so.source_object_name)
									WHERE (target_object_description IS NULL OR LEN(target_object_description)=0) AND (reference_type_name IS NOT NULL AND load_type_code = 'R')								
								END
						END
				END
			
			-- Error IF load_type_code = 'R' but no reference_type_name is provided
			IF EXISTS (SELECT 1 FROM #temp_Target_object
						WHERE reference_type_name IS NULL AND load_type_code = 'R')
				BEGIN
					SET  @error_flag = 'Error'
					SET @error_message =   'reference_type_name cannot be NULL/Blank if Load_Type_Code = R'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message, (N'{'+CONCAT('"Load_Type_Code": "',COALESCE( load_Type_code ,''))  +'" '
																		+','+CONCAT('"reference_type_name": "',COALESCE( reference_type_name ,''))  +'" '
																		+'}' ) 
					FROM #temp_Target_object
					WHERE row_num = 1	 

					SET @Returnvalue =2 ;
				END

			-- If reference_type_name is provided, then it should be a reference load. Hence set to 'R' as default
			IF EXISTS( SELECT 1 FROM #temp_Target_object
						WHERE reference_type_name IS NOT NULL AND Load_Type_Code != 'R')
				BEGIN
					UPDATE #temp_Target_object
					SET Load_Type_Code = 'R'
					WHERE reference_type_name IS NOT NULL

					UPDATE #temp_Target_object
					SET target_object_name = reference_type_name, [Schema_Name] = 'gld_core'
					WHERE reference_type_name IS NOT NULL AND Load_Type_Code = 'R'

					IF EXISTS (SELECT 1 FROM #temp_Target_object 
					WHERE target_object_description IS NULL OR LEN(target_object_description)=0)
						BEGIN
							UPDATE #temp_Target_object
							SET target_object_description = source_object_description
							FROM (#temp_Target_object tto INNER JOIN Ctlfwk.source_objects so ON tto.reference_type_name = so.source_object_name)
							WHERE (target_object_description IS NULL OR LEN(target_object_description)=0) AND (reference_type_name IS NOT NULL AND load_type_code = 'R')								
						END
				END

			--V1.2 Reference Object changes END

			*/


			IF EXISTS ( SELECT 1 FROM #temp_Target_object 
						WHERE notebook_name IS NULL OR LEN(notebook_name) =0
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'notebook_name cannot be NULL/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{' +',' +CONCAT('"notebook_name ": "',COALESCE(notebook_name, ''))	+'" '
																     + '}')
					 FROM #temp_Target_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Target_object 
						WHERE notebook_path IS NULL OR LEN(notebook_path) =0
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'notebook_path cannot be NULL/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{' +',' +CONCAT('"notebook_path ": "',COALESCE(notebook_path, ''))	+'" '
																     + '}')
					 FROM #temp_Target_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Target_object 
						WHERE synapse_distribution_type IS NULL OR LEN(synapse_distribution_type) =0
					  )
				BEGIN
					 SET  @error_flag = 'Error'
					 SET @error_message =   'synapse_distribution_type cannot be NULL/Blank.'

					 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					 SELECT @error_flag, @error_message, (N'{' +',' +CONCAT('"synapse_distribution_type ": "',COALESCE(synapse_distribution_type, ''))	+'" '
																     + '}')
					 FROM #temp_Target_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END


			--V1.8 start
			IF EXISTS ( SELECT 1 FROM #temp_Target_object
						WHERE load_type_code = 'D' AND replication_type NOT IN ('DI', 'CTAS') 
					   )
				BEGIN 
					SET  @error_flag = 'Error'
					 SET @error_message =   'Replication_Type does not exist with Delta Merge load type.'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message, (N'{' +',' +CONCAT('"replication_type ": "',COALESCE(replication_type, ''))	+'" '
																     + '}')
					 FROM #temp_Target_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END 

			
			IF EXISTS ( SELECT 1 FROM #temp_Target_object
						WHERE load_type_code = 'T' AND replication_type NOT IN ('T') 
					   )
				BEGIN 
					SET  @error_flag = 'Error'
					 SET @error_message =   'Replication_Type does not exist with Truncate load type.'

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message, (N'{' +',' +CONCAT('"replication_type ": "',COALESCE(replication_type, ''))	+'" '
																     + '}')
					 FROM #temp_Target_object   
					 WHERE row_num = 1	 

					 SET @Returnvalue =2 ;
				END 
			--V1.8 end
--===========================--   Target Object Attribute   ==================================================== 

--V1.6 only do validation checks for target objects. Reference objects should not have attributes.
IF EXISTS (SELECT 1 
		   FROM [ctlfwk].[Utility_Target_Config]
		   WHERE LTRIM(RTRIM(input_filename)) = @input_filename AND Load_Type_Code != 'R')
	BEGIN

	; WITH target_object_attributes AS(
										  SELECT DISTINCT --business_unit_name_code
														--, Source_App_Code
														[Schema_Name]
														, notebook_path
														, notebook_name
														, target_object_name
														, target_attribute_name
														, target_attribute_seq
														, target_attribute_is_active
														, target_attribute_data_type 
														, target_attribute_precision 
														, target_attribute_scale
														, target_attribute_array_name
														, target_attribute_is_target_column
														, target_attribute_is_null
														, target_attribute_is_pk
														, target_attribute_is_BusinessKey
														, [Encryption_Type]
														, target_attribute_PII_Function
														, target_attribute_is_historystitch
														, target_attribute_is_historystitch_sortkey
														, target_attribute_Distributed_On
														, target_attribute_Integration_KeyName
														, target_attribute_default_value
														--, reference_type_name
														, input_filename
															
											FROM [ctlfwk].[Utility_Target_Config]
											WHERE LTRIM(RTRIM(input_filename)) = @input_filename AND Load_Type_Code != 'R' --V1.6 adding load_type_code != 'R'
											)
				SELECT ROW_NUMBER()OVER(ORDER BY Target_Object_Name ASC, CAST(target_attribute_seq AS INT) ASC) 
				AS row_num,* 
				INTO #temp_target_object_attributes
				FROM target_object_attributes
				--V1.5
				/*IF EXISTS( SELECT 1 FROM #temp_target_object_attributes
							WHERE reference_type_name IS NOT NULL)
					BEGIN
						UPDATE #temp_target_object_attributes
						SET target_object_name = reference_type_name
						WHERE reference_type_name IS NOT NULL 
					END*/



				-- V1.1 table containing only DECIMAL spark datatypes attributes
				SELECT DISTINCT --business_unit_name_code
							--, Source_App_Code
							 [Schema_Name]
							, notebook_path
							, notebook_name
							, target_object_name
							, target_attribute_name
							, target_attribute_seq
							, target_attribute_is_active
							, target_attribute_data_type 
							, target_attribute_precision 
							, target_attribute_scale
							, target_attribute_array_name
							, target_attribute_is_target_column
							, target_attribute_is_null
							, target_attribute_is_pk
							, target_attribute_is_BusinessKey
							, [Encryption_Type]
							, target_attribute_PII_Function
							, target_attribute_is_historystitch
							, target_attribute_is_historystitch_sortkey
							, target_attribute_Distributed_On
							, target_attribute_Integration_KeyName
							, input_filename
							INTO #temp_decimal_target_object_attributes 
							FROM #temp_target_object_attributes soa
							LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
							ON soa.target_attribute_data_type = ss.datatype AND 'SQLSERVER' = ss.DataSource
							WHERE ss.SparkSQLDatatype IN ('DECIMAL') AND NOT soa.target_attribute_data_type IN ('MONEY', 'SMALLMONEY') --V2.0 money/smallmoney does not require precision/scale

				IF EXISTS (
					SELECT  [Schema_Name], notebook_path, notebook_name, Target_Object_Name, Target_Attribute_Seq , count(*) from #temp_target_object_attributes
					GROUP BY [Schema_Name], notebook_path, notebook_name, Target_Object_Name,Target_Attribute_Seq
					HAVING COUNT(*) > 1
					)
						BEGIN
							SET @error_flag = 'Error'
							SET @error_message =   'Target_Attribute_Seq has incorrect values.'

							INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
							SELECT @error_flag, @error_message,''

							SET @Returnvalue =2 ;

						END

				IF EXISTS (
					SELECT [Schema_Name], notebook_path, notebook_name, Target_Object_Name , Target_attribute_name , count(*) from #temp_target_object_attributes
					GROUP BY  [Schema_Name], notebook_path, notebook_name, Target_Object_Name , Target_attribute_name
					HAVING COUNT(*) > 1
				)
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_name has incorrect values.' 

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''

						SET @Returnvalue =2 ;

					END

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (Target_Attribute_Name IS NULL OR LEN(Target_Attribute_Name) =0))
				   BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_Attribute_Name cannot be NULL/Blank'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''
						FROM #temp_target_object_attributes   
						WHERE row_num = 1	 

						SET @Returnvalue =2 ;

					END 

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (Target_Attribute_Seq IS NULL OR Target_Attribute_Seq <1) 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Incorrect Target_Attribute_Seq, cannot be NULL or <0'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''
						FROM #temp_target_object_attributes   
						WHERE row_num = 1	 

						SET @Returnvalue =2 ;

					 END

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (Target_attribute_Is_Active NOT IN ('Y', 'N')) 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_Is_Active can only have value Y or N'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,'' 

						SET @Returnvalue =2 ;

					 END

				IF EXISTS( SELECT * FROM #temp_target_object_attributes toa
				LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
				ON toa.target_attribute_data_type = ss.datatype AND 'SQLSERVER' = ss.DataSource
				WHERE ss.SourceSystemToSparkDataTypeMappingID IS NULL
				)
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Incorrect Target_Object_Attribute_Data_Type'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''
						FROM #temp_target_object_attributes   
						WHERE row_num = 1	

						SET @Returnvalue =2 ;

					END 

				IF EXISTS( SELECT * FROM #temp_target_object_attributes toa WHERE target_attribute_data_type IN  ('smalldatetime','date','datetime') --These datatypes will not have precision and scale 
						   AND NOT ((target_attribute_precision IS NULL OR LEN(target_attribute_precision) = 0) AND (target_attribute_scale IS NULL OR LEN(target_attribute_scale) = 0))
						 )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'SMALLDATETIME, DATE, DATETIME provided should have NULL Values as Target_Attribute_Precision and Target_Attribute_Scale'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''

						SET @Returnvalue =2 ;

					END

				IF EXISTS( SELECT * FROM #temp_target_object_attributes toa
							INNER JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss
							ON toa.Target_Attribute_data_type = ss.datatype AND ss.DataSource='SQLSERVER'
							WHERE ss.SparkSQLDatatype IN ('STRING', 'DOUBLE', 'DECIMAL', 'FLOAT') 
								AND NOT toa.target_attribute_data_type IN ('TEXT', 'NTEXT', 'TIMESTAMP', 'UNIQUEIDENTIFIER', 'MONEY', 'SMALLMONEY') --V2.0
								AND (target_attribute_precision IS NULL OR LEN(target_attribute_precision) = 0)
						 )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Precision cannot be NULL/Blank for spark equivalent datatypes STRING, DOUBLE, DECIMAL, FLOAT exceptdatatypes TEXT, NTEXT, TIMESTAMP, UNIQUEIDENTIFIER, MONEY, SMALLMONEY'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''	

						SET @Returnvalue =2 ;

					END

		   		IF  EXISTS ( 
			            
							SELECT 1 FROM #temp_decimal_target_object_attributes soa --V2.7
							WHERE CAST(soa.target_attribute_precision AS INT) > 38 
						 )
					BEGIN
							UPDATE soa 
							SET Target_Attribute_Precision = 38 
							FROM #temp_target_object_attributes soa
							INNER JOIN #temp_decimal_target_object_attributes dsoa 
							ON soa.target_attribute_Seq = dsoa.target_attribute_Seq AND soa.target_object_name =dsoa.target_object_name AND soa.[Schema_Name] = dsoa.[Schema_Name] AND soa.notebook_path = dsoa.notebook_path AND soa.notebook_name = dsoa.notebook_name
							WHERE CAST(dsoa.target_attribute_precision AS INT) > 38 ;  

							--V2.0 To also update the DECIMAL only table for downstream validations
							UPDATE dsoa
							SET target_attribute_precision = 38 
							FROM #temp_decimal_target_object_attributes dsoa
							WHERE (CAST(dsoa.target_attribute_precision AS INT) > 38)
					END

				IF EXISTS ( SELECT 1 FROM #temp_decimal_target_object_attributes soa 
							WHERE  CAST(soa.target_Attribute_Precision AS INT)   NOT BETWEEN 1 AND 38 
						 )
					BEGIN 
						SET @error_flag = 'Error'
						SET @error_message =   'Precision has to be between 1 and 38 for spark equivalent DECIMAL datatypes except datatypes MONEY, SMALLMONEY'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''

						SET @Returnvalue =2 ;
					 					
					END
            
				IF EXISTS ( SELECT 1 FROM #temp_decimal_target_object_attributes soa
							WHERE (CAST(soa.target_Attribute_scale AS INT) > CAST(soa.target_Attribute_Precision AS INT)
																										OR 
																		   CAST(soa.target_Attribute_scale AS INT) <0))
						
				BEGIN

						SET @error_flag = 'Error'
						SET @error_message =   'Scale has to be between [0, Precision] for spark equivalent DECIMAL datatypes except datatypes MONEY, SMALLMONEY'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''

						SET @Returnvalue =2 ;

				END 

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (target_attribute_is_target_column NOT IN ('Y', 'N')) 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_is_target_column can only have value Y or N'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,'' 

						SET @Returnvalue =2 ;

					 END

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (target_attribute_is_null NOT IN ('Y', 'N')) 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_is_null can only have value Y or N'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''	 

						SET @Returnvalue =2 ;

					 END

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (target_attribute_is_pk NOT IN ('Y', 'N')) 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_is_pk can only have value Y or N'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''	 

						SET @Returnvalue =2 ;

					 END

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (target_attribute_is_BusinessKey NOT IN ('Y', 'N')) 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_is_BusinessKey can only have value Y or N'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''	 

						SET @Returnvalue =2 ;

					 END

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE (target_attribute_is_pk = 'Y' AND target_attribute_is_BusinessKey = 'Y') 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_Is_BusinessKey has to be N when target_attribute_is_pk = Y'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,'' 

						SET @Returnvalue = 2 ;

					 END

			-- V2.1 D must contain at least one Primary Key 
			IF EXISTS (SELECT 1 FROM #temp_Target_object WHERE Load_Type_Code = 'D') 
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM #temp_target_object_attributes WHERE target_attribute_is_pk = 'Y')
						BEGIN 
							SET @error_flag = 'Error'
							SET @error_message =   'For Delta Load Type: At least one attribute for the object must be a Primary Key column'

							INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
							SELECT @error_flag, @error_message,'' 

							SET @Returnvalue =2 ;
						END			
				END

			--V2.1 D and T must contain at least one Business Key
			IF EXISTS (SELECT 1 FROM #temp_Target_object WHERE Load_Type_Code IN ('D','T')) 
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM #temp_target_object_attributes WHERE target_attribute_is_BusinessKey = 'Y')
						BEGIN 
							SET @error_flag = 'Error'
							SET @error_message =   'For Delta or Truncate Load Type: At least one attribute for the object must be a Business Key column'

							INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
							SELECT @error_flag, @error_message,''

							SET @Returnvalue =2 ;
						END	
				END

				IF EXISTS (SELECT 1 FROM #temp_target_object_attributes WHERE [Encryption_Type] IS NOT NULL)
					BEGIN
						IF NOT EXISTS ( SELECT 1 FROM #temp_target_object_attributes toa 
										INNER JOIN Ctlfwk.Encryption_Types et on toa.[Encryption_Type] = et.[Encryption_Type]
										WHERE toa.[Encryption_Type] IS NOT NULL
									  )
							BEGIN
								 SET  @error_flag = 'Error'
								 SET @error_message =   'Encryption_Type does not exist'

								 INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
								 SELECT @error_flag, @error_message, ''

								 SET @Returnvalue =2 ;
							END
					END



				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE target_attribute_is_historystitch NOT IN ('Y', 'N') 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_Is_Historystitch can only have value Y or N'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,''

					 END

				IF EXISTS ( SELECT 1 FROM #temp_target_object_attributes 
							WHERE target_attribute_is_historystitch_sortkey NOT IN ('Y', 'N') 
						  )
					BEGIN
						SET @error_flag = 'Error'
						SET @error_message =   'Target_attribute_is_historystitch_sortkey can only have value Y or N'

						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						SELECT @error_flag, @error_message,'' 

						SET @Returnvalue =2 ;

					 END
	END
--===========================--    Process    ==================================================== 

	; WITH Process AS(
					SELECT DISTINCT Process_Name
								  , Process_Name_Description
								  , Is_Enabled
								  , Stream_Name
								  , Process_Type
								  , business_unit_name_code
								  , Source_App_Code
								  , [Schema_Name]
								  , notebook_path
								  , notebook_name
								  , Target_Object_Name
								--  , Load_Type_Code
								----  , COALESCE(target_object_name,'') as  target_object_name
								  , PoolName 
								  , NoOfWorkers 
								  --, reference_type_name  --V1.5
					FROM [ctlfwk].[Utility_Target_Config]
					WHERE LTRIM(RTRIM(input_filename)) = @input_filename
				)
			SELECT ROW_NUMBER()OVER(ORDER BY Process_Name ASC) AS row_num,*
			INTO #temp_Process
			FROM Process

						--Deleting Duplicate data 
			;WITH dups (  Process_Name ,Process_Name_Description,
				          DuplicateCount)
			AS (SELECT  Process_Name, Process_Name_Description,
					   ROW_NUMBER() OVER(PARTITION   BY Process_Name ,Process_Name_Description  ORDER BY row_num) AS DuplicateCount
				FROM #temp_Process)
			DELETE FROM dups
			WHERE DuplicateCount > 1;

			--IF EXISTS( SELECT 1 FROM #temp_Process
			--			WHERE reference_type_name IS NOT NULL)
			--	BEGIN
			--		UPDATE #temp_Process
			--		SET target_object_name = reference_type_name, Load_Type_Code = 'R'
			--		WHERE reference_type_name IS NOT NULL 
			--	END

			-- Split up all validations to have their own validations START
			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (Process_Name IS NULL OR LEN(Process_Name) = 0)
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Process_Name cannot be NULL/Blank.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (Process_Name_Description IS NULL OR LEN(Process_Name_Description) =0)
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Process_Name_Description cannot be NULL/Blank.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" ' 
																+',' +CONCAT('"Process_Name_Description": "',COALESCE( Process_Name_Description ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Process 
						WHERE (Is_Enabled NOT IN ('Y','N') OR Is_Enabled IS NULL)
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Is_Enabled can only have values Y/N.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" '
																+',' +CONCAT('"Is_Enabled": "',COALESCE( Is_Enabled ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END

			IF EXISTS ( SELECT 1 FROM #temp_Process p
			            LEFT JOIN ctlfwk.process_type pt ON pt.process_type = p.Process_Type
						WHERE pt.process_type IS NULL  --V2.3 Error out when process_Type doesn't exist in ctlfwk.process_type table instead of when it is NULL
					  )
				 BEGIN
					   SET  @error_flag = 'Error'
					   SET @error_message =   'Process_Type provided does not exist in ctlfwk.process_type table.'

					   INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					   SELECT @error_flag, @error_message, (N'{'+CONCAT('"Process_Name": "',COALESCE( Process_Name ,''))  +'" ' 
																+',' +CONCAT('"Process_Type": "',COALESCE( Process_Type ,''))  +'" ' 
																+'}' )
					   FROM #temp_Process   
					   WHERE row_num = 1	 

					   SET @Returnvalue =2 ;
				END
				--  Split up all validations to have their own validations END		
		
			IF EXISTS ( SELECT 1 FROM #temp_Process tp
			            LEFT JOIN ctlfwk.PoolConfigurationDetails pc ON tp.PoolName = pc.PoolName
						WHERE pc.PoolName IS NULL  
					  )
				BEGIN
					SET @error_flag = 'Error'
					SET @error_message =   'PoolName does not match data in ctlfwk.PoolConfigurationDetails table' 

					INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
					SELECT @error_flag, @error_message,''
					FROM #temp_Process  
					WHERE row_num = 1		  

					SET @Returnvalue =2 ;

				END 

--==============================Generate Execute Statement==============================================================================

IF @Returnvalue = 0 
	BEGIN --RetrunValue 0 
	      BEGIN TRY 
		   
-- 1. Stream
			DECLARE @count_stream int;

			SELECT @count_stream = COUNT(*)
			FROM #temp_stream

			DECLARE @counter_stream int = 1
			--V1.7
			DECLARE @sql_stream varchar(MAX), @source_app_code varchar(100), @stream_name varchar(255), @stream_description varchar(255), @restart_from_beginning varchar(100)
	
			WHILE @counter_stream <= @count_stream
				BEGIN
					  SELECT @source_app_code = COALESCE(Source_App_Code,''),
					         @stream_name = COALESCE(Stream_Name, ''),
							 @stream_description = COALESCE(Stream_Description,''),
							 @restart_from_beginning = COALESCE(Restart_From_Beginning,'')
					  FROM #temp_stream
					  WHERE row_num = @counter_stream

				      SET @sql_stream = 'EXEC [ctlfwk].[sp_add_stream] @source_app_code = '''+@source_app_code+''', @stream_name = '''+@stream_name+''', @stream_description = '''+@stream_description+''', @restart_from_beginning = '''+@restart_from_beginning+''';'

					  INSERT INTO [ctlfwk].[Utility_Target_Config_Scripts](utility_target_row_num,script_seq,utility_target_exec_script, input_filename)
					  VALUES(1,@counter_stream,@sql_stream, @input_filename);

					  SET @counter_stream = @counter_stream + 1

			 END

			 


-- 2. Object
			DECLARE @count_to int;
			
			SELECT @count_to = COUNT(*)
			FROM #temp_Target_object

			DECLARE @k int = 1
			DECLARE @sql_to varchar(MAX)
			DECLARE @load_type_code varchar(5), @replication_type varchar(20), @business_unit_name_code varchar(100), @target_object_name varchar(100), @Target_Object_Description varchar(1000),  @Schema_Name varchar(50), @notebook_name varchar(255) , @notebook_path varchar(255) , @synapse_distribution_type varchar(max), @synapse_override varchar(max), @Input_Source_Type varchar(30) --V2.2

			WHILE @k <= @count_to
			BEGIN
				SELECT @business_unit_name_code = COALESCE (Business_Unit_Name_code, '')
					 , @source_app_code = COALESCE(Source_App_Code, '') 
					 , @Target_Object_Name = COALESCE(Target_Object_Name,'') 
					 , @Target_Object_Description = COALESCE(Target_Object_Description,'') 
					 , @load_type_code = COALESCE(Load_Type_Code,'') 
					 , @Schema_Name = COALESCE([Schema_Name],'') 
					 , @notebook_name = COALESCE(notebook_name,'') 
					 , @notebook_path = COALESCE(notebook_path,'') 
					 , @synapse_distribution_type = COALESCE(synapse_distribution_type,'')
					 , @synapse_override = COALESCE(synapse_override, '')
					 , @Input_Source_Type = COALESCE(Input_Source_Type, '')
					 , @replication_type = COALESCE(replication_type, '') --V1.8
				FROM #temp_Target_object
				WHERE row_num = @k
				
 				SET @sql_to = 'EXEC [ctlfwk].[sp_add_target_objects] @business_unit_name_code = '''+@business_unit_name_code+''', @source_app_code = '''+@source_app_code+''', @Target_Object_Name = '''+@Target_Object_Name+''', @Target_Object_Description = '''+@Target_Object_Description+''',@Schema_Name = '''+@Schema_Name+'' +''' , @load_type_code = '''+@load_type_code+''', @notebook_name = '''+@notebook_name+''', @notebook_path = '''+@notebook_path+''' , @synapse_distribution_type=''' +@synapse_distribution_type+''' , @synapse_override=''' +@synapse_override+''' , @Input_Source_Type=''' +@Input_Source_Type+''', @replication_type=''' +@replication_type+''';'
	
				INSERT INTO [ctlfwk].[Utility_Target_Config_Scripts](utility_target_row_num,script_seq,utility_target_exec_script, input_filename)
				VALUES(3,@k,@sql_to, @input_filename);

				SET @k = @k + 1

			END

-- 3. Object Attribute
			--V1.6 only produce attribute EXEC for target objects. Reference objects should not have attributes.
			IF EXISTS (SELECT 1 
					   FROM [ctlfwk].[Utility_Target_Config]
					   WHERE LTRIM(RTRIM(input_filename)) = @input_filename AND Load_Type_Code != 'R')
				BEGIN
					DECLARE @count_toa int;

					SELECT @count_toa = COUNT(*)
					FROM #temp_target_object_attributes

					DECLARE @l int = 1
					DECLARE @sql_toa varchar(MAX)
					DECLARE @target_attribute_name varchar(100), @target_attribute_seq varchar(100), @target_attribute_is_active varchar(1), @target_attribute_data_type varchar(100), 
							@target_attribute_scale varchar(100), @target_attribute_precision varchar(100),@target_attribute_array_name varchar(100), @target_attribute_is_target_column varchar(1),
							@target_attribute_is_pk varchar(100), @target_attribute_is_null varchar(100), @target_attribute_is_BusinessKey varchar(1), @Encryption_Type varchar(10),
							@target_attribute_PII_Function varchar(150), @target_attribute_is_historystitch varchar(1), @target_attribute_is_historystitch_sortkey varchar(1),
							@target_attribute_Distributed_On varchar(150), @target_attribute_Integration_KeyName varchar(500), @target_attribute_default_value varchar(200)
					WHILE @l <= @count_toa
					BEGIN
						SELECT @target_object_name = Target_Object_Name
							 , @Schema_Name = COALESCE([Schema_Name],'')  --V1.4
							 , @notebook_path = COALESCE(notebook_path,'')  --V1.4
							 , @notebook_name = COALESCE(notebook_name,'') --V1.4
							 , @target_attribute_name = target_attribute_name
							 , @target_attribute_seq = target_attribute_seq
							 , @target_attribute_is_active = target_attribute_is_active
							 , @target_attribute_data_type  = target_attribute_data_type 
							 , @target_attribute_scale =  COALESCE(target_attribute_scale,'')  
							 , @target_attribute_precision =  COALESCE(target_attribute_precision,'')  
							 , @target_attribute_array_name = COALESCE(target_attribute_array_name,'')
							 , @target_attribute_is_target_column = COALESCE(target_attribute_is_target_column,'')
							 , @target_attribute_is_pk = target_attribute_is_pk
							 , @target_attribute_is_null = target_attribute_is_null
							 , @target_attribute_is_BusinessKey = target_attribute_is_BusinessKey
							 , @Encryption_Type = COALESCE(Encryption_Type, '') 
							 , @target_attribute_PII_Function = COALESCE(target_attribute_PII_Function, '')
							 , @target_attribute_is_historystitch = target_attribute_is_historystitch
							 , @target_attribute_is_historystitch_sortkey = target_attribute_is_historystitch_sortkey
							 , @target_attribute_Distributed_On = COALESCE(target_attribute_Distributed_On,'')
							 , @target_attribute_Integration_KeyName =  COALESCE(target_attribute_Integration_KeyName,'')
							 , @target_attribute_default_value = COALESCE(target_attribute_default_value, '') --V1.4
					 
						FROM #temp_target_object_attributes
						WHERE row_num = @l

						--V1.4
						SET @sql_toa = 'EXEC [ctlfwk].[sp_add_target_object_attributes]  @Target_object_name = '''+@Target_object_name +''', @Schema_Name = '''+@Schema_Name+''', @notebook_path = '''+@notebook_path+''', @notebook_name = '''+@notebook_name  +''', @target_attribute_name = '''+@target_attribute_name +''', @target_attribute_seq = '+@target_attribute_seq+', @target_attribute_is_active = '''+@target_attribute_is_active+''', @target_attribute_data_type = '''+@target_attribute_data_type+''', @target_attribute_precision = '''+@target_attribute_precision+''', @target_attribute_scale = '''+@target_attribute_scale+''', @target_attribute_array_name = '''+@target_attribute_array_name+''', @target_attribute_is_target_column = '''+@target_attribute_is_target_column+''', @target_attribute_is_null = '''+@target_attribute_is_null+''', @target_attribute_is_pk = '''+@target_attribute_is_pk+''', @target_attribute_is_BusinessKey = '''+@target_attribute_is_BusinessKey+''', @Encryption_Type = '''+@Encryption_Type+''', @target_attribute_PII_Function = '''+@target_attribute_PII_Function+''', @target_attribute_is_historystitch = '''+@target_attribute_is_historystitch+''', @target_attribute_is_historystitch_sortkey = '''+@target_attribute_is_historystitch_sortkey+''', @target_attribute_Distributed_On = '''+@target_attribute_Distributed_On+''', @target_attribute_Integration_KeyName ='''+@target_attribute_Integration_KeyName+''', @target_attribute_default_value ='''+@target_attribute_default_value+''';'

						INSERT INTO [ctlfwk].[Utility_Target_Config_Scripts](utility_target_row_num,script_seq,utility_target_exec_script, input_filename)
						VALUES(4,@l,@sql_toa, @input_filename);

						SET @l = @l + 1

					END
				END


-- 4. Process
			DECLARE @count_process int;

			SELECT @count_process = COUNT(*)
			FROM #temp_Process

			DECLARE @counter_process int = 1
			DECLARE @sql_process varchar(MAX), @process_name varchar(100), @proces_name_description varchar(100), @is_enabled varchar(100), @process_type varchar(100) 
				   , @PoolName varchar(MAX) 
				   , @NoOfWorkers int 
			WHILE @counter_process <= @count_process
			BEGIN

				SELECT @process_name = COALESCE(Process_Name,''), 
					   @proces_name_description = COALESCE(Process_Name_Description,''), 
					   @is_enabled = COALESCE(Is_Enabled,''), 
					   @stream_name = COALESCE(Stream_Name,''), 
					   @process_type = COALESCE(Process_Type, ''), 
					   @business_unit_name_code = COALESCE(business_unit_name_code, ''),
					   @source_app_code = COALESCE(Source_App_Code,''), 
					   @Target_Object_Name = COALESCE(Target_Object_Name,''), 
					   @Schema_Name = COALESCE([Schema_Name],''),  --V1.4
					   @notebook_path = COALESCE(notebook_path,''),  --V1.4
					   @notebook_name = COALESCE(notebook_name,''),  --V1.4
					   @PoolName = COALESCE(PoolName,''), 
					   @NoOfWorkers = ISNULL(@NoOfWorkers,1) 

				FROM #temp_Process
	 			WHERE row_num = @counter_process
				
				--V1.4
				--V1.2
				SET @sql_process = 'EXEC [ctlfwk].[sp_add_target_process] @process_name = '''+@process_name+''', @process_name_description = '''+@proces_name_description+''', @is_enabled = '''+@is_enabled+''', @stream_name = '''+@stream_name+''', @process_type = '''+@process_type+''', @business_unit_name_code = '''+@business_unit_name_code+''', @source_app_code = '''+@source_app_code+''', @target_object_name =''' +@target_object_name  +''', @Schema_Name = '''+@Schema_Name+''', @notebook_path = '''+@notebook_path+''', @notebook_name = '''+@notebook_name  +'''  , @PoolName = '''+@PoolName+''', @NoOfWorkers = '+CAST(@NoOfWorkers as VARCHAR)+';' 
		  
				INSERT INTO [ctlfwk].[Utility_Target_Config_Scripts](utility_target_row_num,script_seq,utility_target_exec_script, input_filename)
				VALUES(5,@counter_process,@sql_process, @input_filename);

				SET @counter_process = @counter_process + 1

			END
			SET @error_flag = 'Success'
			SET @error_message = 'Success - Exec Statements  has been created'
			END TRY 
			BEGIN CATCH 
				SET @error_flag = 'Error'
				SET @error_message = ERROR_MESSAGE()

				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 

				SELECT @error_flag AS Error_Flag, @error_message AS Error_Message 

			END CATCH 
END  --RetrunValue 0 
			IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'getUtilityScripts_' + COALESCE(@input_filename,'')
					FROM @ErrorUDT; 
				END 
			SELECT @error_flag AS Error_Flag, @error_message AS Error_Message

		--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 

			--DROP TABLE #temp_bu
			--DROP TABLE #temp_sa
			DROP TABLE #temp_stream
			DROP TABLE #temp_Process
			DROP TABLE #temp_Target_object
			DROP TABLE #temp_target_object_attributes
			DROP TABLE #temp_decimal_target_object_attributes


/*EXEC [ctlfwk].[getUtilityTargetConfigScripts]
@input_filename = '' */


 


END
