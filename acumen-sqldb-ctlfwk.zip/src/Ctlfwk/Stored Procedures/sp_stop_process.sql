﻿
CREATE PROCEDURE [ctlfwk].[sp_stop_process]
( 
  @process_status_id VARCHAR(100),
  @process_execution_status varchar(10) 
)
AS

/*===============================================================================================================================================================================
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte 				 1.0				InitialVersion
	15-09-2021						Tammy H					 1.1				Changes to Capture Error (those that RAISERROR() / error_flag = 'Failed' / error_flag = 'Cancelled')
																				into ctrlfwk.process_errors and key Input Parameters of Error as JSON
	01-12-2021						vikas p					 1.2				Added restart from monitor logic
	10-03-2022						Vikas P					 1.3                not to fail stream after bronze load , it will be in running state to pick silver
	18-03-2022						Tammy H					 1.4			    New req: Stream_name raised to be varchar(255)
	23-03-2022						Tammy H					 1.5				Added milliseconds to timestamps: fff
 ================================================================================================================================================================================ */  

SET NOCOUNT ON

BEGIN
BEGIN TRY
	DECLARE 
		@exectution_status_id	INT,
		@ret_status VARCHAR(100),
		@Additional_Data        NVARCHAR(4000),    --V1.1
		@StreamName				VARCHAR(255), --V1.4
		@Stream_execution_status				VARCHAR(250),
		@Is_restart_from_monitor VARCHAR(10),
		@process_type VARCHAR(250),
		@stream_id int, --v1.2
		@Is_restart_from_monitor_count int  --v1.2



	/* FETCH Execution_Status_ID based on the input parameter value @process_execution_status */
	SELECT @exectution_status_id = execution_status_id FROM ctlfwk.Execution_Status WHERE execution_status_name = @process_execution_status


	/* FETCH stream_name ,execution_status_namebased ,Is_restart_from_monitor and stream_id on the input parameter value @process_status_id */
	SELECT @StreamName=s.stream_name,@Stream_execution_status=es.execution_status_name,@Is_restart_from_monitor=ps.Is_restart_from_monitor,@Process_Type=pt.Process_Type,@stream_id=s.stream_id
				 FROM ctlfwk.process p 
					Join Ctlfwk.process_type as pt on pt.process_type_id=p.process_type_id
					join  Ctlfwk.process_status as ps on ps.process_id=p.process_id
					join ctlfwk.stream as s on s.stream_id=p.stream_id 
					JOIN Ctlfwk.stream_status as ss on s.stream_id=ss.stream_id 
					JOIN Ctlfwk.execution_status as es on es.execution_status_id=ss.execution_status_id
					WHERE ps.process_status_id=@process_status_id   --v1.2

	/* FETCH Is_restart_from_monitor_count value @stream_id */
	SELECT  @Is_restart_from_monitor_count=COUNT(*) FROM [Ctlfwk].[process] p
            INNER JOIN [Ctlfwk].[stream] s
            ON p.stream_id = s.stream_id
            INNER JOIN [Ctlfwk].[process_status] ps
            ON ps.process_id = p.process_id
            WHERE s.stream_id = @stream_id AND ps.Is_restart_from_monitor =1   --v1.2


	IF (@process_status_id is null)
		BEGIN
			SET @ret_status ='ERROR - Process_instance_id is null.'
			SET @Additional_Data = N'{"Process_Status_Id": ""' + ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}' --V1.5



			RAISERROR('ERROR - Job Cannot Start. Previous Process Is Either Still Running.' ,16,-1)
		END

	IF ((@Is_restart_from_monitor_count=0 ) and @process_execution_status = 'Success' )
	   BEGIN
			UPDATE [ctlfwk].[process_status]
				SET 
					execution_status_id = @exectution_status_id, end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') --V1.5
				WHERE  
					execution_status_id IN (SELECT execution_status_id FROM ctlfwk.execution_status WHERE execution_status_name = 'Running')
				AND
					process_status_Id = @process_status_id

			SET @ret_status ='Process successfully completed.'
	   END 
---------------------------------------------v 1.2 vikas code, restart from monitor---------------------------------------------------------
/*this can happen when @Is_restart_from_monitor_count is grater than or equal to 1 and process execution status is failed/success*/

	IF ( @Is_restart_from_monitor_count>=1 and @process_execution_status in('Success','Failed')  )
	   BEGIN
			UPDATE [ctlfwk].[process_status]
				SET 
					execution_status_id = @exectution_status_id, end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')  --V1.5
				WHERE  
					execution_status_id IN (SELECT execution_status_id FROM ctlfwk.execution_status WHERE execution_status_name = 'Running')
				AND
					process_status_Id = @process_status_id

			SET @ret_status ='Process executed from monitor.'
			
		   (SELECT @ret_status AS ErrorMessage, format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') AS Process_Stop_TimeStamp)  --V1.5

			EXEC [Ctlfwk].[sp_stop_stream]
	      	@stream_name = @StreamName
		
			/*this update statment is reqired to pick the failed silver process for run if bronze is successfule*/		
			IF @Process_Type='Bronze'
				BEGIN
				Update Ctlfwk.stream_status set execution_status_id =1 where stream_id=@stream_id--v1.3
				END
	   END 
---------------------------------------------vikas code, restart from monitor---------------------------------------------------------

	ELSE IF ((@Is_restart_from_monitor_count=0 ) AND  @process_execution_status = 'Failed')
	   BEGIN
			UPDATE [ctlfwk].[process_status]
				SET 
					execution_status_id = @exectution_status_id, end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')  --V1.5
				WHERE 
					process_status_id = @process_status_id
			

			SET @ret_status ='Process Report Failure.'

			INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			VALUES( 'Failed', @ret_status, 
					(N'{'+CONCAT('"Process_Status_ID": "',COALESCE( @process_status_id ,''))  +'" ' 
					+','+CONCAT('"Process_Execution_Status": "',COALESCE( @process_execution_status ,''))  +'" '
					+ ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}')  --V1.5
					, 'sp_stop_process'
				  );
	   END 
	ELSE IF ((@Is_restart_from_monitor_count=0 ) AND @process_execution_status = 'Cancelled')
	   BEGIN
			UPDATE [ctlfwk].[process_status]
				SET
					execution_status_id = @exectution_status_id, end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')  --V1.5
				WHERE 
					process_status_id = @process_status_id
			SET @ret_status ='Process Is Cancelled.'

			INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			VALUES( 'Cancelled', @ret_status, 
					(N'{'+CONCAT('"Process_Status_ID": "',COALESCE( @process_status_id ,''))  +'" ' 
					+','+CONCAT('"Process_Execution_Status": "',COALESCE( @process_execution_status ,''))  +'" '
					+ ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}')  --V1.5
					, 'sp_stop_process'
				  );
	   END 

	(SELECT @ret_status AS ErrorMessage, format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') AS Process_Stop_TimeStamp)  --V1.5

	/* Uncomment the below line for DCC integration */
	--Exec [ctlfwk].[sp_send_api_payload] @process_status_id

END TRY


BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()

	--V1.1
	INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  )  
	SELECT 'Error' ,@ret_status ,@Additional_Data ,'sp_stop_process' ;

	RAISERROR	('Exception Details :
					Error Number		:	%d
					Error Message		:	%d
					Affected Procedure	:	%d
					Affected Line Number:	%d',
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;
END

