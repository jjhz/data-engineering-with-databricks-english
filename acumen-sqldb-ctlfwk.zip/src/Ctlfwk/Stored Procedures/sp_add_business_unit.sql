﻿CREATE PROCEDURE [Ctlfwk].[sp_add_business_unit]
(
	--V1.1 Modified the order of Input 
 	@business_unit_name_code varchar(7)
,	@business_unit_name varchar(100)  -- Descritpion of the BusinessUnit 
,	@storage_account varchar(100) 
,	@storage_secret_name varchar(100)=NULL
)
AS

-- =============================================
-- Description:	Insert business unit record if it does not exist
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	08-07-2021						Deloitte				 1.0				InitialVersion
--	11-10-2021						Sheela R 				 1.1				Fixed Bug 
--  01-02-2022						Sheela R 				 1.2                Added Raise Error 

-- =============================================


BEGIN

	SET NOCOUNT ON;
    DECLARE @trancount int;
	DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] --V1.1 
   -- set @trancount = @@trancount;  --V1.1
    BEGIN TRY
	
        --if @trancount = 0
        --    begin transaction
        --else
        --    save transaction sp_add_business_unit;  --V1.1

	
		-- check if record exists, if not, insert the row
		--V1.1 modified business_unit_name as business_unit_name_code
		BEGIN TRANSACTION
		IF (NOT EXISTS (SELECT 1 FROM [ctlfwk].[business_unit] WHERE [business_unit_name_code]  = @business_unit_name_code)) --V1. 
			BEGIN --If 
				INSERT INTO [ctlfwk].[business_unit]
				(
					[business_unit_name]
				,	[business_unit_name_code]
				,	[start_date_time]
				,	[end_date_time]
				,	[storage_account]
				,	[storage_secret_name]
				)
				VALUES
				(
					@business_unit_name
				,	@business_unit_name_code
				,	GETDATE()
				,	'9999-12-31'
				,	@storage_account
				,	@storage_secret_name
				)
				PRINT 'Inserted  ' + @business_unit_name_code + ', ' + @business_unit_name;
			END --If
		ELSE --V1.1 
			UPDATE 	[ctlfwk].[business_unit]
			SET [business_unit_name] =@business_unit_name
			,   [storage_account] =@storage_account
			,	[storage_secret_name] =@storage_secret_name
			,   last_modified_datetime =SYSDATETIME() 
			,   last_modified_by =ORIGINAL_LOGIN()
		    WHERE  business_unit_name_code=@business_unit_name_code

			PRINT 'Entry Updated ' + @business_unit_name_code + ', ' + @business_unit_name;

	--if @trancount = 0
			COMMIT TRANSACTION ;
	END TRY

/*
BEGIN CATCH
        DECLARE @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        --if @xstate = -1
        --    rollback;
        --if @xstate = 1 and @trancount = 0
        --    rollback
        --if @xstate = 1 and @trancount > 0
        --    rollback transaction sp_add_business_unit;  

        raiserror ('Ctlfwk.sp_add_business_unit: %d: %s', 16, 1, @error, @message) ;
    END CATCH
*/
		BEGIN CATCH 
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR,(ERROR_LINE())) + '"}')); 
				ROLLBACK TRANSACTION 
		END CATCH 
	   

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) --V1.2
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_business_unit' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
			  raiserror ('Ctlfwk.sp_add_business_unit: ERROR - Refer to Process_Error Table .', 16, -1 ) ; --V1.2 
		  END 
END 