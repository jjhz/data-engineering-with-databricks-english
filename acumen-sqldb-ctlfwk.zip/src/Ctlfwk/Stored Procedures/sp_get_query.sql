﻿CREATE PROCEDURE [ctlfwk].[sp_get_query] @source_object_name varchar(100), @source_app_name varchar(40), @histroystitch_column varchar(100) AS

BEGIN

set nocount on;

		Declare 
				@select1 varchar(max),
				@query1 varchar(max),
				@query2 varchar(max),
				@select2 varchar(max),
				@replace1 varchar(max),
				@replace2 varchar(max),
				@object_id int,
				@counter int,
				@max_seq int,
				@changedate varchar(100),
				@temp date,
				@schema_name varchar(255),
				@database_name varchar(255),
				@datatype varchar(50),
				@custom_logic varchar(20)
	
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 

	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app WHERE source_app_name = @source_app_name ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'source_app_name does not exist',	(N'{'+CONCAT('"source_app_name": "',COALESCE( @source_app_name ,''))  +'" ' 
																			+'}' )
			);
			SET @Returnvalue =2 ;
		END
	IF @Returnvalue = 2 
		RAISERROR('sp_add_source_app: ERROR - Refer to Process_Error Table .', 16, -1)	

	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_objects WHERE source_object_name = @source_object_name ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'source_object_name does not exist',	(N'{'+CONCAT('"source_object_name": "',COALESCE( @source_object_name ,''))  +'" ' 
																			+'}' )
			);

			SET @Returnvalue =2 ;
		END 

     IF @Returnvalue = 2 
		RAISERROR('sp_add_source_objects: ERROR - Refer to Process_Error Table .', 16, -1)


 	-- If No Errors
	IF @Returnvalue =0
		
	BEGIN --ReturnValue 0
		BEGIN TRY
			Select @database_name = sourcesystemdatabasename from ctlfwk.sourcesystemdatabasename a join ctlfwk.source_app b on a.SourceSystemDatabaseName_ID = b.SourceSystemDatabaseName_ID where source_app_name = @source_app_name
			
			Select @object_id = source_object_id from ctlfwk.source_objects where source_object_name = @source_object_name and source_app_id in (Select source_app_id from ctlfwk.source_app where source_app_name = @source_app_name)
			
			--Select @select1 = STRING_AGG(source_object_attribute_name, ',') from ctlfwk.source_objects_attributes where source_object_id = @object_id  
			Select @max_seq = max(source_object_attribute_seq) from ctlfwk.source_objects_attributes where source_object_id = @object_id
			SET @changedate = @histroystitch_column
			Select @schema_name = Schema_Name from ctlfwk.source_objects where source_object_id = @object_id
			
			IF @database_name = 'SQLSERVER'
			BEGIN
				SET @counter = 7
				Select @select1 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 6
				While(@counter < @max_seq-1)
					Begin
						IF Exists (Select 1 from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter)
						BEGIN
							SELECT @select2 = soa.source_object_attribute_name, @custom_logic = ecl.extraction_custom_logic_code FROM ctlfwk.source_objects_attributes soa 
							LEFT JOIN ctlfwk.extraction_custom_logic ecl ON soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
							WHERE source_object_id = @object_id and source_object_attribute_seq = @counter

							SET @select2 = CASE 
												when @custom_logic = 'extract_year' then concat('year(', @select2,') as ',@select2)
												when @custom_logic = 'check_null' then concat('case when RTRIM(LTRIM(',@select2,')) = '''' OR ', @select2 ,' IS NULL then ''N'' else ''Y'' end as ', @select2,'_Flag')
												else @select2
											END
							SET @select1 =  concat(@select1 , ', ' , @select2)
							SET @counter = @counter + 1
						END
						ELSE
						BEGIN 
							SET @counter = @counter + 1
						END
					End
				--SET @temp = cast(@changedate as datetime)
				--Select  @histroystitch_column, ISDATE(substring(@histroystitch_column,2,len(@histroystitch_column)-2))

				IF ISDATE(substring(@histroystitch_column,2,len(@histroystitch_column)-2)) = 1
				BEGIN
						SET @query1 = concat('Select NULL as __$start_lsn, NULL as __$end_lsn,  NULL as __$seqval, ''2'' as __$operation, NULL as __$update_mask,', @select1,', NULL as __$command_id, ', @changedate, ' as ChangeDateTime' , ' from ', @schema_name,'.',@source_object_name)
						SET @replace1 = concat('NULL as __$start_lsn, NULL as __$end_lsn,  NULL as __$seqval, ''2'' as __$operation, NULL as __$update_mask,', @select1,', NULL as __$command_id, ', @changedate, ' as ChangeDateTime')
				END
				ELSE
				BEGIN
						SET @query1 = concat('Select NULL as __start_lsn, NULL as __end_lsn,  NULL as __seqval, ''2'' as __operation, NULL as __update_mask,', @select1,', NULL as __command_id, ', @changedate, ' as ChangeDateTime' , ' from ', @schema_name,'.',@source_object_name, ' WHERE ', @changedate, ' > ''LastReadDate''')
						SET @replace1 = concat('NULL as __start_lsn, NULL as __end_lsn,  NULL as __seqval, ''2'' as __operation, NULL as __update_mask,', @select1,', NULL as __command_id, ', @changedate, ' as ChangeDateTime')
				END

				SET @counter = 7
				Select @select1 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 6
				While(@counter < @max_seq-1)
				Begin 
					IF Exists (Select 1 from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter)
						BEGIN
							SELECT @select2 = soa.source_object_attribute_name, @custom_logic = ecl.extraction_custom_logic_code FROM ctlfwk.source_objects_attributes soa 
							LEFT JOIN ctlfwk.extraction_custom_logic ecl ON soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
							WHERE source_object_id = @object_id and source_object_attribute_seq = @counter

							SET @select2 = CASE 
												when @custom_logic = 'extract_year' then concat('year(', @select2,') as ',@select2)
												when @custom_logic = 'check_null' then concat('case when RTRIM(LTRIM(',@select2,')) = '''' OR ', @select2 ,' IS NULL then ''N'' else ''Y'' end as ', @select2,'_Flag')
												else @select2
											END
							SET @select1 =  concat(@select1 , ', ' , @select2)
							SET @counter = @counter + 1
						END
					ELSE
						BEGIN
							SET @counter = @counter + 1
						END
				End
				SET @query2 = concat('Select  __$start_lsn as __start_lsn, __$end_lsn as __end_lsn,  __$seqval as __seqval, __$operation as __operation, __$update_mask as __update_mask,',  @select1, ', __$command_id  as __command_id, ', ' sys.fn_cdc_map_lsn_to_time(__$start_lsn) AS ChangeDateTime', ' from cdc.', @schema_name, '_', @source_object_name , '_ct', ' WHERE __$operation != 3  AND  sys.fn_cdc_map_lsn_to_time(__$start_lsn) > ''LastReadDate''')
			    SET @replace2 = concat('__$start_lsn as __start_lsn, __$end_lsn as __end_lsn,  __$seqval as __seqval, __$operation as __operation, __$update_mask as __update_mask,',  @select1, ', __$command_id  as __command_id, ', ' sys.fn_cdc_map_lsn_to_time(__$start_lsn) AS ChangeDateTime')

			END

		ELSE	
			BEGIN
				IF @database_name = 'Progress'
				BEGIN
					SET @counter = 8
					Select @select1 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 7
					While(@counter <= @max_seq)
					Begin 
						IF Exists (Select 1 from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter)
							BEGIN
								SELECT @select2 = soa.source_object_attribute_name, @custom_logic = ecl.extraction_custom_logic_code FROM ctlfwk.source_objects_attributes soa 
								LEFT JOIN ctlfwk.extraction_custom_logic ecl ON soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
								WHERE source_object_id = @object_id and source_object_attribute_seq = @counter
							
								SET @select2 = CASE 
													when @custom_logic = 'extract_year' then concat('year(', @select2,') as ',@select2)
													when @custom_logic = 'check_null' then concat('case when RTRIM(LTRIM(',@select2,')) = '''' OR ', @select2 ,' IS NULL then ''N'' else ''Y'' end as ', @select2,'_Flag')
													else @select2
												END
								SET @select1 =  concat(@select1 , ', ' , @select2)
								SET @counter = @counter + 1
							END
						ELSE
							BEGIN
								SET @counter = @counter + 1
							END
					End
					SET @query1 = concat('Select NULLIF(0,0) AS "_Tran-Id", NULLIF(0,0) AS "_Time-Stamp",  NULLIF(0,0) AS "_Change-Sequence", NULLIF(0,0) AS "_Continuation-Position", NULLIF(0,0) AS "_Array-Index", NULLIF(0,0) AS "_Fragment", ''1'' as "_Operation", ', @select1,' , ', @changedate, ' as ChangeDateTime' , ' from ', @schema_name,'.',@source_object_name, ' WHERE ', @changedate, ' > ''LastReadDate''')
					SET @replace1 = concat('NULLIF(0,0) AS "_Tran-Id", NULLIF(0,0) AS "_Time-Stamp",  NULLIF(0,0) AS "_Change-Sequence", NULLIF(0,0) AS "_Continuation-Position", NULLIF(0,0) AS "_Array-Index", NULLIF(0,0) AS "_Fragment", ''1'' as "_Operation", ', @select1,' , ', @changedate, ' as ChangeDateTime')
					
					SET @counter = 2
					Select @select1 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 1
					While(@counter <= @max_seq)
					Begin 
						IF Exists (Select 1 from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter)
							BEGIN
								SELECT @select2 = soa.source_object_attribute_name, @custom_logic = ecl.extraction_custom_logic_code FROM ctlfwk.source_objects_attributes soa 
								LEFT JOIN ctlfwk.extraction_custom_logic ecl ON soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
								WHERE source_object_id = @object_id and source_object_attribute_seq = @counter

							SET @select2 = CASE 
												when @custom_logic = 'extract_year' then concat('year(', @select2,') as ',@select2)
												when @custom_logic = 'check_null' then concat('case when RTRIM(LTRIM(',@select2,')) = '''' OR ', @select2 ,' IS NULL then ''N'' else ''Y'' end as ', @select2,'_Flag')
												else @select2
											END
								SET @select1 =  concat(@select1 , ', ' , @select2)
								SET @counter = @counter + 1
							END
						ELSE
							BEGIN
								SET @counter = @counter + 1
							END
					End
					SET @query2 = concat('Select ',  @select1,', "_Time-Stamp" as "ChangeDateTime"', ' from ', @schema_name,'.CDC_',@source_object_name, ' WHERE __$operation != 3  AND  "_Time-Stamp" > ''LastReadDate''')
					SET @replace2=concat(@select1,', "_Time-Stamp" as "ChangeDateTime"')
				END

				ELSE 
					BEGIN
						IF @database_name = 'Oracle' and @source_app_name = 'ICE'
				BEGIN
					SET @counter = 2
					Select @select1 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 1
					While(@counter < @max_seq)
					Begin 
						IF Exists (Select 1 from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter)
							BEGIN
								SELECT @select2 = soa.source_object_attribute_name, @custom_logic = ecl.extraction_custom_logic_code FROM ctlfwk.source_objects_attributes soa 
								LEFT JOIN ctlfwk.extraction_custom_logic ecl ON soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
								WHERE source_object_id = @object_id and source_object_attribute_seq = @counter
							
							SET @select2 = CASE 
												when @custom_logic = 'extract_year' then concat('year(', @select2,') as ',@select2)
												when @custom_logic = 'check_null' then concat('case when RTRIM(LTRIM(',@select2,')) = '''' OR ', @select2 ,' IS NULL then ''N'' else ''Y'' end as ', @select2,'_Flag')
												else @select2
											END
								SET @select1 =  concat(@select1 , ', ' , @select2)
								SET @counter = @counter + 1
							END
						ELSE
							BEGIN
								SET @counter = @counter + 1
							END
					End
					SET @query1 = concat('Select ', @select1,', ''I'' as Operation' , ' from ', @schema_name,'.',@source_object_name, ' WHERE ', @changedate, ' > To_date(''LastReadDate'',''YYYY-MM-DD HH24:MI:SS'')')
					SET @replace1 = concat(@select1,', ''I'' as Operation' )

					--change later
					--SET @query1 = concat('Select ', @select1,', ''I'' as Operation' , ' from ', @schema_name,'.',@source_object_name, ' where rownum = 1')
				    --SET @query1 = concat('Select ', @select1,', ''I'' as Operation' , ' from ', @schema_name,'.',@source_object_name)

					SET @counter = 1
					SET @select1=NULL
					While(@counter <= @max_seq)
					Begin 
						IF Exists (Select 1 from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter and source_object_attribute_is_pk = 'Y' )
							BEGIN
								SELECT @select2 = soa.source_object_attribute_name, @custom_logic = ecl.extraction_custom_logic_code FROM ctlfwk.source_objects_attributes soa 
								LEFT JOIN ctlfwk.extraction_custom_logic ecl ON soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
								WHERE source_object_id = @object_id and source_object_attribute_seq = @counter
								
								SET @select2 = CASE 
												when @custom_logic = 'extract_year' then concat('year(', @select2,') as ',@select2)
												when @custom_logic = 'check_null' then concat('case when RTRIM(LTRIM(',@select2,')) = '''' OR ', @select2 ,' IS NULL then ''N'' else ''Y'' end as ', @select2,'_Flag')
												else @select2
											END
								IF @select1 is NULL
								BEGIN
									SET @select1 = @select2
									SET @counter = @counter + 1
								END
								ELSE
								BEGIN
									SET @select1 =  concat(@select1 , ', ' , @select2)
									SET @counter = @counter + 1
								END
							END
						ELSE
							BEGIN
								SET @counter = @counter + 1
							END
					End
					SET @query2 = concat('Select  ',  @select1, ' from ', @schema_name,'.',@source_object_name)
					SET @replace2 = @select1

				END
					ELSE
							BEGIN
								IF @database_name = 'Oracle' and @source_app_name = 'GIS'
								BEGIN
									SET @counter = 2
									Select @datatype = source_object_attribute_data_type from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 1
									IF(@datatype = 'SDO_GEOMETRY')
									BEGIN
										Select @select1 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 1	
										SET @select1  = concat('SDO_UTIL.TO_WKTGEOMETRY(sdo_cs.make_2d(',@select1,'))')
									END
									ELSE
									BEGIN 
										Select @select1 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = 1	
									END
									While(@counter <= @max_seq)
									Begin 
										IF Exists (Select 1 from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter)
											BEGIN
												Select @datatype = source_object_attribute_data_type from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter
												IF(@datatype = 'SDO_GEOMETRY')
												BEGIN
													Select @select2 = source_object_attribute_name from ctlfwk.source_objects_attributes where source_object_id = @object_id and source_object_attribute_seq = @counter
													SET @select2 = concat('SDO_UTIL.TO_WKTGEOMETRY(sdo_cs.make_2d(',@select2,'))')
													SET @select1 =  concat(@select1 , ', ' , @select2)
													SET @counter = @counter + 1
												END
												ELSE
												BEGIN
													Select @select2 = soa.source_object_attribute_name, @custom_logic = ecl.extraction_custom_logic_code from ctlfwk.source_objects_attributes soa 
													left join ctlfwk.extraction_custom_logic ecl on soa.extraction_custom_logic_id = ecl.extraction_custom_logic_id
													where source_object_id = @object_id and source_object_attribute_seq = @counter
													
													SET @select2 = CASE 
																		when @custom_logic = 'extract_year' then concat('year(', @select2,') as ',@select2)
																		when @custom_logic = 'check_null' then concat('case when RTRIM(LTRIM(',@select2,')) = '''' OR ', @select2 ,' IS NULL then ''N'' else ''Y'' end as ', @select2,'_Flag')
																		else @select2
																	END
													SET @select1 =  concat(@select1 , ', ' , @select2)
													SET @counter = @counter + 1
												END
											END
										ELSE
											BEGIN
												SET @counter = @counter + 1
											END
									End
									SET @query1 = concat('Select ', @select1, ' from ', @schema_name,'.',@source_object_name)
									SET @replace1 = @select1

									SET @query2 = NULL
									SET @replace2 = NULL
								END
							END
					END
			END	
			
	Select @query1 as Database_Query, @query2 as Database_Query_CDC, @replace1 as Replace_Query, @replace2 as Replace_Query_CDC
	END TRY
	BEGIN CATCH
				--V1.3
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 				
	END CATCH
END
        IF EXISTS ( SELECT 1 FROM @ErrorUDT )
            BEGIN
                INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  )
                SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_query_maker'
                FROM @ErrorUDT;
               SELECT * FROM @ErrorUDT
            END
END
