﻿CREATE PROCEDURE [Ctlfwk].[sp_add_SourceSystemDatabaseName]
(
	@SourceSystemDatabaseName varchar(100)
)
AS

-- =============================================
-- Author:      Niharika S
-- Create Date: 15/11/2021
-- Description: Adds and updates records in [ctlfwk].[SourceSystemDatabaseName]

-- Usage Comments if Any :
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	15-11-2021						Niharika S				 1.0				InitialVersion
--	02-02-2022						Tammy H					 1.1				Add Raise Error
-- =============================================

BEGIN

set nocount on;
     -- Error Validations Start 
	    declare @SourceSystemDatabaseName_ID INT ;
		declare @Actiontype varchar(100) ; 
		-- Table Variable to Capture Input Paramters 
		declare @InsertedParameterValues AS TABLE 
		( 
		   SourceSystemDatabaseName VARCHAR(100)
	   )
	   -- Table Variable to Capture Error 
		declare @ErrorUDT [ctlfwk].[ErrorUDT] 
		declare @Returnvalue INT = 0 --Success 

		-- Table Variable to fetch ID's by doing Looukups to Input into File_Specification_Type Table 
		declare @FinalValues AS TABLE 
				 (
                          SourceSystemDatabaseName_ID INT IDENTITY (1,1)
					,	  SourceSystemDatabaseName VARCHAR (100)   
				  ) 

--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
		
		
		IF (@SourceSystemDatabaseName IS NULL OR LEN(@SourceSystemDatabaseName) = 0) --V1.2
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error' , 'SourceSystemDatabaseName cannot be NULL or Blank', '' );

			SET @Returnvalue =2 ;
		END 


--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 


 	-- V1.1
	IF @Returnvalue = 2 
		RAISERROR('sp_add_SourceSystemDatabaseName: ERROR - Refer to Process_Error Table .', 16, -1)

--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				BEGIN TRY 
					BEGIN TRANSACTION
			
	 
	         
						INSERT INTO @InsertedParameterValues
						(  
						     SourceSystemDatabaseName
						)    
						VALUES 
						(
						     @SourceSystemDatabaseName
						)  


--=======================================================================================================================
						 --Check if SourceSystemDatabaseName_ID Already  Exists fetch the SourceSystemDatabaseName_ID to identify the Insert/Update Action 

						 SELECT @SourceSystemDatabaseName_ID  = SourceSystemDatabaseName_ID
                         FROM [Ctlfwk].[SourceSystemDatabaseName] 
                         WHERE SourceSystemDatabaseName = @SourceSystemDatabaseName
						
--================================Update  Process Table ==============================================			 
						 --Capturing the Merge Action into #MergeActions Table 
						 DROP TABLE IF EXISTS #MergeActions ;
						 CREATE TABLE #MergeActions ([Action] VARCHAR(10),SourceSystemDatabaseName_ID INT  ) 
						 INSERT INTO #MergeActions ([Action],SourceSystemDatabaseName_ID)
						 SELECT [Action]  ,SourceSystemDatabaseName_ID
						 FROM ( 
			 
						 MERGE ctlfwk.SourceSystemDatabaseName as tgt 
						 USING @InsertedParameterValues as source ON ( tgt.SourceSystemDatabaseName_ID =ISNULL(@SourceSystemDatabaseName_ID,0)						  
																	 )
						 WHEN MATCHED THEN 
							  UPDATE 
							  SET   tgt.SourceSystemDatabaseName =source.SourceSystemDatabaseName
								  , tgt.last_modified_datetime =SYSDATETIME()
								  , tgt.last_modified_by = ORIGINAL_LOGIN()
 

						 WHEN NOT MATCHED THEN 
							 INSERT ( SourceSystemDatabaseName)
							 VALUES ( 
									 source.SourceSystemDatabaseName
           						   )
						   
						OUTPUT
							 $action as Action ,
						   inserted.SourceSystemDatabaseName_ID
						  ) MergeOutput 
						SELECT * FROM #MergeActions ;  
				COMMIT TRANSACTION	 
			END TRY
        
	  
       
		BEGIN CATCH 
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}'));
				ROLLBACK TRANSACTION 
		END CATCH 
	   END  --ReturnValue 0

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_SourceSystemDatabaseName' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
		  END 
	   ELSE 
	      SELECT CONCAT('SourceSystemDatabaseName_ID ',+ CONVERT(VARCHAR, SourceSystemDatabaseName_ID)   + ' Is '+Action +'D')  FROM #MergeActions
	 
END
