﻿
CREATE PROCEDURE [ctlfwk].[sp_add_load_types]
(
	@load_type_code varchar(5)
,	@load_type_description varchar(30)
)
AS
-- =============================================
-- Author:		Deloitte
-- Create date: 2020-07-08
-- Description:	Insert load type record if it does not exist
-- =============================================

BEGIN

set nocount on;
    declare @trancount int;
    set @trancount = @@trancount;
    begin try
	print 'Inserting ' + @load_type_code + ', ' + @load_type_description;
        if @trancount = 0
            begin transaction
        else
            save transaction sp_add_load_types;
	
	
	-- check if record exists, if not, insert the row
	if (not exists (select 1 from [ctlfwk].[load_types] where [load_type_code] = @load_type_code))
	begin
		insert into [ctlfwk].[load_types]
		(
			[load_type_code]
		,	[load_type_description]
		,	[start_date_time]
		,	[end_date_time]
		)
		values
		(
			@load_type_code
		,	@load_type_description
		,	GETDATE()
		,	'9999-12-31'
		)
	end
	else
		print 'Entry already exists for ' + @load_type_code + ', ' + @load_type_description

if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_load_types;

        raiserror ('Ctlfwk.sp_add_load_types: %d: %s', 16, 1, @error, @message) ;
    end catch

end