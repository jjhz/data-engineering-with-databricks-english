CREATE PROCEDURE [Ctlfwk].[sp_force_stop_process]
( 
  @process_name VARCHAR(200),
  @process_execution_status varchar(10) 
)
AS
SET NOCOUNT ON


BEGIN TRY
	DECLARE 
		@exectution_status_id	INT,
		@ret_status VARCHAR(100),
		@Process_ID	INT,
		@process_status_id VARCHAR(100)

	/* FETCH Execution_Status_ID based on the input parameter value @process_execution_status */
	SELECT @exectution_status_id = execution_status_id FROM ctlfwk.Execution_Status WHERE execution_status_name = @process_execution_status

	/* Fetch Process_ID From process Table */
	SELECT @Process_ID = process_id FROM ctlfwk.vw_process WHERE process_name = @process_name

	/* Fetch Process_status_ID From process_status Table */
	SELECT @process_status_id = process_status_id FROM ctlfwk.vw_process_status WHERE process_id = @Process_ID


	IF (@process_execution_status = 'Success')
	   BEGIN
			UPDATE [ctlfwk].[process_status]
				SET 
					execution_status_id = @exectution_status_id, end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss')
				WHERE  
					process_status_Id = @process_status_id

			SET @ret_status ='Process successfully completed.'
	   END 

	ELSE IF (@process_execution_status = 'Failed')
	   BEGIN
			UPDATE [ctlfwk].[process_status]
				SET 
					execution_status_id = @exectution_status_id, end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss')
				WHERE 
					process_status_id = @process_status_id

			SET @ret_status ='Process Report Failure.'
	   END 
	ELSE IF (@process_execution_status = 'Cancelled')
	   BEGIN
			UPDATE [ctlfwk].[process_status]
				SET
					execution_status_id = @exectution_status_id, end_date_time = format(getdate(),'yyyy-MM-dd HH:mm:ss')
				WHERE 
					process_status_id = @process_status_id
			SET @ret_status ='Process Is Cancelled.'
	   END 

	(SELECT @ret_status AS ErrorMessage, format(getdate(),'yyyy-MM-dd HH:mm:ss') AS Process_Stop_TimeStamp)

END TRY


BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()
	
	RAISERROR	('Exception Details :
					Error Number		:	%d
					Error Message		:	%d
					Affected Procedure	:	%d
					Affected Line Number:	%d',
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;
GO
