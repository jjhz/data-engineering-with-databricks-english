﻿CREATE PROCEDURE [ctlfwk].[sp_add_Src_Obj_Attr_To_RBAC_Map]
(  @Source_Object_Name	VARCHAR(100),
   @Source_Object_Attribute_Name	VARCHAR(100),
   @RBAC_Code          VARCHAR(100)
)
AS
-- ==================================================================================================================================================
-- Description: This proc can be used to find the Stream, process and Pool Config details for a given object 
--	DATE						Author			         VERSION			COMMENTS  
--	06-12-2022					Shubham S.				 1.0				InitialVersion
-- =======================================================================================================================================*/

BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    declare @trancount int,
	@source_object_id int,
	@RBAC_Id int;
	-- V1.2 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0; --Success 
	declare @error_message VARCHAR(max);
	declare @error_flag VARCHAR(5);
    set @trancount = @@trancount;
	
	Select @source_object_id = source_object_id from ctlfwk.source_objects where source_object_name = @Source_Object_Name

	-- Inserting record ignoring if it already exists or not
	-- if (not exists (select 1 from [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] where Source_Object_ID = @Source_Object_ID and Source_Object_Attribute_Name=@Source_Object_Attribute_Name))
	
--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 

	IF NOT EXISTS(Select 1 from ctlfwk.source_objects where source_object_name = @source_object_name)
	BEGIN
		SET @error_flag = 'Error'
		SET @error_message = 'Invalid Source_Object_Name'

		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
		VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
												+'}' )
				);

		SET @Returnvalue =2 ;
	END

	IF NOT EXISTS(Select 1 from ctlfwk.source_objects_attributes where source_object_id = @source_object_id
	and source_object_attribute_name = @Source_Object_Attribute_Name and source_object_attribute_is_PII = 'Y')
	BEGIN
		SET @error_flag = 'Error'
		SET @error_message = 'Source_Object_Attribute is not a PII attribute or Source_Object_Attribute is not valid'

		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
		VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
												+'}' )
				);

		SET @Returnvalue =2 ;
	END

	IF NOT EXISTS(Select 1 from ctlfwk.RBAC_Master where RBAC_Master_code = @RBAC_Code)
	BEGIN
		SET @error_flag = 'Error'
		SET @error_message = 'Invalid RBAC_Master_Code'

		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
		VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
												+'}' )
				);

		SET @Returnvalue =2 ;
	END


--===========================-- Insert ot Update Source_Object_Attribute_To_RBAC_Mapping ==================================================== 
IF @Returnvalue = 0 
	BEGIN  --ReturnValue 0
		BEGIN TRY
			BEGIN TRANSACTION
				Select @RBAC_Id =RBAC_Master_id  from ctlfwk.RBAC_Master where RBAC_Master_code = @RBAC_Code

				DROP TABLE IF EXISTS #ActionTable;
				CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT, [Name] VARCHAR(100))

				IF NOT EXISTS(Select 1 from ctlfwk.Source_Object_Attribute_To_RBAC_Mapping 
				where Source_Object_Attribute_Name = @Source_Object_Attribute_Name and Source_Object_ID = @source_object_id)
					BEGIN
						INSERT INTO [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping]
						      (                    
								Source_Object_ID,	
								Source_Object_Attribute_Name,		
								RBAC_ID
						      )
						OUTPUT 'Inserted', inserted.source_object_id, inserted.source_object_attribute_name
						INTO #ActionTable (Act, Id, [Name])
						 VALUES
						      ( 
								@Source_Object_ID,
								@Source_Object_Attribute_Name,
								@RBAC_ID
						      )
					END
				ELSE
					BEGIN
						UPDATE [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping]
						SET Source_Object_ID = @source_object_id,
							Source_Object_Attribute_Name = @Source_Object_Attribute_Name,
							RBAC_ID = @RBAC_Id
						OUTPUT 'Updated', inserted.source_object_id, inserted.source_object_attribute_name
						INTO #ActionTable (Act, Id, [Name])
						where Source_Object_ID = @source_object_id and Source_Object_Attribute_Name = @Source_Object_Attribute_Name
					END
				COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
					
			SET @error_flag = 'Error'
			SET @error_message = ERROR_MESSAGE()

			INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
			VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
			ROLLBACK TRANSACTION
			
		END CATCH

	END
IF EXISTS ( SELECT 1 FROM @ErrorUDT )
	BEGIN
		INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
		SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Src_Obj_Attr_To_RBAC_Map' 
		FROM @ErrorUDT; 
		RAISERROR('sp_add_Src_Obj_Attr_To_RBAC_Map: ERROR - Refer to Process_Error Table .' ,17, 1) 
	END
ELSE 
		SELECT CONCAT('Source_Object_Attribute_Name ' + [Name] + ' for Source_Object_Id ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 


END
GO


