﻿
CREATE PROCEDURE [ctlfwk].[sp_start_stream]
( 
  @stream_name VARCHAR(255), --V1.4
  @restart_from_beginning int=1 ---- V1.2
)
AS

/*===============================================================================================================================================================================
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	01-08-2021						Deloitte 				 1.0				InitialVersion
	15-09-2021						Tammy H					 1.1				Changes to Capture Error (those that RAISERROR()) into ctrlfwk.process_errors 
																				and key Input Parameters of Error as JSON
	10-12-2021						Vikas P 				 1.2				Changes for restart flexiblity to pass restart_from_beginning flag from Execution plan
																				restart_from_beginning in stream table will be defulted always as 1
	22-01-2022						Vikas p 				 1.3				Added Logic for error handling
	18-03-2022						Tammy H					 1.4			    New req: Stream_name raised to be varchar(255)
	23-03-2022						Tammy H					 1.5				Added milliseconds to timestamps: fff
 ================================================================================================================================================================================ */  

SET NOCOUNT ON
SET XACT_ABORT ON

BEGIN TRY 

	DECLARE 
		@Last_Execution_Status VARCHAR(10),
		@Execution_Status_ID	INT,
		@Stream_ID				INT,
		@stream_status_id		INT,  --changed it into INT
		@stream_start_ts		VARCHAR(100),
		@ret_status             VARCHAR(100),
        @error_flag			    VARCHAR(100),
		@ret_message		    VARCHAR(100),
		@restart_flg            BIT,
		@Additional_Data        NVARCHAR(4000)    --V1.1

		


/* Check two Error conditions. 1. StreamName not provided 2. Stream Name Invalid*/
		/* Error Condition 1 - If Stream Name is not provided or NULL*/
		IF (@stream_name IS NULL OR @stream_name = '')
			BEGIN
				SET @error_flag='Error'--v1.3
				SET @ret_message ='ERROR - Stream name not provided.'
				SET @stream_status_id = NULL
			    SET @stream_start_ts = NULL
				SET @Additional_Data = N'{ "Stream_Status_ID": "" ' 
										+', "Stream_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}'  --V1.5

				SELECT @stream_status_id as Stream_Status_ID, @stream_start_ts AS Stream_Start_TimeStamp, @error_flag AS Error_Flag, @ret_message AS Error_Message --v1.3

				RAISERROR(@ret_message ,16,-1)

				return -1
			END
		
		/* Fetch Stream_ID From Stream view*/
		SELECT @Stream_ID = stream_id FROM ctlfwk.vw_stream WHERE stream_name = @stream_name
		
		/* Error Condition 2 - Check for invalid stream - Stream_ID=NULL*/
		IF (@Stream_ID is null)
        BEGIN
			SET @error_flag='Error'
			SET @ret_message = 'ERROR - Job Cannot Start. Stream Name does not exists.'
			SET @stream_status_id = NULL
			SET @stream_start_ts = NULL
			SET @Additional_Data = N'{ "Stream_Status_ID": "" , "Stream_Stop_TimeStamp" : ""}'

            SELECT @stream_status_id as Stream_Status_ID, @stream_start_ts AS Stream_Start_TimeStamp, @error_flag AS Error_Flag, @ret_message AS Error_Message
		    RAISERROR(@ret_message ,16,-1)


        END



/* If Stream is already RUNNING, Stop Talend Job and Throw Error*/ 
			/* Step 1 Fetch Execution_Status_ID From Execution_Status Table */
		SELECT @Execution_Status_ID = Execution_Status_ID FROM ctlfwk.execution_status WHERE execution_status_name = 'Running'
		/* GET Last Execution Status Information For Given Stream Name */
		SELECT 
			@Last_Execution_Status = execution_status_name 
		FROM 
			ctlfwk.vw_stream_status
		WHERE
			stream_name = @stream_name
				
		IF @Last_Execution_Status IN ('Running')
		BEGIN

		SET @error_flag='Error'
			SET @ret_message = 'ERROR - Stream Cannot Start. Previous Stream Is Still Running.'
			SET @stream_status_id = NULL
			SET @stream_start_ts = NULL
			SET @Additional_Data = N'{ "Stream_Status_ID": "" ' 
									+','+CONCAT('"Stream_Start_TimeStamp": "',COALESCE( @stream_start_ts ,''))  +'" '
									+'}'

		SELECT @stream_status_id as Stream_Status_ID, @stream_start_ts AS Stream_Start_TimeStamp, @error_flag AS Error_Flag, @ret_message AS Error_Message

		RAISERROR(@ret_message ,16,1)


		--);
		END

-----------------------V 1.2--------------------------------------------------------------------------------------------------------
		IF @restart_from_beginning in(1,0)
			Begin	
				Update Ctlfwk.stream set restart_from_beginning=@restart_from_beginning where stream_id=@Stream_ID	
			END
		ELSE
			Begin
				RAISERROR('Invalid value set to restart_from_beginning column, please enter 1 or 0' ,16,1)
			END

-----------------------V 1.2--------------------------------------------------------------------------------------------------------

/* If Previous Stream execution status = Successful or Cancelled, Run process normally by inserting execution_status_id=1 in ctlfwk.stream_status with current timestamp */ 		
		
		IF @Last_Execution_Status IN ('Success' ,'Cancelled','') OR @Last_Execution_Status IS NULL
		
		BEGIN
		SET_RUNNING:			-- LABEL SET_RUNNING
		
		
		/* COPY PREVIOUS SUCCEssful/Cancelled RUN VALUES FROM STEAM_STATUS Table to STEAM_STATUS_LOG */

		INSERT INTO ctlfwk.stream_status_log 
			(stream_status_id, stream_id, execution_status_id, start_date_time, end_date_time)
		SELECT 
			stream_status_id, stream_id, execution_status_id, start_date_time, end_date_time
		FROM
			ctlfwk.vw_stream_status
		WHERE
			stream_name = @stream_name		
		
		/* DELETE RECORD FOR PREVIOUS EXECUTION FROM STEAM_STATUS Table*/

		DELETE FROM ctlfwk.stream_status WHERE stream_id = @Stream_ID 
		
		/* INSERT NEW EXECUTION in Stream_Status Table */

		INSERT INTO ctlfwk.stream_status (stream_id, execution_status_id, start_date_time)
		VALUES
		(@Stream_ID,'1',format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')) --V1.5
	
	   /* Set Execution_Status = Running, This check is necessary because it will fix continuous loop bug in case stream is restarted*/
		SELECT @Last_Execution_Status= execution_status_name 
		FROM 
			ctlfwk.vw_stream_status
		WHERE
			stream_name = @stream_name

		SET	@stream_status_id = (SELECT MAX(A.stream_status_id) 
									FROM (	SELECT stream_status_id
											FROM [ctlfwk].[vw_stream_status] 
											WHERE stream_name = @stream_name)A)
		SET @stream_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V1.5
									FROM (	SELECT MAX(start_date_time) as start_date_time
											FROM [ctlfwk].[vw_stream_status]
											WHERE stream_name = @stream_name)B)
		SET @error_flag ='Success'
		SET @ret_message ='Success'

		SELECT @stream_status_id as Stream_Status_ID, @stream_start_ts AS Stream_Start_TimeStamp, @error_flag AS Error_Flag, @ret_message AS Error_Message
	END
		
		
/* If Previous Stream execution status = FAILED, Check Restart Options Flag=1 or Flag=0 in Ctlfwk.stream */ 		
		
		IF @Last_Execution_Status IN ('Failed')
		/* Check Restart_FromBeginning Flag from Ctlfwk.stream */
			BEGIN		
			/* Get value of Restart_FromBeginning Flag from Ctlfwk.stream */
			SELECT @restart_flg=restart_from_beginning FROM Ctlfwk.stream WHERE stream_id=@Stream_ID
		
					/* Check if restart from beginning required */
					IF @restart_flg=1 GOTO SET_RUNNING
		
					/* Start from failed process */
					ELSE
						BEGIN
						/* Fetch Execution_Status_ID From Execution_Status Table for Status='Restart'*/
						SELECT @Execution_Status_ID = Execution_Status_ID FROM ctlfwk.execution_status WHERE execution_status_name = 'Restart'
						
						/* COPY PREVIOUS SUCCEssful/Cancelled RUN VALUES FROM STEAM_STATUS Table to STEAM_STATUS_LOG */

							INSERT INTO ctlfwk.stream_status_log 
								(stream_status_id, stream_id, execution_status_id, start_date_time, end_date_time)
							SELECT 
								stream_status_id, stream_id, execution_status_id, start_date_time, end_date_time
							FROM
								ctlfwk.vw_stream_status
							WHERE
								stream_name = @stream_name		
		
							/* DELETE RECORD FOR PREVIOUS EXECUTION FROM STEAM_STATUS Table*/

							DELETE FROM ctlfwk.stream_status WHERE stream_id = @Stream_ID 


						/* Insert execution_status_id=7 for 'Restart' in ctlfwk.stream_status for last 'Failed' stream */
						INSERT INTO ctlfwk.stream_status (stream_id, execution_status_id, start_date_time)
						VALUES
						(@Stream_ID,@Execution_Status_ID,format(getdate(),'yyyy-MM-dd HH:mm:ss.fff')) --V1.5
						
						SET	@stream_status_id = (SELECT MAX(A.stream_status_id) 
											FROM (	SELECT stream_status_id
													FROM [ctlfwk].[vw_stream_status] 
													WHERE stream_name = @stream_name)A)
						SET @stream_start_ts = (	SELECT FORMAT(start_date_time, 'yyyyMMddHHmmssfff') --V1.5
																	FROM (	SELECT MAX(start_date_time) as start_date_time
																			FROM [ctlfwk].[vw_stream_status]
																			WHERE stream_name = @stream_name)B)
						SET @error_flag ='Success'
						SET @ret_message ='Success - Stream Restarted'							
						SELECT @stream_status_id as Stream_Status_ID, @stream_start_ts AS Stream_Start_TimeStamp, @error_flag AS Error_Flag, @ret_message AS Error_Message
					
					END

			
			
			END

/* If Previous Stream execution status = RESTART, Stream is already in RESTART MODE and we can't START it AGAIN */ 		
		
		IF @Last_Execution_Status IN ('Restart')
		/* Check Restart_FromBeginning Flag from Ctlfwk.stream */
			BEGIN		
				SET @error_flag='Error'
				SET @ret_message = 'ERROR - STREAM Is Already In RESTART Mode. Please STOP stream before re-running it.'
				SET @stream_status_id = NULL
				SET @stream_start_ts = NULL
				SET @Additional_Data = N'{ "Stream_Status_ID": "" ' 
										+','+CONCAT('"Stream_Start_TimeStamp": "',COALESCE( @stream_start_ts ,''))  +'" '
										+'}'

				SELECT @stream_status_id as Stream_Status_ID, @stream_start_ts AS Stream_Start_TimeStamp, @error_flag AS Error_Flag, @ret_message AS Error_Message
				RAISERROR(@ret_message ,16,-1)


			END

		
END TRY


BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()

	--V1.1 
	INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  )  
	SELECT 'Error' ,@ret_message ,@Additional_Data ,'sp_start_stream' ;
  

	RAISERROR	(   @ret_message,
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;
