﻿CREATE PROCEDURE [ctlfwk].[sp_add_RBAC_Code]
(  
    @RBAC_Code          VARCHAR(100),
	@RBAC_Code_Desc		VARCHAR(100)
)
AS
-- ==================================================================================================================================================
-- Description: This proc can be used to add RBAC code to the RBAC Master Table
--	DATE						Author			         VERSION			COMMENTS  
--	16-01-2023					Rohit Kumar				 1.0				InitialVersion
-- =======================================================================================================================================*/

BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    declare @trancount int
	-- V1.2 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0; --Success 
	declare @error_message VARCHAR(max);
	declare @error_flag VARCHAR(5);
    set @trancount = @@trancount;
	
	-- Inserting record ignoring if it already exists or not
	-- if (not exists (select 1 from [ctlfwk].[Source_Object_Attribute_To_RBAC_Mapping] where Source_Object_ID = @Source_Object_ID and Source_Object_Attribute_Name=@Source_Object_Attribute_Name))
	
--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 



--===========================-- Insert ot Update Source_Object_Attribute_To_RBAC_Mapping ==================================================== 
IF @Returnvalue = 0 
	BEGIN  --ReturnValue 0
		BEGIN TRY
			BEGIN TRANSACTION
				
				DROP TABLE IF EXISTS #ActionTable;
				CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT, [Name] VARCHAR(100))

				IF NOT EXISTS(Select 1 from ctlfwk.RBAC_Master where  RBAC_Master_code = @RBAC_Code)
					BEGIN
						INSERT INTO [ctlfwk].[RBAC_Master]
						      (                    
								RBAC_Master_code,	
								RBAC_Master_desc		
						      )
						OUTPUT 'Inserted', inserted.RBAC_Master_id, inserted.RBAC_Master_code
						INTO #ActionTable (Act, Id, [Name])
						 VALUES
						      ( 
								@RBAC_Code,
								@RBAC_Code_Desc
								
						      )
					END
				ELSE
					BEGIN
						UPDATE [ctlfwk].[RBAC_Master]
						SET RBAC_Master_code = @RBAC_Code,
							RBAC_Master_desc = @RBAC_Code_Desc,
							start_date_time = getdate(),
							end_date_time = '9999-12-31 11:59:59',
							last_modified_datetime =sysdatetime(),
							last_modified_by = original_login()
						OUTPUT 'Updated', inserted.RBAC_Master_id, inserted.RBAC_Master_Code
						INTO #ActionTable (Act, Id, [Name])
						where RBAC_Master_code = @RBAC_Code
					END
				COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
					
			SET @error_flag = 'Error'
			SET @error_message = ERROR_MESSAGE()

			INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
			VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
			ROLLBACK TRANSACTION
			
		END CATCH

	END
IF EXISTS ( SELECT 1 FROM @ErrorUDT )
	BEGIN
		INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
		SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_Add_RBAC_Code' 
		FROM @ErrorUDT; 
		RAISERROR('sp_Add_RBAC_Code: ERROR - Refer to Process_Error Table .' ,17, 1) 
	END
ELSE 
		SELECT CONCAT('RBAC_Master_Code ' + [Name] + ' for RBAC_Master_Id ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 

END
GO


