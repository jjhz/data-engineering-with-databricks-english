﻿
CREATE PROCEDURE [ctlfwk].[getJsonTargetSchema]
	--@business_unit_name_code VARCHAR(100), 
	--@source_app_name VARCHAR(100),
	@Schema_Name VARCHAR(50),
	@notebook_path varchar(max),
	@notebook_name varchar(max),
	@target_object_name VARCHAR(100)
AS 
/* ==================================================================================================================================================
 
-- Usage Comments if Any : Used to create JSON Schema containing Target Object Details (target_object, target_object_attributes)
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	21-01-2022						Niharika S  			 1.0				InitialVersion
	31-01-2022						Tammy H					 1.1				Formatting integration_key_names to format required by JSON
	01-02-2022						Tammy H					 1.2				Removed non-used table joins. Use SQLSERVER as datasource
	03-02-2022						Tammy H					 1.3				Adding the array_name as target_column in json and with required values and format
	04-02-2022						Tammy H					 1.4				Filtering on target_attribute_is_target_columns for the columns to appear in the target_columns (on top of the array)
	07-02-2022						Tammy H					 1.5				Adding additional columns to JSON. 
																				Including source_app_id (from business_unit_name_code&source_app_code) into table filtering & validations etc. 
																				Added RAISEERORR()
	08-02-2022						Tammy H					 1.6				Removed (SELECT @error_flag AS Error_Flag, @error_message AS Error_Message) stmt  from Validation 
	09-02-2022						Tammy H					 1.7				Change hardcoded array nullable column from False to Postiive - new requirement
	11-02-2022						Tammy H					 1.8				Change hardcoded array syn_data_Type column from NULL to NVARCHAR(max) - new requirement
	01-03-2022						Tammy H					 1.9				Added source_app_name value into Json as source_application_name
	04-03-2022						Tammy H					 2.0				Update validations and rules to meet new req: Unique set of keys for target object -schema_name, notebook_path, notebook_name, target_object
	13-04-2022						Tammy H					 2.1				Passing to ADB: sqlserver MONEY as DECIMAL(19,4) and SMALLMONEY as DECIMAL(14,4)
	21-04-2022						Niharika S				 2.2				Passing value of scale and precision when sqlserver MONEY,SMALLMONEY is not null
	06-05-2022						Tammy H					 2.3				Bugfix on MONEY/SMALLMONEY scale rule -if scale = 0, pass as it is instead of defaulting to 4
===================================================================================================================================================*/
BEGIN 

	--DECLARE @source_app_id INT 

	-- Table Variable to Capture Error/Actions 
	DECLARE @ErrorUDT [ctlfwk].[ErrorUDT] 
	DECLARE @Returnvalue INT = 0 --Success 
	DECLARE @error_flag VARCHAR(100)
	DECLARE @error_message VARCHAR(200)
	
--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
	
	--IF NOT EXISTS ( SELECT 1 FROM ctlfwk.business_unit WHERE business_unit_name_code = @business_unit_name_code ) 
	--BEGIN 
			
	--	SET @error_flag = 'Error'
	--	SET @error_message = 'Business_Unit_Name_Code does not exist'

	--	INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
	--	VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
	--											+','+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" '
	--											+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
	--											+'}' )
	--			);

	--	SET @Returnvalue =2 ;

	--	--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --V1.6 Removed
	--END 
	
	--IF NOT EXISTS ( SELECT 1 
	--				FROM ctlfwk.source_app sa 
	--				INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
	--				WHERE source_app_name = @source_app_name AND business_unit_name_code = @business_unit_name_code) 
	--	BEGIN 
			
	--		SET @error_flag = 'Error'
	--		SET @error_message = 'Business_Unit_Name_Code and Source_App_Name does not exist together'

	--		INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
	--		VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Business_Unit_Name_Code": "',COALESCE( @business_unit_name_code ,''))  +'" ' 
	--											+','+CONCAT('"Source_App_Name": "',COALESCE( @source_app_name ,''))  +'" '
	--											+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
	--											+'}' )
	--				);

	--		SET @Returnvalue =2 ;

	--		--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --V1.6 Removed
	--	END
	--ELSE --V1.4 Get the unique id -source_app_id
	--	BEGIN
	--		SELECT @source_app_id = source_app_id 
	--		FROM ctlfwk.source_app sa 
	--		INNER JOIN ctlfwk.business_unit bu ON sa.business_unit_id = bu.business_unit_id
	--		WHERE source_app_name = @source_app_name AND business_unit_name_code = @business_unit_name_code
	--	END
		


	--V2.0 Replace business_unit_name_code & source_app_name with schema_name, notebook_path, notebook_name
	IF NOT EXISTS ( SELECT 1 
					FROM ctlfwk.target_objects [to]
					WHERE [to].target_object_name = @target_object_name AND [Schema_Name] = @Schema_Name AND notebook_path = @notebook_path AND notebook_name = @notebook_name )
		BEGIN 
			Set @error_flag = 'Error'
			Set @error_message = 'Target_Object_Name must exist in ctlfwk.target_objects with Schema_Name, Notebook_Path, Notebook_Name' 
			
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Schema_Name": "',COALESCE( @Schema_Name ,''))  +'" ' 
												+','+CONCAT('"Notebook_Path": "',COALESCE( @Notebook_Path ,''))  +'" '
												+','+CONCAT('"Notebook_Name": "',COALESCE( @Notebook_Name ,''))  +'" '
												+','+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
												+'}' )
					);

			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --V1.6 Removed
		END  
		
	--V2.0 replaced source_app_id with schema_name, notebook_path, notebook_name
	-- Shouldn't allow a JSON to be created with nothing
	IF NOT EXISTS (SELECT 1 
					FROM [ctlfwk].[target_objects_attributes] toa 
					INNER JOIN [ctlfwk].[target_objects] [to] ON toa.target_object_id = [to].target_object_id
					WHERE [to].target_object_name = @target_object_name AND [Schema_Name] = @Schema_Name AND notebook_path = @notebook_path AND notebook_name = @notebook_name) 
		BEGIN
			SET @error_flag = 'Error'
			SET @error_message = 'The provided Target_Object_Name does not contain any Target Object Attributes.' --V1.2

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
													+'}' )
					);
			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --V1.6 Removed
		END

	--V2.0 replaced source_app_id with schema_name, notebook_path, notebook_name
	-- validation causing error when it's not D(pk) or D/T (bk) START
	IF EXISTS (SELECT 1 
					FROM [ctlfwk].[target_objects_attributes] toa 
					INNER JOIN [ctlfwk].[target_objects] [to] ON toa.target_object_id = [to].target_object_id
					--INNER JOIN ctlfwk.source_app sa ON [to].source_app_id = sa.source_app_id 
					INNER JOIN Ctlfwk.load_types lt on [to].load_type_id = lt.load_type_id
					WHERE [to].target_object_name = @target_object_name 
					--AND sa.source_app_id= @source_app_id
					AND [Schema_Name] = @Schema_Name 
					AND notebook_path = @notebook_path 
					AND notebook_name = @notebook_name
					AND toa.target_attribute_is_pk ='Y'
					and lt.load_type_code = 'D'
					)
		AND NOT EXISTS (SELECT 1 
					FROM [ctlfwk].[target_objects_attributes] toa 
					INNER JOIN [ctlfwk].[target_objects] [to] ON toa.target_object_id = [to].target_object_id
					--INNER JOIN ctlfwk.source_app sa ON [to].source_app_id = sa.source_app_id 
					INNER JOIN Ctlfwk.load_types lt on [to].load_type_id = lt.load_type_id
					WHERE [to].target_object_name = @target_object_name 
					--AND sa.source_app_id = @source_app_id
					AND [Schema_Name] = @Schema_Name 
					AND notebook_path = @notebook_path 
					AND notebook_name = @notebook_name
					AND toa.target_attribute_is_pk ='Y'
					)
		BEGIN
			SET @error_flag = 'Error'
			SET @error_message = 'At least one target column for the object must be a primary key column for objects with Delta load type'

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
													+'}' )
					);
			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --V1.6 Removed
		END

	IF EXISTS (SELECT 1 
					FROM [ctlfwk].[target_objects_attributes] toa 
					INNER JOIN [ctlfwk].[target_objects] [to] ON toa.target_object_id = [to].target_object_id
					--INNER JOIN ctlfwk.source_app sa ON [to].source_app_id = sa.source_app_id 
					INNER JOIN Ctlfwk.load_types lt on [to].load_type_id = lt.load_type_id
					WHERE [to].target_object_name = @target_object_name 
					--AND sa.source_app_id = @source_app_id
					AND [Schema_Name] = @Schema_Name 
					AND notebook_path = @notebook_path 
					AND notebook_name = @notebook_name
					--AND toa.target_attribute_is_BusinessKey ='Y'
					and lt.load_type_code in ('D', 'T')
					)
		AND NOT EXISTS (SELECT 1 
					FROM [ctlfwk].[target_objects_attributes] toa 
					INNER JOIN [ctlfwk].[target_objects] [to] ON toa.target_object_id = [to].target_object_id
					--INNER JOIN ctlfwk.source_app sa ON [to].source_app_id = sa.source_app_id 
					INNER JOIN Ctlfwk.load_types lt on [to].load_type_id = lt.load_type_id
					WHERE [to].target_object_name = @target_object_name 
					--AND sa.source_app_id = @source_app_id
					AND [Schema_Name] = @Schema_Name 
					AND notebook_path = @notebook_path 
					AND notebook_name = @notebook_name
					AND toa.target_attribute_is_BusinessKey ='Y'
					)
		BEGIN
			SET @error_flag = 'Error'
			SET @error_message = 'At least one target column for the object must be a business key column for objects with Delta or Truncate load type'

			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES (@error_flag, @error_message, (N'{'+CONCAT('"Target_Object_Name": "',COALESCE( @target_object_name ,''))  +'" '
													+'}' )
					);
			SET @Returnvalue =2 ;

			--SELECT @error_flag AS Error_Flag, @error_message AS Error_Message --V1.6 Removed
		END

	--  validation causing error when it's not D(pk) or D/T (bk) load END

--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

	--  If No Errors 
	IF @Returnvalue = 0 
		BEGIN  --ReturnValue 0
			BEGIN TRY
				DROP TABLE IF EXISTS #TargetObjectColumns ;
				DROP TABLE IF EXISTS #TargetObjectDetails ;

				/*format the required columns for JSON SourceColumns*/
				SELECT
					toa.target_attribute_seq
				,	toa.target_attribute_name AS column_name
				,   CASE 	WHEN target_attribute_data_type IN ('MONEY') 
								AND (toa.target_attribute_precision = 0 OR toa.target_attribute_precision IS NULL OR LEN(toa.target_attribute_precision) = 0) 
								AND (toa.target_attribute_scale IS NULL OR LEN(toa.target_attribute_scale) = 0) 
								THEN 'DECIMAL(19,4)' --V2.1 --V2.2 --V2.3
							WHEN target_attribute_data_type IN ('MONEY') 
								AND (toa.target_attribute_precision = 0 OR toa.target_attribute_precision IS NULL OR LEN(toa.target_attribute_precision) = 0) 
								AND toa.target_attribute_scale IS NOT NULL 
								THEN CONCAT('DECIMAL(', '19', ',', toa.target_attribute_scale, ')') --V2.2
							WHEN target_attribute_data_type IN ('MONEY') 
								AND toa.target_attribute_precision IS NOT NULL 
								AND (toa.target_attribute_scale IS NULL OR LEN(toa.target_attribute_scale) = 0) 
								THEN CONCAT('DECIMAL(', toa.target_attribute_precision, ',', '4', ')') --V2.2 --V2.3
							WHEN target_attribute_data_type IN ('SMALLMONEY') 
								AND (toa.target_attribute_precision = 0 OR toa.target_attribute_precision IS NULL OR LEN(toa.target_attribute_precision) = 0) 
								AND (toa.target_attribute_scale IS NULL OR LEN(toa.target_attribute_scale) = 0) 
								THEN 'DECIMAL(12,4)' --V2.1 --V2.2 --V2.3
							WHEN target_attribute_data_type IN ('SMALLMONEY')  
								 AND (toa.target_attribute_precision = 0 OR toa.target_attribute_precision IS NULL OR LEN(toa.target_attribute_precision) = 0) 
								 AND toa.target_attribute_scale IS NOT NULL 
								THEN CONCAT('DECIMAL(', '12', ',', toa.target_attribute_scale, ')') --V2.2
							WHEN target_attribute_data_type IN ('SMALLMONEY') 
								 AND toa.target_attribute_precision IS NOT NULL 
								 AND (toa.target_attribute_scale IS NULL OR LEN(toa.target_attribute_scale) = 0) 
								THEN CONCAT('DECIMAL(', toa.target_attribute_precision, ',', '4', ')') --V2.2 --V2.3
						 WHEN ss.SparkSQLDatatype = 'DECIMAL' THEN CONCAT('DECIMAL(', toa.target_attribute_precision, ',',  target_attribute_scale, ')')
						 ELSE ss.SparkSQLDatatype
						 END AS adb_data_type
				,	CASE WHEN toa.target_attribute_data_type = 'BINARY' THEN CONCAT('BINARY(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'CHAR' THEN CONCAT('CHAR(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'DATETIME2' THEN CONCAT('DATETIME2(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'DATETIMEOFFSET' THEN CONCAT('DATETIMEOFFSET(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'DECIMAL' THEN CONCAT('DECIMAL(', toa.target_attribute_precision, ',',  target_attribute_scale, ')')
						 WHEN toa.target_attribute_data_type = 'NUMERIC' THEN CONCAT('NUMERIC(', toa.target_attribute_precision, ',',  target_attribute_scale, ')')
						 WHEN toa.target_attribute_data_type = 'NCHAR' THEN CONCAT('NCHAR(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'NVARCHAR' THEN CONCAT('NVARCHAR(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'VARBINARY' THEN CONCAT('VARBINARY(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'VARCHAR' THEN CONCAT('VARCHAR(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'TIME' THEN CONCAT('TIME(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'FLOAT' THEN CONCAT('FLOAT(', toa.target_attribute_precision, ')')
						 WHEN toa.target_attribute_data_type = 'REAL' THEN CONCAT('REAL(', toa.target_attribute_precision, ')')
						 ELSE toa.target_attribute_data_type
						 END as syn_data_type
				,	CASE WHEN toa.target_attribute_is_active  = 'Y' 
						 THEN 0 ELSE 1 -- V1.3 switched T/F around. ignore opposite to active. Temporarily used INT for summing used later on.
						 END AS ignore
				,	CASE WHEN toa.target_attribute_is_pk = 'Y' 
						 THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) 
						 END AS is_primary_key_col
				,	CASE WHEN toa.target_attribute_is_BusinessKey = 'Y' 
						 THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) 
						 END AS is_business_col
				,	et.[Encryption_Type] AS adb_encryption_type
				,	toa.target_attribute_PII_Function AS syn_pii_function
				,	CASE WHEN toa.target_attribute_is_historystitch = 'Y' 
					THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT)
					END AS is_history_stitch_col --V1.5
				,	CASE WHEN toa.target_attribute_is_historystitch_sortkey = 'Y'
					THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT)
					END AS is_history_stitch_sort_col --V1.5
				,	CASE WHEN toa.target_attribute_is_null = 'Y'
					THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT)
					END AS nullable --V1.5
				,	CASE WHEN ss.SparkSQLDatatype = 'STRING' THEN ' ' 
						   WHEN ss.SparkSQLDatatype IN ('DOUBLE', 'BIGINT', 'FLOAT', 'DECIMAL', 'BOOLEAN', 'TINYINT', 'INT', 'SMALLINT') THEN '0'
						   WHEN ss.SparkSQLDatatype = 'TIMESTAMP' THEN '1900-01-01 00:00:00'
						   WHEN ss.SparkSQLDatatype = 'DATE' THEN '1900-01-01'
						   WHEN ss.SparkSQLDatatype IS NULL THEN NULL
					END AS default_value --V1.5
				,	toa.target_attribute_Integration_KeyName AS integration_key_names
				,	CASE WHEN toa.target_attribute_array_name IS NOT NULL THEN CONCAT(toa.target_attribute_array_name, '_Json') 
					ELSE NULL 
					END AS array_name --V1.3
				,	toa.target_attribute_is_target_column AS target_column--V1.4
				INTO #TargetObjectColumns
				FROM [ctlfwk].[target_objects_attributes] toa 
				INNER JOIN [ctlfwk].[target_objects] [to] ON toa.target_object_id = [to].target_object_id
				--INNER JOIN ctlfwk.source_app sa ON [to].source_app_id = sa.source_app_id  
				--INNER JOIN Ctlfwk.business_unit bu ON bu.business_unit_id = sa.business_unit_id 
				LEFT JOIN ctlfwk.Encryption_Types et ON toa.Encryption_TypeID = et.Encryption_TypeID 
				--INNER JOIN Ctlfwk.SourceSystemDatabaseName sdb ON sa.SourceSystemDatabaseName_ID = sdb.SourceSystemDatabaseName_ID --V1.2 Remove
				LEFT JOIN Ctlfwk.SourceSystemToSparkDataTypeMapping ss ON toa.target_attribute_data_type = ss.DataType   
				WHERE [to].target_object_name = @target_object_name --AND sa.source_app_id = @source_app_id
				AND [to].[Schema_Name] = @Schema_Name 
				AND [to].notebook_path = @notebook_path 
				AND [to].notebook_name = @notebook_name
				AND ss.DataSource = 'SQLSERVER'  --V1.2 Remove sourcesystemdatabase join and added SQLSERVER where clause as target_object datasource is SQLSERVER
				ORDER BY toa.target_attribute_seq ASC
			  	--SELECT * from #TargetObjectColumns

				/* V1.3 format the array_name details that are additional target_columns START */
				DECLARE @seq INT
				SELECT @seq = max(target_attribute_seq)+1 FROM #TargetObjectColumns 
				
				INSERT INTO #TargetObjectColumns
				SELECT
					NULL AS target_attribute_seq
					, array_name AS column_name
					, 'array<struct<'+STRING_AGG(Concat(column_name,':', adb_data_type), ',') WITHIN GROUP (ORDER BY target_attribute_seq)+'>>' AS adb_data_type
					, 'NVARCHAR(max)' AS syn_data_type --V1.8
					, CASE WHEN SUM(ignore) > 0 THEN 1 ELSE 0 END AS ignore
					, CAST(0 AS BIT) AS is_primary_key_col
					, CAST(1 AS BIT) AS is_business_col
					, NULL AS adb_encryption_type
					, NULL AS syn_pii_function
					, CAST(0 AS BIT) AS is_history_stitch_col --V1.5
					, CAST(0 AS BIT) AS is_history_stitch_sort_col --V1.5
					, CAST(1 AS BIT) AS nullable --V1.5
					, NULL AS default_value --V1.5
					, NULL AS integration_key_names
					, NULL AS array_name
					, 'Y' AS target_column
				FROM #TargetObjectColumns
				WHERE array_name IS NOT NULL
				GROUP BY array_name 

				UPDATE #TargetObjectColumns
				SET @seq = target_attribute_seq = @seq + 1
				WHERE target_attribute_seq IS NULL

				--SELECT * from #TargetObjectColumns

				/* V1.3 format the array_name details that are additional target_colums ENDS */

				/* format the required columns for JSON target_object_details */
				SELECT DISTINCT
					[to].target_object_name as [object_name]
				,   [to].[Schema_Name] as [schema_name]
				,	[sa].[source_app_code] as source_application_name --V2.0
				INTO #TargetObjectDetails 
				FROM [ctlfwk].[target_objects] [to]
				--INNER JOIN [ctlfwk].[target_objects_attributes] [toa] ON toa.target_object_id = [to].target_object_id --V1.2 Removed not used table
				INNER JOIN ctlfwk.source_app sa ON [to].source_app_id = sa.source_app_id  
				--INNER JOIN Ctlfwk.business_unit bu ON bu.business_unit_id = sa.business_unit_id
				WHERE [to].target_object_name = @target_object_name --AND sa.source_app_id = @source_app_id
				AND [to].[Schema_Name] = @Schema_Name 
				AND [to].notebook_path = @notebook_path 
				AND [to].notebook_name = @notebook_name

			 	--SELECT * from #TargetObjectDetails

				--V1.6 Removed
				--SET @error_flag = 'Success'
				--SET @error_message = 'Success - JSON has been created'


				/* format query to JSON */
				SELECT --@error_flag AS Error_Flag, @error_message AS Error_Message, --V1.6 Removed
					(SELECT 
						[object_name]
					,	[schema_name] 
					,	[source_application_name] --V1.9
					, (SELECT
								column_name
							,	adb_data_type
							,	syn_data_type
							,	CASE WHEN ignore = 1
									 THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT)
									 END AS ignore --V1.3
							,	is_primary_key_col
							,	is_business_col
							,	adb_encryption_type
							,	syn_pii_function
							,	is_history_stitch_col
							,	is_history_stitch_sort_col
							,	nullable
							,	default_value
							, CASE WHEN integration_key_names IS NOT NULL
								   THEN JSON_QUERY (CONCAT('["', REPLACE(integration_key_names, '|', '","'), '"]')) --V1.1
								   ELSE JSON_QUERY('[]')
								   END AS integration_key_names
						FROM #TargetObjectColumns 
						WHERE target_column = 'Y' --V1.4
						ORDER BY target_attribute_seq ASC
						FOR JSON PATH, INCLUDE_NULL_VALUES  ) AS target_columns
				FROM #TargetObjectDetails 
				FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER) JsonSchema


			END TRY

			BEGIN CATCH
					
				SET @error_flag = 'Error'
				SET @error_message = ERROR_MESSAGE()

				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( @error_flag, @error_message , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 

				SELECT @error_flag AS Error_Flag, @error_message AS Error_Message 

			END CATCH

		END -- Return Value 0 

		 IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'getJsonTargetSchema' 
				FROM @ErrorUDT; 
				
				RAISERROR('sp_getJsonTargetSchema: ERROR - Refer to Process_Error Table .' ,17, 1) 
				
			END 
/*
EXEC [ctlfwk].[getJsonTargetSchema]
@schema_name = 'hugo_uplift'
,@notebook_path = '../templates/hugo'
,@notebook_name = 'test'
,@target_object_name ='Hugo_Member' 



*/
				  

END 
