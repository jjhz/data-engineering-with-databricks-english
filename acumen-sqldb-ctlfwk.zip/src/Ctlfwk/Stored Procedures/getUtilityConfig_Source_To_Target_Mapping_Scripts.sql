﻿
-- =============================================
-- Author:      <Author, , Name>
-- Create Date: <Create Date, , >
-- Description: <Description, , >
-- =============================================
CREATE PROCEDURE [ctlfwk].[getUtilityConfig_Source_To_Target_Mapping_Scripts]
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    -- Insert statements for procedure here



	TRUNCATE TABLE [ctlfwk].[Utility_Config_Source_To_Target_Mapping_Scripts]


	SELECT ROW_NUMBER()OVER(ORDER BY Source_Object ASC) AS row_num,*
	INTO #temp_sttm
	FROM [ctlfwk].[Utility_Config_Source_To_Target_Mapping]


	-- Source_To_Target_Mapping
	DECLARE @count_sttm int;

	SELECT @count_sttm = COUNT(*)
	FROM #temp_sttm

	DECLARE @i int = 1
	DECLARE @sql_sttm varchar(MAX), @Target_Schema varchar(100), @Target_Object varchar(100), @Target_Object_Type varchar(100),
	@Source_Schema varchar(100), @Source_Object varchar(100), @Source_BK_Column_Sequence varchar(100), @Source_BK_Column varchar(100),
	@Query_Filter varchar(4000), @Truncate_Flag varchar(100), @Hash_Key_Name varchar(100), @Key_Source_Name varchar(100),
	@Load_Type varchar(100), @Change_Detection_Column varchar(100)



	WHILE @i <= @count_sttm
	BEGIN
		SELECT @Target_Schema = Target_Schema
		, @Target_Object = Target_Object
		, @Target_Object_Type = Target_Object_Type
		, @Source_Schema = Source_Schema
		, @Source_Object = Source_Object
		, @Source_BK_Column_Sequence = Source_BK_Column_Sequence
		, @Source_BK_Column = Source_BK_Column
		, @Query_Filter = COALESCE(Query_Filter,'')
		, @Truncate_Flag = Truncate_Flag
		, @Hash_Key_Name = COALESCE(Hash_key_Name,'')
		, @Key_Source_Name = COALESCE(Key_Source_Name,'')
		, @Load_Type = Load_Type
		, @Change_Detection_Column = Change_Detection_Column
		FROM #temp_sttm
		WHERE row_num = @i

		SET @sql_sttm = 'EXEC [ctlfwk].[sp_add_Source_To_Target_Mapping] @Target_Schema = '''+@Target_Schema+''', @Target_Object = '''+@Target_Object+''', @Target_Object_Type ='''+@Target_Object_Type+''',@Source_Schema ='''+@Source_Schema+''' ,@Source_Object ='''+@Source_Object+''',@Source_BK_Column_Sequence ='''+@Source_BK_Column_Sequence+''' ,@Source_BK_Column = '''+@Source_BK_Column+''',@Query_Filter ='''+@Query_Filter+''',@Truncate_Flag = '''+@Truncate_Flag+''',@Hash_key_Name = '''+@Hash_Key_Name+''',@Key_Source_Name = '''+@Key_Source_Name+''',@load_type='''+@Load_Type+''',@Change_Detection_Column='''+@Change_Detection_Column+''';
'

		INSERT INTO [ctlfwk].[Utility_Config_Source_To_Target_Mapping_Scripts](utility_exec_script)
		VALUES(@sql_sttm);


		SET @i = @i + 1

	END



	DROP TABLE #temp_sttm



END