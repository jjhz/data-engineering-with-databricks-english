﻿
-- =============================================
-- Author:		Deloitte
-- Create date: 2020-07-08
-- Description:	Insert execution status record if it does not exist
-- =============================================
CREATE PROCEDURE [Ctlfwk].[sp_add_execution_status]
(
	@execution_status_name varchar(10)
)
AS
BEGIN

set nocount on;
    declare @trancount int;
    set @trancount = @@trancount;
    begin try
	print 'Inserting ' + @execution_status_name;
        if @trancount = 0
            begin transaction
        else
            save transaction sp_add_execution_status;

	
	-- check if record exists, if not, insert the row
	if (not exists (select 1 from [ctlfwk].[execution_status] where [execution_status_name] = @execution_status_name))
	begin
		insert into [ctlfwk].[execution_status]
		(
			[execution_status_name]
		,	[start_date_time]
		,	[end_date_time]
		)
		values
		(
			@execution_status_name
		,	GETDATE()
		,	'9999-12-31'
		)
	end
	else
		print 'Entry already exists for ' + @execution_status_name

	if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_execution_status;

        raiserror ('Ctlfwk.sp_add_execution_status: %d: %s', 16, 1, @error, @message) ;
    end catch

end
GO


