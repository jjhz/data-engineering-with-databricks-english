﻿CREATE PROCEDURE [ctlfwk].[sp_Ops_UpdatePoolConfigurationId]
(
	--V1.1 Modified the order of Input 
	@stream_name varchar(200) =NULL --V1.2
,	@process_name varchar(200) =NULL
,	@PoolName varchar(max)
,	@NoOfWorkers int =NULL
)
AS

-- =============================================
-- Usage Comments if Any :Used to update PoolConfigurationDetailsID and NoOfWorkers for process table  
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	25-03-2022						Niharika S				 1.0				InitialVersion
--	14/04/2022						Niharika S				 1.1				Adding null validation for process name and pool name
--	12/05/2022						Sakshi S				 1.2				Adding stream name as input paramater and updating the validation conditions to use either process name or stream name or both

-- =============================================

BEGIN 
	declare @ErrorUDT [ctlfwk].[ErrorUDT]
	declare @Returnvalue INT = 0
	declare @PoolConfigurationDetailsID int
	declare @PreviousNoOfWorkers int
	declare @PreviousPoolName VARCHAR(200)
	--V1.2
	IF(@stream_name IS NOT NULL OR LEN(@stream_name) > 0)
		BEGIN
			IF NOT EXISTS ( SELECT 1 
								FROM ctlfwk.stream 
								WHERE stream_name = @stream_name ) 
					BEGIN 
						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						VALUES ('Error', 'Stream does not exist',	(N'{'+CONCAT('"Stream ": "',COALESCE( @stream_name ,''))  +'" ' 
																			+'}' )
						);

						SET @Returnvalue =2 ;
					END  
		END

	IF(@process_name IS NOT NULL OR LEN(@process_name) > 0)
		BEGIN
			IF NOT EXISTS ( SELECT 1 
								FROM ctlfwk.process 
								WHERE process_name = @process_name ) 
					BEGIN 
						INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
						VALUES ('Error', 'Process_Name does not exist',	(N'{'+CONCAT('"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
																			+'}' )
						);

						SET @Returnvalue =2 ;
					END  
		END
	--V1.2
	IF ((@process_name IS NULL OR LEN(@process_name) = 0) AND (@stream_name IS NULL OR LEN(@stream_name) = 0))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', ' Stream and Process name both cannot be NULL or Blank', (N'{'+CONCAT('"Stream ": "',COALESCE( @stream_name ,''),'"Process_Name": "',COALESCE( @process_name ,''))  +'" ' 
																						+'}' )
			);

			SET @Returnvalue =2 ;
		END

	IF (@PoolName IS NULL OR LEN(@PoolName) = 0) --V1.1
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', ' PoolName cannot be NULL or Blank', (N'{'+CONCAT('"PoolName": "',COALESCE( @PoolName ,''))  +'" ' 
																						+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	IF NOT EXISTS ( SELECT 1 
						FROM ctlfwk.PoolConfigurationDetails 
						WHERE PoolName = @PoolName ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'PoolName does not exist',	(N'{'+CONCAT('"PoolName": "',COALESCE( @PoolName ,''))  +'" ' 
																	+'}' )
				);

				SET @Returnvalue =2 ;
			END  

	IF @Returnvalue = 2 
			RAISERROR('sp_Ops_UpdatePoolConfigurationId: ERROR - Refer to Process_Error Table .', 16, -1)
	--V1.2
	IF ((@process_name IS NOT NULL OR LEN(@process_name) > 0) AND (@stream_name IS NOT NULL OR LEN(@stream_name) > 0))
		BEGIN
			SELECT @PreviousNoOfWorkers = NoOfWorkers 
			FROM ctlfwk.process WHERE process_name = @process_name
			AND stream_id= (select stream_id from ctlfwk.stream where stream_name=@stream_name)
		END
	ELSE
		BEGIN
			SELECT @PreviousNoOfWorkers = NoOfWorkers 
			FROM ctlfwk.process WHERE process_name = @process_name
			OR stream_id= (select stream_id from ctlfwk.stream where stream_name=@stream_name)
		END

	IF (@NoOfWorkers  IS NULL )  
			BEGIN 
				SET @NoOfWorkers = @PreviousNoOfWorkers
			END 

	IF @Returnvalue = 0
			BEGIN --Returnvalue0
				BEGIN TRY
					BEGIN TRANSACTION 

						SET @PoolConfigurationDetailsID=(Select PoolConfigurationDetailsID from ctlfwk.PoolConfigurationDetails where PoolName = @PoolName)
					
					IF ((@process_name IS NOT NULL OR LEN(@process_name) > 0) AND (@stream_name IS NOT NULL OR LEN(@stream_name) > 0))
						BEGIN
							UPDATE p
							SET
								  p.PoolConfigurationDetailsID = @PoolConfigurationDetailsID
								, NoOfWorkers = @NoOfWorkers
								, Last_Modified_Datetime =SYSDATETIME()
								, Last_Modified_By = ORIGINAL_LOGIN()
							FROM ctlfwk.process p
							WHERE process_name = @process_name  AND stream_id= (select stream_id from ctlfwk.stream where stream_name=@stream_name)
						END
					ELSE
						BEGIN
							UPDATE p
							SET
								  p.PoolConfigurationDetailsID = @PoolConfigurationDetailsID
								, NoOfWorkers = @NoOfWorkers
								, Last_Modified_Datetime =SYSDATETIME()
								, Last_Modified_By = ORIGINAL_LOGIN()
							FROM ctlfwk.process p
							WHERE process_name = @process_name  OR stream_id= (select stream_id from ctlfwk.stream where stream_name=@stream_name)
						END
					COMMIT TRANSACTION;
				END TRY

			BEGIN CATCH
		
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
					VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION

			END CATCH
			END --Returnvalue0

	IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
				BEGIN
					INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
					SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_Ops_UpdatePoolConfigurationId' 
					FROM @ErrorUDT; 
				
					SELECT * FROM @ErrorUDT 
				END
/* 
EXEC [ctlfwk].[sp_Ops_UpdatePoolConfigurationId] 
	@stream_name='Hugo_U_Gold_Reference_Replication_Load'
,	@process_name = 'Hugo_U_CoreSchema_Reference'
,	@PoolName = 'memory_optimised_8'
,	@NoOfWorkers = 2

*/

END 
 


