﻿-- =============================================
-- Get the source app name and all attributes of objects owned by the given stream's source app.
-- Results are ordered by source object id and object attributes sequence.
-- =============================================
CREATE PROCEDURE [Ctlfwk].[sp_get_stream_object_attributes]
(
	@stream_name varchar(255)
)
AS
BEGIN

    WITH stream_app AS (
      SELECT source_app_id
      FROM Ctlfwk.stream 
      WHERE stream_name = @stream_name
    ),
    app_name AS (
      SELECT source_app_name
      FROM Ctlfwk.source_app
      WHERE source_app_id = (SELECT * FROM stream_app)
    )
    SELECT 
      (SELECT * FROM app_name) AS source_app_name,
      source_object_id,
      source_object_name,
      load_type_code,
      load_type_description,
      source_object_attribute_name,
      source_object_attribute_seq,
      source_object_attribute_data_type,
      Column_IS_Null,
      Column_IS_PrimaryKey,
      Column_IS_PII
    FROM 
      Ctlfwk.vw_source_objects_attributes
    WHERE source_object_id IN (
      SELECT 
        source_object_id
      FROM 
        Ctlfwk.source_objects
      WHERE source_app_id = (SELECT * FROM stream_app)
    )
    ORDER BY source_object_id, source_object_attribute_seq;

END