﻿ CREATE  PROCEDURE [ctlfwk].[sp_add_SourceToIncoming_FilePath_Dtls]
(
	@source_app_code varchar(6)
,	@source_object_name varchar(100)
,	@load_type_code varchar(5)
,   @source_file_path varchar(200)
)
AS
-- =============================================
-- Description: Adds and updates records in ctlfwk.sp_add_SourceToIncoming_FilePath_Dtls table
--
-- Parameters:
--   @source_app_code - unique source app code from ctlfwk.source_app
--   @source_object_name - name of source object
--	 @load_type_code - unique load type code from ctlfwk.load_types
--   @source_file_path - relative filepath of the source file

-- Usage Comments if Any :
--	DATE							ChangesMadeBy			VERSION				COMMENTS  
--	04-05-2022						Deloitte				 1.0				InitialVersion
-- =============================================

BEGIN


set nocount on;
--V1.2

	-- check if record exists, if not, insert the row
	-- source object could have multiple load types
	
	declare @ErrorUDT [ctlfwk].[ErrorUDT]
	declare @source_app_id int;
	declare @load_type_id int;
	declare @source_object_id int;
	declare @SourceToIncoming_FilePath_Dtls_ID int =NULL ;
	declare @Returnvalue int=0;

	-- Table Variable to fetch ID's by doing Looukups to Input into SourceToIncoming_FilePath_Dtls  Table 
	declare @FinalValues AS TABLE 
			 ( 
				  source_app_id INT 
				, source_object_id INT 
				, load_type_id INT 
				, source_file_path varchar(200) 
				, start_date_time datetime
				, end_date_time   datetime
			  )	
--===========================-- Input Paramter Validation and  Setting Return Value ==================================================== 
		
		--V1.2
		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app WHERE source_app_code = @source_app_code ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','sp_add_SourceToIncoming_FilePath_Dtls : source_app_code does not exist' , (N'{' + CONCAT('"source_app_code": "',COALESCE(@source_app_code,'' ))	+'" '
																	 +',' +CONCAT('"source_object_name": "',COALESCE(@source_object_name, ''))	+'" '
																	 + '}')
						) ;
				SET @Returnvalue =2 ;
			END 

		IF NOT EXISTS ( SELECT 1 FROM ctlfwk.load_types WHERE load_type_code = @load_type_code ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error','sp_add_SourceToIncoming_FilePath_Dtls : load_type_code does not exist' ,  (N'{' +',' +CONCAT('"load_type_code ": "',COALESCE(@load_type_code, ''))	+'" '
																	 + CONCAT('"source_object_name": "',COALESCE(@source_object_name,'' ))	+'" '
																	 +',' +CONCAT('"source_app_code": "',COALESCE(@source_app_code, ''))	+'" '
																     + '}')  
						 ) ;
				SET @Returnvalue =2 ;
			END 

		IF NOT EXISTS ( SELECT 1 
						FROM ctlfwk.source_objects so
						INNER JOIN ctlfwk.source_app sa ON so.source_app_id = sa.source_app_id 
						WHERE so.source_object_name = @source_object_name AND sa.source_app_code = @source_app_code ) 
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'The provided Source_App_Code and Source_Object_Name does not exist together',	
						(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
						+','+CONCAT('"Source_Object_Name": "',COALESCE( @source_object_name ,''))  +'" '
						+'}' )
				);

				SET @Returnvalue =2 ;
		END  

		IF (@source_file_path IS NULL OR LEN(@source_file_path) = 0) --V1.3
			BEGIN 
				INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
				VALUES ('Error', 'Source file path cannot be NULL or Blank', (N'{'+CONCAT('"source_app_code": "',COALESCE( @source_app_code ,''))  +'" ' 
																						+','+CONCAT('"source_object_name": "',COALESCE( @source_object_name ,''))  +'" '
																						 +','+CONCAT('"source_file_path": "',COALESCE( @source_file_path ,''))  +'" '
																						+'}' )
						);

				SET @Returnvalue =2 ;
			END 

--===========================-- Input Paramter Validation and  Setting Return Value ENDS ====================================================
	--V2.0
	IF @Returnvalue = 2 
		RAISERROR('sp_add_SourceToIncoming_FilePath_Dtls: ERROR - Refer to Process_Error Table .', 16, -1) 
--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				BEGIN TRY 
					BEGIN TRANSACTION
			               
						  INSERT INTO @FinalValues
						  (
							  source_app_id
							, source_object_id 
							, load_type_id 
							, source_file_path 
							, start_date_time 
							, end_date_time 
						  )	  
						  SELECT 
							   sa.source_app_id
							 , so.source_object_id 
							 , lt.load_type_id
							 , @source_file_path
							 , GETDATE()
							 , '9999-12-31'
						  FROM [ctlfwk].[source_objects] so 
						  left join [ctlfwk].[load_types] lt ON lt.load_type_code = @load_type_code
						  left join [ctlfwk].[source_app] sa on sa.[source_app_id] = so.[source_app_id]
						  WHERE sa.source_app_code =@source_app_code 
						    AND so.source_object_name = @source_object_name
						--Debug 
						-- SELECT * from @FinalValues 
		   --=======================================================================================================================
						 --Check if source_app_id+source_object_id+load_type_id Already Exists fetch the SourceToIncoming_FilePath_Dtls ID to identify the Insert/Update Action 

						 SELECT @SourceToIncoming_FilePath_Dtls_ID =SourceToIncoming_FilePath_Dtls_ID 
						 FROM  @FinalValues fv 
						 LEFT JOIN ctlfwk.SourceToIncoming_FilePath_Dtls p 
						   ON fv.source_app_id = p.source_app_id 
						      AND fv.source_object_id = p.source_object_id 
							  AND fv.load_type_id = p.load_type_id
						--Debug 
						--SELECT @SourceToIncoming_FilePath_Dtls_ID 
			 --================================Update  Process Table ==============================================			 
						 --Capturing the Merge Action into #MergeActions Table 
						 
						 DROP TABLE IF EXISTS #MergeActions ;
						 CREATE TABLE #MergeActions ([Action] VARCHAR(10),SourceToIncoming_FilePath_Dtls_ID INT  ) 
						 INSERT INTO #MergeActions ([Action],SourceToIncoming_FilePath_Dtls_ID)
						 SELECT [Action]  ,SourceToIncoming_FilePath_Dtls_ID
						 FROM ( 
			 
						 MERGE ctlfwk.SourceToIncoming_FilePath_Dtls as tgt 
						 USING @FinalValues as source ON ( tgt.SourceToIncoming_FilePath_Dtls_ID =ISNULL(@SourceToIncoming_FilePath_Dtls_ID,0)						  
														  )
						 WHEN MATCHED THEN 
							  UPDATE 
							  SET   tgt.source_file_path =source.source_file_path
								  , tgt.start_date_time = source.start_date_time
								  , tgt.end_date_time =  source.end_date_time
								  , tgt.Last_Modified_Datetime =SYSDATETIME()
								  , tgt.Last_Modified_By = ORIGINAL_LOGIN()

						 WHEN NOT MATCHED THEN 
							 INSERT ( source_app_id,source_object_id,load_type_id,source_file_path,start_date_time,end_date_time)
							 VALUES ( 
									  source.source_app_id
									, source.source_object_id
									, source.load_type_id
									, source.source_file_path
									, source.start_date_time
									, source.end_date_time
           						   )
						   
						OUTPUT
							 $action as Action ,
						   inserted.SourceToIncoming_FilePath_Dtls_ID
						  ) MergeOutput 
					--	SELECT * FROM #MergeActions ;    
				COMMIT TRANSACTION	 
			END TRY
        
	  
       
		BEGIN CATCH 
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10),(ERROR_LINE())) + '"}')); 
				ROLLBACK TRANSACTION 
		END CATCH 
	   END  --ReturnValue 0

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) --V1.2
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_SourceToIncoming_FilePath_Dtls' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
		  END 
	   ELSE 
	      SELECT CONCAT('SourceToIncoming_FilePath_Dtls ID ',+CONVERT(VARCHAR,SourceToIncoming_FilePath_Dtls_ID)  + ' Is '+Action +'D')  FROM #MergeActions
	 
END

