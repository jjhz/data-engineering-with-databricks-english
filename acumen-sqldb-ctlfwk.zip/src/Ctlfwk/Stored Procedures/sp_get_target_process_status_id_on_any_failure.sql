﻿CREATE PROCEDURE [ctlfwk].[sp_get_target_process_status_id_on_any_failure]
( 
  @stream_name	VARCHAR(255) , --V1.2
  @process_type	VARCHAR(20) ,
  @object_name	VARCHAR(100),
  @sourceapp_name	VARCHAR(100),
  @notebook_name VARCHAR(250)= NULL,
  @notebook_Path VARCHAR(250)= NULL,
  @Schema_name VARCHAR(50) --V1.4
)
AS
/*=================================================================================================
-- Usage Comments if Any :Used to Fetch get_process_status_id_on_any_failure and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	07-03-2022						Vikas P					 1.1				newly Added  
	18-03-2022						Tammy H					 1.2			    New req: Stream_name raised to be varchar(255)
	20-04-2022						Sakshi S				 1.3			    Added Schema_name as parameter
	21-04-2022                      Sheela R                 1.4                Added Process Type Conditions in the code 
 ================================================================================================= */ 

--v1.2
BEGIN
	DECLARE @Target_object_Name_Check int
	-- Check for target  Layer 
	IF @process_type != 'Ref_Replication' OR @process_type IS NULL  --V1.4
		SELECT @Target_object_Name_Check=Count(1) 
		FROM Ctlfwk.target_objects as so 
		JOIN Ctlfwk.source_app as sa ON so.source_app_id=sa.source_app_id
		JOIN Ctlfwk.process p ON p.target_object_id  =so.target_object_id
		JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
		JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
		WHERE  pt.process_type =@process_type--v1.3
		AND    so.target_object_name=@object_name
		AND    sa.source_app_name=@sourceapp_name
		AND    st.stream_name=@stream_name
		AND so.notebook_name=@notebook_name
		AND so.notebook_path=@notebook_Path
		AND so.Schema_Name = @Schema_Name --V1.4

    IF @process_type  = 'Ref_Replication' OR @process_type IS NULL  --V1.4 
		SELECT @Target_object_Name_Check=Count(1) 
		FROM Ctlfwk.target_objects as so 
		JOIN Ctlfwk.source_app as sa ON so.source_app_id=sa.source_app_id
		JOIN Ctlfwk.process p ON p.target_object_id  =so.target_object_id
		JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
		JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
		WHERE  pt.process_type =@process_type--v1.3
		AND    so.target_object_name=@object_name
		AND    sa.source_app_name=@sourceapp_name
		AND    st.stream_name=@stream_name
		AND so.Schema_Name = @Schema_Name --V1.4

IF  @Target_object_Name_Check=0
	BEGIN 
		RAISERROR('Process not found ERROR - target_objects is not linked with provided parameters' ,17,1)
	END

	
IF @Target_object_Name_Check>=1  AND @process_type != 'Ref_Replication'  --V1.4
	BEGIN
	SELECT Max(process_status_id) AS process_status_id
			FROM  (
				  SELECT 
                     CASE
                            WHEN pt.process_type=@process_type THEN ps.process_status_id
                            WHEN pt.process_type is null  THEN NULL 
                     END AS process_status_id
              FROM   ctlfwk.process p
              JOIN   ctlfwk.process_status AS ps  ON     ps.process_id=p.process_id
              JOIN   ctlfwk.target_objects AS s   ON     s.target_object_id=p.target_object_id
              JOIN   ctlfwk.source_app AS sa      ON     sa.source_app_id=s.source_app_id
              JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
              JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
              WHERE  pt.process_type =@process_type
              AND    s.target_object_name=@object_name
              AND    sa.source_app_name=@sourceapp_name
              AND    st.stream_name=@stream_name
			  AND	 s.notebook_name=@notebook_name
			  AND	 s.notebook_path=@notebook_Path
			  AND	 s.Schema_Name = @Schema_Name --V1.4
		) as s
	END

	IF @Target_object_Name_Check>=1  AND @process_type  = 'Ref_Replication'   --V1.4
	BEGIN
	SELECT Max(process_status_id) AS process_status_id
			FROM  (
				  SELECT 
                     CASE
                            WHEN pt.process_type=@process_type THEN ps.process_status_id
                            WHEN pt.process_type is null  THEN NULL 
                     END AS process_status_id
              FROM   ctlfwk.process p
              JOIN   ctlfwk.process_status AS ps  ON     ps.process_id=p.process_id
              JOIN   ctlfwk.target_objects AS s   ON     s.target_object_id=p.target_object_id
              JOIN   ctlfwk.source_app AS sa      ON     sa.source_app_id=s.source_app_id
              JOIN   ctlfwk.stream AS st          ON     st.stream_id=p.stream_id
              JOIN   ctlfwk.process_type AS pt    ON     pt.process_type_id=p.process_type_id
              WHERE  pt.process_type =@process_type
              AND    s.target_object_name=@object_name
              AND    sa.source_app_name=@sourceapp_name
              AND    st.stream_name=@stream_name
			  AND	 s.Schema_Name = @Schema_Name --V1.4
		) as s
	END
	
END


