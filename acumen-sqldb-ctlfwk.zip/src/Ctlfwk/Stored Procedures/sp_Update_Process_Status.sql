﻿
CREATE Proc [ctlfwk].[sp_Update_Process_Status]
(
@process_status_id VARCHAR(100),
@data_Doc_Link VARCHAR(max) = NULL ,
@Src_File_count VARCHAR(200) = NULL 
)
AS 


/*===============================================================================================================================================================================
-- Usage Comments if Any :Used to Fetch Source Job Details and is called in ADF 
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	10-11-2021						Vikas P 				     1.0				InitialVersion
	23-11-2021						Vikas P                      1.1                changes to update Filecount and src_file_count in Process status 
	24-03-2022						Tammy H					     1.2				Added milliseconds to timestamps: fff
 ================================================================================================================================================================================ */  

SET NOCOUNT ON
 
BEGIN TRY
	DECLARE 
		@exectution_status_id	INT,
		@ret_status VARCHAR(100),
		@Additional_Data        NVARCHAR(4000)    --V1.1

	IF @process_status_id IS NULL
		BEGIN
		    SET @ret_status ='ERROR - Process_instance_id is null.'
			SET @Additional_Data = N'{"Process_Status_Id": ""' + ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}' --V1.2
			RAISERROR('Data_Doc_Update_ERROR - Process_instance_id is null' ,16,-1)

    END
	
	IF NOT EXISTS (SELECT TOP 1 process_id FROM Ctlfwk.process_status where process_status_id=@process_status_id) 
		BEGIN
		    SET @ret_status ='ERROR - Process is not exit in process table.'
			SET @Additional_Data = N'{"Process_Status_Id": ""' + ', "Process_Stop_TimeStamp" : "' + format(getdate(),'yyyy-MM-dd HH:mm:ss.fff') + '"}'  --V1.2
			RAISERROR('Data_Doc_Update_ERROR - Process is not exit in process table.' ,16,-1)

    END
--v1.2
--Update process with data doc url
   If @data_Doc_Link IS NOT NULL 
   BEGIN 
	UPDATE [ctlfwk].[process_status]
				SET 
					data_doc_link = NULLIF(@data_Doc_Link,'')
				WHERE 
					process_status_Id = @process_status_id
	END
	--V1.2 
--Update process with src_file_count

    If @Src_File_count IS NOT NULL 

   BEGIN 
	
	UPDATE [ctlfwk].[process_status]
				SET 
					src_file_count = NULLIF(@src_file_count,'')
				WHERE 
					process_status_Id = @process_status_id
	END
   --V1.2
END TRY


BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()

	--V1.1
	INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  )  
	SELECT 'Error' ,@ret_status ,@Additional_Data ,'sp_stop_process' ;

	RAISERROR	('Exception Details :
					Error Number		:	%d
					Error Message		:	%d
					Affected Procedure	:	%d
					Affected Line Number:	%d',
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;
