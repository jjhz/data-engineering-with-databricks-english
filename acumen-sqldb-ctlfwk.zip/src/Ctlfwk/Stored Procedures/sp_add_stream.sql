﻿CREATE PROCEDURE [Ctlfwk].[sp_add_stream]
( 
  @source_app_code VARCHAR(100), 
  @stream_name VARCHAR(255), --V1.4
  @stream_description VARCHAR(255),
  @restart_from_beginning bit = 0
)
AS

/*=============================================
-- Author:      Deloitte
-- Create date: 20/07/2020
-- Description: Adds and updates records in ctlfwk.stream table
--
-- Parameters:
--   @source_app_code - unique source app code from ctlfwk.source_app
--   @stream_name - name of stream
--	 @stream_description - description of stream
--	 @restart_from_beginning - 

-- Validations:
--   @source_app_code - must exist in ctlfwk.source_app
--   @stream_name - can't be NULL or Blank
--	 @stream_description - can't be NULL or Blank
--   @restart_from_beginning - BIT 1/0. If User gives NULL/Blank, value is 0.


-- Usage Comments if Any :
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	20-07-2020						Deloitte				 1.0				InitialVersion
	07-10-2021						Tammy H					 1.1				Adding validations for all parameters and inserting errors [ctlfwk].[process_errors] 
																				and key Input Parameters of Error as JSON in addiotnal_messages
																				and capturing actions
	10-01-2022                     Sheela R                  1.2                Updated Restart Flag to 1 instead of 0 
	02-02-2022						Tammy H					 1.3				Add Raise Error
	18-03-2022						Tammy H					 1.4			    New req: Stream_name and stream_description raised to be varchar(255)
-- ===================================================================================================================================================  */

BEGIN

set nocount on;
 --   declare @trancount int;
 --   set @trancount = @@trancount;
 --   begin try
	--print 'Inserting ' + @source_app_code + ', ' + @stream_name ;
 --       if @trancount = 0
 --           begin transaction
 --       else
 --           save transaction sp_add_stream;


	declare @stream_id int;
	declare @source_app_id int;
	-- V1.1 Table Variable to Capture Error 
	declare @ErrorUDT [ctlfwk].[ErrorUDT] 
	declare @Returnvalue INT = 0 --Success 

 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 
 	IF NOT EXISTS ( SELECT 1 FROM ctlfwk.source_app WHERE source_app_code = @source_app_code ) 
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Source_App_Code does not exist',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																+','+CONCAT('"Stream_Name": "',COALESCE( @stream_name ,''))  +'" '
																+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	IF (@stream_name IS NULL OR LEN(@stream_name) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Stream_Name cannot be NULL or Blank',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																+','+CONCAT('"Stream_Name": "',COALESCE( @stream_name ,''))  +'" '
																+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	IF (@stream_description IS NULL OR LEN(@stream_description) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Stream_Description cannot be NULL or Blank',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																+','+CONCAT('"Stream_Name": "',COALESCE( @stream_name ,''))  +'" '
																+','+CONCAT('"Stream_Description": "',COALESCE( @stream_description ,''))  +'" '
																+'}' )
			);

			SET @Returnvalue =2 ;
		END 

	-- If user gives NULL/Blank, let the value be 0
	IF (@restart_from_beginning IS NULL OR LEN(@restart_from_beginning) = 0)
		BEGIN 
			SET @restart_from_beginning = 1 ;  --V1.2  Setting Restart to 1 as the stream will always restrart from beginning . 
		END 

	-- Precaution check. Since restart_from_beginning is BIT, SQL should auto convert values to 1 or 0 unless it is a NULL, which is the previous validation. So this error should not occut at all.
	IF (@restart_from_beginning NOT IN (1,0))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'Restart_From_Beginning can only have values 1 or 0',	(N'{'+CONCAT('"Source_App_Code": "',COALESCE( @source_app_code ,''))  +'" ' 
																+','+CONCAT('"Stream_Name": "',COALESCE( @stream_name ,''))  +'" '
																+','+CONCAT('"Restart_From_Beginning": "',COALESCE( @restart_from_beginning ,''))  +'" '
																+'}' )
			);

			SET @Returnvalue =2 ;
		END 		





 --===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

  	-- V1.3
--	IF @Returnvalue = 2 
		

 	-- If No Errors
	IF @Returnvalue =0
		BEGIN --ReturnValue 0
			BEGIN TRY
				BEGIN TRANSACTION
					-- V1.1 Capturing the Action into #Actions Table 
					DROP TABLE IF EXISTS #ActionTable;
					CREATE TABLE #ActionTable (Act VARCHAR(10), Id INT)	
					
					if (not exists 
							(
								select 1 
								from [ctlfwk].[stream] s
								left join [ctlfwk].[source_app] sa on
									sa.source_app_id = s.source_app_id
								where 
									s.stream_name = @stream_name
								and sa.source_app_code = @source_app_code
							)
						)
						begin
							insert into [ctlfwk].[stream]
							(
								[stream_name]
							,	[stream_description]
							,	[source_app_id]
							,	[start_date_time]
							,	[end_date_time]
							,	[restart_from_beginning]
							)
							OUTPUT 'Inserted', inserted.stream_id
							INTO #ActionTable (Act, Id)
							select
								@stream_name
							,	@stream_description
							,	source_app_id
							,	GETDATE()
							,	'9999-12-31 00:00:00.000'
							,	@restart_from_beginning
							from [ctlfwk].[source_app]
							where
								source_app_code = @source_app_code
						end
					else
						begin
							set @stream_id = (
												select s.stream_id 
												from [ctlfwk].[stream] s
												left join [ctlfwk].[source_app] sa on
													sa.source_app_id = s.source_app_id
												where 
													s.stream_name = @stream_name
												and sa.source_app_code = @source_app_code
											)
							set @source_app_id = (select source_app_id from ctlfwk.source_app where source_app_code = @source_app_code)


							update ctlfwk.stream
							set
								stream_description = @stream_description,
								restart_from_beginning = @restart_from_beginning,
								Last_Modified_Datetime = SYSDATETIME(),
								Last_Modified_By = ORIGINAL_LOGIN()
							OUTPUT 'Updated', inserted.stream_id
							INTO #ActionTable (Act, Id)
							where
								stream_id = @stream_id
								and source_app_id = @source_app_id
								and end_date_time > GETDATE();

						end

				COMMIT TRANSACTION
			END TRY
			BEGIN CATCH
				--declare @error int, @message varchar(4000), @xstate int;
				--select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
				--if @xstate = -1
				--	rollback;
				--if @xstate = 1 and @trancount = 0
				--	rollback
				--if @xstate = 1 and @trancount > 0
				--	rollback transaction sp_add_stream;
				
				--V1.1
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}')); 
				ROLLBACK TRANSACTION 

				--raiserror ('Ctlfwk.sp_add_stream: %d: %s', 16, 1, @error, @message) ;
			END CATCH
		END -- ReturnValue 0

		--V1.1
		IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
			BEGIN
				INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
				SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_Stream' 
				FROM @ErrorUDT; 

				SELECT * FROM @ErrorUDT
				RAISERROR('sp_add_stream: ERROR - Refer to Process_Error Table .', 16, -1) --V1.3
			END 
		ELSE 
			SELECT CONCAT('Stream_Id ', + CONVERT(VARCHAR, Id)  + ' is '+ Act)  FROM #ActionTable 
END