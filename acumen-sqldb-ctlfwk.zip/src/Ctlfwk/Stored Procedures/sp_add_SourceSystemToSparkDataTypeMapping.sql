﻿CREATE PROCEDURE [Ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping]
(
	@DataSource varchar(100)
,	@DataType varchar(100)
,	@SparkSQLDatatype varchar(100)
,	@IsDateWithTimezone varchar(1)
)
AS

/* =========================================================================================================================================
-- Author:      Deloitte
-- Create date: 03/11/2021
-- Description: Adds and updates records in ctlfwk.SourceSystemToSparkDataTypeMapping table. 
				This stored procs will not allow the following below. Manual Insert/Updates will be required.
             
-- Parameters:
--   @DataSource 
--   @DataType 
--	 @SparkSQLDatatype 
--	 @IsDateWithTimezone - must be Y when DataType has timezone


-- Validations: 
--   @DataSource - can't be NULL or Blank
--   @DataType - can't be NULL or Blank
--	 @IsDateWithTimezone - only 'Y' or 'N'

-- Usage Comments if Any :
	DATE							ChangesMadeBy			VERSION				COMMENTS  
	03/11/2021						Niharika S				 1.0				InitialVersion
	02-02-2022						Tammy H					 1.1				Add Raise Error
-- ===================================================================================================================================================  */
BEGIN

set nocount on;
	 -- Error Validations Start 
	    declare @SourceSystemToSparkDataTypeMappingID INT ;
		declare @Actiontype varchar(100) ;     

		-- Table Variable to Capture Input Paramters 
		declare @InsertedParameterValues AS TABLE 
		(
			DataSource varchar(100)
		,	DataType varchar(100)
		,	SparkSQLDatatype varchar(100)
		,	IsDateWithTimezone varchar(1)
	   )
	   -- Table Variable to Capture Error 
		declare @ErrorUDT [ctlfwk].[ErrorUDT] 
		declare @Returnvalue INT = 0 --Success 

		-- Table Variable to fetch ID's by doing Looukups to Input into File_Specification_Type Table 
		declare @FinalValues AS TABLE 
				 (
						SourceSystemToSparkDataTypeMappingID INT IDENTITY (1,1)
					,	DataSource varchar(100)
					,	DataType varchar(100)
					,	SparkSQLDatatype varchar(100)
					,	IsDateWithTimezone varchar(1)
				  ) 



 --===========================-- Input Parameter Validation and Setting Return Value ==================================================== 

	IF (@DataSource IS NULL OR LEN(@DataSource) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', ' DataSource cannot be NULL or Blank', (N'{'+CONCAT('"DataSource": "',COALESCE( @DataSource ,''))  +'" ' 
																						+'}' )
			);

			SET @Returnvalue =2 ;
		END 


	IF (@DataType IS NULL OR LEN(@DataType) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'DataType cannot be NULL or Blank',	(N'{'+CONCAT('"DataType": "',COALESCE( @DataType ,''))  +'" ' 
																					+'}' )
			);

			SET @Returnvalue =2 ;
		END 

/*
	IF (@SparkSQLDatatype IS NULL OR LEN(@SparkSQLDatatype) = 0)
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', 'SparkSQLDatatype cannot be NULL or Blank',	(N'{'+CONCAT('"SparkSQLDatatype": "',COALESCE( @SparkSQLDatatype ,''))  +'" ' 
																					+'}' )
			);

			SET @Returnvalue =2 ;
		END 
*/

		IF (@IsDateWithTimezone NOT IN ('Y', 'N'))
		BEGIN 
			INSERT INTO @ErrorUDT (error_flag,error_message,additional_message )
			VALUES ('Error', ' IsDateWithTimezone can only be Y/N' , (N'{'+CONCAT('"IsDateWithTimezone": "',COALESCE( @IsDateWithTimezone ,''))  +'" ' 
																					+'}' )
				   ) ;
			SET @Returnvalue =2 ;
		END
--===========================-- Input Paramter Validation and  Setting Return Value ENDS  ==================================================== 

 	-- V1.1
	IF @Returnvalue = 2 
		RAISERROR('sp_add_SourceSystemToSparkDataTypeMapping: ERROR - Refer to Process_Error Table .', 16, -1)

--  If No Errors 
		IF @Returnvalue =0 
			BEGIN  --ReturnValue 0
				BEGIN TRY 
					BEGIN TRANSACTION
			
	 
	         
						INSERT INTO @InsertedParameterValues
						(  
						     DataSource
						   , DataType 
                           , SparkSQLDatatype 
                           , IsDateWithTimezone 
						)    
						VALUES 
						(
						     @DataSource
						   , @DataType 
                           , @SparkSQLDatatype 
                           , @IsDateWithTimezone 
						)    
--=======================================================================================================================
--Check if DataSource and DataType Already  Exists fetch the SourceSystemToSparkDataTypeMappingID to identify the Insert/Update Action 

						 SELECT @SourceSystemToSparkDataTypeMappingID  =SourceSystemToSparkDataTypeMappingID
                         FROM Ctlfwk.SourceSystemToSparkDataTypeMapping
                         WHERE DataSource = @DataSource AND DataType = @DataType

--================================Update  Process Table ==============================================			 
						 --Capturing the Merge Action into #MergeActions Table 
						 DROP TABLE IF EXISTS #MergeActions ;
						 CREATE TABLE #MergeActions ([Action] VARCHAR(10),SourceSystemToSparkDataTypeMappingID INT  ) 
						 INSERT INTO #MergeActions ([Action],SourceSystemToSparkDataTypeMappingID)
						 SELECT [Action]  ,SourceSystemToSparkDataTypeMappingID
						 FROM ( 
			 
						 MERGE ctlfwk.SourceSystemToSparkDataTypeMapping as tgt 
						 USING @InsertedParameterValues as source ON ( tgt.SourceSystemToSparkDataTypeMappingID =ISNULL(@SourceSystemToSparkDataTypeMappingID,0)						  
														  )
						 WHEN MATCHED THEN 
							  UPDATE 
							  SET  
								    tgt.SparkSQLDatatype =source.SparkSQLDatatype
								  , tgt.IsDateWithTimezone =source.IsDateWithTimezone
								  , tgt.last_modified_datetime =SYSDATETIME()
								  , tgt.last_modified_by = ORIGINAL_LOGIN()
 

						 WHEN NOT MATCHED THEN 
							 INSERT ( DataSource, DataType, SparkSQLDatatype, IsDateWithTimezone)
							 VALUES ( 
									  source.DataSource
									, source.DataType
									, source.SparkSQLDatatype
									, source.IsDateWithTimezone
           						   )
						   
						OUTPUT
							 $action as Action ,
						   inserted.SourceSystemToSparkDataTypeMappingID
						  ) MergeOutput 
					--	SELECT * FROM #MergeActions ;  
				COMMIT TRANSACTION	 
			END TRY
        
	  
       
		BEGIN CATCH 
				INSERT INTO @ErrorUDT(error_flag ,error_message ,additional_message ) 
				VALUES ( 'Error', ERROR_MESSAGE() , (N'{"' + ERROR_PROCEDURE() +  '" : "Line' + CONVERT(VARCHAR(10), ERROR_LINE()) + '"}'));
				ROLLBACK TRANSACTION 
		END CATCH 
	   END  --ReturnValue 0

	   IF EXISTS ( SELECT 1 FROM @ErrorUDT ) 
	      BEGIN 
			  INSERT INTO ctlfwk.process_errors (error_flag,error_description ,additional_data ,processing_module  ) 
			  SELECT error_flag ,error_message AS Error_Description,additional_message,  'sp_add_ SourceSystemToSparkDataTypeMapping' 
			  FROM @ErrorUDT; 

			  SELECT * FROM @ErrorUDT ;
		  END 
	   ELSE 
	      SELECT CONCAT('SourceSystemToSparkDataTypeMappingID ',+ CONVERT(VARCHAR, SourceSystemToSparkDataTypeMappingID)   + ' Is '+Action +'D')  FROM #MergeActions
	 
END


