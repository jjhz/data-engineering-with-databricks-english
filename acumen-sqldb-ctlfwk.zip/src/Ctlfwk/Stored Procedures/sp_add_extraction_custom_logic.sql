﻿CREATE PROCEDURE [ctlfwk].[sp_add_extraction_custom_logic]
	@extraction_custom_logic_code	VARCHAR(100)=NULL,
    @extraction_custom_logic_desc	VARCHAR(255)= NULL
AS
-- ==================================================================================================================================================
-- Description: This proc can be used to find the Stream, process and Pool Config details for a given object 
--	DATE						Author			         VERSION			COMMENTS  
--	28-11-2022					Shubham S.				 1.0				InitialVersion
-- =======================================================================================================================================*/
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    declare @trancount int;
    set @trancount = @@trancount;
    begin try
	print 'Inserting ' + @extraction_custom_logic_code;
        if @trancount = 0
            begin transaction
        else
            save transaction [sp_add_extraction_custom_logic];
	-- Inserting record ignoring if it already exists or not
	if (not exists (select 1 from [ctlfwk].[extraction_custom_logic] where [extraction_custom_logic_code] = @extraction_custom_logic_code))
	begin
	INSERT INTO [ctlfwk].[extraction_custom_logic]
          (                    
			[extraction_custom_logic_code],
            [extraction_custom_logic_desc],
			[start_date_time],
			[end_date_time],
			[last_modified_by],
			[last_modified_datetime]
          )
     VALUES 
          ( 
			 @extraction_custom_logic_code,
			 @extraction_custom_logic_desc,
			 GETDATE(),
			 '9999-12-31',
			 ORIGINAL_LOGIN(),
			 SYSDATETIME()
          )
	end
	else
		print 'Entry already exists for ' + @extraction_custom_logic_code
	if @trancount = 0
            commit;
end try

begin catch
        declare @error int, @message varchar(4000), @xstate int;
        select @error = ERROR_NUMBER(), @message = ERROR_MESSAGE(), @xstate = XACT_STATE();
        if @xstate = -1
            rollback;
        if @xstate = 1 and @trancount = 0
            rollback
        if @xstate = 1 and @trancount > 0
            rollback transaction sp_add_extraction_custom_logic;

        raiserror ('Ctlfwk.sp_add_extraction_custom_logic: %d: %s', 16, 1, @error, @message) ;
    end catch


END

