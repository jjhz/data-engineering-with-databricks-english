CREATE PROCEDURE [Ctlfwk].[sp_get_pii_column_list]
( 
  @object_name VARCHAR(100),
  @app_name varchar(100)
)
AS

SET NOCOUNT ON
SET XACT_ABORT ON

BEGIN TRY 
    DECLARE 
        @ret_status             VARCHAR(100),
        @ret_message            VARCHAR(100),
        @object_id              INT,
        @source_app_id          INT

        /* Error Condition 1 - If Object name is not provided or NULL*/
        IF (@object_name IS NULL OR @object_name = '')
        BEGIN
            SET @ret_status ='ERROR'
            SET @ret_message ='ERROR - Object Name name not provided.'
            (SELECT @object_name AS Object_Name, 
                        @app_name as App_Name, 
                        @ret_status AS Return_Status,
                        @ret_message AS Return_Message)
            RAISERROR(@ret_message ,16,-1)
            return -1
        END
            
        /* Error Condition 1 - If Application name Name is not provided or NULL*/
        IF (@app_name IS NULL OR @app_name = '')
        BEGIN
            SET @ret_status ='ERROR'
            SET @ret_message ='ERROR - Application Name name not provided.'
            (SELECT @object_name AS Object_Name, 
                    @app_name as App_Name, 
                    @ret_status AS Return_Status,
                    @ret_message AS Return_Message)
            RAISERROR(@ret_message ,16,-1)
            return -1
        END
        
        /* Fetch Stream_ID From Stream view*/
        SELECT @object_id = source_object_id FROM [Ctlfwk].[source_objects] where source_object_name = @object_name
        IF (@object_id IS NULL OR @object_id = '')
        BEGIN
            SET @ret_status ='ERROR'
            SET @ret_message ='ERROR - Object name is incorrect.'
            (SELECT @object_name AS Object_Name, 
                    @app_name as App_Name, 
                    @ret_status AS Return_Status,
                    @ret_message AS Return_Message)
            RAISERROR(@ret_message ,16,-1)
            return -1
        END
        
        SELECT @source_app_id = source_app_id FROM [Ctlfwk].[source_app] where source_app_name = @app_name
        IF (@source_app_id IS NULL OR @source_app_id = '')
        BEGIN
            SET @ret_status ='ERROR'
            SET @ret_message ='ERROR - App name is incorrect.'
            (SELECT @object_name AS Object_Name, 
                    @app_name as App_Name, 
                    @ret_status AS Return_Status,
                    @ret_message AS Return_Message)
            RAISERROR(@ret_message ,16,-1)
            return -1
        END

        select [source_object_attribute_name] from [Ctlfwk].[source_objects_attributes]
        where source_object_id = (select source_object_id from [Ctlfwk].[source_objects] 
                                  where source_object_name = @object_name 
                                  and source_app_id = (select source_app_id from [Ctlfwk].[source_app] 
                                                       where source_app_name = @app_name))
        and [source_object_attribute_is_PII] = 'Y'

        
END TRY


BEGIN CATCH
    IF @@TRANCOUNT > 0
    ROLLBACK TRANSACTION

    DECLARE @ErrorNumber    INT             =   ERROR_NUMBER()
    DECLARE @ErrorMessage   NVARCHAR(4000)  =   ERROR_MESSAGE()
    DECLARE @ErrorProcedure NVARCHAR(4000)  =   ERROR_PROCEDURE()
    DECLARE @ErrorLine      INT             =   ERROR_LINE()
    
    RAISERROR   (   @ret_message,
                    16,
                    1,
                    @ErrorNumber,
                    @ErrorMessage,
                    @ErrorProcedure,
                    @ErrorLine
                );

    RETURN -1;
END CATCH;
