﻿

CREATE PROCEDURE [Ctlfwk].[sp_get_isfilemandatory]
( 
   @source_app_name	VARCHAR(100) NULL,
   @object_name     varchar(100) NULL
)
AS

SET NOCOUNT ON
SET XACT_ABORT ON

BEGIN TRY

	SET NOCOUNT ON

	DECLARE 
		@error_flag		        VARCHAR(100),
		@error_message	        VARCHAR(100),
        @source_app_count       INT,
        @source_object_count    INT

   	SELECT @source_app_count = count(*) FROM ctlfwk.source_app WHERE source_app_name = @source_app_name
    SELECT @source_object_count = count(*) FROM ctlfwk.source_objects WHERE Source_Object_Name = @object_name

    IF @source_app_count <= 0
        BEGIN
            select NULL as Source_App_Name, NULL as Source_Object_Name, NULL as is_file_mandatory, 
            'ERROR' as Error_Flag, 'ERROR - Source app name incorrect' as Error_Message
        RAISERROR('ERROR - Source app name incorrect.' ,16,-1)
        END

    IF @source_object_count <= 0
        BEGIN
            select NULL as Source_App_Name, NULL as Source_Object_Name, NULL as is_file_mandatory, 
            'ERROR' as Error_Flag, 'ERROR - Object name incorrect' as Error_Message
            RAISERROR('ERROR - Source object name incorrect.' ,16,-1)
        END

	SELECT sa.source_app_name, so.source_object_name,so.is_file_mandatory,
        'SUCCESS' as Error_Flag, 'SUCCESS' as Error_Message FROM [Ctlfwk].[source_objects] so
		INNER JOIN [Ctlfwk].[source_app] sa
		ON so.source_app_id = sa.source_app_id
		WHERE source_object_name = @object_name AND source_app_name = @source_app_name

END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION

	DECLARE @ErrorNumber	INT				=	ERROR_NUMBER()
	DECLARE @ErrorMessage	NVARCHAR(4000)	=	ERROR_MESSAGE()
	DECLARE @ErrorProcedure	NVARCHAR(4000)	=	ERROR_PROCEDURE()
	DECLARE @ErrorLine		INT				=	ERROR_LINE()
	
	RAISERROR	('Exception Details :
					Error Number		:	%d
					Error Message		:	%d
					Affected Procedure	:	%d
					Affected Line Number:	%d',
					16,
					1,
					@ErrorNumber,
					@ErrorMessage,
					@ErrorProcedure,
					@ErrorLine
				);

	RETURN -1;
END CATCH;


GO


