﻿/*
The following is the main post deployment script.

Note:
- Scripts are executed first below for shared tables.
- Individual source app based scripts are in separate script files using
  name convention PostDeployment_<source app name>
- The individual source app scripts are executed in order after the shared table
  scripts in this table

*/

/* Shared Reference Tables */

/*Encryption_Types*/

EXEC [ctlfwk].[sp_add_Encryption_Types] @Encryption_Type = 'DET', @Encryption_Name = 'Deterministic Encryption';
EXEC [ctlfwk].[sp_add_Encryption_Types] @Encryption_Type = 'NDET', @Encryption_Name = 'Non-Deterministic Encryption';

/* Load Types */
exec [ctlfwk].[sp_add_load_types] @load_type_code = 'F', @load_type_description = 'Full Load';
exec [ctlfwk].[sp_add_load_types] @load_type_code = 'D', @load_type_description = 'Delta Load';
exec [ctlfwk].[sp_add_load_types] @load_type_code = 'I', @load_type_description = 'Insert Only Load';
exec [ctlfwk].[sp_add_load_types] @load_type_code = 'T', @load_type_description = 'Truncate and Load';
exec [ctlfwk].[sp_add_load_types] @load_type_code = 'IUD', @load_type_description = 'Insert Update Delete';
/*This is required only when  you want to load Reference data ausing the patterns  */ --28-02-2022
exec [ctlfwk].[sp_add_load_types] @load_type_code = 'R', @load_type_description = 'Reference Data Load';
/*Insert Overwrite for Silver to Platinum IOT objects  */ --10-02-2023
exec [ctlfwk].[sp_add_load_types] @load_type_code='IO', @load_type_description='Insert Overwrite Load'
 
 --=================================================Execution Status========================
 
/* Execution Status */
exec [ctlfwk].[sp_add_execution_status] @execution_status_name = 'Running';
exec [ctlfwk].[sp_add_execution_status] @execution_status_name = 'Success';
exec [ctlfwk].[sp_add_execution_status] @execution_status_name = 'Failed';
exec [ctlfwk].[sp_add_execution_status] @execution_status_name = 'Cancelled';
exec [ctlfwk].[sp_add_execution_status] @execution_status_name = 'Restart';
 --=================================================Process Type========================
/* Process Type */
-- Refer the guidlines and execute the Relevant  Process based on your requirement 
/* These processes are used to ingest incoming files into Broze and Silver layer using Azure Databricks */
Exec [ctlfwk].[sp_add_process_type]  @process_type = 'Bronze'
Exec [ctlfwk].[sp_add_process_type]  @process_type = 'Silver'
-- This is required if any preprocessing of files has to happen before loading data into First Layer
exec [Ctlfwk].[sp_add_process_type] @process_type = 'PreProcess'; 
-- This is required if you want to use Extraction from Sources using the Patterns 
exec [ctlfwk].[sp_add_process_type] @process_type = 'Extract';
-- To Process Gold Layer in Databricks 
exec [ctlfwk].[sp_add_process_type] @process_type = 'Gold';
-- To Process Gold Layer from Databricks to Synapse 
exec [ctlfwk].[sp_add_process_type] @process_type = 'Gold_Replication';
-- To Process Reference Data  in Databricks 
exec [ctlfwk].[sp_add_process_type] @process_type = 'Reference';

 --================================================= Business Unit Configuration========================
 -- If Managed Identity is used , the storage Account Variable can be updated as NULL 
/* Business Unit Configuration */
-- storage account to change to build variable for diff env at release: $(storage_account_<bu code>) e.g. @storage_account = $(storage_account_hi)  N'$(storage_account)'
exec [ctlfwk].[sp_add_business_unit] @business_unit_name = 'South East Water',	@business_unit_name_code = 'SEW', @storage_account = N'$(storage_account)', @storage_secret_name = NULL;
--exec [ctlfwk].[sp_add_business_unit] @business_unit_name = 'Common System',	@business_unit_name_code = 'common', @storage_account = N'$(common_storage_account)', @storage_secret_name = N'$(common_storage_secret)';
 --================================================= SourceSystemToSparkDataTypeMapping========================
--New enhancements 03-12-2021
/* SourceSystemToSparkDataTypeMapping Strategic changes*/
/* SourceSystemDatabaseName Strategic changes*/
EXEC [Ctlfwk].[sp_add_SourceSystemDatabaseName] @SourceSystemDatabaseName = 'ORACLE';
EXEC [Ctlfwk].[sp_add_SourceSystemDatabaseName] @SourceSystemDatabaseName = 'SQLSERVER';
EXEC [Ctlfwk].[sp_add_SourceSystemDatabaseName] @SourceSystemDatabaseName = 'OTHER';
EXEC [Ctlfwk].[sp_add_SourceSystemDatabaseName] @SourceSystemDatabaseName = 'SCADA';

EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'VARCHAR2', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'NVARCHAR2', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'NUMBER', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'FLOAT', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'LONG', @SparkSQLDatatype = 'BIGINT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'DATE', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'BINARY_FLOAT', @SparkSQLDatatype = 'FLOAT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'BINARY_DOUBLE', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'TIMESTAMP', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'TIMESTAMPWITHTIMEZONE', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'Y';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'TIMESTAMPWITHLOCALTIMEZONE', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'Y';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'RAW', @SparkSQLDatatype = NULL, @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'LONGRAW', @SparkSQLDatatype = NULL, @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'ROWID', @SparkSQLDatatype = NULL, @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'UROWID', @SparkSQLDatatype = NULL, @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'CHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'NCHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'CLOB', @SparkSQLDatatype = NULL, @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'NCLOB', @SparkSQLDatatype = NULL, @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'BLOB', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'FILE', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'VARCHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'INT', @SparkSQLDatatype = 'INT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'DATETIME', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'DECIMAL', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'XML', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'ORACLE', @DataType = 'SDO_GEOMETRY', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N'; 
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'CHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'NVARCHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'VARCHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'TEXT', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'NCHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'NTEXT', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'BINARY', @SparkSQLDatatype = 'BINARY', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'VARBINARY', @SparkSQLDatatype = 'BINARY', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'IMAGE', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'BIGINT', @SparkSQLDatatype = 'BIGINT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'NUMERIC', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'BIT', @SparkSQLDatatype = 'BOOLEAN', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'SMALLINT', @SparkSQLDatatype = 'SMALLINT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'DECIMAL', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'SMALLMONEY', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'INT', @SparkSQLDatatype = 'INT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'TINYINT', @SparkSQLDatatype = 'TINYINT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'MONEY', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'FLOAT', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'REAL', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'DATE', @SparkSQLDatatype = 'DATE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'DATETIME', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'TIME', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'DATETIME2', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'SMALLDATETIME', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'DATETIMEOFFSET', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'Y';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'UNIQUEIDENTIFIER', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'TIMESTAMP', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
--added 07-11-22
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SQLSERVER', @DataType = 'XML', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
--
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'STRING', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'NUMBER', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'DECIMAL', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'DATE', @SparkSQLDatatype = 'DATE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'DATETIME', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'DATETIME2', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'VARCHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'VARCHAR2', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'DATETIMEOFFSET', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'Y';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'INTEGER', @SparkSQLDatatype = 'INT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'CHAR', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'UNIQUEIDENTIFIER', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'TIMESTAMP', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone = 'N';
 --Added on 09-02-2022
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'INT', @SparkSQLDatatype = 'INT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'BIGINT', @SparkSQLDatatype = 'BIGINT', @IsDateWithTimezone = 'N';
--14-04-2022
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'ENUM', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'INT64', @SparkSQLDatatype = 'BIGINT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'INT32', @SparkSQLDatatype = 'INT', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'BOOLEAN', @SparkSQLDatatype = 'BOOLEAN', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'TIME', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone = 'N';

--16-01-2023
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'LONG', @SparkSQLDatatype = 'BIGINT',@IsDateWithTimezone = 'N'
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'DOUBLE', @SparkSQLDatatype = 'DOUBLE', @IsDateWithTimezone = 'N';
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'OTHER', @DataType = 'SMALLINT', @SparkSQLDatatype = 'SMALLINT', @IsDateWithTimezone = 'N'

--01-02-2023
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SCADA', @DataType = 'STRING', @SparkSQLDatatype = 'STRING', @IsDateWithTimezone ='N' 
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SCADA', @DataType = 'REAL', @SparkSQLDatatype = 'DECIMAL', @IsDateWithTimezone ='N' 
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SCADA', @DataType = 'INT', @SparkSQLDatatype = 'INT', @IsDateWithTimezone ='N' 
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SCADA', @DataType = 'DATETIME', @SparkSQLDatatype = 'TIMESTAMP', @IsDateWithTimezone ='N' 
EXEC [ctlfwk].[sp_add_SourceSystemToSparkDataTypeMapping] @DataSource = 'SCADA', @DataType = 'BOOL', @SparkSQLDatatype = 'BOOLEAN', @IsDateWithTimezone ='N'
 
--10-Nov-22 ===============IUD_Config_Types=========================

EXEC [ctlfwk].[sp_add_IUD_config_types] @config_type = N'default', @config_type_description = N'Default IUD Values - I U D';

EXEC [ctlfwk].[sp_add_IUD_config_types] @config_type = N'SQL', @config_type_description = N'SQL with CDC enabled - 1 2 4';

--10-Nov-22 =============Source_IUD_Mapping========================
EXEC [ctlfwk].[sp_add_Source_IUD_Mapping] @config_type = 'default',	@record_type_name = 'I', @source_CDC_record_type_value = 'I';
EXEC [ctlfwk].[sp_add_Source_IUD_Mapping] @config_type = 'default',	@record_type_name = 'U', @source_CDC_record_type_value = 'U';
EXEC [ctlfwk].[sp_add_Source_IUD_Mapping] @config_type = 'default',	@record_type_name = 'D', @source_CDC_record_type_value = 'D';


EXEC [ctlfwk].[sp_add_Source_IUD_Mapping] @config_type = 'SQL',	@record_type_name = 'I', @source_CDC_record_type_value = '2';
EXEC [ctlfwk].[sp_add_Source_IUD_Mapping] @config_type = 'SQL',	@record_type_name = 'U', @source_CDC_record_type_value = '4';
EXEC [ctlfwk].[sp_add_Source_IUD_Mapping] @config_type = 'SQL',	@record_type_name = 'D', @source_CDC_record_type_value = '1';

--01-DEC-22 =============Extraction_Custom_Logic========================
EXEC [ctlfwk].[sp_add_extraction_custom_logic] @extraction_custom_logic_code = 'extract_year',@extraction_custom_logic_desc = 'Extract year from dob column';
EXEC [ctlfwk].[sp_add_extraction_custom_logic] @extraction_custom_logic_code = 'check_null',@extraction_custom_logic_desc = 'Check if there is value in source colummn';

 --================================================= PoolConfigurationDetails========================
/*  If you are configuring Job clusters you can use Memory_optimised Config shown as below  */
--exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'default_pool', @PoolId = '0303-064405-hows31-pool-8r6lhva0' , @cluster_type ='Job';  
-- The below configuration is pointing to std cluster of ITS  
Exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'Interactive', @PoolId = N'$(cluster_id)', @cluster_type ='Interactive';
--exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'Operational_Cluster', @PoolId = N'$(Interactive_Cluster_Id)', @cluster_type ='Interactive'; N'1111-034240-64h60rpk
/*  If you are configuring Job clusters you can use Memory_optimised Config shown as below  */
--exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'memory_optimised', @PoolId = '1216-003656-tell235-pool-gj3opcpl';  
--exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'memory_optimised_8', @PoolId = '1221-052459-tunas793-pool-khgpp6zc';  
--exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'memory_optimised_16', @PoolId = '1221-052524-rises794-pool-i1orw1w8';  
--exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'memory_optimised_32', @PoolId = '1221-052547-laced795-pool-xwjluhkl';  
--exec [Ctlfwk].[sp_add_PoolConfigurationDetails] @PoolName = 'memory_optimised_64', @PoolId = '1221-052614-force796-pool-o1fr1qqg';   



-- Execs to add RBAC Code to RBAC Master Table
EXEC [ctlfwk].[sp_add_RBAC_Code] 'AD-Acumen-Finance-Sensitive', 'AD-Acumen-Finance-Sensitive'
EXEC [ctlfwk].[sp_add_RBAC_Code] 'AD-Acumen-Corporate-Sensitive', 'AD-Acumen-Corporate-Sensitive'
EXEC [ctlfwk].[sp_add_RBAC_Code] 'AD-Acumen-Customer-Sensitive', 'AD-Acumen-Customer-Sensitive'
EXEC [ctlfwk].[sp_add_RBAC_Code] 'AD-Acumen-Employee-Sensitive', 'AD-Acumen-Employee-Sensitive'
EXEC [ctlfwk].[sp_add_RBAC_Code] 'AD-Acumen-AllOtherSubArea-Sensitive', 'AD-Acumen-AllOtherSubArea-Sensitive'


/*Ingestion Post Deployment */
 :r .\Utility_Scripts_ICE.sql
 :r .\Utility_Scripts_Maximo.sql
 :r .\Utility_Scripts_Montage.sql
 :r .\Utility_Scripts_IoT.sql
 :r .\Utility_Scripts_GIS.sql
 :r .\Utility_Scripts_BOM.sql
 :r .\RBAC_Mapping.sql
 :r .\Utility_Scripts_SCADA.sql