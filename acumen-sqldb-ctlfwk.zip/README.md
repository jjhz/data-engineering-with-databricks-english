# Introduction 
This Repo has the code for CtlFwk Database Deployment 
* It has a PostDeployment which has statements to be executed in ctlfwk database 

Type   | EXEC Command 
------------- | -------------
Encryption Type  | sp_add_Encryption_Types
Load Type  | sp_add_load_types
Execution Status  | sp_add_execution_status
Process Type   | sp_add_process_type
SourceSystemDatabase | sp_add_SourceSystemDatabaseName
DataTypeMapping   | sp_add_SourceSystemToSparkDataTypeMapping
PoolConfigurationDetails   | sp_add_PoolConfigurationDetails
BusinessUnit   | sp_add_business_unit

   
## 1.Encryption Type Configuration-Supported Encryption Types are added in to Ctlfwk using the EXEC Code in Post Deployment Script 
## 2.Load Types-Supported Pattern Load Types are added in to Ctlfwk using the EXEC Code in Post Deployment Script 
## 3.Execution Status-Supported Pattern Execution Status are added in to Ctlfwk using the EXEC Code in Post Deployment Script 
## 4.Process Type-Supported Pattern Process Type are added in to Ctlfwk using the EXEC Code in Post Deployment Script
## 5.SourceSystemDatabaseName-Supported SourceSystemDatabase and Spark Data Type Mapping are added in to Ctlfwk using the EXEC Code in Post Deployment Script
## 6.PoolConfigurationDetails- Pattern supports usage of Following Databricks Clusters 
   1. Memory Optmised Multi Worker Job Clusters  (NoofWorkers >=1)
   2. Memory Optmised Single Node  Job Clusters  (NoofWorkers= 0)
   3. Standard/Interactive Clusters (NoofWorkers NULL)
   ### Based on your requirement you can configure them using the PoolConfiguration in to Ctlfwk using the EXEC Code in Post Deployment Script 
   (Note : The PoolId is parameterised so that in higher environments the corresponding values can be passed and updated in ctlfwk table )
## 7.BusinessUnit- BusinessUnit defined by the client  are added in to Ctlfwk using the EXEC Code in Post Deployment Script 
   (Note : The Storage Name and Secret are parameterised so that in higher environments the corresponding values can be passed and updated in ctlfwk table 
           If Managed Identity is used to configure instead of using secrets , the ADLS Secret can be left as NULL) 


